#input 
public static string GetFullPath (string fileName) {
    if (File.Exists (fileName))
        return Path.GetFullPath (fileName);
    var values = Environment.GetEnvironmentVariable ("PATH");
    foreach (var path in values.Split (';')) {
        var fullPath = Path.Combine (path, fileName);
        if (File.Exists (fullPath))
            return fullPath;
    }
    return null;
}


#====================
#gpt output=============
Java Code:

import java.nio.file.*;
import java.util.*;

public static String getFullPath(String fileName) {
    Path filePath = Paths.get(fileName);
    if (Files.exists(filePath)) {
        return filePath.toAbsolutePath().toString();
    }
    String pathValues = System.getenv("PATH");
    List<String> paths = new ArrayList<>(Arrays.asList(pathValues.split(";")));
    for (String path : paths) {
        Path fullPath = Paths.get(path, fileName);
        if (Files.exists(fullPath)) {
            return fullPath.toString();
        }
    }
    return null;
}

C Code:

#include <stdlib.h>
#include <string.h>
#include <unistd.h>

char* getFullPath(char* fileName) {
    if(access(fileName, F_OK) != -1) {
        char* fullPath = realpath(fileName, NULL);
        return fullPath;
    }
    char* pathValues = getenv("PATH");
    char* path = strtok(pathValues, ";");
    while (path != NULL) {
        char fullPath[4096];
        snprintf(fullPath, sizeof(fullPath), "%s/%s", path, fileName);
        if(access(fullPath, F_OK) != -1) {
            return strdup(fullPath);
        }
        path = strtok(NULL, ";");
    }
    return NULL;
}

Python Code:

import os

def get_full_path(file_name):
    if os.path.exists(file_name):
        return os.path.abspath(file_name)
    path_values = os.environ["PATH"].split(";")
    for path in path_values:
        full_path = os.path.join(path, file_name)
        if os.path.exists(full_path):
            return full_path
    return None