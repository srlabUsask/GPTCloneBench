#input 
protected override void OnMouseMove (MouseEventArgs e) {
    if (e.Button == MouseButtons.Left) {
        rec.Width = e.X - rec.X;
        rec.Height = e.Y - rec.Y;
    } else if (e.Button == MouseButtons.Right) {
        rec.X = e.X - MouseDownLocation.X;
        rec.Y = e.Y - MouseDownLocation.Y;
    }
}


#====================
#gpt output=============
- Java 

```java
@Override
public void mouseMoved(MouseEvent e) {
    if (SwingUtilities.isLeftMouseButton(e)) {
        rec.width = e.getX() - rec.x;
        rec.height = e.getY() - rec.y;
    } else if (SwingUtilities.isRightMouseButton(e)) {
        rec.x = e.getX() - MouseDownLocation.x;
        rec.y = e.getY() - MouseDownLocation.y;
    }
}
```

- C 

C doesn't have built-in Mouse events. You should use some libraries for that. Here is an example using WinAPI:

```c
switch (message) {
    case WM_MOUSEMOVE: {
        if (wParam & MK_LBUTTON) {
            rec.right = LOWORD(lParam) - rec.left;
            rec.bottom = HIWORD(lParam) - rec.top;
        }
        else if (wParam & MK_RBUTTON) {
            rec.left = LOWORD(lParam) - MouseDownLocation.x;
            rec.top = HIWORD(lParam) - MouseDownLocation.y;
        }
        break;
    }
}
```

- Python 

Python also doesn't have native support for Mouse events. You could use a library like Tkinter:

```python
from tkinter import *

root = Tk()

def mouse_move(event):
    if event.state == 0x0100:    # Check if left button is down
        rec.width = event.x - rec.x
        rec.height = event.y - rec.y
    elif event.state == 0x0200:  # Check if right button is down
        rec.x = event.x - MouseDownLocation.x
        rec.y = event.y - MouseDownLocation.y

root.bind("<B1-Motion>", mouse_move)
root.bind("<B3-Motion>", mouse_move)

root.mainloop()
``` 

Keep in mind that some of the variables used haven't been declared in these snippets. Also, these are basic implementations, handling only the part equivalent to the provided code. The libraries used may require other configuration.
