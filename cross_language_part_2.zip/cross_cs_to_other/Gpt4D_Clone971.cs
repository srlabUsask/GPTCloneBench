#input 
private int CountOccurrences (string TestString, string TestPattern) {
    int PatternCount = 0;
    int SearchIndex = 0;
    if (TestPattern.Length == 0)
        throw new ApplicationException ("CountOccurrences: Unable to process because TestPattern has zero length.");
    if (TestString.Length == 0)
        return 0;
    do
        {
            SearchIndex = TestString.IndexOf (TestPattern, SearchIndex);
            if (SearchIndex >= 0) {
                ++ PatternCount;
                SearchIndex += TestPattern.Length;
            }
        } while ((SearchIndex >= 0) && (SearchIndex < TestString.Length));
    return PatternCount;
}


#====================
#gpt output=============
Java:

```
private int countOccurrences(String testString, String testPattern) {
    int patternCount = 0;
    int searchIndex = 0;
    if (testPattern.length() == 0)
        throw new IllegalArgumentException("CountOccurrences: Unable to process because TestPattern has zero length.");
    if (testString.length() == 0)
        return 0;
    do {
        searchIndex = testString.indexOf(testPattern, searchIndex);
        if (searchIndex >= 0) {
            patternCount++;
            searchIndex += testPattern.length();
        }
    } while (searchIndex >= 0 && searchIndex < testString.length());
    return patternCount;
}
```

C:

```c
#include <string.h>
#include <stdlib.h>

int countOccurrences(char *testString, char *testPattern) {
    int patternCount = 0;
    char *searchIndex = testString;
    if (strlen(testPattern) == 0)
        exit(EXIT_FAILURE);
    if (strlen(testString) == 0)
        return 0;
    do {
        searchIndex = strstr(searchIndex, testPattern);
        if (searchIndex != NULL) {
            patternCount++;
            searchIndex += strlen(testPattern);
        }
    } while (searchIndex != NULL && searchIndex < (testString + strlen(testString)));
    return patternCount;
}
```

Python:

```python
def count_occurrences(test_string, test_pattern):
    pattern_count = 0
    search_index = 0
    if len(test_pattern) == 0:
        raise ValueError('CountOccurrences: Unable to process because TestPattern has zero length.')
    if len(test_string) == 0:
        return 0
    while True:
        search_index = test_string.find(test_pattern, search_index)
        if search_index >= 0:
            pattern_count += 1
            search_index += len(test_pattern)
        else:
            break
    return pattern_count
```