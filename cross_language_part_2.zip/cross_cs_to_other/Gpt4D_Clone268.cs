#input 
static void Main () {
    HiResTimer timer = new HiResTimer ();
    Int64 counterAtStart = timer.Value;
    for (int count = 0; count < 10000; count ++) {
        count ++;
        count --;
    }
    Int64 counterAtEnd = timer.Value;
    Int64 timeElapsedInTicks = counterAtEnd - counterAtStart;
    Int64 timeElapseInTenthsOfMilliseconds = (timeElapsedInTicks * 10000) / timer.Frequency;
    MessageBox.Show ("Time Spent in operation (tenths of ms) " + timeElapseInTenthsOfMilliseconds + "\nCounter Value At Start: " + counterAtStart + "\nCounter Value At End : " + counterAtEnd + "\nCounter Frequency : " + timer.Frequency);
}


#====================
#gpt output=============
Java implementation:

```java
public static void main(String[] args) {
    long counterAtStart = System.nanoTime();
    for (int count = 0; count < 10000; count++) {
        count++;
        count--;
    }
    long counterAtEnd = System.nanoTime();
    long timeElapsedInTicks = counterAtEnd - counterAtStart;
    long timeElapseInTenthsOfMilliseconds = (timeElapsedInTicks * 10000) / 1000000;
    System.out.println("Time Spent in operation (tenths of ms) " + timeElapseInTenthsOfMilliseconds + "\nCounter Value At Start: " + counterAtStart + "\nCounter Value At End : " + counterAtEnd + "\nCounter Frequency : " + 1000000);
}
```

Python implementation:

```python
import time

counter_start=time.perf_counter()
for count in range(10000):
    count+=1
    count-=1
counter_end = time.perf_counter()
time_elapsed_ticks=counter_end-counter_start
time_elapsed_tenth_millisec = (time_elapsed_ticks * 10000) 
print("Time Spent in operation (tenths of ms) ",time_elapsed_tenth_millisec, "\nCounter Value At Start: ", 
counter_start, "\nCounter Value At End : ", counter_end)
```

C implementation:

```C
#include <stdio.h>
#include <time.h>

int main() {
    clock_t counterAtStart = clock();
    for (int count = 0; count < 10000; count ++) {
        count ++;
        count --;
    }
    clock_t counterAtEnd = clock();
    const long double cpu_time = (long double)(counterAtEnd - counterAtStart)/CLOCKS_PER_SEC;
    long double timeElapsedInTicks = cpu_time * 1000000;
    long double timeElapseInTenthsOfMilliseconds = (timeElapsedInTicks * 10000) / CLOCKS_PER_SEC;
    printf("Time Spent in operation (tenths of ms) %.2Lf;\nCounter Value At Start: %ld;\nCounter Value At End : %ld;\nCounter Frequency : %d;\n", timeElapseInTenthsOfMilliseconds, (long)counterAtStart, (long)counterAtEnd, CLOCKS_PER_SEC);
    return 0;
}
```