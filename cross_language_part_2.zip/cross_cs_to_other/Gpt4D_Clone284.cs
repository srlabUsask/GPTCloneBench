#input 
public void fromAdmin (Message message, SessionID id) {
    var logon = message as QuickFix44.Logon;
    if (logon != null) {
        string userName = logon.getUserName ().getValue ();
        string expectedPassword = PasswordsByUser [userName];
        string suppliedPassword = logon.getPassword ().getValue ();
        if (expectedPassword != suppliedPassword) {
            Message _logoutmess = new Message ();
            _logoutmess.Header.SetField (new MsgType () {Tag = 35, Obj = "5"});
            _logoutmess.SetField (new Text ("Invalid credentials"));
            Session.SendToTarget (_logoutmess, id);
        }
    }
}


#====================
#gpt output=============
Java Implementation:

public void fromAdmin(Message message, SessionID id) {
    try {
        if (message instanceof quickfix.fix44.Logon) {
            quickfix.fix44.Logon logon = (quickfix.fix44.Logon) message;
            String userName = logon.getnew quickfix.fields.Username().getValue();
            String expectedPassword = PasswordsByUser.get(userName);
            String suppliedPassword =  logon.getnew quickfix.fields.Password().getValue();
            if (!expectedPassword.equals(suppliedPassword)) {
                Message logoutMessage = new Message();
                logoutMessage.getHeader().setField(new MsgType("5"));
                logoutMessage.setField(new Text("Invalid credentials"));
                Session.sendToTarget(logoutMessage, id);
            }
        }
    } catch (FieldNotFound e) {
        e.printStackTrace();
    }
}



C Implementation:

void fromAdmin(Message *message, SessionID id) {
    Logon* logon = dynamic_cast<Logon*>(message);
    if (logon != nullptr) {
        char* userName = logon->getUserName();
        char* expectedPassword = PasswordsByUser[userName];
        char* suppliedPassword = logon->getPassword();
        if (strcmp(expectedPassword, suppliedPassword) != 0) {
            Message* logoutMessage = new Message();
            logoutMessage->header.SetField(35, "5");
            logoutMessage->SetField("Invalid credentials");
            Session_SendToTarget(logoutMessage, id);
        }
    }
}


Python Implementation:

def fromAdmin(self, message, id):
    logon = message
    if isinstance(logon, Quickfix44.Logon):
        userName = logon.getUserName().getValue()
        expectedPassword = PasswordsByUser[userName]
        suppliedPassword = logon.getPassword().getValue()
        if expectedPassword != suppliedPassword:
            logoutMessage = Message()
            logoutMessage.Header.SetField(MsgType(35, "5"))
            logoutMessage.SetField(Text("Invalid credentials"))
            Session.SendToTarget(logoutMessage, id)