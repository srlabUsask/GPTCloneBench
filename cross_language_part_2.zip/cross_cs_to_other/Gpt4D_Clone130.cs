#input 
static void Main (string [] args) {
    var first = new List < double > {1, 2, 3};
    var second = new List < double > {3, 4, 5};
    var lists = new List < List < double > > {first, second};
    var flatten = lists.SelectMany (a = > a).ToArray ();
    foreach (var i in flatten) {
        Console.WriteLine (i);
    }
}


#====================
#gpt output=============
Java:

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        ArrayList<Double> first = new ArrayList<>(Arrays.asList(1.0, 2.0, 3.0));
        ArrayList<Double> second = new ArrayList<>(Arrays.asList(3.0, 4.0, 5.0));
        ArrayList<ArrayList<Double>> lists = new ArrayList<>();
        lists.add(first);
        lists.add(second);
        ArrayList<Double> flatten = new ArrayList<>();
        for(ArrayList<Double> list : lists) {
            flatten.addAll(list);
        }
        for(double i : flatten) {
            System.out.println(i);
        }
    }
}

Python:

first = [1, 2, 3]
second = [3, 4, 5]
lists = [first, second]
flatten = [item for sublist in lists for item in sublist]
for i in flatten:
    print(i)

C:

// C does not natively support list or List of List.
// We need a different approach or use a library to create same feature in C.

#include<stdio.h>

int main() {
    double first[] = {1.0, 2.0, 3.0};
    double second[] = {3.0, 4.0, 5.0};
    int size_first = sizeof(first)/sizeof(double);
    int size_second = sizeof(second)/sizeof(double);
    double flatten[size_first + size_second];
    int i=0,j=0;

    for(i=0; i<size_first; i++)
       flatten[i] = first[i];

    for(j=0; j<size_second; j++)
        flatten[i+j] = second[j];

    for(i=0; i<sizeof(flatten)/sizeof(double); i++)
        printf("%lf \n", flatten[i]);

    return 0;
}
