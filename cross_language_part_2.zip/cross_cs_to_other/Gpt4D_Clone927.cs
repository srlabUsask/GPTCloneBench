#input 
private static void SanitizeNode (HtmlNode node) {
    if (node.NodeType == HtmlNodeType.Element) {
        if (! Whitelist.ContainsKey (node.Name)) {
            if (! DeletableNodesXpath.Contains (node.Name)) {
                node.Name = "removeableNode";
                DeletableNodesXpath.Add (node.Name);
            }
            if (node.HasChildNodes) {
                SanitizeChildren (node);
            }
            return;
        }
        if (node.HasAttributes) {
            for (int i = node.Attributes.Count - 1; i >= 0; i --) {
                HtmlAttribute currentAttribute = node.Attributes [i];
                string [] allowedAttributes = Whitelist [node.Name];
                if (allowedAttributes != null) {
                    if (! allowedAttributes.Contains (currentAttribute.Name)) {
                        node.Attributes.Remove (currentAttribute);
                    }
                } else {
                    node.Attributes.Remove (currentAttribute);
                }
            }
        }
    }
    if (node.HasChildNodes) {
        SanitizeChildren (node);
    }
}


#====================
#gpt output=============
Java Implementation:

```java
private static void sanitizeNode(Node node) {
    if (node.getNodeType() == Node.ELEMENT_NODE) {
        if (!Whitelist.containsKey(node.getNodeName())) {
            if (!DeletableNodesXpath.contains(node.getNodeName())) {
                node.setNodeName("removableNode");
                DeletableNodesXpath.add(node.getNodeName());
            }
            if (node.hasChildNodes()) {
                sanitizeChildren(node);
            }
            return;
        }
        if (node.hasAttributes()) {
            NamedNodeMap attributes = node.getAttributes();
            for (int i = attributes.getLength() - 1; i >= 0; i--) {
                Node currentAttribute = attributes.item(i);
                String[] allowedAttributes = Whitelist.get(node.getNodeName());
                if (allowedAttributes != null) {
                    if (!Arrays.asList(allowedAttributes).contains(currentAttribute.getNodeName())) {
                        attributes.removeNamedItem(currentAttribute.getNodeName());
                    }
                } else {
                    attributes.removeNamedItem(currentAttribute.getNodeName());
                }
            }
        }
    }
    if (node.hasChildNodes()) {
        sanitizeChildren(node);
    }
}
```

C Implementation:

Assuming that we have a custom struct for HtmlNode, attributes and Whitelist. C does not support classes or objects, So the script is based on procedural programming and the functionality might not be the same as the original one.

```c
void sanitizeNode(HtmlNode *node) {
  if (node->nodeType == Element) {
    if (!hashmap_contains(&Whitelist, node->name)){
      if (!arraylist_contains(&DeletableNodesXpath, node->name)) {
        free(node->name);
        node->name = strdup("removableNode");
        arraylist_add(&DeletableNodesXpath, node->name);
      }
      if (node->childNodes->length > 0) {
        sanitizeChildren(node);
      }
      return;
    }
    if (node->attributes->length) {
      for (int i = node->attributes->length - 1; i >= 0; i--) {
        HtmlAttribute currentAttribute = node->attributes[i];
        char **allowedAttributes = hashmap_get(&Whitelist, node->name);
        if (allowedAttributes != NULL) {
          if (!contains(currentAttribute.name, allowedAttributes)) {
            removeAttribute(node, currentAttribute.name);
          }
        } else {
          removeAttribute(node, currentAttribute.name);
        }
      }
    }
  }
  if (node->childNodes->length > 0) {
    sanitizeChildren(node);
  }
}
```

Python Implementation:

```python
def sanitize_node(node):
    if node.NodeType == "Element":
        if node.Name not in Whitelist:
            if node.Name not in DeletableNodesXpath:
                node.Name = "removableNode"
                DeletableNodesXpath.append(node.Name)
            if node.HasChildNodes:
                sanitizeChildren(node)
            return
        if node.HasAttributes:
            i = len(node.Attributes) - 1
            while i >= 0:
                currentAttribute = node.Attributes[i]
                allowedAttributes = Whitelist[node.Name]
                if allowedAttributes is not None:
                    if currentAttribute.Name not in allowedAttributes:
                        del node.Attributes[i]
                else:
                    del node.Attributes[i]
                i -= 1
    if node.HasChildNodes:
        sanitizeChildren(node)
```
Note: Here, it assumes that HtmlNode, Whitelist, DeletableNodesXpath and sanitizeChildren are previously defined and associated with appropriate object and method.