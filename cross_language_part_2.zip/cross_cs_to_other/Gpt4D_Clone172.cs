#input 
internal static string GetIPAddress (HttpRequestBase request) {
    string forwarded = request.Headers ["Forwarded"];
    if (! String.IsNullOrEmpty (forwarded)) {
        foreach (string segment in forwarded.Split (',') [0].Split (';')) {
            string [] pair = segment.Trim ().Split ('=');
            if (pair.Length == 2 && pair [0].Equals ("for", StringComparison.OrdinalIgnoreCase)) {
                string ip = pair [1].Trim ('"');
                int left = ip.IndexOf ('['), right = ip.IndexOf (']');
                if (left == 0 && right > 0) {
                    return ip.Substring (1, right - 1);
                }
                int colon = ip.IndexOf (':');
                if (colon != - 1) {
                    return ip.Substring (0, colon);
                }
                return ip;
            }
        }
    }
    string xForwardedFor = request.Headers ["X-Forwarded-For"];
    if (! String.IsNullOrEmpty (xForwardedFor)) {
        return xForwardedFor.Split (',') [0];
    }
    return request.UserHostAddress;
}


#====================
#gpt output=============
```Java
import javax.servlet.http.HttpServletRequest;
// ...
public static String getIPAddress(HttpServletRequest request) {
    String forwarded = request.getHeader("Forwarded");
    if (forwarded != null && !forwarded.isEmpty()) {
        String[] segments = forwarded.split(",");
        for (String segment : segments[0].split(";")) {
            String[] pair = segment.trim().split("=");
            if (pair.length == 2 && pair[0].equalsIgnoreCase("for")) {
                String ip = pair[1].trim().replace("\"", "");
                int left = ip.indexOf("[");
                int right = ip.indexOf("]");
                if (left == 0 && right > 0) {
                    return ip.substring(1, right - 1);
                }
                int colon = ip.indexOf(":");
                if (colon != -1) {
                    return ip.substring(0, colon);
                }
                return ip;
            }
        }
    }
    String xForwardedFor = request.getHeader("X-Forwarded-For");
    if (xForwardedFor != null && !xForwardedFor.isEmpty()) {
        return xForwardedFor.split(",")[0];
    }
    return request.getRemoteAddr();
}
```

```C
// As C doesn't directly support HTTP requests, C-based solution isn't provided.
```

```Python
from flask import request
from werkzeug.datastructures import Headers

def get_ip_address(request):
    forwarded = request.headers.get('Forwarded')
    if forwarded:
        segments = forwarded.split(',')
        for segment in segments[0].split(';'):
            pair = segment.strip().split('=')
            if len(pair) == 2 and pair[0].lower() == 'for':
                ip = pair[1].strip().strip('"')
                left = ip.find('[')
                right = ip.find(']')
                if left == 0 and right > 0:
                    return ip[1:right]
                colon = ip.find(':')
                if colon != -1:
                    return ip[:colon]
                return ip
    x_forwarded_for = request.headers.get('X-Forwarded-For')
    if x_forwarded_for:
        return x_forwarded_for.split(',')[0]
    return request.remote_addr
```