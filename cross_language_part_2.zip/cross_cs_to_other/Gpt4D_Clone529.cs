#input 
static void Main (string [] args) {
    string stringtotal = "";
    string chartotal = "";
    Stopwatch stringconcat = new Stopwatch ();
    Stopwatch charconcat = new Stopwatch ();
    stringconcat.Start ();
    for (int i = 0; i < 100000; i ++) {
        stringtotal += ".";
    }
    stringconcat.Stop ();
    charconcat.Start ();
    for (int i = 0; i < 100000; i ++) {
        chartotal += '.';
    }
    charconcat.Stop ();
    Console.WriteLine ("String: " + stringconcat.Elapsed.ToString ());
    Console.WriteLine ("Char  : " + charconcat.Elapsed.ToString ());
    Console.ReadLine ();
}


#====================
#gpt output=============
Java:
```
import java.time.Duration;
import java.time.Instant;

public class Main {
    public static void main(String[] args) {
        StringBuilder stringTotal = new StringBuilder();
        StringBuilder charTotal = new StringBuilder();
        Instant start = Instant.now();
        for (int i = 0; i < 100000; i++) {
            stringTotal.append(".");
        }
        Instant finish = Instant.now();
        long timeElapsed = Duration.between(start, finish).toMillis();
        System.out.println("String: " + timeElapsed);
        start = Instant.now();
        for (int i = 0; i < 100000; i++) {
            charTotal.append('.');
        }
        finish = Instant.now();
        timeElapsed = Duration.between(start, finish).toMillis();
        System.out.println("Char  : " + timeElapsed);
    }
}
```

C:
```
#include<stdio.h>
#include<time.h>

int main() { 
    char stringTotal[100001] = "";
    char charTotal[100001] = "";
    clock_t start, end;
    start = clock();
    for (int i = 0; i < 100000; i++) {
        stringTotal[i] = '.';
    }
    end = clock();
    printf("String: %f\n", ((double) (end - start)) / CLOCKS_PER_SEC);
        start = clock();
    for (int i = 0; i < 100000; i++) {
        charTotal[i] = '.';
    }
    end = clock();
    printf("Char  : %f\n", ((double) (end - start)) / CLOCKS_PER_SEC);
    return 0;
}
```

Python:
```python
import time

def main():
    string_total = ""
    char_total = ""
    start = time.time()
    for i in range(100000):
        string_total += "."
    end = time.time()
    print("String: ", end - start)
    start = time.time()
    for i in range(100000):
        char_total += '.'
    end = time.time()
    print("Char  : ", end - start)

if __name__ == "__main__":
    main()
```