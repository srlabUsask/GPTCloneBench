#input 
static void Main () {
    int i, n;
    Console.WriteLine ("Enter the number of highest elements you want to extract from the array:");
    while (! int.TryParse (Console.ReadLine (), out n)) {
        Console.WriteLine ("Enter the number of highest elements you want to extract from the array:");
    }
    double [] arr = {12.1, 5.9, 2.9, 6.8, 20.5};
    if (n > arr.Length)
        n = arr.Length;
    double [] result = new double [n];
    double max = 0;
    int k;
    for (int j = 0; j < n; j ++) {
        max = arr [0];
        k = 0;
        for (i = 1; i < arr.Length; i ++) {
            if (max < arr [i]) {
                max = arr [i];
                k = i;
            }
        }
        result [j] = max;
        arr [k] = Double.MinValue;
        Console.WriteLine ("Highest numbers: {0}", result [j]);
    }
    Console.ReadKey ();
}


#====================
#gpt output=============
Java Implementation:

```java
import java.util.Scanner;

public class MainClass {
    public static void main(String[] args) {
        int i, n;
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the number of highest elements you want to extract from the array:");
        while (!input.hasNextInt()) {
            input.next();
        }
        n = input.nextInt();
        double[] arr = {12.1, 5.9, 2.9, 6.8, 20.5};
        if (n > arr.length)
            n = arr.length;
        double[] result = new double[n];
        double max;
        int k;
        for (int j = 0; j < n; j ++) {
            max = arr[0];
            k = 0;
            for (i = 1; i < arr.length; i++) {
                if (max < arr[i]) {
                    max = arr[i];
                    k = i;
                }
            }
            result[j] = max;
            arr[k] = Double.NEGATIVE_INFINITY;
            System.out.println("Highest numbers: " + result[j]);
        }
    }
}
```

C Implementation:

```c
#include <stdio.h>
#define SIZE 5

int main() {
    int i, n, k;
    double arr[] = {12.1, 5.9, 2.9, 6.8, 20.5};
    double result[SIZE];
    double max;

    printf("Enter the number of highest elements you want to extract from the array: ");
    scanf("%d", &n);

    if (n > SIZE)
        n = SIZE;

    for (int j = 0; j < n; j++) {
        max = arr[0];
        k = 0;

        for (i = 1; i < SIZE; i++) {
            if (max < arr[i]) {
                max = arr[i];
                k = i;
            }
        }

        result[j] = max;
        arr[k] = -1.0/0.0;
        printf("Highest numbers: %f\n", result[j]);
    }

    return 0;
}
```
Python Implementation:

```python
print("Enter the number of highest elements you want to extract from the array:")
n = int(input())

arr = [12.1, 5.9, 2.9, 6.8, 20.5]
if n > len(arr):
    n = len(arr)
result = [0] * n

for j in range(n):
    max = arr[0]
    k = 0
    for i in range(1, len(arr)):
        if max < arr[i]:
            max = arr[i]
            k = i
    result[j] = max
    arr[k] = float("-inf")
    print("Highest numbers:", result[j])
```