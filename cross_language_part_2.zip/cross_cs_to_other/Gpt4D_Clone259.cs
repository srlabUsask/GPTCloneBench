#input 
public string IntToString (int a) {
    if (a == 0)
        return "0";
    if (a == int.MinValue)
        return "-2147483648";
    var isNegative = false;
    if (a < 0) {
        a = - a;
        isNegative = true;
    }
    var stack = new Stack < char > ();
    while (a != 0) {
        var c = a % 10 + '0';
        stack.Push ((char) c);
        a /= 10;
    }
    if (isNegative)
        stack.Push ('-');
    return new string (stack.ToArray ());
}


#====================
#gpt output=============
Java:

public String intToString(int a) {
    if (a == 0)
        return "0";
    if (a == Integer.MIN_VALUE)
        return "-2147483648";
    boolean isNegative = false;
    if (a < 0) {
        a = - a;
        isNegative = true;
    }
    Stack<Character> stack = new Stack<>();
    while (a != 0) {
        char c = (char) ((a % 10) + '0');
        stack.push(c);
        a /= 10;
    }
    if (isNegative)
        stack.push('-');
    StringBuilder sb = new StringBuilder();
    while(!stack.empty()) {
        sb.append(stack.pop());
    }
    return sb.toString();
}

C:

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>

char* intToString(int a) {
    if (a == 0)
        return "0";
    if (a == INT_MIN)
        return "-2147483648";
    bool isNegative = false;
    if (a < 0) {
        a = - a;
        isNegative = true;
    }
    char stack[12];
    int top = 0;
    while (a != 0) {
        stack[top++] = (a % 10) + '0';
        a /= 10;
    }
    if (isNegative)
        stack[top++] = '-';
    stack[top] = '\0';
    for (int i = 0; i < top / 2; i++) {
        char temp = stack[i];
        stack[i] = stack[top - i - 1];
        stack[top - i - 1] = temp;
    }
    char* result = malloc(sizeof(char) * (top + 1));
    strncpy(result, stack, top + 1);
    return result;
}

Python:

def int_to_string(a):
    if a == 0:
        return "0"
    if a == -2147483648:
        return "-2147483648"
    is_negative = False
    if a < 0:
        a = - a
        is_negative = True
    stack = []
    while a != 0:
        c = chr((a % 10) + ord('0'))
        stack.append(c)
        a //= 10
    if is_negative:
        stack.append('-')
    return ''.join(reversed(stack))