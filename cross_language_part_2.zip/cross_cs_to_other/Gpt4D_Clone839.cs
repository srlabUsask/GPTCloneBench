#input 
private static int ? GetAssemblyDelimiterIndex (string fullyQualifiedTypeName) {
    int scope = 0;
    for (int i = 0; i < fullyQualifiedTypeName.Length; i ++) {
        char current = fullyQualifiedTypeName [i];
        switch (current) {
            case '[' :
                scope ++;
                break;
            case ']' :
                scope --;
                break;
            case ',' :
                if (scope == 0) {
                    return i;
                }
                break;
        }
    }
    return null;
}


#====================
#gpt output=============
Java :
```java
private static Integer GetAssemblyDelimiterIndex(String fullyQualifiedTypeName) {
    int scope = 0;
    for (int i = 0; i < fullyQualifiedTypeName.length(); i++) {
        char current = fullyQualifiedTypeName.charAt(i);
        switch (current) {
            case '[':
                scope++;
                break;
            case ']':
                scope--;
                break;
            case ',':
                if (scope == 0) {
                    return i;
                }
                break;
        }
    }
    return null;
}
```

C :
```c
int GetAssemblyDelimiterIndex(char* fullyQualifiedTypeName) {
    int scope = 0;
    int i;
    for (i = 0; fullyQualifiedTypeName[i] != '\0'; i++) {
        char current = fullyQualifiedTypeName[i];
        switch (current) {
            case '[':
                scope++;
                break;
            case ']':
                scope--;
                break;
            case ',':
                if (scope == 0) {
                    return i;
                }
                break;
        }
    }
    return -1;
}
```
Python :
```python
def GetAssemblyDelimiterIndex(fullyQualifiedTypeName):
    scope = 0
    for i in range(len(fullyQualifiedTypeName)):
        current = fullyQualifiedTypeName[i]
        if current == '[':
            scope += 1
        elif current == ']':
            scope -= 1
        elif current == ',':
            if scope == 0:
                return i
    return None
```