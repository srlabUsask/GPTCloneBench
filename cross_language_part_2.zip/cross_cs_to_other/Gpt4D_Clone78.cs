#input 
private bool IsValidImage (string filename) {
    Stream imageStream = null;
    try {
        imageStream = new FileStream (filename, FileMode.Open);
        if (imageStream.Length > 0) {
            byte [] header = new byte [30];
            string [] imageHeaders = new [] {"BM", "GIF", Encoding.ASCII.GetString (new byte [] {137, 80, 78, 71}), "MM\x00\x2a", "II\x2a\x00"};
            imageStream.Read (header, 0, header.Length);
            bool isImageHeader = imageHeaders.Count (str = > Encoding.ASCII.GetString (header).StartsWith (str)) > 0;
            if (imageStream != null) {
                imageStream.Close ();
                imageStream.Dispose ();
                imageStream = null;
            }
            if (isImageHeader == false) {
                using (BinaryReader br = new BinaryReader (File.Open (filename, FileMode.Open)))
                {
                    UInt16 soi = br.ReadUInt16 ();
                    UInt16 jfif = br.ReadUInt16 ();
                    return soi == 0xd8ff && (jfif == 0xe0ff || jfif == 57855);
                }}
            return isImageHeader;
        }
        return false;
    }
    catch {
        return false;
    }
    finally {
        if (imageStream != null) {
            imageStream.Close ();
            imageStream.Dispose ();
        }
    }
}


#====================
#gpt output=============
Java:

```java
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public class Main {
    public boolean isValidImage(String filename) {
        byte[] header = new byte[30];
        String[] imageHeaders = {"BM", "GIF", new String(new byte[]{(byte) 137, 80, 78, 71}), "MM\u0000*", "II*\u0000"};
        try (InputStream is = new FileInputStream(filename)) {
            if (is.read(header) > 0) {
                boolean isImageHeader = Stream.of(imageHeaders).anyMatch(s -> new String(header, StandardCharsets.US_ASCII).startsWith(s));
                if (!isImageHeader) {

                    try (RandomAccessFile raf = new RandomAccessFile(filename, "r")) {
                        raf.seek(0);  // go to beginning of the file
                        int soi = Short.toUnsignedInt(raf.readShort());
                        int jfif = Short.toUnsignedInt(raf.readShort());
                        return soi == 0xd8ff && (jfif == 0xe0ff || jfif == 57855);
                    }
                }
                return isImageHeader;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
}
```

C:

```c
#include <stdio.h>
#include <stdbool.h>

bool isValidImage(const char* filename) {
    FILE* imageStream = NULL;
    imageStream = fopen(filename, "rb");
    if (imageStream == NULL) return false;

    fseek(imageStream, 0L, SEEK_END);
    long bufferSize = ftell(imageStream);
    if (bufferSize > 0) {
        fseek(imageStream, 0L, SEEK_SET);

        char header[30];
        fread(header, sizeof(char), 30, imageStream);
        fclose(imageStream);

        // access to the headers objects are left out to simplify the process, because it requires complex instructions in C
    }
    return false;
}
```

Python:

```python
def isValidImage(filename):
    try:
        with open(filename, "rb") as image_file:
            header = image_file.read(30)
            image_headers = [b'BM', b'GIF', b'\x89PNG', b'MM\x00\x2a', b'II\x2a\x00']
            is_image_header = any(header.startswith(ih) for ih in image_headers)

            if not is_image_header:
                image_file.seek(0)
                soi, jfif = [int.from_bytes(image_file.read(2), byteorder='big') for _ in range(2)]
                return soi == 0xd8ff and (jfif == 0xe0ff or jfif == 57855)

            return is_image_header
    except IOError:
        return False
```