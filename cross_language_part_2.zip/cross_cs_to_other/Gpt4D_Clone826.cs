#input 
private static string [] SplitIntoChunks (string text, int chunkSize, bool truncateRemaining) {
    string chunk = chunkSize.ToString ();
    string pattern = truncateRemaining ? ".{" + chunk + "}" : ".{1," + chunk + "}";
    string [] chunks = null;
    if (chunkSize > 0 && ! String.IsNullOrEmpty (text))
        chunks = (from Match m in Regex.Matches (text, pattern)
            select m.Value).ToArray ();
    return chunks;
}


#====================
#gpt output=============
Here are the equivalent codes in Java, C and Python:

Java:

```java
private static String[] splitIntoChunks(String text, int chunkSize, boolean truncateRemaining) {
    String pattern = truncateRemaining  ? "(.{" + chunkSize + "})" : "(.{1," + chunkSize + "})";
    List<String> chunks = new ArrayList<>();
    if (chunkSize > 0 && text != null && !text.isEmpty()){
        Pattern compiledPattern = Pattern.compile(pattern);
        Matcher matcher = compiledPattern.matcher(text);
        while (matcher.find()){
            chunks.add(matcher.group());
        }}
   return chunks.toArray(new String[0]);
}
```

C:

```C
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char **splitIntoChunks(char *text, int chunkSize, int truncateRemaining, int *returnSize) {
    size_t len = strlen(text);
    if (chunkSize <= 0 || text == NULL || len == 0) { 
        *returnSize = 0;
        return NULL; 
    }
    
    size_t size = truncateRemaining ? (((len-1)/chunkSize) + 1) : len/chunkSize;
    char **chunks = malloc(size * sizeof(*chunks));

    for (int i = 0; i < size; i++) {
        chunks[i] = calloc(chunkSize + 1, sizeof(*chunks[i]));
        strncpy(chunks[i], text + i*chunkSize, chunkSize);
    }

    *returnSize = size;
    return chunks;
}
```

Python:

```python
import re

def split_into_chunks(text, chunk_size, truncate_remaining):
    pattern = f".{{1,{chunk_size}}}" if truncate_remaining else f".{{0,{chunk_size}}}"
    chunks = []
    if chunk_size > 0 and text:
        chunks = re.findall(pattern, text)
    return chunks
```