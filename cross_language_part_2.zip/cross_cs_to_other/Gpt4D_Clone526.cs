#input 
public bool Seq_Check (int [] elems, int k) {
    for (int i = elems.Length; i > 0; i --) {
        if (elems [i] == k) {
            int curr = k - 1;
            for (; i > 0 && curr > 0; i --) {
                if (elems [i] != curr) {
                    if (elems [i] == k) {
                        curr = k - 1;
                        continue;
                    }
                    break;
                }
                curr --;
            }
            if (curr == 0) {
                return true;
            }
        }
    }
    return false;
}


#====================
#gpt output=============
Java Implementation:

```java
public boolean seqCheck(int [] elems, int k) {
    for (int i = elems.length - 1; i >= 0; i--) {
        if (elems[i] == k) {
            int curr = k - 1;
            for (; i >= 0 && curr > 0; i--) {
                if (elems[i] != curr) {
                    if (elems[i] == k) {
                        curr = k - 1;
                        continue;
                    }
                    break;
                }
                curr--;
            }
            if (curr == 0) {
                return true;
            }
        }
    }
    return false;
}
```

Python Implementation:

```Python
def seq_check(elems, k):
    i = len(elems) - 1
    while i >= 0:
        if elems[i] == k:
            curr = k - 1
            while i >= 0 and curr > 0:
                if elems[i] != curr:
                    if elems[i] == k:
                        curr = k - 1
                        continue
                    break
                curr -= 1
                i -= 1
            if curr == 0:
                return True
        i -= 1
    return False
```

C Implementation ( Assumes elems array ends with -1 or any invalid input ) :

```C
#include <stdbool.h>

bool seqCheck(int elems[], int k) {
    for (int i = sizeof(elems) / sizeof(int) - 2; i >= 0; i--) {
        if (elems[i] == k) {
            int curr = k - 1;
            for (; i >= 0 && curr > 0; i--) {
                if (elems[i] != curr) {
                    if (elems[i] == k) {
                        curr = k - 1;
                        continue;
                    }
                    break;
                }
                curr--;
            }
            if (curr == 0) {
                return true;
            }
        }
    }
    return false;
}
```