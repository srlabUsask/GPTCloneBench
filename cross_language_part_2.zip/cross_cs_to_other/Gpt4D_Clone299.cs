#input 
public static string CombinePaths (params string [] paths) {
    if (paths == null) {
        return null;
    }
    string currentPath = paths [0];
    for (int i = 1; i < paths.Length; i ++) {
        currentPath = Path.Combine (currentPath, paths [i]);
    }
    return currentPath;
}


#====================
#gpt output=============
JAVA
```java
import java.nio.file.Paths;

public class Main {
    public static String combinePaths(String... paths) {
        if (paths == null) {
            return null;
        }
        String currentPath = paths[0];
        for (int i = 1; i < paths.length; i++) {
            currentPath = Paths.get(currentPath, paths[i]).toString();
        }
        return currentPath;
    }
}
```

C 
```c
#include <stdio.h>
#include <string.h>

char *combinePaths(int num, char *paths[]) {
    if (paths == NULL) {
        return NULL;
    }
    char *currentPath = paths[0];
    for (int i = 1; i < num; i++) {
        strcat(currentPath, "/");
        strcat(currentPath, paths[i]);
    }
    return currentPath;
}
```

PYTHON
```python
import os

def combine_paths(*paths):
    if paths is None:
        return None
    current_path = paths[0]
    for i in range(1, len(paths)):
        current_path = os.path.join(current_path, paths[i])
    return current_path
```