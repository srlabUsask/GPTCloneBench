#input 
static void Main (string [] args) {
    Console.Clear ();
    Console.ForegroundColor = ConsoleColor.Gray;
    Dictionary < string, string [] > skins = new Dictionary < string, string [] > ();
    skins.Add ("ahri", new string [] {"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"});
    skins.Add ("leesin", new string [] {"Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"});
    Console.WriteLine ("Conor's Random League of Legends Skin Selector v0.1\r\n\r\n");
    Console.WriteLine ("What champion would you like to select a skin for? \r\nPress enter for a random champion...    ");
    var champion = Console.ReadLine ();
    var rnd = new Random ();
    if (champion.Equals (string.Empty)) {
        var tmpList = Enumerable.ToList (skins.Keys);
        champion = tmpList [rnd.Next (tmpList.Count)];
    } else {
        champion = champion.Trim ().ToLower ();
    }
    Console.Write (string.Format ("Champion {0} Selected \r\n", champion));
    if (skins.ContainsKey (champion)) {
        Console.WriteLine (string.Format ("Your random skin for {0} is: {1}\r\n", champion, skins [champion] [rnd.Next (skins [champion].Length)]));
    } else {
        Console.Clear ();
        Main (args);
    }
}


#====================
#gpt output=============
Java:

public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    Map<String, String[]> skins = new HashMap<>();
    skins.put("ahri", new String[]{"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"});
    skins.put("leesin", new String[]{"Traditional", "Acolyte", "Dragon Fist", "Muay Thai", "Pool Party", "SKT T1", "Knockout"});
    System.out.println("Conor's Random League of Legends Skin Selector v0.1");

    System.out.println("What champion would you like to select a skin for? Press enter for a random champion...");
    String champion = in.nextLine();
    Random rnd = new Random();
    if(champion.isEmpty()) {
        Object[] keys = skins.keySet().toArray();
        champion = (String) keys[rnd.nextInt(keys.length)];
    } else {
        champion = champion.trim().toLowerCase();
    }
    System.out.println("Champion " + champion + " Selected");
    if(skins.containsKey(champion)) {
        System.out.println("Your random skin for " + champion + " is: " + skins.get(champion)[rnd.nextInt(skins.get(champion).length)]);
    } else {
        main(args);
    }
}

C:

This cannot be implemented in C as it doesn't have built-in support for string arrays and dictionaries. 

Python:

import random

def main():
    skins = {
        "ahri": ["Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"],
        "leesin": ["Traditional", "Acolyte", "Dragon Fist", "Muay Thai", "Pool Party", "SKT T1", "Knockout"]
    }

    print("Conor's Random League of Legends Skin Selector v0.1")
    print("What champion would you like to select a skin for? Press enter for a random champion...")
    champion = input().strip().lower() or random.choice(list(skins.keys()))

    print("Champion", champion, "Selected")

    if champion in skins:
        print("Your random skin for", champion, "is:", random.choice(skins[champion]))
    else:
        main()

main()