#input 
static void DeleteEmptyDirs (string dir) {
    if (String.IsNullOrEmpty (dir))
        throw new ArgumentException ("Starting directory is a null reference or an empty string", "dir");
    try {
        foreach (var d in Directory.EnumerateDirectories (dir)) {
            DeleteEmptyDirs (d);
        }
        var entries = Directory.EnumerateFileSystemEntries (dir);
        if (! entries.Any ()) {
            try {
                Directory.Delete (dir);
            }
            catch (UnauthorizedAccessException) {
            }
            catch (DirectoryNotFoundException) {
            }
        }
    }
    catch (UnauthorizedAccessException) {
    }
}


#====================
#gpt output=============
Java:

```java
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class Main {
    public static void main(String[] args) {
        deleteEmptyDirs("dir");
    }

    static void deleteEmptyDirs(String dir) {
        if (dir == null || dir.isEmpty()){
            throw new IllegalArgumentException("Starting directory is a null reference or an empty string");
        }
        try (Stream<Path> paths = Files.walk(Paths.get(dir))) {
            paths.forEach(filePath -> {
                if (Files.isDirectory(filePath)) {
                    File[] files = new File(filePath.toString()).listFiles();
                    if (files != null && files.length == 0){
                        try {
                            Files.delete(filePath);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
```

C:

```c
#include <stdio.h>
#include <string.h>
#define MAX_PATH 260

void deleteDirectoryIfEmpty(const char * dirname) {
    if (dirname == NULL || strlen(dirname) == 0)
        fprintf(stderr, "Starting directory is a null reference or an empty string\n");

    char path[MAX_PATH];
    snprintf(path, sizeof(path), "rmdir \"%s\"", dirname); // Attempts to remove directory, fails if not empty

    system(path); // Invoke OS command to remove directory
}

int main(){
    deleteDirectoryIfEmpty("dir");
    return 0;
}
```

Python:

```python
import os

def delete_empty_dirs(dir):
    if not dir:
        raise ValueError("Starting directory is a null reference or an empty string")
    for d in os.listdir(dir):
        new_dir = os.path.join(dir, d)
        if os.path.isdir(new_dir):
            delete_empty_dirs(new_dir)
    if not os.listdir(dir):
        os.rmdir(dir)

delete_empty_dirs("dir")
```

Please note that the C code is not a direct implementation of the original C# code, since not all its features are available in C. Thus, it just tries to delete the directory, which will fail if the directory is not empty. For more advanced file system functionality in C, consider using libraries such as `boost::filesystem`.