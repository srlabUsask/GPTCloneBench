#input 
private void FillBuffer (long position) {
    long newStart;
    if (position > bufferStart) {
        newStart = position;
    } else {
        newStart = Math.Max (0, position - buffer.Length + 2);
    }
    int bytesRead;
    int index = 0;
    stream.Position = newStart;
    while ((bytesRead = stream.Read (buffer, index, buffer.Length - index)) > 0) {
        index += bytesRead;
    }
    bufferStart = newStart;
    bufferEnd = bufferStart + index;
}


#====================
#gpt output=============
Java Version: 

```java
private void fillBuffer(long position) {
    long newStart;
    if (position > bufferStart) {
        newStart = position;
    } else {
        newStart = Math.max(0, position - buffer.length + 2);
    }
    int bytesRead;
    int index = 0;
    stream.seek(newStart);
    while ((bytesRead = stream.read(buffer, index, buffer.length - index)) > 0) {
        index += bytesRead;
    }
    bufferStart = newStart;
    bufferEnd = bufferStart + index;
}
```

C Version: 

```c
void fillBuffer(long position) {
    long newStart;
    if (position > bufferStart) {
        newStart = position;
    } else {
        newStart = (position - bufferLength + 2 > 0) ? position - bufferLength + 2 : 0;
    }
    int bytesRead;
    int index = 0;
    fseek(stream, newStart, SEEK_SET);
    while ((bytesRead = fread(buffer + index, 1, bufferLength - index, stream)) > 0) {
        index += bytesRead;
    }
    bufferStart = newStart;
    bufferEnd = bufferStart + index;
}
```

Python Version: 

```python
def fillBuffer(self, position):
    if position > self.bufferStart:
        newStart = position
    else:
        newStart = max(0, position - len(self.buffer) + 2)
    bytesRead = 0
    index = 0
    self.stream.seek(newStart)
    while ((bytesRead := len(self.stream.read(self.buffer[index:])))) > 0:
        index += bytesRead
    self.bufferStart = newStart
    self.bufferEnd = self.bufferStart + index
```
Please note that the python's walrus operator (:=) is used to assign values inside condition. It is available from python 3.8 onwards.
And the 'stream' variable in each case is assumed to be an instance variable of a class and must be capable of Seek/Position operations. Additionally 'buffer' is expected to be an array or list with '.length' or 'len()' property supported.