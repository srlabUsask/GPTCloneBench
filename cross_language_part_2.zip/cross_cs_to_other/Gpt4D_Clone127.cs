#input 
private static ImageFormat GetImageFormat (string fileName) {
    string extension = Path.GetExtension (fileName);
    if (string.IsNullOrEmpty (extension))
        throw new ArgumentException (string.Format ("Unable to determine file extension for fileName: {0}", fileName));
    switch (extension.ToLower ()) {
        case @".bmp" :
            return ImageFormat.Bmp;
        case @".gif" :
            return ImageFormat.Gif;
        case @".ico" :
            return ImageFormat.Icon;
        case @".jpg" : case @".jpeg" :
            return ImageFormat.Jpeg;
        case @".png" :
            return ImageFormat.Png;
        case @".tif" : case @".tiff" :
            return ImageFormat.Tiff;
        case @".wmf" :
            return ImageFormat.Wmf;
        default :
            throw new NotImplementedException ();
    }
}


#====================
#gpt output=============
Java:

import javax.imageio.ImageIO;

import java.awt.image.BufferedImage;

public ImageFormat GetImageFormat(String fileName){
    String extension = fileName.substring(fileName.lastIndexOf('.'));
    if (extension.isEmpty() || extension.isBlank())
        throw new IllegalArgumentException (
         String.format ("Unable to determine file extension for fileName: %s", fileName));
     switch(extension.toLowerCase()){
         case ".bmp":
             return "bmp";
         case ".gif":
             return "gif";
         case ".ico":
             return "ico";
         case ".jpg": case ".jpeg":
             return "jpg";
         case ".png":
             return "png";
         case ".tif": case ".tiff":
             return "tif";
         case ".wmf":
             return "wmf";
         default:
             throw new IllegalArgumentException("Not supported file type");
     }
}


C:

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

const char *GetImageFormat(char *filename){
    const char *extension = strrchr(filename, '.');
    if (!extension){
       printf("Unable to determine file extension for fileName: %s", filename);
       exit(1);
    }
    if(strcasecmp(extension, ".jpeg") == 0 || strcasecmp(extension, ".jpg") == 0){
        return "jpeg";
    } else if(strcasecmp(extension, ".png") == 0){
        return "png";
    } else if(strcasecmp(extension, ".bmp") == 0){
        return "bmp";
    } else if(strcasecmp(extension, ".gif") == 0){
        return "gif";
    } else if(strcasecmp(extension, ".ico") == 0){
        return "ico";
    } else if(strcasecmp(extension, ".tiff") == 0 || strcasecmp(extension, ".tif") == 0){
        return "tiff";
    } else if(strcasecmp(extension, ".wmf") == 0){
        return "wmf";
    } else {
        printf("Unrecognized file type: %s", extension);
        exit(1);
    }
}

Python:

import os

def GetImageFormat(fileName):
   _, extension = os.path.splitext(fileName)
   if not extension:
      raise ValueError (
         "Unable to determine file extension for fileName: {}".format(fileName)
      )
   extension = extension[1:]
   switcher = {
      "bmp": "bmp",
      "gif": "gif",
      "ico": "ico",
      "jpg": "jpg",
      "jpeg": "jpeg",
      "png": "png",
      "tif": "tif",
      "tiff": "tiff",
      "wmf": "wmf"
   }
   return switcher.get(extension.lower(), "Invalid file type")
