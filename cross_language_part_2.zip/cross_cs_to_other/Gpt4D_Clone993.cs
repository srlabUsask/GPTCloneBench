#input 
public static IDictionary < string, object > ToDictionary (this JObject @object) {
    var result = @object.ToObject < Dictionary < string, object > > ();
    var JObjectKeys = (from r in result
        let key = r.Key
        let value = r.Value
        where value.GetType () == typeof (JObject)
        select key).ToList ();
    var JArrayKeys = (from r in result
        let key = r.Key
        let value = r.Value
        where value.GetType () == typeof (JArray)
        select key).ToList ();
    JArrayKeys.ForEach (key = > result [key] = ((JArray) result [key]).Values ().Select (x = > ((JValue) x).Value).ToArray ());
    JObjectKeys.ForEach (key = > result [key] = ToDictionary (result [key] as JObject));
    return result;
}


#====================
#gpt output=============
The original code you provided is a method written in C#. It converts a JSON object to a Dictionary with nested JSON objects and arrays converted appropriately. Below are the equivalent implementations in Java, C, and Python:

Java (uses org.json library):

```java
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.*;

public static Map<String, Object> toDictionary(JSONObject jsonObject) {
    Map<String, Object> result = new HashMap<>();

    jsonObject.keys().forEachRemaining(key -> {
        Object value = jsonObject.get(key);
        if (value instanceof JSONObject) {
            result.put(key, toDictionary((JSONObject) value));
        } else if (value instanceof JSONArray) {
            ArrayList<Object> list = new ArrayList<>();
            ((JSONArray)value).iterator().forEachRemaining(item -> list.add(item));
            result.put(key, list);
        } else {
            result.put(key, value);
        }
    });

    return result;
}
```

C (uses json-c library):

```c
#include <json-c/json.h>
#include <json-c/json_object.h>
#include <stdio.h>

void toDictionary(struct json_object *jobj) {
    enum json_type type;
    json_object_object_foreach(jobj, key, val) {
        type = json_object_get_type(val);
        switch (type) {
        case json_type_array:
        case json_type_object:
            toDictionary(val);
            break;
        default:
            printf("key: %s, value: %s\n", key, json_object_to_json_string(val));
            break;
        }
    }
}
```

Python:

```python
def to_dictionary(obj):
    if isinstance(obj, dict):
        return {k: to_dictionary(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [to_dictionary(elem) for elem in obj]
    else:
        return obj
```

Please note that these are not direct and exact translations, but rather adaptations based on the capabilities of each language and the available JSON libraries for each. They perform similar functionality but there will be differences in terms of typing, method parameters, and nested object/array conversions.