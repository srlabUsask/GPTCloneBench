#input 
public static bool IsPowerOfTwo (ulong n) {
    if (n % 2 != 0)
        return false;
    double exp = Math.Log (n, 2);
    if (exp != Math.Floor (exp))
        return false;
    return Math.Pow (2, exp) == n;
}


#====================
#gpt output=============
Java implementation:

```java
public static boolean isPowerOfTwo(long n){
    if (n % 2 != 0)
        return false;
    double exp = Math.log(n) / Math.log(2);
    if (exp != Math.floor(exp))
        return false;
    return Math.pow(2, exp) == n;
}
```

C implementation:

```c
#include <stdbool.h>
#include <math.h>

bool isPowerOfTwo(unsigned long long n) {
    if (n % 2 != 0)
        return false;
    double exp = log(n) / log(2);
    if (exp != floor(exp))
        return false;
    return pow(2, exp) == n;
}
```

Python implementation:

```python
import math

def is_power_of_two(n):
    if n % 2 != 0:
        return False
    exp = math.log(n, 2)
    if exp != math.floor(exp):
        return False
    return math.pow(2, exp) == n
```