#input 
public static IEnumerable < IEnumerable < T > > QuickPerm < T > (this IEnumerable < T > set) {
    int N = set.Count ();
    int [] a = new int [N];
    int [] p = new int [N];
    var yieldRet = new T [N];
    List < T > list = new List < T > (set);
    int i, j, tmp;
    for (i = 0; i < N; i ++) {
        a [i] = i + 1;
        p [i] = 0;
    }
    yield return list;
    i = 1;
    while (i < N) {
        if (p [i] < i) {
            j = i % 2 * p [i];
            tmp = a [j];
            a [j] = a [i];
            a [i] = tmp;
            for (int x = 0; x < N; x ++) {
                yieldRet [x] = list [a [x] - 1];
            }
            yield return yieldRet;
            p [i] ++;
            i = 1;
        } else {
            p [i] = 0;
            i ++;
        }
    }
}


#====================
#gpt output=============
Java Implementation:

```java
public static < T > List < List < T > > QuickPerm(List < T > set) {
    int N = set.size();
    List < Integer > a = new ArrayList < > (), p = new ArrayList < > ();
    List < T > yieldRet = new ArrayList < > ();
    List < T > list = new ArrayList < > (set);
    int i, j, tmp;
    for (i = 0; i < N; i++) {
        a.add(i + 1);
        p.add(0);
        yieldRet.add(null);
    }
    List < List < T > > result = new ArrayList < > ();
    result.add(new ArrayList < > (list));
    i = 1;
    while (i < N) {
        if (p.get(i) < i) {
            j = i % 2 * p.get(i);
            tmp = a.get(j);
            a.set(j, a.get(i));
            a.set(i, tmp);
            for (int x = 0; x < N; x++) {
                yieldRet.set(x, list.get(a.get(x) - 1));
            }
            result.add(new ArrayList < > (yieldRet));
            p.set(i, p.get(i) + 1);
            i = 1;
        } else {
            p.set(i, 0);
            i++;
        }
    }
    return result;
}
```

C Implementation:

```c
// C language does not have a generic type and does not directly support higher level data structures like List.
// It will require creating your own data structures and functions to operate on those structures. Hence, a QuickPerm algorithm will be more complex to implement in C.

```

Python Implementation:

```python
def QuickPerm(set):
    N = len(set)
    a = [i+1 for i in range(N)]
    p = [0 for _ in range(N)]
    yieldRet = [None for _ in range(N)]
    list = set.copy()
    result = []
    result.append(list)
    i = 1
    while i < N:
        if p[i] < i:
            j = i % 2 * p[i]
            tmp = a[j]
            a[j] = a[i]
            a[i] = tmp
            for x in range(N):
                yieldRet[x] = list[a[x] - 1]
            result.append(yieldRet.copy())
            p[i] += 1
            i = 1
        else:
            p[i] = 0
            i += 1
    return result
```