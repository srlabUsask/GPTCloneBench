#input 
public void Send () {
    if (String.IsNullOrEmpty (Server)) {
        throw new PreferenceNotSetException ("Server not set");
    }
    if (String.IsNullOrEmpty (From)) {
        throw new PreferenceNotSetException ("Sender's E-Mail address not set.");
    }
    if (String.IsNullOrEmpty (To)) {
        throw new PreferenceNotSetException ("Recipient's E-Mail address not set.");
    }
    using (MailMessage message = new MailMessage (From, To, Subject, FormattedText))
    {
        message.IsBodyHtml = true;
        using (SmtpClient client = new SmtpClient (Server))
        {
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            int temp = ServicePointManager.MaxServicePointIdleTime;
            ServicePointManager.MaxServicePointIdleTime = 1;
            try {
                client.Send (message);
            }
            catch (Exception ex) {
                MessageBox.Show (ex.ToString ());
            }
            finally {
                ServicePointManager.MaxServicePointIdleTime = temp;
            }
        }}}


#====================
#gpt output=============
Java:

```java
public void Send() throws IllegalArgumentException {
    if (Server == null || Server.isEmpty()) {
        throw new IllegalArgumentException("Server not set");
    }
    if (From == null || From.isEmpty()) {
        throw new IllegalArgumentException("Sender's E-Mail address not set.");
    }
    if (To == null || To.isEmpty()) {
        throw new IllegalArgumentException("Recipient's E-Mail address not set.");
    }
    try {
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(From));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(To));
        message.setSubject(Subject);
        message.setText(FormattedText, "utf-8", "html");

        Transport.send(message);
    } catch (MessagingException ex) {
        throw new RuntimeException(ex);
    }
}
```
C:

```C
/* C does not have built-in support for sending email. Here's an example using the libcurl library: */

#include <curl/curl.h>

void Send() {
  if (!Server || !*Server) {
    perror("Server not set");
    exit(EXIT_FAILURE);
  }
  if (!From || !*From) {
    perror("Sender's E-Mail address not set");
    exit(EXIT_FAILURE);
  }
  if (!To || !*To) {
    perror("Recipient's E-Mail address not set");
    exit(EXIT_FAILURE);
  }

  CURL *curl;
  CURLcode res = CURLE_OK;
  struct curl_slist *recipients = NULL;
  curl = curl_easy_init();
  if(curl) {
    /* Set username and password */ 
    curl_easy_setopt(curl, CURLOPT_USERNAME, "user");
    curl_easy_setopt(curl, CURLOPT_PASSWORD, "secret");

    /* URL for SMTP server */
    curl_easy_setopt(curl, CURLOPT_URL, Server);

    /* Sender */
    curl_easy_setopt(curl, CURLOPT_MAIL_FROM, From);

    /* Recipient(s) */
    recipients = curl_slist_append(recipients, To);
    curl_easy_setopt(curl, CURLOPT_MAIL_RCPT, recipients);

    /* Message body */
    curl_easy_setopt(curl, CURLOPT_READDATA, FormattedText);
    
    res = curl_easy_perform(curl);

    if(res != CURLE_OK)
      fprintf(stderr, "curl_easy_perform() failed: %s\n",
              curl_easy_strerror(res));

    /* Free the list of recipients */
    curl_slist_free_all(recipients);

    /* Always cleanup */ 
    curl_easy_cleanup(curl);
  }
}
```

Python:

```python
from smtplib import SMTP
from email.mime.text import MIMEText
from sys import exit

def Send():
    if not Server:
        print("Server not set")
        exit()
    if not From:
        print("Sender's E-Mail address not set")
        exit()
    if not To:
        print("Recipient's E-Mail address not set")
        exit()

    try:
        smtpObj = SMTP(Server)
        msg = MIMEText(FormattedText, 'html')
        msg['Subject'] = Subject
        msg['From'] = From
        msg['To'] = To

        smtpObj.send_message(msg)
        smtpObj.quit()
    except Exception as e:
        print(str(e))
```

Take into account that all codes are assuming variables Server, From, To, Subject and FormattedText are accessible and defined in context. You need to replace placeholders with actual values or variables.