#input 
static void Main (string [] args) {
    Console.WriteLine ("Enter number(s): ");
    double [] values = new double [3];
    for (int i = 0; i < values.Length; i ++) {
        values [i] = Convert.ToDouble (Console.ReadLine ());
    }
    average (values);
    Console.ReadKey ();
}


#====================
#gpt output=============
Java:

```java
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number(s): ");
        double[] values = new double[3];
        for (int i = 0; i < values.length; i++) {
            values[i] = scanner.nextDouble();
        }
        average(values);
    }

    public static void average(double[] values) {
        double sum = 0.0;
        for(double value : values) {
            sum += value;
        }
        double average = sum / values.length;
        System.out.println("Average: " + average);
    }
}
```

C:

```c
#include <stdio.h>

void average(double values[], int length) {
    double sum = 0.0;
    for(int i = 0; i < length; i++) {
        sum += values[i];
    }
    double average = sum / length;
    printf("Average: %.2f\n", average);
}

int main() {
    printf("Enter number(s): \n");
    double values[3];
    for(int i = 0; i < 3; i++) {
        scanf("%lf", &values[i]);
    }
    average(values, 3);
    return 0;
}
```

Python:

```python
def average(values):
    average = sum(values) / len(values)
    print("Average: ", average)

values = []
print("Enter number(s): ")
for i in range(3):
    values.append(float(input()))
average(values)
```