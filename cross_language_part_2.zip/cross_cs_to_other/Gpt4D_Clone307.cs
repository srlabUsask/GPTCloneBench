#input 
public static void Main () {
    int a = 1234;
    int b = 4321;
    Console.WriteLine ("Before: a {0} and b {1}", a, b);
    b = b - a;
    a = a + b;
    b = a - b;
    Console.WriteLine ("After: a {0} and b {1}", a, b);
}


#====================
#gpt output=============
In Java:

```java
public class Main {
    public static void main(String[] args) {
        int a = 1234;
        int b = 4321;
        System.out.printf("Before: a %d and b %d\n", a, b);
        b = b - a;
        a = a + b;
        b = a - b;
        System.out.printf("After: a %d and b %d\n", a, b);
    }
}
```

In C:

```c
#include <stdio.h>

int main() {
    int a = 1234;
    int b = 4321;
    printf("Before: a %d and b %d\n", a, b);
    b = b - a;
    a = a + b;
    b = a - b;
    printf("After: a %d and b %d\n", a, b);
    return 0;
}
```

In Python:

```python
a = 1234
b = 4321
print(f'Before: a {a} and b {b}')
b = b - a
a = a + b
b = a - b
print(f'After: a {a} and b {b}')
```