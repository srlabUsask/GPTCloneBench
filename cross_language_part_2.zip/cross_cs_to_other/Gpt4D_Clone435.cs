#input 
static void Main (string [] args) {
    var input = Console.ReadLine ();
    var test = new ListArrayLoop (10000, 1000);
    switch (input) {
        case "1" :
            Test (test.ListSum);
            break;
        case "2" :
            Test (test.ArraySum);
            break;
        case "3" :
            test.ArraySum ();
            Test (test.ListSum);
            break;
        default :
            test.ListSum ();
            Test (test.ArraySum);
            break;
    }
}


#====================
#gpt output=============
Java:

```
public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    String input = scanner.nextLine();
    ListArrayLoop test = new ListArrayLoop(10000, 1000);
    switch (input) {
        case "1":
            Test(test.ListSum());
            break;
        case "2":
            Test(test.ArraySum());
            break;
        case "3":
            test.ArraySum();
            Test(test.ListSum());
            break;
        default:
            test.ListSum();
            Test(test.ArraySum());
            break;
    }
}
```

C:

```c
#include <stdio.h>

void main() {
    char input[2];
    fgets(input, 2, stdin);
    ListArrayLoop *test = ListArrayLoop_New(10000, 1000);
    switch (input[0]) {
        case '1':
            Test(ListArrayLoop_ListSum(test));
            break;
        case '2':
            Test(ListArrayLoop_ArraySum(test));
            break;
        case '3':
            ListArrayLoop_ArraySum(test);
            Test(ListArrayLoop_ListSum(test));
            break;
        default:
            ListArrayLoop_ListSum(test);
            Test(ListArrayLoop_ArraySum(test));
            break;
    }
}
```

Python:

```python
def main():
    input = raw_input()
    test = ListArrayLoop(10000, 1000)
    if input == "1":
        Test(test.ListSum())
    elif input == "2":
        Test(test.ArraySum())
    elif input == "3":
        test.ArraySum()
        Test(test.ListSum())
    else:
        test.ListSum()
        Test(test.ArraySum())
```