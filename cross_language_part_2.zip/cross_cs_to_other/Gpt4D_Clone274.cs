#input 
protected override void Update (GameTime gameTime) {
    GameState gameState = _gameState;
    var keyboardState = Keyboard.GetState ();
    if (keyboardState.IsKeyDown (Keys.A) && _keyboardState.IsKeyUp (Keys.A)) {
        gameState = GameState.Menu;
    } else if (keyboardState.IsKeyDown (Keys.B) && _keyboardState.IsKeyUp (Keys.B)) {
        gameState = GameState.InGame;
    } else if (keyboardState.IsKeyDown (Keys.C) && _keyboardState.IsKeyUp (Keys.C)) {
        gameState = GameState.Undefined;
    }
    _keyboardState = keyboardState;
    if (gameState != _gameState) {
        switch (gameState) {
            case GameState.Undefined :
                MediaPlayer.Stop ();
                break;
            case GameState.Menu :
                MediaPlayer.Stop ();
                MediaPlayer.Play (_song1);
                break;
            case GameState.InGame :
                MediaPlayer.Stop ();
                MediaPlayer.Play (_song2);
                break;
            default :
                throw new ArgumentOutOfRangeException ();
        }
        _gameState = gameState;
    }
    base.Update (gameTime);
}


#====================
#gpt output=============
Java:
``` java
protected void update(GameTime gameTime) {
    GameState gameState = _gameState;
    KeyboardState keyboardState = Keyboard.getState();
    if (keyboardState.isKeyDown(Keys.A) && _keyboardState.isKeyUp(Keys.A)) {
        gameState = GameState.Menu;
    } else if (keyboardState.isKeyDown(Keys.B) && _keyboardState.isKeyUp(Keys.B)) {
        gameState = GameState.InGame;
    } else if (keyboardState.isKeyDown(Keys.C) && _keyboardState.isKeyUp(Keys.C)) {
        gameState = GameState.Undefined;
    }
    _keyboardState = keyboardState;
    if (gameState != _gameState) {
        switch (gameState) {
            case Undefined:
                MediaPlayer.stop();
                break;
            case Menu:
                MediaPlayer.stop();
                MediaPlayer.play(_song1);
                break;
            case InGame:
                MediaPlayer.stop();
                MediaPlayer.play(_song2);
                break;
            default:
                throw new IllegalArgumentException("Invalid GameState.");
             }
        _gameState = gameState;
    }
    super.update(gameTime);
}
```

C:
``` c 
void update(GameTime gameTime) {
    GameState gameState = _gameState;
    KeyboardState keyboardState = GetState();
    if (IsKeyDown(&keyboardState, 'A') && IsKeyUp(&_keyboardState, 'A')) {
        gameState = Menu;
    } else if (IsKeyDown(&keyboardState, 'B') && IsKeyUp(&_keyboardState, 'B')) {
        gameState = InGame;
    } else if (IsKeyDown(&keyboardState, 'C') && IsKeyUp(&_keyboardState, 'C')) {
        gameState = Undefined;
    }
    _keyboardState = keyboardState;
    if (gameState != _gameState) {
        switch (gameState) {
            case Undefined:
                MediaPlayerStop();
                break;
            case Menu:
                MediaPlayerStop();
                MediaPlayerPlay(_song1);
                break;
            case InGame:
                MediaPlayerStop();
                MediaPlayerPlay(_song2);
                break;
            default:
                fprintf(stderr, "Invalid GameState.\n");
                exit(1);
        }
        _gameState = gameState;
    }
    UpdateBase(gameTime);
}
```

Python:
``` python
def update(self, gameTime):
    gameState = self._gameState
    keyboardState = Keyboard.GetState()
    if keyboardState.IsKeyDown(Keys.A) and self._keyboardState.IsKeyUp(Keys.A):
        gameState = self.GameState.Menu
    elif keyboardState.IsKeyDown(Keys.B) and self._keyboardState.IsKeyUp(Keys.B):
        gameState = self.GameState.InGame
    elif keyboardState.IsKeyDown(Keys.C) and self._keyboardState.IsKeyUp(Keys.C):
        gameState = self.GameState.Undefined
    self._keyboardState = keyboardState
    if gameState != self._gameState:
        if gameState == self.GameState.Undefined:
            MediaPlayer.Stop()
        elif gameState == self.GameState.Menu:
            MediaPlayer.Stop()
            MediaPlayer.Play(self._song1)
        elif gameState == self.GameState.InGame:
            MediaPlayer.Stop()
            MediaPlayer.Play(self._song2)
        else:
            raise ValueError("Invalid GameState.")
        self._gameState = gameState
    super().Update(gameTime)
```