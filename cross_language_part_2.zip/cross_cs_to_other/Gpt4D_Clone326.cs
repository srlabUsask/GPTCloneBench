#input 
public static void MultiplyDigitArrays (int [] lhs, int [] rhs, int [] result) {
    var n1 = BigInteger.Parse (string.Join ("", lhs));
    var n2 = BigInteger.Parse (string.Join ("", rhs));
    var resultBi = BigInteger.Multiply (n1, n2);
    Array.Clear (result, 0, result.Length);
    var stResult = resultBi.ToString ().PadLeft (result.Length, '0');
    for (int i = 0; i < stResult.Length; i ++) {
        result [(stResult.Length - 1) - i] = int.Parse (stResult [i].ToString ());
    }
}


#====================
#gpt output=============
Here are the sample codes for the required programming languages:

Java:

```
import java.math.BigInteger;

public class Main {
    public static void MultiplyDigitArrays(int[] lhs, int[] rhs, int[] result) {
        BigInteger n1 = new BigInteger(String.valueOf(lhs));
        BigInteger n2 = new BigInteger(String.valueOf(rhs));
        BigInteger resultBi = n1.multiply(n2);
        Arrays.fill(result, 0);
        String stResult = resultBi.toString();
        while(stResult.length() < result.length){
            stResult = "0" + stResult;
        }
        for (int i = 0; i < stResult.length(); i++) {
            result[(stResult.length() - 1) - i] = Integer.parseInt(String.valueOf(stResult.charAt(i)));
        }
    }
}
```

C:

```c
#include<stdio.h>
#include<string.h>

void MultiplyDigitArrays (int lhs[], int rhs[], int result[], int lhs_size, int rhs_size) {
    char n1[100], n2[100];
    sprintf(n1, "%d", lhs);
    sprintf(n2, "%d", rhs);
    int resultBi = atoi(n1) * atoi(n2);
    memset(result, 0, sizeof(result));
    char stResult[100];
    sprintf(stResult, "%d", resultBi);
    int padding = strlen(stResult);
    for (int i = 0; i < padding; i++) {
        result [(padding - 1) - i] = stResult [i]-'0';
    }
}
```

Python:

```python
def MultiplyDigitArrays(lhs, rhs, result):
    n1 = int(''.join(map(str, lhs)))
    n2 = int(''.join(map(str, rhs)))
    resultBi = n1 * n2
    result.clear()
    result.extend([int(d) for d in str(resultBi).zfill(len(result))])
```

Please note: C does not have a direct equivalent to BigInteger so you need to make sure your arrays don't overflow integers. Also in Java and Python there is no need to clear the input array since it's passed by value, not by reference unlike in C#. In order to compensate for this in C, the size of the lhs and rhs arrays are included as additional arguments.