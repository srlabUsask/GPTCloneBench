#input 
public void ShotHit (Point shot, bool sunk) {
    HitShots.AddLast (shot);
    MissCount = 0;
    EndPoints [1] = shot;
    if (EndPoints [0] == null)
        EndPoints [0] = shot;
    if (sunk)
        NullOutTarget ();
}


#====================
#gpt output=============
Java Implementation:

```java
public void shotHit(Point shot, boolean sunk) {
    hitShots.addLast(shot);
    missCount = 0;
    endPoints[1] = shot;
    if (endPoints[0] == null)
        endPoints[0] = shot;
    if (sunk)
        nullOutTarget();
}
```

C Implementation:

```c
void shotHit(Point shot, int sunk) {
    addLast(hitShots, shot);
    missCount = 0;
    endPoints[1] = shot;
    if (endPoints[0] == NULL)
        endPoints[0] = shot;
    if (sunk)
        nullOutTarget();
}
```

Python Implementation:

```python
def shot_hit(shot, sunk):
    hit_shots.append(shot)
    miss_count = 0
    end_points[1] = shot
    if end_points[0] == None:
        end_points[0] = shot
    if sunk:
        null_out_target()
```

Note:
In C, there is no direct way to implement a feature such as the `addLast()` function present in Java. We use a function `addLast()`, which must be implemented separately. 

Also, the Python implementation assumes that `hit_shots`, `miss_count`, `end_points` and `null_out_target()` are all defined or imported before this function, as Python doesn't require you to declare or initialize a variable before using it in a function. Similarly for Java and C, it is assumed that these variables and methods have been declared and defined elsewhere in your code. 

There is no `bool` type in C. Instead, `int` is used where `0` signifies `false` and any non-zero value signifies `true`. 

The Python equivalent of `null` in Java is `None`.

Please also note that Python uses indentation to indicate blocks of code like loops or if statements or function definitions. Make sure to correctly indent your code when using Python.