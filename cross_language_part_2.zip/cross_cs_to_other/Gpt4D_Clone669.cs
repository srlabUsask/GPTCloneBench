#input 
public void RunAll () {
    new Thread (Worker1).Start ();
    new Thread (Worker2).Start ();
    new Thread (Worker3).Start ();
    Console.WriteLine ("All Threads Scheduled to RUN!. ThreadId: {0}", Thread.CurrentThread.ManagedThreadId);
    Console.WriteLine ("Main Thread is waiting for 15 seconds, observe 3 thread behaviour. All threads run once and stopped. Why? Because they call WaitOne() internally. They will wait until signals arrive, down below.");
    Thread.Sleep (15000);
    Console.WriteLine ("1- Main will call ManualResetEvent.Set() in 5 seconds, watch out!");
    Thread.Sleep (5000);
    _manualReset.Set ();
    Thread.Sleep (2000);
    Console.WriteLine ("2- Main will call ManualResetEvent.Set() in 5 seconds, watch out!");
    Thread.Sleep (5000);
    _manualReset.Set ();
    Thread.Sleep (2000);
    Console.WriteLine ("3- Main will call ManualResetEvent.Set() in 5 seconds, watch out!");
    Thread.Sleep (5000);
    _manualReset.Set ();
    Thread.Sleep (2000);
    Console.WriteLine ("4- Main will call ManualResetEvent.Reset() in 5 seconds, watch out!");
    Thread.Sleep (5000);
    _manualReset.Reset ();
    Thread.Sleep (2000);
    Console.WriteLine ("It ran one more time. Why? Even Reset Sets the state of the event to nonsignaled (false), causing threads to block, this will initial the state, and threads will run again until they WaitOne().");
    Thread.Sleep (10000);
    Console.WriteLine ();
    Console.WriteLine ("This will go so on. Everytime you call Set(), ManualResetEvent will let ALL threads to run. So if you want synchronization between them, consider using AutoReset event, or simply user TPL (Task Parallel Library).");
    Thread.Sleep (5000);
    Console.WriteLine ("Main thread reached to end! ThreadId: {0}", Thread.CurrentThread.ManagedThreadId);
}


#====================
#gpt output=============
Java implementation:

```java
public void runAll() {
        new Thread(Worker1::run).start();
        new Thread(Worker2::run).start();
        new Thread(Worker3::run).start();
        System.out.println("All Threads Scheduled to RUN! ThreadId: " + Thread.currentThread().getId());

        try {
            Thread.sleep(15000);
            System.out.println("1- Main will call ManualResetEvent.set() in 5 seconds, watch out!");
            Thread.sleep(5000);
            manualReset.signalAll();
            Thread.sleep(2000);
            System.out.println("2- Main will call ManualResetEvent.set() in 5 seconds, watch out!");
            Thread.sleep(5000);
            manualReset.signalAll();
            Thread.sleep(2000);
            System.out.println("3- Main will call ManualResetEvent.set() in 5 seconds, watch out!");
            Thread.sleep(5000);
            manualReset.signalAll();
            Thread.sleep(2000);
            System.out.println("4- Main will call ManualResetEvent.reset() in 5 seconds, watch out!");
            Thread.sleep(5000);
            manualReset.reset();
            Thread.sleep(2000);
            System.out.println("It ran one more time");
            Thread.sleep(10000);
            System.out.println();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Main thread reached to end! ThreadId: " + Thread.currentThread().getId());
    }
```

The C language does not have native support for threads. Threading can be implemented using libraries like POSIX threads (pthreads), but it's quite complex and beyond the scope of this simple task.

Python implementation:

```python
import time
import threading

def run_all():
    threading.Thread(target=worker1).start()
    threading.Thread(target=worker2).start()
    threading.Thread(target=worker3).start()
    print(f"All Threads Scheduled to RUN. ThreadId: {threading.get_ident()}")
    time.sleep(15)
    print("1- Main will call Event.set in 5 seconds, watch out!")
    time.sleep(5)
    event.set()
    time.sleep(2)
    print("2- Main will call Event.set in 5 seconds, watch out!")
    time.sleep(5)
    event.set()
    time.sleep(2)
    print("3- Main will call Event.set in 5 seconds, watch out!")
    time.sleep(5)
    event.set()
    time.sleep(2)
    print("4- Main will call Event.clear in 5 seconds, watch out!")
    time.sleep(5)
    event.clear()
    time.sleep(2)
    print("It ran one more time.")
    time.sleep(10)
    print("Main thread reached to end! ThreadId: {0}", threading.get_ident())
```