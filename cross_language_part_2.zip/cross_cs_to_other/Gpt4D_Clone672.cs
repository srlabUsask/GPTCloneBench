#input 
private void loadFromFile (String file) {
    foreach (String line in System.IO.File.ReadAllLines (file)) {
        if ((! String.IsNullOrEmpty (line)) && (! line.StartsWith (";")) && (! line.StartsWith ("#")) && (! line.StartsWith ("'")) && (line.Contains ('='))) {
            int index = line.IndexOf ('=');
            String key = line.Substring (0, index).Trim ();
            String value = line.Substring (index + 1).Trim ();
            if ((value.StartsWith ("\"") && value.EndsWith ("\"")) || (value.StartsWith ("'") && value.EndsWith ("'"))) {
                value = value.Substring (1, value.Length - 2);
            }
            try {
                list.Add (key, value);
            }
            catch {
            }
        }
    }
}


#====================
#gpt output=============
In Java:

```java
private void loadFromFile(String file) {
    try (Stream<String> lines = Files.lines(Paths.get(file))) {
        lines.forEach(line -> {
            if (!line.isEmpty() && !line.startsWith(";") && !line.startsWith("#") && !line.startsWith("'") && line.contains("=")){
                int index=line.indexOf('=');
                String key=line.substring(0,index).trim();
                String value=line.substring(index+1).trim();
                if ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) {
                    value=value.substring(1, value.length()-1);
                }
                list.put(key, value);
            }
        });
    } catch (IOException e) {
        e.printStackTrace();
    }
}
```
In C:

```c
void loadFromFile (char* file) {
    FILE* filePointer;
    char line[256];
    char *key, *value;
    int index;

    filePointer = fopen(file, "r");
    
    while (fgets(line, sizeof(line), filePointer)) {
        if (line[0] != '\0' && line[0] != ';' && line[0] != '#' && line[0] != '\'' && strchr(line, '=') != NULL) {
            char* linePointer = line;
            while (*linePointer != '=') {
                linePointer++;
            }
            index = linePointer - line;
            key = strtok(line, "=");
            value = strtok(NULL, "=");
            key[index] = '\0';
            value[index] = '\0';
            key = trim(key);
            value = trim(value);
            if((value[0] == '\"' && value[strlen(value)-1] == '\"') || (value[0] == '\'' && value[strlen(value)-1] == '\'')) {
                memmove(value, value+1, strlen(value)-1);
                value[strlen(value)-2] = '\0';
            }
            list_add(list, key, value);
        }
    }
    
    fclose(filePointer);
}
```
In Python:

```python
def load_from_file(self, file):
    with open(file) as f:
        for line in f:
            if line and not line.startswith((";", "#", "'")) and "=" in line:
                index = line.index("=")
                key = line[:index].strip()
                value = line[index+1:].strip()
                if value[0] == value[-1] and value.startswith(("'", '"')):
                    value = value[1:-1]
                self.dict[key] = value
```
Please adjust according to your specific needs. For instance, the way 'list' is accessed may differ based on your overall code design and your programming language.