#input 
public static bool IsAvailableNetworkActive () {
    if (! System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable ())
        return false;
    NetworkInterface [] interfaces = System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces ();
    return (from face in interfaces
        where face.OperationalStatus == OperationalStatus.Up
        where (face.NetworkInterfaceType != NetworkInterfaceType.Tunnel) && (face.NetworkInterfaceType != NetworkInterfaceType.Loopback)
        where (! (face.Name.ToLower ().Contains ("virtual") || face.Description.ToLower ().Contains ("virtual")))
        select face.GetIPv4Statistics ()).Any (statistics = > (statistics.BytesReceived > 0) && (statistics.BytesSent > 0));
}


#====================
#gpt output=============
Java:

```java
import java.net.*;
import java.util.Enumeration;

public static boolean isAvailableNetworkActive() {
    try {
        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
        while (interfaces.hasMoreElements()) {
            NetworkInterface networkInterface = interfaces.nextElement();
            if (networkInterface.isUp() && !networkInterface.isLoopback()) {
                List<InterfaceAddress> addresses = networkInterface.getInterfaceAddresses();
                for (InterfaceAddress address: addresses) {
                    if (address.getAddress() instanceof Inet4Address) {
                        return true;
                    }
                }
            }
        }
    } catch (SocketException e) {
        e.printStackTrace();
    }
    return false;
}
```

C:

```c
#include <stdio.h>
#include <ifaddrs.h>
#include <netinet/in.h> 
#include <string.h> 
#include <arpa/inet.h>

int isAvailableNetworkActive() {
    struct ifaddrs * ifAddrStruct = NULL;
    struct ifaddrs * ifa = NULL;
    void * tmpAddrPtr = NULL;

    getifaddrs(&ifAddrStruct);

    for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next) {
        if (!ifa->ifa_addr) {
            continue;
        }
        if (ifa->ifa_addr->sa_family == AF_INET) {
            tmpAddrPtr=&((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
            char addressBuffer[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
            return strcmp(addressBuffer, "127.0.0.1") != 0;
        }
    }
    if (ifAddrStruct != NULL)
        freeifaddrs(ifAddrStruct);
    return 0;
}
```

Python:

```python
import psutil

def is_available_network_active():
    faces = psutil.net_if_stats()
    for face in faces:
        if face.isup:
            address = psutil.net_if_addrs()[face.name]
            for addr in address:
                if addr.family == socket.AF_INET:
                    return True
    return False
```