#input 
static void Main (string [] args) {
    Console.Clear ();
    Console.ForegroundColor = ConsoleColor.Gray;
    Dictionary < string, string [] > skins = new Dictionary < string, string [] > ();
    skins.Add ("ahri", new string [] {"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"});
    skins.Add ("leesin", new string [] {"Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"});
    Console.WriteLine ("Conor's Random League of Legends Skin Selector v0.1\r\n\r\n");
    Console.WriteLine ("What champion would you like to select a skin for? \r\nPress enter for a random champion...    ");
    var champion = Console.ReadLine ();
    var rnd = new Random ();
    if (champion.Equals (string.Empty)) {
        var tmpList = Enumerable.ToList (skins.Keys);
        champion = tmpList [rnd.Next (tmpList.Count)];
    } else {
        champion = champion.Trim ().ToLower ();
    }
    Console.Write (string.Format ("Champion {0} Selected \r\n", champion));
    if (skins.ContainsKey (champion)) {
        Console.WriteLine (string.Format ("Your random skin for {0} is: {1}\r\n", champion, skins [champion] [rnd.Next (skins [champion].Length)]));
    } else {
        Console.Clear ();
        Main (args);
    }
}


#====================
#gpt output=============
Here are the code implementations in Java, C and Python.

Java:
```
import java.util.*;

public class Main {
    private static final String[] ACADEMY_SKINS = {"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"};
    private static final String[] LEE_SIN_SKINS = {"Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"};
    private static final HashMap<String, String[]> SKINS = new HashMap<>();

    public static void main(String[] args) {
        SKINS.put("ahri", ACADEMY_SKINS);
        SKINS.put("leesin", LEE_SIN_SKINS);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Conor's Random League of Legends Skin Selector v0.1\n\n");
        System.out.println("What champion would you like to select a skin for? \nPress enter for a random champion...");
        String champion = scanner.nextLine().trim().toLowerCase();
        Random random = new Random();
        if (champion.isEmpty()) {
            Object[] keyset = SKINS.keySet().toArray();
            champion = (String) keyset[random.nextInt(keyset.length)];
        }
        System.out.println(String.format("Champion %s Selected \n", champion));
        if (SKINS.containsKey(champion)) {
            String[] championSkins = SKINS.get(champion);
            System.out.println(String.format("Your random skin for %s is: %s\n", champion, championSkins[random.nextInt(championSkins.length)]));
        } else {
            main(args);
        }
    }
}
```

C: (C does not have native support for Object Oriented Programming and hence, mapping dictionary like data structure is bit complex. It also does not support function overloading etc. Hence the following code is bit complex)

```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

char *skins[2][7] = {
    { "Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar", NULL }, 
    { "Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout" }
};

char *champions[2] = {"ahri", "leesin"};

char* randomSkin(char* champion) {
    int champIndex = 0;
    if(strcmp(champion, "leesin") == 0) champIndex = 1;

    int i = 0, len = 6;
    while(skins[champIndex][i] != NULL) {
        i++;
    }
    srand(time(NULL));
    return skins[champIndex][rand() % len];
}

void main() {
    printf("Conor's Random League of Legends Skin Selector v0.1\n\n");
    printf("What champion would you like to select a skin for?\n");

    char champion[10];
    scanf("%s", champion);

    printf("Champion %s Selected\n", champion);
    printf("Your random skin for %s is: %s\n", champion, randomSkin(champion));
}
```

Python:
```
import random

skins = {
    "ahri": ["Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"],
    "leesin": ["Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"]
}

print("Conor's Random League of Legends Skin Selector v0.1\n\n")
champion = input("What champion would you like to select a skin for? \nPress enter for a random champion...").lower().strip()

if not champion:
    champion = random.choice(list(skins.keys()))

print(f"Champion {champion} Selected \r\n")

if champion in skins.keys():
    print(f"Your random skin for {champion} is: {random.choice(skins[champion])}\r\n")    
else:
    print("Champion not found.")
```
Please note that due to differences in languages, the C and Java versions might not behave identically to the C# version in some edge case scenarios (for instance, how they handle non-existent keys). Please let me know how you want these to be handled if you need them to be identical.