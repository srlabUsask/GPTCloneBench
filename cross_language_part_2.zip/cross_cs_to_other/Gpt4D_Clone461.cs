#input 
public static string CreateZip (string stDirToZip) {
    try {
        DirectoryInfo di = new DirectoryInfo (stDirToZip);
        string stZipPath = di.Parent.FullName + "\\" + di.Name + ".zip";
        CreateZip (stZipPath, stDirToZip);
        return stZipPath;
    }
    catch (Exception) {
        throw;
    }
}


#====================
#gpt output=============
Here's how these pieces of code could be implemented in Java, C and Python.

Java Implementation: (Java does not have a built in zipping function, so you would have to use a library for that)

```java
import java.nio.file.*;
import java.util.zip.*;
import java.io.*;

public static String createZip(String stDirToZip) throws IOException {
    Path srcPath = Paths.get(stDirToZip);
    String stZipPath = srcPath.getParent().toString() + File.separator + srcPath.getFileName() + ".zip";

    try {
      ZipOutputStream zip_out = new ZipOutputStream(new FileOutputStream(stZipPath));
      Files.walkFileTree(srcPath, new SimpleFileVisitor<Path>() {
        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
          zip_out.putNextEntry(new ZipEntry(srcPath.relativize(file).toString()));
          Files.copy(file, zip_out);
          zip_out.closeEntry();
          return FileVisitResult.CONTINUE;
        }
      });
      zip_out.finish();
    } catch(Exception ex) {
      throw new RuntimeException(ex);
    }
    return stZipPath;
}
```

C Implementation: (Note that C it is very rare to manage zipped files natively in C code without using a library. However, you can implement zipping functionality in C by using libraries such as 'zlib' or minizip)

```C 
// Using the minizip library

#include "minizip/zip.h"
#include "dirent.h"
#include "sys/stat.h"

void addFileToZip(zipFile zip, const char* filename) {
    FILE* fp = fopen(filename, "rb");
    fseek(fp, 0, SEEK_END);
    long filesize = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    void* buf = malloc(filesize);
    fread(buf, filesize, 1, fp);
    fclose(fp);

    zipOpenNewFileInZip(zip, filename, NULL, NULL, 0, NULL, 0, NULL, Z_DEFLATED, Z_DEFAULT_COMPRESSION);
    zipWriteInFileInZip(zip, buf, filesize);
    zipCloseFileInZip(zip);

    free(buf);
}

void createZip(const char* directory, const char* zipfilename) {
    DIR* dir = opendir(directory);
    struct dirent* de;
    zipFile zip = zipOpen(zipfilename, 0);

    while((de = readdir(dir))) {
        if ((de->d_type == DT_REG) && strcmp(de->d_name, ".") && strcmp(de->d_name, "..")) {
            char filepath[260];
            snprintf(filepath, 260, "%s/%s", directory, de->d_name);
            addFileToZip(zip, filepath);
        }
    }
    closedir(dir);
    zipClose(zip, NULL);
}
```

Python Implementation:

```python
import zipfile
import os

def create_zip(st_dir_to_zip):
    try:
        st_zip_path = os.path.join(os.path.dirname(st_dir_to_zip), os.path.basename(st_dir_to_zip) + ".zip")
        zipf = zipfile.ZipFile(st_zip_path, 'w', zipfile.ZIP_DEFLATED)
        for root, dirs, files in os.walk(st_dir_to_zip):
            for file in files:
                zipf.write(os.path.join(root, file))
        zipf.close()
        return st_zip_path
    except Exception as e:
        raise e
```