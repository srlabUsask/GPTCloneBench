#input 
static void Main (string [] args) {
    List < double > enteredNubers = new List < double > ();
    Console.WriteLine ("Enter number(s) or 0 to end: ");
    while (true) {
        string userinput = Console.ReadLine ().Trim ();
        if (userinput == "0")
            break;
        double num;
        if (double.TryParse (userinput, out num)) {
            enteredNubers.Add (num);
        } else
            Console.WriteLine ("Wrong input. Please enter number or 0 to end");
    }
    Average (enteredNubers);
    Console.ReadKey ();
}


#====================
#gpt output=============
Java:
```Java
import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Double> enteredNumbers = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number(s) or 0 to end: ");
        while(true) {
            String userInput = scanner.nextLine().trim();
            if(userInput.equals("0")) {
                break;
            }
            try {
                double num = Double.parseDouble(userInput);
                enteredNumbers.add(num);
            } catch(NumberFormatException e) {
                System.out.println("Wrong input. Please enter number or 0 to end");
            }
        }
        average(enteredNumbers);
    }
    public static void average(List<Double> numbers) {
        // your implementation here
    }
}
```

C:
```C
#include <stdio.h>
#include <stdlib.h>

void average(double* numbers, int size) {
    // your implementation here
}

int main() {
    double *numbers = malloc(sizeof(double) * 10);
    int idx = 0;
    printf("Enter number(s) or 0 to end: ");
    while (1) {
        char userInput[256];
        fgets(userInput, sizeof(userInput), stdin);
        if (userInput[0] == '0') {
            break;
        }
        char *end;
        double num = strtod(userInput, &end);
        if (end == userInput) {
            printf("Wrong input. Please enter number or 0 to end\n");
        } else {
            numbers[idx++] = num;
        }
    }
    average(numbers, idx);
    free(numbers);
    return 0;
}
```

Python:
```Python
def average(numbers):
    # your implementation here
    pass

if __name__ == "__main__":
    numbers = []
    print("Enter number(s) or 0 to end: ")
    while True:
        user_input = input().strip()
        if user_input == "0":
            break
        try:
            num = float(user_input)
            numbers.append(num)
        except ValueError:
            print("Wrong input. Please enter number or 0 to end.")
    average(numbers)
```