#input 
static void Main (string [] args) {
    Console.WriteLine ("Enter number(s): ");
    double [] values = new double [3];
    for (int i = 0; i < values.Length; i ++) {
        values [i] = Convert.ToDouble (Console.ReadLine ());
    }
    average (values);
    Console.ReadKey ();
}


#====================
#gpt output=============
Java:

```java
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Enter number(s): ");
        double[] values = new double[3];
        Scanner scan = new Scanner(System.in);
        for (int i = 0; i < values.length; i++) {
            values[i] = scan.nextDouble();
        }
        average(values);
    }

    public static void average(double[] values) {
        double sum = 0.0;
        for (double num : values) {
            sum += num;
        }
        double average = sum / values.length;
        System.out.println("Average is: " + average);
    }
}
```

C:

```c
#include <stdio.h>

void average(double values[], int length) {
    double sum = 0.0;
    for (int i = 0; i < length; i++) {
        sum += values[i];
    }
    double average = sum / length;
    printf("Average is: %.2f\n", average);
}

int main() {
    printf("Enter number(s): \n");
    double values[3];
    for (int i = 0; i < 3; i++) {
        scanf("%lf", &values[i]);
    }
    average(values, 3);
    getchar();
    return 0;
}
```

Python:

```python
def average(values):
    print("Average is: ", sum(values) / len(values))

print("Enter number(s): ")
values = []
for i in range(3):
    values.append(float(input()))
average(values)
```