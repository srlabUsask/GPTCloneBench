#input 
public static int [] RowSums (int [] [] arr2D) {
    int [] sums = new int [arr2D.GetLength (0)];
    int rowSums = 0;
    foreach (int [] arr in arr2D) {
        sums [rowSums] = ArraySum (arr);
        rowSums ++;
    }
    return sums;
}


#====================
#gpt output=============
Java:

```java
public class Test {
    public static void main(String[] args) {
        int[][] arr2D = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int[] sums = rowSums(arr2D);
        for (int sum : sums) {
            System.out.println(sum);
        }
    }

    public static int arraySum(int[] arr) {
        int sum = 0;
        for (int num : arr) {
            sum += num;
        }
        return sum;
    }

    public static int[] rowSums(int[][] arr2D) {
        int[] sums = new int[arr2D.length];
        int index = 0;
        for (int[] arr : arr2D) {
            sums[index] = arraySum(arr);
            index++;
        }
        return sums;
    }
}
```

C:

```c
#include <stdio.h>

void rowSums(int arr2D[][3], int rowSize, int* sums) {
    for (int i = 0; i < rowSize; i++) {
        sums[i] = 0;
        for (int j = 0; j < 3; j++) {
            sums[i] += arr2D[i][j];
        }
    }
}

int main() {
    int arr2D[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int sums[3];
    rowSums(arr2D, 3, sums);
    for (int i = 0; i < 3; i++) {
        printf("%d\n", sums[i]);
    }
    return 0;
}
```

Python:

```python
def row_sums(arr2D):
    return [sum(arr) for arr in arr2D]


arr2D = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(row_sums(arr2D))
```