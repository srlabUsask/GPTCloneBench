#input 
static void Main (string [] args) {
    var EDGES = new List < Edge > ();
    EDGES.Add (new Edge (new Point (5, 50), new Point (20, 100)));
    EDGES.Add (new Edge (new Point (20, 100), new Point (30, 50)));
    EDGES.Add (new Edge (new Point (30, 50), new Point (10, 0)));
    EDGES.Add (new Edge (new Point (5, 50), new Point (30, 50)));
    EDGES.Add (new Edge (new Point (5, 50), new Point (10, 0)));
    EDGES.Add (new Edge (new Point (20, 100), new Point (80, 100)));
    EDGES.Add (new Edge (new Point (10, 0), new Point (80, 100)));
    var POINTS = new List < double [] > (EDGES.Count * 2);
    FillPoints (EDGES, ref POINTS);
    for (int i = 0; i < POINTS.Count; i ++) {
        Console.WriteLine ("{0} {1} {2}", i, POINTS [i] [0], POINTS [i] [1]);
    }
    Console.WriteLine ();
    var edgeIndices = new int [EDGES.Count, 2];
    FillEdges (EDGES, POINTS, ref edgeIndices);
    for (int i = 0; i < edgeIndices.GetLength (0); i ++) {
        Console.WriteLine ("({0}, {1})", edgeIndices [i, 0], edgeIndices [i, 1]);
    }
    Console.ReadKey (true);
}


#====================
#gpt output=============
Java Implementation:

```java
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Edge> EDGES = new ArrayList<>();
        EDGES.add (new Edge (new Point (5, 50), new Point (20, 100)));
        EDGES.add (new Edge (new Point (20, 100), new Point (30, 50)));
        EDGES.add (new Edge (new Point (30, 50), new Point (10, 0)));
        EDGES.add (new Edge (new Point (5, 50), new Point (30, 50)));
        EDGES.add (new Edge (new Point (5, 50), new Point (10, 0)));
        EDGES.add (new Edge (new Point (20, 100), new Point (80, 100)));
        EDGES.add (new Edge (new Point (10, 0), new Point (80, 100)));
        ArrayList<double[]> POINTS = new ArrayList<>(EDGES.size() * 2);
        fillPoints(EDGES, POINTS);
        for (int i = 0; i < POINTS.size(); i++) {
            System.out.printf("%d %.1f %.1f\n",i,POINTS.get(i)[0],POINTS.get(i)[1]);
        }
        int[][] edgeIndices = new int[EDGES.size()][2];
        fillEdges(EDGES, POINTS, edgeIndices);
        for (int[] edgeIndex : edgeIndices) {
            System.out.printf("(%d, %d)\n", edgeIndex[0], edgeIndex[1]);
        }
    }
}
```

Python Implementation:

```python 
EDGES = []
EDGES.append(Edge(Point(5, 50), Point(20, 100)))
EDGES.append(Edge(Point(20, 100), Point(30, 50)))
EDGES.append(Edge(Point(30, 50), Point(10, 0)))
EDGES.append(Edge(Point(5, 50), Point(30, 50)))
EDGES.append(Edge(Point(5, 50), Point(10, 0)))
EDGES.append(Edge(Point(20, 100), Point(80, 100)))
EDGES.append(Edge(Point(10, 0), Point(80, 100)))
POINTS = [None] * (len(EDGES) * 2)
fillPoints(EDGES, POINTS)
for i in range(len(POINTS)):
    print("{} {:.1f} {:.1f}".format(i, POINTS[i][0], POINTS[i][1]))
edgeIndices = [[0]*2 for _ in range(len(EDGES))]
fillEdges(EDGES, POINTS, edgeIndices)
for i in range(len(edgeIndices)):
    print("({}, {})".format(edgeIndices[i][0], edgeIndices[i][1]))
```

C Implementation:
Note: In C, you would need to define `Edge` and `Point` struct, as well as the `fillPoints` and `fillEdges` functions.

```c
#include <stdio.h>
#include <stdlib.h>

int main() {
    struct Edge *EDGES = malloc(7 * sizeof(struct Edge));
    EDGES[0] = createEdge(createPoint(5, 50), createPoint(20, 100));
    … // repeat for the other edges
    double **POINTS = malloc(14 * sizeof(double *));
    fillPoints(EDGES, 7, POINTS);
    for (int i = 0; i < 14; i++) {
        printf("%d %.1f %.1f\n", i, POINTS[i][0], POINTS[i][1]);
    }
    int (*edgeIndices)[2] = malloc(7 * sizeof(*edgeIndices));
    fillEdges(EDGES, 7, POINTS, edgeIndices);
    for (int i = 0; i < 7; i++) {
        printf("(%d, %d)\n", edgeIndices[i][0], edgeIndices[i][1]);
    }
    free(edgeIndices);
    free(POINTS);
    free(EDGES);
    return 0;
}
```