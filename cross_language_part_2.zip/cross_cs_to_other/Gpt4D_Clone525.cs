#input 
static void Main (string [] args) {
    var sum = 0;
    foreach (var number in GetEvenFibonacciSeries ()) {
        if (sum + number > 4000000)
            break;
        sum += number;
    }
    Console.WriteLine (sum);
}


#====================
#gpt output=============
Java:

```java
public static void main(String[] args) {
    int sum = 0;
    int n1 = 0;
    int n2 = 1;
    while (true) {
        int number = n1 + n2;
        n1 = n2;
        n2 = number;
        if (number % 2 == 1 || sum + number > 4000000)
            break;
        sum += number;
    }
    System.out.println(sum);
}
```

C:

```c
#include <stdio.h>

int main(void) {
    int sum = 0;
    int n1 = 0;
    int n2 = 1;
    while (1) {
        int number = n1 + n2;
        n1 = n2;
        n2 = number;
        if (number % 2 == 1 || sum + number > 4000000)
            break;
        sum += number;
    }
    printf("%d\n", sum);
    return 0;
}
```

Python:

```python
def main():
    sum = 0
    n1 = 0
    n2 = 1
    while True:
        number = n1 + n2
        n1 = n2
        n2 = number
        if number % 2 == 1 or sum + number > 4000000:
            break
        sum += number
    print(sum)

if __name__ == "__main__":
    main()
```