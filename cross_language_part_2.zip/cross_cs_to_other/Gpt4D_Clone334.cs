#input 
public static bool init_access (string file_path) {
    if (File.Exists (file_path)) {
        int counter = 0;
        foreach (string line in File.ReadAllLines (file_path)) {
            counter ++;
            Console.WriteLine (counter + " " + line);
        }
        return true;
    }
    return false;
}


#====================
#gpt output=============
Java:

```Java
import java.io.*;
import java.util.*;

public static boolean init_access(String filePath) {
    File file = new File(filePath);
    if(file.exists()) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            int counter = 0;
            while ((line = br.readLine()) != null) {
                counter++;
                System.out.println(counter + " " + line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
    return false;
}
```

C:

```C
#include <stdio.h>

int init_access(char *file_path) {
    FILE *file = fopen(file_path, "r");
    if(file != NULL) {
        char line[256];
        int counter = 0;
        while (fgets(line, sizeof(line), file)) {
            counter++;
            printf("%d %s", counter, line);
        }
        fclose(file);
        return 1;
    }
    return 0;
}
```

Python:

```Python
import os

def init_access(file_path):
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            lines = file.readlines()
            for i, line in enumerate(lines, start=1):
                print(f"{i} {line}")
        return True
    return False
```