#input 
static void Main () {
    int total = 0;
    var vowels = new HashSet < char > {'a', 'e', 'i', 'o', 'u'};
    Console.WriteLine ("Enter a Sentence");
    string sentence = Console.ReadLine ().ToLower ();
    for (int i = 0; i < sentence.Length; i ++) {
        if (vowels.Contains (sentence [i])) {
            total ++;
        }
    }
    Console.WriteLine ("Your total number of vowels is: {0}", total);
    Console.ReadLine ();
}


#====================
#gpt output=============
Java Implementation:
```java
import java.util.*;

public class Main {
    public static void main(String[] args) {
        int total = 0;
        Set<Character> vowels = new HashSet<>(Arrays.asList('a', 'e', 'i', 'o', 'u'));
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a Sentence");
        String sentence = scanner.nextLine().toLowerCase();

        for (int i = 0; i < sentence.length(); i++) {
            if (vowels.contains(sentence.charAt(i))) {
                total++;
            }
        }
        System.out.println("Your total number of vowels is: " + total);
    }
}
```

C Implementation:
```c
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    char vowels[] = "aeiou";
    char sentence[256];
    int total = 0;

    printf("Enter a Sentence\n");
    fgets(sentence, 256, stdin);
    for (int i = 0; i < strlen(sentence); i++) {
        sentence[i] = tolower(sentence[i]);
        if (strchr(vowels, sentence[i]) != NULL) {
            total++;
        }
    }
    printf("Your total number of vowels is: %d\n", total);
    return 0;
}
```

Python Implementation:
```python
vowels = set('aeiou')
total = 0
print("Enter a Sentence")
sentence = input().lower()
for i in range(len(sentence)):
    if sentence[i] in vowels:
        total += 1
print("Your total number of vowels is: %d" % total)
```