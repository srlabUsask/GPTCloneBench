#input 
public static void Main () {
    try {
        Console.WriteLine ("Before throwing");
        throw new Exception ("Exception!");
    }
    finally {
        Console.WriteLine ("In finally");
        Console.ReadLine ();
    }
}


#====================
#gpt output=============
Java Implementation:

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Before throwing");
            throw new Exception("Exception!");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.out.println("In finally");
        }
    }
}

C Implementation (Note that C does not have a try-catch-finally block or an equivalent, so we can't throw an exception in C like we can in Java or Python):

#include <stdio.h>

int main() {
    printf("Before throwing\n");
    printf("Exception!\n");
    printf("In finally\n");
    return 0;
}

Python Implementation:

def main():
    try:
        print("Before throwing")
        raise Exception("Exception!")
    except:
        pass
    finally:
        print("In finally")

main()