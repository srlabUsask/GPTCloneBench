#input 
private bool IsTableSame (DataTable t1, DataTable t2) {
    if (t1 == null)
        return false;
    if (t2 == null)
        return false;
    if (t1.Rows.Count != t2.Rows.Count)
        return false;
    if (t1.Columns.Count != t2.Columns.Count)
        return false;
    if (t1.Columns.Cast < DataColumn > ().Any (dc = > ! t2.Columns.Contains (dc.ColumnName))) {
        return false;
    }
    for (int i = 0; i <= t1.Rows.Count - 1; i ++) {
        if (t1.Columns.Cast < DataColumn > ().Any (dc1 = > t1.Rows [i] [dc1.ColumnName].ToString () != t2.Rows [i] [dc1.ColumnName].ToString ())) {
            return false;
        }
    }
    return true;
}


#====================
#gpt output=============
Java:

```
import java.util.*;
import java.sql.*;

private boolean isTableSame (ResultSet t1, ResultSet t2) throws SQLException {
    if (t1 == null || t2 == null) return false;
    ResultSetMetaData metaData1 = t1.getMetaData();
    ResultSetMetaData metaData2 = t2.getMetaData();
    if (metaData1.getColumnCount() != metaData2.getColumnCount()) return false;
    for (int i=1; i<=metaData1.getColumnCount(); i++) {
        if (!metaData1.getColumnName(i).equals(metaData2.getColumnName(i))) return false;
    }
    while(t1.next()){
        t2.next();
        for (int i=1; i<=metaData1.getColumnCount(); i++) {
            if (!t1.getString(i).equals(t2.getString(i))) return false;
        }
    }
    return t2.next() == false;
}
```

Note: There is no perfect way to compare the data tables in C as in Java or Python. 

Python:

```
import pandas as pd

def is_table_same(t1, t2):
    if t1 is None or t2 is None: 
        return False
    if t1.shape != t2.shape: 
        return False
    if not (t1.columns == t2.columns).all(): 
        return False    
    if not (t1.dtypes == t2.dtypes).all(): 
        return False
    return t1.equals(t2)
```