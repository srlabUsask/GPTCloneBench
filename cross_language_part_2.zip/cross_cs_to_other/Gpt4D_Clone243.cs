#input 
public void ShotHit (Point shot, bool sunk) {
    HitShots.AddLast (shot);
    MissCount = 0;
    EndPoints [1] = shot;
    if (EndPoints [0] == null)
        EndPoints [0] = shot;
    if (sunk)
        NullOutTarget ();
}


#====================
#gpt output=============
Java:
```java
public void shotHit(Point shot, boolean sunk) {
    hitShots.addLast(shot);
    missCount = 0;
    endPoints[1] = shot;
    if (endPoints[0] == null)
        endPoints[0] = shot;
    if (sunk)
        nullOutTarget();
}
```

C:
```c
void shotHit(Point shot, bool sunk) {
    addLast(hitShots, shot);
    missCount = 0;
    endPoints[1] = shot;
    if (endPoints[0] == NULL)
        endPoints[0] = shot;
    if (sunk)
        nullOutTarget();
}
```

Python:
```python
def shot_hit(self, shot, sunk):
    self.hit_shots.append(shot)
    self.miss_count = 0
    self.end_points[1] = shot
    if self.end_points[0] is None:
        self.end_points[0] = shot
    if sunk:
        self.null_out_target()
```

**Note**: In the C code snippet, it is assumed that the `addLast` method is available and handles adding elements to the end of a list. As standard C does not have a linked list data structure and related methods like addLast(), it's a pseudo-like C code. Also, it assumes `nullOutTarget()` is a function in the same scope. 

In Python, it's assumed to be used in a class method, as your given code seems to use object-oriented programming. If your code runs in the global namespace, replace `self.` with the name of your class, or otherwise restructure your code.

Java version is very similar to C# version in your question. The true/false value in C# is `bool`, while in Java it's `boolean`.