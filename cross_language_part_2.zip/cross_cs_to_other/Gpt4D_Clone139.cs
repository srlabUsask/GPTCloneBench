#input 
static void Main (string [] args) {
    string Path = @"C:\Abhishek\Documents";
    string filePath = @"C:\Abhishek\Documents.txt";
    bool isDirExists = Directory.Exists (Path);
    bool isFileExists = File.Exists (filePath);
    if (isDirExists) {
        Console.WriteLine ("Directory Exists");
    } else {
        Console.WriteLine ("Directory does not exists");
    }
    if (isFileExists) {
        Console.WriteLine ("File Exists");
    } else {
        Console.WriteLine ("File does not exists");
    }
    Console.ReadKey ();
}


#====================
#gpt output=============
Java:

import java.io.File;
public class Main {
    public static void main(String args[]) {
        File dir = new File("C:\\Abhishek\\Documents");
        boolean isDirExists = dir.exists() && dir.isDirectory();
        File file = new File("C:\\Abhishek\\Documents.txt");
        boolean isFileExists = file.exists() && file.isFile();
        if(isDirExists) {
            System.out.println("Directory Exists");
        } else {
            System.out.println("Directory does not exists");
        }
        if(isFileExists) {
            System.out.println("File Exists");   
        } else {
            System.out.println("File does not exists");
        }
    }
}

C:

#include<stdio.h>
#include<dirent.h>
int main() {
    DIR *dir = opendir("C:\\Abhishek\\Documents");
    FILE *file = fopen("C:\\Abhishek\\Documents.txt", "r");
    if (dir) {
        printf("Directory Exists\n");
        closedir(dir);
    } else {
        printf("Directory does not exists\n");
    }
    if (file) {
        printf("File Exists\n");
        fclose(file);
    } else {
        printf("File does not exists\n");
    }
    return 0;
}

Python:

import os
dir_path = "C:\\Abhishek\\Documents"
file_path = "C:\\Abhishek\\Documents.txt"
if os.path.exists(dir_path) and os.path.isdir(dir_path):
    print("Directory Exists")
else:
    print("Directory does not exists")
if os.path.exists(file_path) and os.path.isfile(file_path):
    print("File Exists")
else:
    print("File does not exists")