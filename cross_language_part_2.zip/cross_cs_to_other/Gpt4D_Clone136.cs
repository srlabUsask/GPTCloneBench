#input 
static void Main (string [] args) {
    authenticator auth = new authenticator ();
    string login = "hello";
    string pass = "12345";
    if (auth.CheckPassword (login, pass))
        Console.Write ("Access granted");
    else
        Console.Write ("Wrong login or password");
}


#====================
#gpt output=============
For Java:

```java
public static void main(String[] args) {
    Authenticator auth = new Authenticator();
    String login = "hello";
    String pass = "12345";
    if (auth.checkPassword(login, pass))
        System.out.println("Access granted");
    else
        System.out.println("Wrong login or password");
}
```

In C:

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    Authenticator *auth = newAuthenticator();
    char login[] = "hello";
    char pass[] = "12345";
    if (checkPassword(auth, login, pass))
        printf("Access granted");
    else
        printf("Wrong login or password");
    return 0;
}
```

In Python:

```python
def main():
    auth = Authenticator()
    login = "hello"
    pass = "12345"
    if auth.check_password(login, pass):
        print("Access granted")
    else:
        print("Wrong login or password")

if __name__ == "__main__":
    main()
```
Please ensure `Authenticator` and `check_password` method are correctly defined and implemented in all the three codes.