#input 
public static int convertNum (String n1, String n2) {
    int num1 = 0;
    int num2 = 0;
    int result = 0;
    try {
        num1 = Int32.Parse (n1);
        num2 = Int32.Parse (n2);
        result = sum (num1, num2);
        return result;
    }
    catch (FormatException) {
        MessageBox.Show ("Input only numbers.");
        return result;
    }
}


#====================
#gpt output=============
Java:
```java
public static int convertNum(String n1, String n2) {
    int num1 = 0;
    int num2 = 0;
    int result = 0;
    try {
        num1 = Integer.parseInt (n1);
        num2 = Integer.parseInt (n2);
        result = num1 + num2;
        return result;
    }
    catch (NumberFormatException e) {
        System.out.println("Input only numbers.");
        return result;
    }
}
```
C:
```c
#include<stdio.h>
#include<stdlib.h>

int convertNum(const char* n1, const char* n2) {
    int num1 = 0;
    int num2 = 0;
    int result = 0;
    char *ptr;
    long ret;

    ret = strtol(n1, &ptr, 10);
    if (*ptr == '\0') num1 = ret;
    else {
        printf("Input only numbers.");
        return result;
    }

    ret = strtol(n2, &ptr, 10);
    if (*ptr == '\0') num2 = ret;
    else {
        printf("Input only numbers.");
        return result;
    }

    result = num1 + num2;
    return result;
}
```
Python:
```python
def convertNum(n1, n2):
    result = 0
    try:
        num1 = int(n1)
        num2 = int(n2)
        result = num1 + num2
        return result
    except ValueError:
        print("Input only numbers.")
        return result
```