#input 
static List < string > Perm (string input, int M) {
    var chars = input.ToCharArray ();
    int N = chars.Length;
    List < List < char > > result = new List < List < char > > ();
    for (int i = 0; i < Math.Pow (2, N); i ++) {
        if (BitCount (i) == M) {
            List < char > line = new List < char > ();
            for (int j = 0; j < N; j ++) {
                if (((i > > j) & 1) == 1) {
                    line.Add (chars [j]);
                }
            }
            result.Add (line);
        }
    }
    return result.Select (l = > String.Join ("", l)).OrderBy (s = > s).ToList ();
}


#====================
#gpt output=============
In Java:

```java
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public static List<String> perm(String input, int M) {
    char[] chars = input.toCharArray();
    int N = chars.length;
    List<List<Character>> result = new ArrayList<>();
    for (int i = 0; i < Math.pow(2, N); i++) {
        if (Integer.bitCount(i) == M) {
            List<Character> line = new ArrayList<>();
            for (int j = 0; j < N; j++) {
                if (((i >> j) & 1) == 1) {
                    line.add(chars[j]);
                }
            }
            result.add(line);
        }
    }
    List<String> strResult = new ArrayList<>();
    for (List<Character> line : result) {
        String lineAsString = "";
        for (Character c : line) {
            lineAsString += c;
        }
        strResult.add(lineAsString);
    }
    Collections.sort(strResult);
    return strResult;
}
```

In C:

```c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int bit_count(int number) {
    int count = 0;
    while (number) {
        count += number & 1;
        number >>= 1;
    }
    return count;
}

char** perm(char* input, int M, int* returnSize) {
    int N = strlen(input);
    int pow2N = 1<<N;
    char** result = (char**)malloc(pow2N*sizeof(char*));
    *returnSize = 0;
    for (int i = 0; i < pow2N; i++) {
        if (bit_count(i) == M) {
            result[(*returnSize)] = (char*)malloc(N+1);
            int idx = 0;
            for (int j = 0; j < N; j++) {
                if (((i >> j) & 1) == 1) {
                    result[(*returnSize)][idx++] = input[j];
                }
            }
            result[(*returnSize)][idx] = '\0';
            (*returnSize)++;
        }
    }
    return result;
}
```

In Python:

```python
import itertools

def perm(input, M):
    result = []
    for combinations in itertools.combinations(sorted(input), M):
        result.append(''.join(combinations))
    return result
```