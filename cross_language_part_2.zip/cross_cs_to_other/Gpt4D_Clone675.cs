#input 
static IEnumerable < IEnumerable < T > > Partition < T > (this IEnumerable < T > source, int size) {
    int count = 0;
    T [] group = null;
    foreach (T item in source) {
        if (group == null)
            group = new T [size];
        group [count ++] = item;
        if (count == size) {
            yield return group;
            group = null;
            count = 0;
        }
    }
    if (count > 0) {
        Array.Resize (ref group, count);
        yield return group;
    }
}


#====================
#gpt output=============
Java implementation:
```java
public static <T> Iterable<List<T>> partition(Iterable<T> source, int size) {
    Iterator<T> sourceIterator = source.iterator();
    List<List<T>> result = new ArrayList<>();

    while (sourceIterator.hasNext()) {
        List<T> group = new ArrayList<>();
        for (int i = 0; i < size && sourceIterator.hasNext(); i++) {
            group.add(sourceIterator.next());
        }
        result.add(group);
    }

    return result;
}
```

Python implementation:
```python
def partition(source, size) :
    return (source[i : i + size] for i in range(0, len(source), size))
```

C implementation:
```c
#include <stdlib.h>
#include <string.h>

typedef struct {
    void **items;
    int size;
} Group;

Group **partition(void **source, int sourceSize, int size, int *resultSize) {
    *resultSize = (sourceSize + size - 1) / size;
    Group **result = (Group**)malloc(*resultSize * sizeof(Group*));

    for (int i = 0; i < *resultSize; i++) {
        result[i] = (Group*)malloc(sizeof(Group));
        int groupSize = ((i + 1) * size > sourceSize) ? sourceSize % size : size;
        result[i]->items = (void**)malloc(groupSize * sizeof(void*));
        result[i]->size = groupSize;
        memcpy(result[i]->items, &source[i * size], groupSize * sizeof(void*));
    }

    return result;
}
```
(Note: The C code creates an array of arrays (`Group` struct), because C doesn't have a built-in `IEnumerable` like C# does.)