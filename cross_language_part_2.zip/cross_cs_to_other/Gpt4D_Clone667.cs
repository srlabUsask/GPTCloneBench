#input 
public static void WriteLog (string strLog) {
    StreamWriter log;
    FileStream fileStream = null;
    DirectoryInfo logDirInfo = null;
    FileInfo logFileInfo;
    string logFilePath = "C:\\Logs\\";
    logFilePath = logFilePath + "Log-" + System.DateTime.Today.ToString ("MM-dd-yyyy") + "." + "txt";
    logFileInfo = new FileInfo (logFilePath);
    logDirInfo = new DirectoryInfo (logFileInfo.DirectoryName);
    if (! logDirInfo.Exists)
        logDirInfo.Create ();
    if (! logFileInfo.Exists) {
        fileStream = logFileInfo.Create ();
    } else {
        fileStream = new FileStream (logFilePath, FileMode.Append);
    }
    log = new StreamWriter (fileStream);
    log.WriteLine (strLog);
    log.Close ();
}


#====================
#gpt output=============
Sure, here are the implementations in Java, C and Python:

JAVA:
```java
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        String strLog = "Log Message";
        writeLog(strLog);
    }

    public static void writeLog(String strLog) {
        File dir = new File("C:\\logs\\");
        if (!dir.exists()) dir.mkdirs();
        String logFileName = "Log-" + new SimpleDateFormat("MM-dd-yyyy").format(new Date()) + ".txt";
        try {
            BufferedWriter out = new BufferedWriter(
                    new FileWriter("C:\\logs\\" + logFileName, true));
            out.write(strLog);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
```

C:
```c
#include<stdio.h>

void writeLog(char* strLog){
    FILE* file;
    file = fopen("log.txt", "a");
    if(file == NULL) printf("File could not be opened");
    else {
        fprintf(file, "%s\n",strLog);
        fclose(file);
    }
}

int main() {
    char strLog[50] = "Log Message";
    writeLog(strLog);
    return 0;
}
```

PYTHON:
```python
from datetime import date
import os

def write_log(str_log):
    log_dir = "C:\\Logs\\"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    log_file_path = os.path.join(log_dir, "Log-" + date.today().strftime("%m-%d-%Y") + ".txt")
    with open(log_file_path, "a") as log_file:
        log_file.write(str_log + "\n")

if __name__ == "__main__":
    write_log("Log Message")
```
Please note that the C code does not take into account the current date for the file name, nor does it create directories since these features are not straightforward in C compared to higher-level languages like Java and Python. You can use external libraries to implement these features, but it is beyond the scope of this answer.