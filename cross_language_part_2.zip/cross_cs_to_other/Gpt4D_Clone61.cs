#input 
static bool Check2DArray (int [,] data, int [,] find) {
    int dataLen = data.Length;
    int findLen = find.Length;
    for (int i = 0; i < dataLen; i ++) {
        int dataX = i % data.GetLength (0);
        int dataY = i / data.GetLength (0);
        bool okay = true;
        for (int j = 0; j < findLen && okay; j ++) {
            int findX = j % find.GetLength (1);
            int findY = j / find.GetLength (1);
            int checkedX = findX + dataX;
            int checkedY = findY + dataY;
            if (checkedX >= data.GetLength (0) || checkedY >= data.GetLength (1)) {
                okay = false;
                break;
            }
            okay = data [dataY + findY, dataX + findX] == find [findY, findX];
        }
        if (okay)
            return true;
    }
    return false;
}


#====================
#gpt output=============
Here are the implementations for Java, C and Python.

Java:

```java
public static boolean check2DArray(int[][] data, int[][] find) {
    int dataLen = data.length * data[0].length;
    int findLen = find.length * find[0].length;
    for (int i = 0; i < dataLen; i++) {
        int dataX = i % data[0].length;
        int dataY = i / data[0].length;
        boolean okay = true;
        for (int j = 0; j < findLen && okay; j++) {
            int findX = j % find[0].length;
            int findY = j / find[0].length;
            int checkedX = findX + dataX;
            int checkedY = findY + dataY;
            if (checkedX >= data[0].length || checkedY >= data.length) {
                okay = false;
                break;
            }
            okay = data[dataY + findY][dataX + findX] == find[findY][findX];
        }
        if (okay)
            return true;
    }
    return false;
}
```

C:

```c
#include <stdbool.h>

bool check2DArray(int[100][100] data, int[100][100] find, int dataLen, int findLen) {
    for (int i = 0; i < dataLen; i++) {
        int dataX = i % 100;
        int dataY = i / 100;
        bool okay = true;
        for (int j = 0; j < findLen && okay; j++) {
            int findX = j % 100;
            int findY = j / 100;
            int checkedX = findX + dataX;
            int checkedY = findY + dataY;
            if (checkedX >= 100 || checkedY >= 100) {
                okay = false;
                break;
            }
            okay = data[dataY + findY][dataX + findX] == find[findY][findX];
        }
        if (okay)
            return true;
    }
    return false;
}
```

Python:

```python
def check2DArray(data, find):
    dataLen = len(data) * len(data[0])
    findLen = len(find) * len(find[0])
    for i in range(dataLen):
        dataX = i % len(data[0])
        dataY = i // len(data[0])
        okay = True
        for j in range(findLen) and okay:
            findX = j % len(find[0])
            findY = j // len(find[0])
            checkedX = findX + dataX
            checkedY = findY + dataY
            if checkedX >= len(data[0]) or checkedY >= len(data):
                okay = False
                break
            okay = data[dataY + findY][dataX + findX] == find[findY][findX]
        if okay:
            return True
    return False
```