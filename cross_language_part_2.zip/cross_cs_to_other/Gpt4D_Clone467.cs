#input 
public static bool IsAnagram (string s1, string s2) {
    if (string.IsNullOrEmpty (s1) || string.IsNullOrEmpty (s2))
        return false;
    if (s1.Length != s2.Length)
        return false;
    foreach (char c in s2) {
        int ix = s1.IndexOf (c);
        if (ix >= 0)
            s1 = s1.Remove (ix, 1);
        else
            return false;
    }
    return string.IsNullOrEmpty (s1);
}


#====================
#gpt output=============
Java implementation:

```java
public static boolean isAnagram (String s1, String s2) {
    if (s1 == null || s2 == null || s1.length() != s2.length())
        return false;
    for (char c : s2.toCharArray()) {
        int ix = s1.indexOf(c);
        if (ix >= 0)
            s1 = s1.substring(0, ix) + s1.substring(ix + 1);
        else
            return false;
    }
    return s1.isEmpty();
}
```

C implementation:

```c
#include <stdbool.h>
#include <string.h>

bool isAnagram(char *s1, char *s2) {
    int len1 = strlen(s1);
    int len2 = strlen(s2);
    if (len1 != len2)
        return false;
    for (int i = 0; i < len2; i++) {
        char *p = strchr(s1, s2[i]);
        if (p)
            *p = '\0';
        else
            return false;
    }
    return true;
}
```

Python implementation:

```python
def is_anagram(s1, s2):
    if len(s1) != len(s2):
        return False
    for c in s2:
        if c in s1:
            s1 = s1.replace(c, '', 1)
        else:
            return False
    return len(s1) == 0
```