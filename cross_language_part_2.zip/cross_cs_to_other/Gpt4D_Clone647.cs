#input 
public static int Count < TSource > (this IEnumerable < TSource > source) {
    checked {
        if (source == null) {
            throw Error.ArgumentNull ("source");
        }
        ICollection < TSource > collection = source as ICollection < TSource >;
        if (collection != null) {
            return collection.Count;
        }
        ICollection collection2 = source as ICollection;
        if (collection2 != null) {
            return collection2.Count;
        }
        int num = 0;
        using (IEnumerator < TSource > enumerator = source.GetEnumerator ())
        {
            while (enumerator.MoveNext ()) {
                num ++;
            }
        } return num;
    }
}


#====================
#gpt output=============
Java:

```java
public static <T> int count(Iterable<T> source) {
    if (source == null) {
        throw new IllegalArgumentException("source");
    }
    if (source instanceof Collection) {
        return ((Collection)source).size();
    }
    int num = 0;
    for (Object item : source) {
        num ++;
    }
    return num;
}
```

C:

```c
#include <stdlib.h>
struct IEnumerable{
    void** items;
    int count;
};


int count(struct IEnumerable* source){
    if (source == NULL) {
        fprintf(stderr, "source");
        exit(1);
    }
    return source->count;
}
```

Python:

```python
def count(source):
    if source is None:
        raise ValueError('source')
    return len(source)
```