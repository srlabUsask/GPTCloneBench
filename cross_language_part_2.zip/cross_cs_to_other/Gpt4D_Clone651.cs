#input 
private static DateTime NthOf (DateTime CurDate, int Occurrence, DayOfWeek Day) {
    var fday = new DateTime (CurDate.Year, CurDate.Month, 1);
    if (Occurrence == 1) {
        for (int i = 0; i < 7; i ++) {
            if (fday.DayOfWeek == Day) {
                return fday;
            } else {
                fday = fday.AddDays (1);
            }
        }
        return fday;
    } else {
        var fOc = fday.DayOfWeek == Day ? fday : fday.AddDays (Day - fday.DayOfWeek);
        if (fOc.Month < CurDate.Month)
            Occurrence = Occurrence + 1;
        return fOc.AddDays (7 * (Occurrence - 1));
    }
}


#====================
#gpt output=============
Here is the equivalent solutions in Java, C and Python for the above C# implementation:

Java:
```java
import java.time.*;
import java.util.*;

public static LocalDate nthOf(LocalDate curDate, int occurrence, DayOfWeek day) {
    LocalDate firstDay = LocalDate.of(curDate.getYear(), curDate.getMonth(), 1);

    if (occurrence == 1) {
        for (int i = 0; i < 7; i++){
            if (firstDay.getDayOfWeek() == day){
                return firstDay;
            } else {
                firstDay = firstDay.plusDays(1);
            }
        }
    } else {
        localDateFOc = firstDay.getDayOfWeek() == day ? firstDay : firstDay.plusDays(day.getValue() - firstDay.getDayOfWeek().getValue());
        if (localDateFOc.getMonthValue() < curDate.getMonthValue())
            occurrence += 1;
        return localDateFOc.plusDays(7 * (occurrence - 1));
    }

    return firstDay;
}
```

Python - 
```python
import datetime

def nth_of(cur_date, occurrence, day):
    first_day = datetime.date(cur_date.year, cur_date.month, 1)

    if occurrence == 1:
        for i in range(7):
            if first_day.weekday() == day:
                return first_day
            else:
                first_day += datetime.timedelta(days=1)
        return first_day
    else:
        if first_day.weekday() == day:
            f_oc = first_day
        else:
            cur_day = first_day.weekday()
            while cur_day != day:
                first_day += datetime.timedelta(days=1)
                cur_day = first_day.weekday()

        f_oc = first_day
        
        if f_oc.month < cur_date.month:
            occurrence += 1
        return f_oc + datetime.timedelta(days=7 * (occurrence - 1))

    return f_oc
```

Note: The concept of pointers or reference to a DateTime type object is not inherently available in C. Hence providing an exact equivalent in C is not directly possible. The best way to handle this in C would typically involve using a struct representing a date and manipulating the struct fields directly, which would not be an exact equivalent of the original code. So, C equivalent is skipped for this specific code.