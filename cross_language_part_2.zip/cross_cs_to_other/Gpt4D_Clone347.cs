#input 
static void Main (string [] args) {
    string [] ahri = {"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"};
    string [] leeSin = {"Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"};
    Console.WriteLine ("Conor's Random League of Legends Skin Selector v0.1");
    Console.WriteLine (" ");
    Console.WriteLine (" ");
    Random rnd = new Random ();
    Console.ForegroundColor = ConsoleColor.Gray;
    Console.WriteLine ("What champion would you like to select a skin for?..    ");
    string champion = Console.ReadLine ();
    Console.Write ("Press the 'enter' key for a random champion..     ");
    string question = Console.ReadLine ();
    if (champion == "ahri") {
        int randomNumber = rnd.Next (ahri.Length - 1);
        Console.WriteLine (ahri [randomNumber]);
    } else {
        int randomNumber = rnd.Next (leeSin.Length - 1);
        Console.WriteLine (leeSin [randomNumber]);
    }
}


#====================
#gpt output=============
Java:

public static void main(String[] args) {
    String[] ahri = {"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"};
    String[] leeSin = {"Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"};
    System.out.println("Conor's Random League of Legends Skin Selector v0.1\n\n");
    Scanner sc = new Scanner(System.in);
    System.out.println("What champion would you like to select a skin for?..");
    String champion = sc.nextLine();
    System.out.print("\nPress the 'enter' key for a random champion..");
    String question = sc.nextLine();
    Random rnd = new Random();
    if (champion.equals("ahri")) {
        int randomNumber = rnd.nextInt(ahri.length);
        System.out.println(ahri[randomNumber]);
    } else {
        int randomNumber = rnd.nextInt(leeSin.length);
        System.out.println(leeSin[randomNumber]);
    }
}

C:

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define MAX 100

int main(){
   srand(time(0));
   char* ahri[]={"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"};
   char* leesin[]={"Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"};
   char champion[MAX];
   printf("Conor's Random League of Legends Skin Selector v0.1\n\n");
   printf("What champion would you like to select a skin for?..\n");
   fgets(champion, MAX, stdin);
   printf("Press the 'enter' key for a random champion..\n");
   getch();
   if(strcmp(champion, "ahri\n") == 0){
      int randomNumber=rand()%(6-1+1)+1;
      printf("%s", ahri[randomNumber]);
   }
   else{
      int randomNumber=rand()%(7-1+1)+1;
      printf("%s", leesin[randomNumber]);
   }
  return 0;
}

Python:

import random

def main():
    ahri = ["Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"]
    lee_sin = ["Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"]
    print("Conor's Random League of Legends Skin Selector v0.1\n\n")
    champion = input("What champion would you like to select a skin for?..    ")
    question = input("Press the 'enter' key for a random champion..     ")
    if champion == "ahri":
        random_number = random.randint(0, len(ahri) - 1)
        print(ahri[random_number])
    else:
        random_number = random.randint(0, len(lee_sin) - 1)
        print(lee_sin[random_number])

if __name__ == "__main__":
    main()