#input 
static void Main (string [] args) {
    Stopwatch sw = new Stopwatch ();
    const int NUM_ITEMS = 10000;
    const int NUM_LOOPS2 = 1000000000;
    List < int > lst = new List < int > (NUM_ITEMS);
    IList < int > ilst = lst;
    for (int i = 0; i < NUM_ITEMS; i ++) {
        lst.Add (i);
    }
    int count = 0;
    sw.Reset ();
    sw.Start ();
    for (int i = 0; i < NUM_LOOPS2; i ++) {
        count = lst.Count;
    }
    sw.Stop ();
    Console.Out.WriteLine ("Took " + (sw.ElapsedMilliseconds) + "ms - 1.");
    sw.Reset ();
    sw.Start ();
    for (int i = 0; i < NUM_LOOPS2; i ++) {
        count = ilst.Count;
    }
    sw.Stop ();
    Console.Out.WriteLine ("Took " + (sw.ElapsedMilliseconds) + "ms - 2.");
}


#====================
#gpt output=============
Java:

```
public static void main(String[] args) {
    java.util.List<Integer> lst = new java.util.ArrayList<>();
    final int NUM_ITEMS = 10000;
    final int NUM_LOOPS2 = 1000000000;

    for(int i = 0; i < NUM_ITEMS; i++) {
        lst.add(i);
    }
    int count = 0;
    long startTime = System.currentTimeMillis();
    for(int i = 0; i < NUM_LOOPS2; i++) {
        count = lst.size();
    }
    long endTime = System.currentTimeMillis();
    System.out.println("Took "+ (endTime - startTime) + "ms - 1");
    
    startTime = System.currentTimeMillis();
    for(int i = 0; i < NUM_LOOPS2; i++) {
        count = lst.size();
    }
    endTime = System.currentTimeMillis();
    System.out.println("Took "+ (endTime - startTime) + "ms - 2");
}
```

C:

```
#include <stdio.h>
#include <time.h>

#define NUM_ITEMS 10000
#define NUM_LOOPS2 1000000000

int main() {
    clock_t start, end;
    int lst[NUM_ITEMS];
    int count = 0;

    for(int i = 0; i < NUM_ITEMS; i++) {
        lst[i] = i;
    }

    start = clock();
    for(int i = 0; i < NUM_LOOPS2; i++) {
        count = sizeof(lst) / sizeof(lst[0]);
    }
    end = clock();
    printf("Took %ldms - 1\n", ((long)end - start) / (CLOCKS_PER_SEC / 1000));

    start = clock();
    for(int i = 0; i < NUM_LOOPS2; i++) {
        count = sizeof(lst) / sizeof(lst[0]);
    }
    end = clock();
    printf("Took %ldms - 2\n", ((long)end - start) / (CLOCKS_PER_SEC / 1000));

    return 0;
}
```

Python:

```
import time

NUM_ITEMS = 10000
NUM_LOOPS2 = 1000000000
lst = []

for i in range(NUM_ITEMS):
    lst.append(i)
    
count = 0
start_time = time.time()
for i in range(NUM_LOOPS2):
    count = len(lst)

print("Took %s ms - 1." % ((time.time() - start_time)*1000))
start_time = time.time()

for i in range(NUM_LOOPS2):
    count = len(lst)
    
print("Took %s ms - 2." % ((time.time() - start_time)*1000))
```