#input 
static void HasRows (SqlConnection connection) {
    using (connection)
    using (SqlCommand command = new SqlCommand ("SELECT CategoryID, CategoryName FROM Categories;", connection))
    {
        connection.Open ();
        using (SqlDataReader reader = command.ExecuteReader ())
        {
            if (reader.HasRows) {
                while (reader.Read ()) {
                    Console.WriteLine ("{0}\t{1}", reader.GetInt32 (0), reader.GetString (1));
                }
            } else {
                Console.WriteLine ("No rows found.");
            }
            reader.Close ();
        }}}


#====================
#gpt output=============
Java Implementation:
```Java
import java.sql.*;

public class Main {
    public static void main(String[] args) {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=yourDB";
        String username = "username";
        String password = "password";
        
        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT CategoryID, CategoryName FROM Categories");) {
            
            if (!resultSet.next()) {
                System.out.println("No rows found.");
            } else {
                do {
                    System.out.println(resultSet.getInt("CategoryID") + "\t" + resultSet.getString("CategoryName"));
                } while (resultSet.next());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
```
C Implementation (using MySQL client):

```C
#include <mysql.h>
#include <stdio.h>

int main() {
  MYSQL *connection = mysql_init(NULL);
  MYSQL_RES *result;
  MYSQL_ROW row;
  
  mysql_real_connect(connection, "localhost", "username", "password", "yourDB", 0, NULL, 0);
  
  mysql_query(connection, "SELECT CategoryID, CategoryName FROM Categories");
  result = mysql_use_result(connection);
  
  while ((row = mysql_fetch_row(result)) != NULL)
      printf("%s\t%s\n", row[0], row[1]);
  
  if (!row) printf("No rows found.\n");
  
  mysql_free_result(result);
  mysql_close(connection);
  
  return 0;
}
```
Python Implementation:
```Python
import pymysql

connection = pymysql.connect(host='localhost', user='username', password='password', db='yourDB')
cursor = connection.cursor()

cursor.execute("SELECT CategoryID, CategoryName FROM Categories")

rows = cursor.fetchall()

if not rows:
    print("No rows found.")
else:
    for row in rows:
        print(f"{row[0]}\t{row[1]}")

cursor.close()
connection.close()
```