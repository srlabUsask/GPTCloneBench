#input 
static List < Info > RecursiveScan2 (string directory) {
    IntPtr INVALID_HANDLE_VALUE = new IntPtr (- 1);
    WIN32_FIND_DATAW findData;
    IntPtr findHandle = INVALID_HANDLE_VALUE;
    var info = new List < Info > ();
    try {
        findHandle = FindFirstFileW (directory + @"\*", out findData);
        if (findHandle != INVALID_HANDLE_VALUE) {
            do
                {
                    if (findData.cFileName == "." || findData.cFileName == "..")
                        continue;
                    string fullpath = directory + (directory.EndsWith ("\\") ? "" : "\\") + findData.cFileName;
                    bool isDir = false;
                    if ((findData.dwFileAttributes & FileAttributes.Directory) != 0) {
                        isDir = true;
                        info.AddRange (RecursiveScan2 (fullpath));
                    }
                    info.Add (new Info () {CreatedDate = findData.ftCreationTime.ToDateTime (), ModifiedDate = findData.ftLastWriteTime.ToDateTime (), IsDirectory = isDir, Path = fullpath});
                } while (FindNextFile (findHandle, out findData));
        }
    }
    finally {
        if (findHandle != INVALID_HANDLE_VALUE)
            FindClose (findHandle);
    }
    return info;
}


#====================
#gpt output=============
Java Implementation:

```java
import java.nio.file.*;
import java.util.*;
import java.io.*;

public class Main {
    static List<Info> RecursiveScan2(String directory) {
        File folder = new File(directory);
        File[] listOfFiles = folder.listFiles();
        List<Info> info = new ArrayList<>();

        for (File file : listOfFiles) {
            if (file.isFile()) {
                Info data = new Info(file.lastModified(), file.lastModified(), false, file.getAbsolutePath());
                info.add(data);
            } else if (file.isDirectory()) {
                info.addAll(RecursiveScan2(file.getPath()));
                Info data = new Info(file.lastModified(), file.lastModified(), true, file.getAbsolutePath());
                info.add(data);
            }
        }
        return info;
    }
}

class Info {
    long CreatedDate;
    long ModifiedDate;
    boolean IsDirectory;
    String Path;

    Info(long createdDate, long modifiedDate, boolean isDirectory, String path) {
        this.CreatedDate = createdDate;
        this.ModifiedDate = modifiedDate;
        this.IsDirectory = isDirectory;
        this.Path = path;
    }
}
```

C Implementation:

```c
#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    time_t CreatedDate;
    time_t ModifiedDate;
    int IsDirectory;
    char Path[260];
} Info;

Info* RecursiveScan2(char *directory, Info* info, int* length) {
    DIR *dir;
    struct dirent *ent;
    struct stat buf;

    if ((dir = opendir(directory)) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0)
                continue;
            char fullpath[260];
            sprintf(fullpath, "%s/%s", directory, ent->d_name);
            stat(fullpath, &buf);
            info = (Info*)realloc(info, (*length + 1) * sizeof(Info));
            info[*length].CreatedDate = buf.st_ctime;
            info[*length].ModifiedDate = buf.st_mtime;
            info[*length].IsDirectory = S_ISDIR(buf.st_mode);
            strcpy(info[*length].Path, fullpath);
            (*length)++;
            if (info[*length-1].IsDirectory)
                info = RecursiveScan2(fullpath, info, length);
        }
        closedir(dir);
    }
    return info;
}
```

Python Implementation:

```python
import os
import time
from collections import namedtuple

Info = namedtuple('Info', 'CreatedDate ModifiedDate IsDirectory Path')

def RecursiveScan2(directory):
    info = []
    for filename in os.listdir(directory):
        if filename == "." or filename == "..":
            continue
        fullpath = os.path.join(directory, filename)
        stat = os.stat(fullpath)
        isDir = os.path.isdir(fullpath)
        info.append(Info(time.ctime(stat.st_ctime), time.ctime(stat.st_mtime), isDir, fullpath))
        if isDir:
            info += RecursiveScan2(fullpath)
    return info
```
Please provide "Info" object structure/data. It is required to provide the exact solution. I have created Info object with my judgement. Also please update the code if required and use it accordingly.