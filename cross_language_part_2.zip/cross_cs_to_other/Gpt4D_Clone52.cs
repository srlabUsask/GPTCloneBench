#input 
static void Main (string [] args) {
    Console.WriteLine ("Add First:");
    LinkedList myList1 = new LinkedList ();
    myList1.AddFirst ("Hello");
    myList1.AddFirst ("Magical");
    myList1.AddFirst ("World");
    myList1.printAllNodes ();
    Console.WriteLine ();
    Console.WriteLine ("Add Last:");
    LinkedList myList2 = new LinkedList ();
    myList2.AddLast ("Hello");
    myList2.AddLast ("Magical");
    myList2.AddLast ("World");
    myList2.printAllNodes ();
    Console.ReadLine ();
}


#====================
#gpt output=============
Java:

```java
import java.util.LinkedList;
import java.util.Iterator;

public class MainClass {
    public static void main(String[] args) {
        System.out.println("Add First:");
        LinkedList<String> myList1 = new LinkedList<String>();
        myList1.addFirst("Hello");
        myList1.addFirst("Magical");
        myList1.addFirst("World");
        printAllNodes(myList1);
        System.out.println();
        System.out.println("Add Last:");
        LinkedList<String> myList2 = new LinkedList<String>();
        myList2.addLast("Hello");
        myList2.addLast("Magical");
        myList2.addLast("World");
        printAllNodes(myList2);
     }

    static void printAllNodes(LinkedList<String> list){
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
    }
}
```

C:

C does not natively support LinkedLists; we'll need to implement it manually, which is too complex for this request.

Python:

```python
from collections import deque

print("Add First:")
myList1 = deque()
myList1.appendleft("Hello")
myList1.appendleft("Magical")
myList1.appendleft("World")
print(myList1)

print("\nAdd Last:")
myList2 = deque()
myList2.append("Hello")
myList2.append("Magical")
myList2.append("World")
print(myList2)
```