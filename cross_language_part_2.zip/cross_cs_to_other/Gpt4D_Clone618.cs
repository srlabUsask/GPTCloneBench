#input 
public static int IndexOf (byte [] haystack, byte [] needle) {
    if (needle.Length == 0) {
        return 0;
    }
    int [] charTable = MakeCharTable (needle);
    int [] offsetTable = MakeOffsetTable (needle);
    for (int i = needle.Length - 1; i < haystack.Length;) {
        int j;
        for (j = needle.Length - 1; needle [j] == haystack [i]; -- i, -- j) {
            if (j == 0) {
                return i;
            }
        }
        i += Math.Max (offsetTable [needle.Length - 1 - j], charTable [haystack [i]]);
    }
    return - 1;
}


#====================
#gpt output=============
Java:

```java
public static int indexOf(byte[] haystack, byte[] needle) {
    if (needle.length == 0) {
        return 0;
    }
    int[] charTable = makeCharTable(needle);
    int[] offsetTable = makeOffsetTable(needle);
    
    for (int i = needle.length - 1; i < haystack.length;) {
        int j;
        for (j = needle.length - 1; needle[j] == haystack[i]; --i, --j) {
            if (j == 0) {
                return i;
            }
        }
        i += Math.max(offsetTable[needle.length - 1 - j], charTable[haystack[i]]);
    }
    return -1;
}
```

C:

```c
int indexOf(unsigned char *haystack, unsigned char *needle, int *charTable, int *offsetTable) {
    int needle_length = strlen(needle);
    if (needle_length == 0) {
        return 0;
    }
    
    makeCharTable(needle, charTable);
    makeOffsetTable(needle, offsetTable);

    int i;
    for (i = needle_length - 1; i < strlen(haystack);) {
        int j;
        for (j = needle_length - 1; needle[j] == haystack[i]; --i, --j) {
            if (j == 0) {
                return i;
            }
        }
        i += maximum(offsetTable[needle_length - 1 - j], charTable[haystack[i]]);
    }
    return -1;
}
```
Note: Depending on your C environment, you may need to implement `maximum`, `strlen`, `makeCharTable` and `makeOffsetTable` functions yourself.

Python:

```python
def index_of(haystack, needle):
    if len(needle) == 0:
        return 0
    char_table = make_char_table(needle)
    offset_table = make_offset_table(needle)

    i = len(needle) - 1
    while i < len(haystack):
        j = len(needle) - 1
        while needle[j] == haystack[i]:
            if j == 0:
                return i
            i -= 1
            j -= 1
        i += max(offset_table[len(needle) - 1 - j], char_table[ord(haystack[i])])
    return -1
```

Note: `make_char_table()` and `make_offset_table()` methods are assumed to be previously defined. Python doesn't have a built-in 'byte' class, so regular strings are used instead. If you are handling byte-data, consider using bytearray or bytes data types in Python 3.x .