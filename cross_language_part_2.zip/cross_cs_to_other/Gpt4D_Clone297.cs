#input 
static void Main (string [] args) {
    demo obj = new demo ();
    int n = 5;
    string uname, pass;
    Console.ForegroundColor = ConsoleColor.Green;
    label1 : Console.WriteLine ("\n");
    Console.WriteLine ("Enter username");
    uname = Console.ReadLine ();
    Console.WriteLine ("Enter Password");
    pass = Console.ReadLine ();
    obj.setName (uname);
    obj.setPass (pass);
    if (obj.getName () == "niit" && obj.getPass () == "1234") {
        Console.WriteLine ("welcome");
    } else {
        if (n < 1) {
            Console.Clear ();
            Console.WriteLine ("ScreenLock");
        } else {
            Console.WriteLine ("\n Invalid");
            Console.WriteLine ("\n To try again enter y");
            string yes = Console.ReadLine ();
            Console.WriteLine ("\n");
            if (yes == "y") {
                while (n >= 1) {
                    Console.Write (n + " Tries left");
                    n = -- n;
                    goto label1;
                }
            }
        }
    }
    Console.ReadKey ();
}


#====================
#gpt output=============
// Java implementation
```java
import java.util.Scanner;

class Demo {
    private String name;
    private String pass;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}

public class Main {
    public static void main(String[] args) {
        Demo obj = new Demo();
        int n = 5;
        String uname, pass;
        Scanner sc = new Scanner(System.in);

        while(true) {
            System.out.println("Enter username");
            uname = sc.nextLine();
            System.out.println("Enter Password");
            pass = sc.nextLine();
            obj.setName(uname);
            obj.setPass(pass);

            if (obj.getName().equals("niit") && obj.getPass().equals("1234")) {
                System.out.println("welcome");
                break;
            } else {
                if (n < 1) {
                    System.out.println("ScreenLock");
                    break;
                } else {
                    System.out.println("\n Invalid");
                    System.out.println("\n To try again enter y");
                    String yes = sc.nextLine();
                    if (yes.equals("y")) {
                        n--;
                        System.out.println(n + " Tries left");
                    } else {
                        break;
                    }
                }
            }
        }
    }
}
```

// C implementation
```c
#include <stdio.h>
#include <string.h>

struct demo {
    char name[50];
    char pass[50];
};

void setName(char name[], struct demo* p) {
    strcpy(p->name, name);
}

void setPass(char pass[], struct demo* p) {
    strcpy(p->pass, pass);
}

int main() {
    struct demo obj;
    int n = 5;
    char uname[50], pass[50], yes[2];

    while (1) {
        printf("Enter username\n");
        scanf("%s", uname);
        printf("Enter password\n");
        scanf("%s", pass);
        setName(uname, &obj);
        setPass(pass, &obj);

        if (strcmp(obj.name, "niit") == 0 && strcmp(obj.pass, "1234") == 0) {
            printf("Welcome\n");
            break;
        } else {
            if (n < 1) {
                printf("ScreenLock\n");
                break;
            } else {
                printf("\n Invalid");
                printf("\n To try again enter y");
                scanf("%s", yes);
                if (strcmp(yes, "y") == 0) {
                    n--;
                    printf("%d Tries left", n);
                } else {
                    break;
                }
            }
        }
    }

    return 0;
}
```

// Python implementation
```python
class Demo:
    def __init__(self, name="", passw=""):
        self.name = name
        self.passw = passw

def main():
    n = 5
    obj = Demo()
    while True:
        uname = input("Enter username: ")
        passw = input("Enter password: ")
        obj.name = uname
        obj.passw = passw

        if obj.name == 'niit' and obj.passw == '1234':
            print("Welcome")
            break
        else:
            if n < 1:
                print("ScreenLock")
                break
            else:
                print("\nInvalid")
                print("\nTo try again enter y")
                yes = input()
                if yes == 'y':
                    n -= 1
                    print(f"{n} Tries left")
                else:
                    break

if __name__ == "__main__":
    main()
```