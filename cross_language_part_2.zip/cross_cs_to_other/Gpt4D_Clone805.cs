#input 
public Boolean CheckIPValid (String strIP) {
    string [] arrOctets = strIP.Split ('.');
    if (arrOctets.Length != 4)
        return false;
    byte obyte = 0;
    foreach (string strOctet in arrOctets)
        if (! byte.TryParse (strOctet, out obyte))
            return false;
    return true;
}


#====================
#gpt output=============
JAVA:
```java
public boolean checkIPValid(String strIP) {
    String[] arrOctets = strIP.split("\\.");
    if (arrOctets.length != 4)
        return false;
    for (String strOctet : arrOctets)
        try {
            byte b = Byte.parseByte(strOctet);
        } catch (NumberFormatException nfe) {
            return false;
        }
    return true;
}
```
C:
```c
#include <stdlib.h>
#include <string.h>

int checkIPValid(char* strIP) {
    char* strOctet;
    char del[] = ".";
    strOctet = strtok(strIP, del);
    int count = 0;
    while( strOctet != NULL ) {
        count++;
        char* tail;
        int num = strtol(strOctet, &tail, 10);
        if (tail == strOctet || *tail != '\0' || (num < 0 || num > 255)) return 0;
        strOctet = strtok(NULL, del);
    }
    if (count != 4) return 0;
    return 1;
}
```
PYTHON:
```python
def check_ip_valid(str_ip):
    arr_octets = str_ip.split('.')
    if len(arr_octets) != 4:
        return False
    for str_octet in arr_octets:
        if not str_octet.isdigit() or not 0 <= int(str_octet) <= 255:
            return False
    return True
```