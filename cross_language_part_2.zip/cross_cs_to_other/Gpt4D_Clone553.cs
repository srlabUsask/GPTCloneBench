#input 
public void TestList () {
    cvList.Add (new ColumnAndValue () {ColumnName = "Column 1", ColumnValue = "Value 1"});
    cvList.Add (new ColumnAndValue () {ColumnName = "Column 2", ColumnValue = "Value 2"});
    cvList.Add (new ColumnAndValue () {ColumnName = "Column 3", ColumnValue = "Value 3"});
    cvList.Add (new ColumnAndValue () {ColumnName = "Column 4", ColumnValue = "Value 4"});
    List < string > c1 = cvList.Select (c = > c.ColumnName).ToList ();
    foreach (object obj in c1) {
        Console.WriteLine (obj.ToString ());
    }
}


#====================
#gpt output=============
Sorry, the given code seems to be using an object and a syntax that does not naturally exist in C, Java, or Python. But based on its functionality, here's an equivalent code in these three languages:

Java:

```java
class ColumnAndValue {
    String columnName;
    String columnValue;
    
    public ColumnAndValue(String columnName, String columnValue) {
        this.columnName = columnName;
        this.columnValue = columnValue;
    }

    public String getColumnName() {
        return columnName;
    }
}

public void testList () {
    List<ColumnAndValue> cvList = new ArrayList<>();
    cvList.add(new ColumnAndValue("Column 1", "Value 1"));
    cvList.add(new ColumnAndValue("Column 2", "Value 2"));
    cvList.add(new ColumnAndValue("Column 3", "Value 3"));
    cvList.add(new ColumnAndValue("Column 4", "Value 4"));

    for (ColumnAndValue cv : cvList) {
        System.out.println(cv.getColumnName());
    }
}
```

Python:

```python
class ColumnAndValue:
    def __init__(self, column_name, column_value):
        self.column_name = column_name
        self.column_value = column_value

def test_list():
    cv_list = []
    cv_list.append(ColumnAndValue("Column 1", "Value 1"))
    cv_list.append(ColumnAndValue("Column 2", "Value 2"))
    cv_list.append(ColumnAndValue("Column 3", "Value 3"))
    cv_list.append(ColumnAndValue("Column 4", "Value 4"))
    for cv in cv_list:
        print(cv.column_name)
```

Please note that the C language does not support object-oriented principles like classes and objects. It also does not have built-in support for lists(arrays in C are of fixed size and cannot be expanded after declaration), there are no default string type, and dynamic arrays require complex memory management. You'll need to leverage structures and manually handle memory for implementing similar functionality in C.