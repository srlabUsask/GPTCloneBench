#input 
public static bool CompareProperties (T newObject, T oldObject) {
    if (Equals (newObject, oldObject)) {
        return true;
    }
    PropertyInfo [] newProps = newObject.GetType ().GetProperties ();
    PropertyInfo [] oldProps = oldObject.GetType ().GetProperties ();
    if (newProps.Length != oldProps.Length) {
        return false;
    }
    foreach (PropertyInfo newProperty in newProps) {
        PropertyInfo oldProperty = oldProps.SingleOrDefault (pi = > pi.Name == newProperty.Name);
        if (oldProperty == null)
            return false;
        object newval = newProperty.GetValue (newObject, null);
        object oldval = oldProperty.GetValue (oldObject, null);
        if (! Equals (newval, oldval))
            return false;
    }
    return true;
}


#====================
#gpt output=============
Java Version:
```java
import java.lang.reflect.Field;
public static boolean compareProperties(Object newObject, Object oldObject) throws IllegalAccessException {
    boolean isEqual = newObject.equals(oldObject);
    if(isEqual) {
        return true;
    }
    Field[] newProps = newObject.getClass().getFields();
    Field[] oldProps = oldObject.getClass().getFields();
    if(newProps.length != oldProps.length) {
        return false;
    }
    for (Field newProperty : newProps) {
        isEqual = false;
        for (Field oldProperty : oldProps) {
            if (oldProperty.getName().equals(newProperty.getName())) {
                Object newVal = newProperty.get(newObject);
                Object oldVal = oldProperty.get(oldObject);
                if (newVal.equals(oldVal)) {
                    isEqual = true;
                    break;
                }
            }
        }
        if(!isEqual) return false;  
    }
    return true;
}
```

C Version:
C does not support reflection like characteristics and hence the implementation like above in C is not possible.

Python Version:
```python
def compare_properties(new_object, old_object):
    if new_object == old_object:
        return True
    new_props = vars(new_object)
    old_props = vars(old_object)
    if len(new_props) != len(old_props):
        return False
    for new_property, new_value in new_props.items():
        if old_props.get(new_property) != new_value:
            return False
    return True
```