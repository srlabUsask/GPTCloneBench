#input 
static void Main () {
    LinkedList < int > LL = new LinkedList < int > ();
    if (! LL.Contain (0))
        Console.WriteLine ("0 is not exist.");
    LL.Print ();
    LL.Add (0);
    LL.Add (1);
    LL.Add (2);
    LL.Add (2);
    if (LL.Contain (0))
        Console.WriteLine ("0 is exist.");
    LL.Print ();
    LL.Delete (0);
    LL.Delete (2);
    if (! LL.Delete (0))
        Console.WriteLine ("0 is not exist.");
    LL.Print ();
    Console.ReadLine ();
}


#====================
#gpt output=============
Java Code:
```java
import java.util.LinkedList;

public class Main{
    public static void main(String[] args) {
        LinkedList<Integer> LL = new LinkedList<>();
        if (!LL.contains(0))
             System.out.println("0 is not exist.");
        System.out.println(LL);
        LL.add(0);
        LL.add(1);
        LL.add(2);
        LL.add(2);
        if (LL.contains(0))
            System.out.println("0 is exist.");
        System.out.println(LL);
        LL.removeFirstOccurrence(0);
        LL.removeFirstOccurrence(2);
        if (!LL.remove(0))
            System.out.println("0 is not exist.");
        System.out.println(LL);
    }
}
```
C Code:
```c
#include <stdio.h> 
#include <stdlib.h>

struct Node { 
    int data; 
    struct Node* next; 
}; 

void printList(struct Node* n) { 
    while (n != NULL) { 
        printf(" %d ", n->data); 
        n = n->next; 
    } 
} 

int main() { 
    struct Node* head = NULL; 
    struct Node* second = NULL; 
    struct Node* third = NULL; 

    head = (struct Node*)malloc(sizeof(struct Node)); 
    second = (struct Node*)malloc(sizeof(struct Node)); 
    third = (struct Node*)malloc(sizeof(struct Node)); 

    head->data = 1; 
    head->next = second; 

    second->data = 2; 
    second->next = third; 

    third->data = 3; 
    third->next = NULL; 

    printList(head); 

    return 0; 
} 
```
Python Code:
```python
class Node:
    def __init__(self, data=None):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = Node()

    def append(self, data):
        new_node = Node(data)
        cur = self.head
        while cur.next!=None:
            cur = cur.next
        cur.next = new_node

    def display(self):
        elements = []
        cur_node = self.head
        while cur_node.next!=None:
            cur_node = cur_node.next
            elements.append(cur_node.data)
        print(elements)

    def delete(self, data):
        cur = self.head
        if cur and cur.data == data:
            self.head = cur.next
            cur = None
            return
        prev = None
        while cur and cur.data != data:
            prev = cur
            cur = cur.next
        if cur is None:
            return
        prev.next = cur.next
        cur = None

LL = LinkedList()
LL.display()
LL.append(0)
LL.append(1)
LL.append(2)
LL.append(2)
LL.display()
LL.delete(0)
LL.delete(2)
LL.display()
```