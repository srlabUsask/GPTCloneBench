#input 
private void DrawLines (Graphics g) {
    g.Clear (BackColor);
    int y = - editBox.ScrollPos.Y;
    for (var i = 1; i < _lines + 1; i ++) {
        var size = g.MeasureString (i.ToString (), Font);
        g.DrawString (i.ToString (), Font, new SolidBrush (LineNumberColor), new Point (3, y));
        y += Font.Height + 2;
    }
    var max = (int) g.MeasureString ((_lines + 1).ToString (), Font).Width + 6;
    editBox.Location = new Point (max, 0);
    editBox.Size = new Size (ClientRectangle.Width - max, ClientRectangle.Height);
}


#====================
#gpt output=============
In Java:

```Java
private void DrawLines (Graphics g) {
    g.clearRect(0, 0, getWidth(), getHeight());
    int y = - editBox.getVerticalScrollBar().getValue();
    for (int i = 1; i < _lines + 1; i ++) {
        FontMetrics fm = g.getFontMetrics();
        int width = fm.stringWidth(Integer.toString(i));
        g.drawString(Integer.toString(i), 3, y + fm.getAscent());
        y += fm.getHeight() + 2;
    }
    int max = g.getFontMetrics().stringWidth(Integer.toString(_lines + 1)) + 6;
    editBox.setLocation(max, 0);
    editBox.setSize(getWidth() - max, getHeight());
}
```

In C:

```C
void DrawLines (HWND hwnd, HDC hdc) {
    RECT rc;
    GetClientRect(hwnd, &rc);
    FillRect(hdc, &rc, (HBRUSH) (COLOR_WINDOW+1));
    int y = - GetScrollPos(hwnd, SB_VERT);
    HFONT hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    SelectObject(hdc, hFont);
    for (int i = 1; i < _lines + 1; i++) {
        SIZE size;
        char text[10];
        sprintf(text, "%d", i);
        GetTextExtentPoint32(hdc, text, strlen(text), &size);
        TextOut(hdc, 3, y, text, strlen(text));
        y += size.cy + 2;
    }
    char text[10];
    sprintf(text, "%d", _lines + 1);
    SIZE size;
    GetTextExtentPoint32(hdc, text, strlen(text), &size);
    MoveWindow(editBox, size.cx + 6, 0, rc.right - size.cx - 6, rc.bottom, TRUE);
}
```

In Python:

```Python
def DrawLines(self, g):
    g.Clear(self.BackColor)
    y = - self.editBox.ScrollPos[1]
    for i in range(1, self._lines + 1):
        size = g.MeasureString(str(i), self.Font)
        g.DrawString(str(i), self.Font, Brush(self.LineNumberColor), (3, y))
        y += self.Font.Height + 2
    max = int(g.MeasureString(str(self._lines + 1), self.Font).Width + 6)
    self.editBox.Location = max, 0
    self.editBox.Size = self.ClientRectangle.Width - max, self.ClientRectangle.Height
```