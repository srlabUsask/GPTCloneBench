#input 
private void AddNode (int valueToBeInserted, Node current) {
    if (valueToBeInserted < current.value) {
        if (current.left == null)
            current.left = new Node (valueToBeInserted);
        else
            AddNode (valueToBeInserted, current.left);
    }
    if (valueToBeInserted > current.value) {
        if (current.right == null)
            current.right = new Node (valueToBeInserted);
        else
            AddNode (valueToBeInserted, current.right);
    }
}


#====================
#gpt output=============
Java Implementation:

```
class Node {
    int value;
    Node left, right;

    Node(int value) {
        this.value = value;
        left = null;
        right = null;
    }
}

private void AddNode(int valueToBeInserted, Node current) {
    if (valueToBeInserted < current.value) {
        if (current.left == null)
            current.left = new Node(valueToBeInserted);
        else
            AddNode(valueToBeInserted, current.left);
    }
    if (valueToBeInserted > current.value) {
        if (current.right == null)
            current.right = new Node(valueToBeInserted);
        else
            AddNode(valueToBeInserted, current.right);
    }
}
```

C Implementation:

```
struct Node {
    int value;
    struct Node* left;
    struct Node* right;
};

struct Node* newNode(int value) {
    struct Node* node = (struct Node*)malloc(sizeof(struct Node));

    node->value = value;
    node->left = NULL;
    node->right = NULL;

    return (node);
}

void AddNode(int valueToBeInserted, struct Node* current) {
    if (valueToBeInserted < current->value) {
        if (current->left == NULL) 
            current->left = newNode(valueToBeInserted);
        else
            AddNode(valueToBeInserted, current->left);
    }
    if (valueToBeInserted > current->value) {
        if (current->right == NULL) 
            current->right = newNode(valueToBeInserted);
        else
            AddNode(valueToBeInserted, current->right);
    }
}
```

Python Implementation:

```
class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

def AddNode(valueToBeInserted, current):
    if valueToBeInserted < current.value:
        if current.left is None:
            current.left = Node(valueToBeInserted)
        else:
            AddNode(valueToBeInserted, current.left)
    if valueToBeInserted > current.value:
        if current.right is None:
            current.right = Node(valueToBeInserted)
        else:
            AddNode(valueToBeInserted, current.right)
```