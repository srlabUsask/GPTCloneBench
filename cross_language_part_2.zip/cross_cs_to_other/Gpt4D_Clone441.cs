#input 
public static String dt2JSON (DataTable dt) {
    var rows = new List < Object > ();
    foreach (DataRow row in dt.Rows) {
        var rowData = new Dictionary < string, object > ();
        foreach (DataColumn col in dt.Columns)
            rowData [col.ColumnName] = row [col];
        rows.Add (rowData);
    }
    var js = new JavaScriptSerializer ();
    return js.Serialize (new {rows = rows});
}


#====================
#gpt output=============
Here is the translation of the function dt2JSON in Java, C and Python.

For Java:

```java
import java.util.*;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;

public static String dt2JSON (DataTable dt) {
    JSONArray rows = new JSONArray();
    for (DataRow row : dt.getRows()) {
        JSONObject rowData = new JSONObject();
        for (DataColumn col : dt.getColumns())
            rowData.put(col.getColumnName(), row.get(col));
        rows.add (rowData);
    }
    JSONObject js = new JSONObject();
    js.put("rows", rows);
    return js.toJSONString();
}
```

For C:

```c
#include <json-c/json.h>
#include <string.h>

char* dt2JSON (DataTable dt) {
    json_object *jobj = json_object_new_object();
    json_object *jarray = json_object_new_array();
    for(int i=0;i<sizeof(dt.Rows)/sizeof(dt.Rows[0]);i++){
        json_object *jinner = json_object_new_object();
        for(int j=0;j<sizeof(dt.Columns)/sizeof(dt.Columns[0]);j++){
            json_object *temp = json_object_new_string(dt.Rows[i].Columns[j]);
            json_object_object_add(jinner,dt.Columns[j].ColumnName,temp);
        }
        json_object_array_add(jarray, jinner);
    }
    json_object_object_add(jobj,"rows",jarray);
    return strdup(json_object_to_json_string(jobj));
}
```

For Python:

```python
import json

def dt2JSON(dt):
    rows = []
    for row in dt.Rows:
        rowData = {}
        for col in dt.Columns:
            rowData[col.ColumnName] = row[col]
        rows.append(rowData)
    return json.dumps({"rows": rows})
```

Please note that these translations are done according to your provided function and may not perform exactly the same due to differences in standard libraries and implementations of DataTable, DataRow and DataColumn in the respective languages. Also, you might need to install and/or import necessary libraries (like json-c for C and json-simple for Java) to make the above code work.