#input 
protected void btnAdd_Click (object sender, EventArgs e) {
    for (Int32 i = lstAvailableColors.Items.Count; i >= 0; i --) {
        ListItem item = lstAvailableColors.Items [i];
        if (item.Selected) {
            lstSelectedColors.Items.Add (item);
            lstAvailableColors.Items.Remove (item);
        }
    }
}


#====================
#gpt output=============
The provided code appears to be in C#, which is used primarily in web development with frameworks like ASP.NET. Here are the closest translations to Java, C, and Python, though the context will differ as they don't have equivalent event handling and item list management is handled differently in these languages.

Java:

```java
// Assuming lstAvailableColors, lstSelectedColors: ArrayList<String>
for (int i = lstAvailableColors.size() - 1; i >= 0; i--) {
    String item = lstAvailableColors.get(i);
    if (condition) { // substitute your 'selected' condition here
        lstSelectedColors.add(item);
        lstAvailableColors.remove(i);
    }
}
```
 
C (using LLC-struct and somewhat complex as it doesn't have native support for these operations):

```c
// Assuming lstAvailableColors, lstSelectedColors: LinkedList of strings
for (ListElement *e = lstAvailableColors->head;
     e != NULL;
     e = e->next) {
    char *item = e->data;
    if (condition) { // substitute your 'selected' condition here
        list_remove_elem(lstAvailableColors,item);
        list_insert(lstSelectedColors,item);
    }
}
```

Python:

```python
# Assuming lstAvailableColors, lstSelectedColors: list of strings
for item in lstAvailableColors[::-1]:
    if condition: # substitute your 'selected' condition here
        lstSelectedColors.append(item)
        lstAvailableColors.remove(item)
```

In all the implementations above, replace 'condition' with the condition which selects an item. In GUI-based applications, it would be a property (like 'IsSelected') of the item itself, but such concept is not applicable in console-based programming.