#input 
public static IEnumerable < T > TakeLast < T > (this IEnumerable < T > input, int count) {
    if (count <= 0)
        yield break;
    var inputList = input as IList < T >;
    if (inputList != null) {
        int last = inputList.Count;
        int first = last - count;
        if (first < 0)
            first = 0;
        for (int i = first; i < last; i ++)
            yield return inputList [i];
    } else {
        T [] buffer = new T [count];
        int index = 0;
        count = 0;
        foreach (T item in input) {
            buffer [index] = item;
            index = (index + 1) % buffer.Length;
            count ++;
        }
        if (count < buffer.Length)
            index = 0;
        else
            count = buffer.Length;
        while (count > 0) {
            yield return buffer [index];
            index = (index + 1) % buffer.Length;
            count --;
        }
    }
}


#====================
#gpt output=============
Java:

```java
import java.util.*;

public static <T> List<T> takeLast(List<T> input, int count) {
    if (count <= 0 || input.isEmpty())
        return new ArrayList<T>();

    int first = Math.max(0, input.size() - count);
    return input.subList(first, input.size());
}
```

C:

```c
#include <stdlib.h>

int* takeLast(int* input, int count, int inputSize, int* outputSize) {
    if (count <= 0 || inputSize == 0) {
        *outputSize = 0;
        return malloc(0);
    }
    
    int first = (inputSize - count < 0) ? 0 : inputSize - count;
    int* output = malloc((inputSize - first) * sizeof(int));
    for (int i = first; i < inputSize; i++)
        output[i - first] = input[i];

    *outputSize = inputSize - first;
    return output;
}
```

Python:

```python
def take_last(input, count):
    if count <= 0 or not input:
        return []
    
    first = max(0, len(input) - count)
    return input[first:]
}
```