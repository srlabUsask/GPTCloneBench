#input 
static void Main () {
    var moCollection = new ManagementClass ("Win32_LogicalDisk").GetInstances ();
    foreach (var mo in moCollection) {
        if (mo ["DeviceID"] != null && mo ["DriveType"] != null && mo ["Size"] != null && mo ["FreeSpace"] != null) {
            if (Convert.ToInt32 (mo ["DriveType"]) == 3) {
                Console.WriteLine ("Drive {0}", mo ["DeviceID"]);
                Console.WriteLine ("Size {0} bytes", mo ["Size"]);
                Console.WriteLine ("Free {0} bytes", mo ["FreeSpace"]);
            }
        }
    }
}


#====================
#gpt output=============
The sample code you've provided is in C# and retrieves information about hard disk drives on a Windows system using WMI (Windows Management Instrumentation). Here's how you would implement similar code in C, Java, and Python:

Python (using the win32 API):
```python
import wmi

w = wmi.WMI ()

for disk in w.Win32_LogicalDisk (DriveType=3):
    print ("Drive %s" % disk.DeviceID)
    print ("Size %s bytes" % disk.Size)
    print ("Free %s bytes" % disk.FreeSpace)
```

C (using the Windows API) - this is a simplified version and requires additional error handling and setup:
```c
#include <windows.h>

void main()
{
    DWORD aDriveLetters = GetLogicalDrives();
    DWORD i;
   
    for (i = 0; i < 26; i++)
    {
        if(aDriveLetters & 1<<i)
        {
            printf("Drive %c:\n", 'A' + i);
            // Get additional details using GetDiskFreeSpaceEx 
        }
    }
}    
```

Java - Java does not directly support the WMI, but you can use third-party libraries like `com4j` or `j-interop` to access that. The following code uses Java's built-in classes to get basic drive info:
```java
import java.io.File;
    
public class DiskSpace 
{
    public static void main(String[] args)
    {
        File[] roots = File.listRoots();

        for (File root : roots) 
        {
            System.out.println("Drive: " + root.getAbsolutePath());
            System.out.println("Total space (bytes): " + root.getTotalSpace());
            System.out.println("Free space (bytes): " + root.getFreeSpace());
        }
    }
}
```
Note: Keep in mind that Java's getFreeSpace() and getTotalSpace() may not provide the accurate information depending on the operating system and JVM.