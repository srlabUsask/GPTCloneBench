#input 
private static bool IsPowerOfTwo (ulong number) {
    while (number != 0) {
        if (number == 1)
            return true;
        if ((number & 1) == 1)
            return false;
        number = number > > 1;
    }
    return false;
}


#====================
#gpt output=============
Java:

```java
private static boolean isPowerOfTwo(long number) {
    while (number != 0) {
        if (number == 1) 
            return true;
        if ((number & 1) == 1) 
            return false;
        number = number >> 1;
    }
    return false;
}
```

C:

```c
#include <stdbool.h>

bool isPowerOfTwo(unsigned long long number) {
    while (number != 0) {
        if (number == 1)
            return true;
        if ((number & 1) == 1)
            return false;
        number = number >> 1;
    }
    return false;
}
```

Python:

```python
def is_power_of_two(number):
    while number != 0:
        if number == 1:
            return True
        if (number & 1) == 1:
            return False
        number = number >> 1
    return False
```