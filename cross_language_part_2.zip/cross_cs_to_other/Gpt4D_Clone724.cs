#input 
private void Form1_Load (object sender, EventArgs e) {
    DateTime dteThen = DateTime.Parse ("3/31/2010");
    DateTime dteNow = DateTime.Now;
    int intDiffInYears = 0;
    int intDiffInMonths = 0;
    int intDiffInDays = 0;
    if (dteNow.Month >= dteThen.Month) {
        if (dteNow.Day >= dteThen.Day) {
            intDiffInYears = dteNow.Year - dteThen.Year;
            intDiffInMonths = dteNow.Month - dteThen.Month;
            intDiffInDays = dteNow.Day - dteThen.Day;
        } else {
            if (dteNow.Month == dteThen.Month) {
                intDiffInYears = dteNow.Year - dteThen.Year - 1;
                intDiffInMonths = 11;
                int intDaysInSharedMonth = System.DateTime.DaysInMonth (dteThen.Year, dteThen.Month);
                intDiffInDays = intDaysInSharedMonth - dteThen.Day + dteNow.Day;
            } else {
                intDiffInYears = dteNow.Year - dteThen.Year;
                intDiffInMonths = dteNow.Month - dteThen.Month - 1;
                int intDaysInPrevMonth = System.DateTime.DaysInMonth (dteNow.Year, (dteNow.Month - 1));
                intDiffInDays = intDaysInPrevMonth - dteThen.Day + dteNow.Day;
            }
        }
    } else {
        intDiffInYears = dteNow.Year - dteThen.Year - 1;
        intDiffInMonths = 12 - dteThen.Month + dteNow.Month;
        if (dteNow.Day >= dteThen.Day) {
            intDiffInDays = dteNow.Day - dteThen.Day;
        } else {
            intDiffInMonths --;
            int intDaysInPrevMonth = System.DateTime.DaysInMonth (dteNow.Year, (dteNow.Month - 1));
            intDiffInDays = intDaysInPrevMonth - dteThen.Day + dteNow.Day;
        }
    }
    this.addToBox ("Years: " + intDiffInYears + " Months: " + intDiffInMonths + " Days: " + intDiffInDays);
}


#====================
#gpt output=============
Java code:

```java
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public void form_load() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
    LocalDate dateThen = LocalDate.parse("3/31/2010", formatter);
    LocalDate dateNow = LocalDate.now();

    long yearsDiff = ChronoUnit.YEARS.between(dateThen, dateNow);
    long monthsDiff = ChronoUnit.MONTHS.between(dateThen, dateNow) % 12;
    long daysDiff = ChronoUnit.DAYS.between(dateThen.plusYears(yearsDiff).plusMonths(monthsDiff), dateNow);
    addToBox("Years: " + yearsDiff + ". Months: " + monthsDiff + ". Days: " + daysDiff);
}
```

C Code:
C does not have built-in classes for DateTime manipulations. C programmers typically get the current Unix timestamp and calculate the difference in seconds which is then converted to years, months, and days.

Python implementation:

```python
from datetime import datetime
from dateutil import relativedelta

def form_load():
    date_then = datetime.strptime("3/31/2010", "%m/%d/%Y")
    date_now = datetime.now()
    diff = relativedelta.relativedelta(date_now, date_then)

    years_diff = diff.years
    months_diff = diff.months
    days_diff = diff.days
    addToBox("Years: " + str(years_diff) + ". Months: " + str(months_diff) + ". Days: " + str(days_diff))
```
Please note that neither C, Java nor Python is a 1-to-1 translation of your original code. Depending on your needs you might need to adjust the code a bit to exactly match the original behavior. Also, function addToBox does not exist in these examples. You will need to implement it yourself with the expected behavior.
