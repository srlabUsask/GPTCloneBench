#input 
public bool CheckForCrossing (List < Line2D > lines) {
    List < endpointEntry > pts = new List < endpointEntry > (2 * lines.Count);
    foreach (Line2D lin in lines) {
        endpointEntry hi, lo;
        if (lin.P1.X < lin.P2.X) {
            hi = new endpointEntry () {XValue = lin.P2.X, isHi = true, line = lin, hi = lin.P2.X, lo = lin.P1.X};
            lo = new endpointEntry () {XValue = lin.P1.X, isHi = false, line = lin, hi = lin.P1.X, lo = lin.P2.X};
        } else {
            hi = new endpointEntry () {XValue = lin.P1.X, isHi = true, line = lin, hi = lin.P1.X, lo = lin.P2.X};
            lo = new endpointEntry () {XValue = lin.P2.X, isHi = false, line = lin, hi = lin.P2.X, lo = lin.P1.X};
        }
        pts.Add (hi);
        pts.Add (lo);
    }
    pts.Sort (new endpointSorter ());
    endpointEntry prev = null;
    foreach (endpointEntry pt in pts) {
        if (prev != null) {
            pt.bLink = prev;
            prev.fLink = pt;
        }
        prev = pt;
    }
    foreach (endpointEntry pt in pts) {
        if (pt.isHi) {
            for (endpointEntry pLo = pt.fLink; (pLo != null) && (pLo.XValue >= pt.lo); pLo = pLo.fLink) {
                if (! pLo.isHi) {
                    if (pt.line.intersectsLine (pLo.line))
                        return true;
                }
            }
        }
    }
    return false;
}


#====================
#gpt output=============
Java version:

```java
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public boolean checkForCrossing(List<Line2D> lines) {
    List<EndpointEntry> pts = new ArrayList<EndpointEntry>(2 * lines.size());
    for (Line2D lin : lines) {
        EndpointEntry hi, lo;
        if (lin.getP1().getX() < lin.getP2().getX()) {
            hi = new EndpointEntry(lin.getP2().getX(), true, lin, lin.getP2().getX(), lin.getP1().getX());
            lo = new EndpointEntry(lin.getP1().getX(), false, lin, lin.getP1().getX(), lin.getP2().getX());
        } else {
            hi = new EndpointEntry(lin.getP1().getX(), true, lin, lin.getP1().getX(), lin.getP2().getX());
            lo = new EndpointEntry(lin.getP2().getX(), false, lin, lin.getP2().getX(), lin.getP1().getX());
        }
        pts.add(hi);
        pts.add(lo);
    }
    Collections.sort(pts, new EndpointSorter());
    EndpointEntry prev = null;
    for (EndpointEntry pt : pts) {
        if (prev != null) {
            pt.bLink = prev;
            prev.fLink = pt;
        }
        prev = pt;
    }
    for (EndpointEntry pt : pts) {
        if (pt.isHi) {
            for (EndpointEntry pLo = pt.fLink; (pLo != null) && (pLo.xValue >= pt.lo); pLo = pLo.fLink) {
                if (!pLo.isHi) {
                    if (pt.line.intersectsLine(pLo.line))
                        return true;
                }
            }
        }
    }
    return false;
}
```

Python version:

```python
from operator import attrgetter

def check_for_crossing(lines):
    pts = []
    for lin in lines:
        if lin.p1.x < lin.p2.x:
            hi = EndpointEntry(lin.p2.x, True, lin, lin.p2.x, lin.p1.x)
            lo = EndpointEntry(lin.p1.x, False, lin, lin.p1.x, lin.p2.x)
        else:
            hi = EndpointEntry(lin.p1.x, True, lin, lin.p1.x, lin.p2.x)
            lo = EndpointEntry(lin.p2.x, False, lin, lin.p2.x, lin.p1.x)
        pts.append(hi)
        pts.append(lo)
    pts.sort(key=attrgetter('xValue'))
    prev = None
    for pt in pts:
        if prev is not None:
            pt.bLink = prev
            prev.fLink = pt
        prev = pt
    for pt in pts:
        if pt.isHi:
            pLo = pt.fLink
            while (pLo is not None) and (pLo.xValue >= pt.lo):
                if not pLo.isHi:
                    if pt.line.intersects(pLo.line):
                        return True
                pLo = pLo.fLink
    return False
```

The C language doesn't natively support OOP, lists, or the Line2D class used in your code as it is. Implementing equivalent code in C would require quite a different approach and additional code to define structures and operations not present in the C language.