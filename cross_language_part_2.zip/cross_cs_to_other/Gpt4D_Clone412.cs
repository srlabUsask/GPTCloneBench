#input 
private static string ReplaceBBCode (string inStr) {
    StringBuilder outStr = new StringBuilder ();
    bool addBR = false;
    for (int i = 0; i < inStr.Length; i ++) {
        if (addBR) {
            outStr.Append ("<br />");
            addBR = false;
        }
        if (inStr [i] == '\r' || inStr [i] == '\n') {
            if (! addBR)
                addBR = true;
        } else {
            addBR = false;
            if (i + 2 < inStr.Length && inStr [i] == '[' && (inStr [i + 1] == 'b' || inStr [i + 1] == 'i' || inStr [i + 1] == 'u') && inStr [i + 2] == ']') {
                outStr.Append ("<").Append (inStr [i + 1]).Append ("><![CDATA[");
                i += 2;
            } else if (i + 3 < inStr.Length && inStr [i] == '[' && inStr [i + 1] == '/' && (inStr [i + 2] == 'b' || inStr [i + 2] == 'i' || inStr [i + 2] == 'u') && inStr [i + 3] == ']') {
                outStr.Append ("</").Append (inStr [i + 2]).Append ("><![CDATA[");
                i += 3;
            } else
                outStr.Append (inStr [i]);
        }
    }
    return outStr.ToString ();
}


#====================
#gpt output=============
Java:
```java
private static String replaceBBCode (String inStr) {
    StringBuilder outStr = new StringBuilder();
    boolean addBR = false;
    for (int i = 0; i < inStr.length(); i ++) {
        if (addBR) {
            outStr.append("<br />");
            addBR = false;
        }
        if (inStr.charAt(i) == '\r' || inStr.charAt(i) == '\n') {
            if (!addBR)
                addBR = true;
        } else {
            addBR = false;
            if (i + 2 < inStr.length() && inStr.charAt(i) == '[' && (inStr.charAt(i + 1) == 'b' || inStr.charAt(i + 1) == 'i' || inStr.charAt(i + 1) == 'u') && inStr.charAt(i + 2) == ']') {
                outStr.append("<").append(inStr.charAt(i + 1)).append("><![CDATA[");
                i += 2;
            } else if (i + 3 < inStr.length() && inStr.charAt(i) == '[' && inStr.charAt(i + 1) == '/' && (inStr.charAt(i + 2) == 'b' || inStr.charAt(i + 2) == 'i' || inStr.charAt(i + 2) == 'u') && inStr.charAt(i + 3) == ']') {
                outStr.append("</").append(inStr.charAt(i + 2)).append("><![CDATA[");
                i += 3;
            } else
                outStr.append(inStr.charAt(i));
        }
    }
    return outStr.toString();
}
```

Python:
```python
def replaceBBCode(inStr):
    outStr = ""
    addBR = False
    i = 0
    while i < len(inStr):
        if addBR:
            outStr += "<br />"
            addBR = False
        if inStr[i] == '\r' or inStr[i] == '\n':
            addBR = not addBR
        else:
            addBR = False
            if i + 2 < len(inStr) and inStr[i] == '[' and inStr[i + 1] in ['b', 'i', 'u'] and inStr[i + 2] == ']':
                outStr += "<" + inStr[i + 1] + "><![CDATA["
                i += 2
            elif i + 3 < len(inStr) and inStr[i] == '[' and inStr[i + 1] == '/' and inStr[i + 2] in ['b', 'i', 'u'] and inStr[i + 3] == ']':
                outStr += "</" + inStr[i + 2] + "><![CDATA["
                i += 3
            else:
                outStr += inStr[i]
        i += 1
    return outStr
```

C:
```C
#include <string.h>

void replaceBBCode(char *inStr, char *outStr) {
    int addBR = 0, i = 0, j = 0;
    while (inStr[i] != '\0') {
        if (addBR) {
            outStr[j++] = '<';
            outStr[j++] = 'b';
            outStr[j++] = 'r';
            outStr[j++] = ' ';
            outStr[j++] = '/';
            outStr[j++] = '>';
            addBR = 0;
        }
        if (inStr[i] == '\r' || inStr[i] == '\n') {
            if (!addBR)
                addBR = 1;
        } else {
            addBR = 0;
            if (i + 2 < strlen(inStr) && inStr[i] == '[' && (inStr[i + 1] == 'b' || inStr[i + 1] == 'i' || inStr[i + 1] == 'u') && inStr[i + 2] == ']') {
                outStr[j++] = '<';
                outStr[j++] = inStr[i + 1];
                i += 2;
            } else if (i + 3 < strlen(inStr) && inStr[i] == '[' && inStr[i + 1] == '/' && (inStr[i + 2] == 'b' || inStr[i + 2] == 'i' || inStr[i + 2] == 'u') && inStr[i + 3] == ']') {
                outStr[j++] = '<';
                outStr[j++] = '!';
                outStr[j++] = '[';
                outStr[j++] = 'C';
                outStr[j++] = 'D';
                outStr[j++] = 'A';
                outStr[j++] = 'T';
                outStr[j++] = 'A';
                outStr[j++] = '[';
                outStr[j++] = inStr[i + 2];
                i += 3;
            } else
                outStr[j++] = inStr[i];
        }
        i++;
    }
    outStr[j] = '\0';
}
```