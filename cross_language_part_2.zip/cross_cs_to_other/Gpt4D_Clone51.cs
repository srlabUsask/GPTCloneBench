#input 
public static bool IsInPolygon (Point [] poly, Point point) {
    var coef = poly.Skip (1).Select ((p, i) = > (point.Y - poly [i].Y) * (p.X - poly [i].X) - (point.X - poly [i].X) * (p.Y - poly [i].Y)).ToList ();
    if (coef.Any (p = > p == 0))
        return true;
    for (int i = 1; i < coef.Count (); i ++) {
        if (coef [i] * coef [i - 1] < 0)
            return false;
    }
    return true;
}


#====================
#gpt output=============
Java:

```java
public static boolean IsInPolygon (Point [] poly, Point point) {
    ArrayList<Double> coef = new ArrayList<Double>();
    for (int i = 1; i < poly.length; i ++) {
        double temp = (point.y - poly [i - 1].y) * (poly[i].x - poly [i - 1].x) - (point.x - poly [i - 1].x) * (poly[i].y - poly [i - 1].y);
        coef.add(temp);
        if (temp == 0) 
            return true;
    }
    for (int i = 1; i < coef.size(); i ++) {
        if (coef.get(i) * coef.get(i - 1) < 0)
            return false;
    }
    return true;
}
```

C: 

```c
#include <stdbool.h>

typedef struct
{
    double x;
    double y;
} Point;

bool IsInPolygon(Point* poly, int size, Point point) {
    double coef[size - 1];
    int i;
    for (i = 1; i < size; i++) {
        coef[i - 1] = (point.y - poly[i - 1].y) * (poly[i].x - poly[i - 1].x) - (point.x - poly[i - 1].x) * (poly[i].y - poly[i - 1].y);
        if (coef[i - 1] == 0)
            return true;
    }
    for (i = 1; i < size - 1; i++) {
        if (coef[i] * coef[i - 1] < 0)
            return false;
    }
    return true;
}
```

Python:

```python
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

def IsInPolygon(poly, point):
    coef = [(point.y - poly[i].y) * (poly[i + 1].x - poly[i].x) - (point.x - poly[i].x) * (poly[i + 1].y - poly[i].y) for i in range(len(poly) - 1)]
    if 0 in coef:
        return True
    for i in range(1, len(coef)):
        if coef[i] * coef[i - 1] < 0:
            return False
    return True
```
