#input 
public HttpResponseMessage CertificateUpload (employeeModel emp) {
    if (! ModelState.IsValid) {
        string errordetails = "";
        var errors = new List < string > ();
        foreach (var state in ModelState) {
            foreach (var error in state.Value.Errors) {
                string p = error.ErrorMessage;
                errordetails = errordetails + error.ErrorMessage;
            }
        }
        Dictionary < string, object > dict = new Dictionary < string, object > ();
        dict.Add ("error", errordetails);
        return Request.CreateResponse (HttpStatusCode.BadRequest, dict);
    } else {
    }
}


#====================
#gpt output=============
Since the provided code is written in C# using ASP.NET MVC model, translating it exactly into Java, C and Python would not be directly possible because these languages doesn't have the exact model and library functionality like ASP.NET. However, the same functionality can be achieved in these languages in a different way. Below is a high-level representation of the pseudo code.

Java:

```java
public ResponseEntity<String> certificateUpload(Employee employee, Errors errors) {
    if (errors.hasErrors()) {
        StringBuilder errordetails = new StringBuilder();
        for (ObjectError error : errors.getAllErrors()) {
            errordetails.append(error.getDefaultMessage());
        }
        return new ResponseEntity<>(errordetails.toString(), HttpStatus.BAD_REQUEST);
    } else {
        // Other action
    }
}
```

Python:

```python
from flask import jsonify, Response
from werkzeug.exceptions import BadRequest

def certificate_upload(emp):
    error_details = ""
    if not emp.is_valid():
        for error in emp.errors:
            error_details += error
        response = jsonify(error=error_details)
        response.status_code = 400
        return response
    else:
        pass
```

While for C, there is no HTTP Response model or validation model, an approximation could be:

```c
void certificateUpload(struct Employee emp, struct Error *errors, int errorCount) {
    if (errorCount > 0) {
        char errorDetails[1024] = "";
        for(int i=0; i<errorCount; i++) {
            strcat(errorDetails, errors[i].message);
        }
        printf("Status: 400\nError: %s\n", errorDetails);
    } else {
        // Other action
    }
}
```

Note: These are very rudimentary examples and might not work as is, since they are missing necessary components like imports, error classes, HTTP response creation and much more.