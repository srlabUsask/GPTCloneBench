#input 
public static int Asc (char String) {
    int num1 = Convert.ToInt32 (String);
    if (num1 < 128)
        return num1;
    try {
        Encoding fileIoEncoding = Utils.GetFileIOEncoding ();
        char [] chars = new char [1] {String};
        if (fileIoEncoding.IsSingleByte) {
            byte [] bytes = new byte [1];
            fileIoEncoding.GetBytes (chars, 0, 1, bytes, 0);
            return (int) bytes [0];
        }
        byte [] bytes1 = new byte [2];
        if (fileIoEncoding.GetBytes (chars, 0, 1, bytes1, 0) == 1)
            return (int) bytes1 [0];
        if (BitConverter.IsLittleEndian) {
            byte num2 = bytes1 [0];
            bytes1 [0] = bytes1 [1];
            bytes1 [1] = num2;
        }
        return (int) BitConverter.ToInt16 (bytes1, 0);
    }
    catch (Exception ex) {
        throw ex;
    }
}


#====================
#gpt output=============
Java:

public static int Asc (char character) {
    int num1 = (int) character;
    if (num1 < 128)
        return num1;
    try {
        Charset fileTypeEncoding = Charset.defaultCharset();
        CharBuffer charBuffer = CharBuffer.wrap(new char[] {character});
        if (fileTypeEncoding.newEncoder().canEncode(character)) {
            ByteBuffer byteBuffer = ByteBuffer.allocate(1);
            fileTypeEncoding.newEncoder().encode(charBuffer, byteBuffer, true);
            return (int) byteBuffer.get(0);
        }
        ByteBuffer byteBuffer1 = ByteBuffer.allocate(2);
        fileTypeEncoding.newEncoder().encode(charBuffer, byteBuffer1, true);
        if (byteBuffer1.position() == 1)
            return (int) byteBuffer1.get(0);
        if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
            byte num2 = byteBuffer1.get(0);
            byteBuffer1.put(0, byteBuffer1.get(1));
            byteBuffer1.put(1, num2);
        }
        return byteBuffer1.getShort(0);
    }
    catch (Exception ex) {
        throw ex;
    }
}

C:

#include <stdio.h>
#include <stdlib.h>
#include <iconv.h>
#include <locale.h>
#define MAX_BUFFER_SIZE 1024
int Asc(unsigned int unicode) {
    if (unicode < 128) 
        return unicode;
    else 
    {
        char encodingFrom[50] = "UTF-32BE";
        char encodingTo[50] = "";
        strcpy(encodingTo, setlocale(LC_ALL, NULL));
        iconv_t cd = iconv_open(encodingTo, encodingFrom);
        char inbuf[MAX_BUFFER_SIZE] = {0};
        char outbuf[MAX_BUFFER_SIZE] = {0};
        char* inptr = inbuf;
        char* outptr = outbuf;
        size_t insize = sizeof(unicode);
        size_t outsize = sizeof(outbuf);
        memcpy(inbuf, &unicode, insize);
        if (iconv(cd, &inptr, &insize, &outptr, &outsize) != (size_t) -1)
        {
            int result = (int)outbuf[0];
            iconv_close(cd);
            return result;
        }
        else 
        {
            perror("iconv");
            exit(1);
        }
    }
}

Python:

import sys
def Asc(character):
    num1 = ord(character)
    if num1 < 128:
        return num1
    try:
        encodedCharacter = character.encode(sys.getfilesystemencoding())
        if len(encodedCharacter) == 1:
            return encodedCharacter[0]
        if sys.byteorder == 'little':
            return int.from_bytes(encodedCharacter, byteorder='little')
        return int.from_bytes(encodedCharacter, byteorder='big')
    except Exception as ex:
        raise ex
