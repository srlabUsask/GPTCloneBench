#input 
static String findFirstKeyByValue (Dictionary < string, string > Data_Array, String value) {
    if (Data_Array.ContainsValue (value)) {
        foreach (String key in Data_Array.Keys) {
            if (Data_Array [key].Equals (value))
                return key;
        }
    }
    return null;
}


#====================
#gpt output=============
Java version:
```java
import java.util.Map;

public static String findFirstKeyByValue(Map<String, String> data_array, String value) {
    for (Map.Entry<String, String> entry : data_array.entrySet()) {
        if (value.equals(entry.getValue())) {
            return entry.getKey();
        }
    }
    return null;
}
```

C version: C does not have built-in support for associative containers like Dictionaries or Maps. Therefore, C equivalent would have to implement a hash map or a similar data structure. It's significantly more complex opposed to Python and Java versions. You can use third-party libraries such as GLib's GHashTable.

Python version:
```python
def find_first_key_by_value(data_array, value):
    for key, val in data_array.items():
        if val == value:
            return key
    return None
```