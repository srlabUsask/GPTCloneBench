#input 
public static int CountOccurrences (string original, string substring) {
    if (string.IsNullOrEmpty (substring))
        return 0;
    if (substring.Length == 1)
        return CountOccurrences (original, substring [0]);
    if (string.IsNullOrEmpty (original) || substring.Length > original.Length)
        return 0;
    int substringCount = 0;
    for (int charIndex = 0; charIndex < original.Length; charIndex ++) {
        for (int subCharIndex = 0, secondaryCharIndex = charIndex; subCharIndex < substring.Length && secondaryCharIndex < original.Length; subCharIndex ++, secondaryCharIndex ++) {
            if (substring [subCharIndex] != original [secondaryCharIndex])
                goto continueOuter;
        }
        if (charIndex + substring.Length > original.Length)
            break;
        charIndex += substring.Length - 1;
        substringCount ++;
        continueOuter :;}
    return substringCount;
}


#====================
#gpt output=============
Here are the implementations:

Java:
```java
public static int countOccurrences(String original, String substring) {
    if (substring == null || substring.isEmpty())
        return 0;
    if (substring.length() == 1)
        return countOccurrences(original, substring.charAt(0));
    if (original == null || substring.length() > original.length())
        return 0;
    int substringCount = 0;
    outer:
    for (int charIndex = 0; charIndex < original.length(); charIndex++) {
        for (int subCharIndex = 0; subCharIndex < substring.length() && (charIndex + subCharIndex) < original.length(); subCharIndex++) {
            if (substring.charAt(subCharIndex) != original.charAt(charIndex + subCharIndex))
                continue outer;
        }
        substringCount++;
    }
    return substringCount;
}

private static int countOccurrences(String original, char ch) {
    int count = 0;
    for(int i = 0; i < original.length(); i++) {
        if(original.charAt(i) == ch)
            count++;
    }
    return count;
}
```

C:
```c
#include <string.h>

int countOccurrences(char *original, char *substring) {
    if (substring == NULL || strlen(substring) == 0)
        return 0;
    if (strlen(substring) == 1)
        return countOccurrencesChar(original, substring[0]);
    if (original == NULL || strlen(substring) > strlen(original))
        return 0;
    int substringCount = 0;
    for (int charIndex = 0; charIndex < strlen(original); charIndex++) {
        for (int subCharIndex = 0; subCharIndex < strlen(substring) && (charIndex + subCharIndex) < strlen(original); subCharIndex++) {
            if (substring[subCharIndex] != original[charIndex + subCharIndex])
                goto continue_outer;
        }
        substringCount++;
        continue_outer: ;
    }
    return substringCount;
}

int countOccurrencesChar(char *original, char ch) {
    int count = 0;
    for(int i = 0; i < strlen(original); i++) {
        if(original[i] == ch)
            count++;
    }
    return count;
}
```

Python:
```python
def countOccurrences(original, substring):
    if substring == "" or substring is None:
        return 0
    if len(substring) == 1:
        return countOccurrencesChar(original, substring)
    if original == "" or len(substring) > len(original):
        return 0
    substringCount = 0
    charIndex = 0
    while charIndex < len(original):
        if original[charIndex : charIndex + len(substring)] == substring:
            substringCount += 1
            charIndex += len(substring)
        else:
            charIndex += 1
    return substringCount


def countOccurrencesChar(original, ch):
    return original.count(ch)
```