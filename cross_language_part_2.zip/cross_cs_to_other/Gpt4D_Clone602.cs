#input 
public static long fibo_n (long N) {
    if (N <= 0)
        return 0;
    if (N == 1)
        return 1;
    if (N <= 4)
        return N - 1;
    return fibo_n (N - 1) + fibo_n (N - 2);
}


#====================
#gpt output=============
Java:
```java
public static long fibo_n (long N) {
    if (N <= 0)
        return 0;
    if (N == 1)
        return 1;
    if (N <= 4)
        return N - 1;
    return fibo_n (N - 1) + fibo_n (N - 2);
}
```

C:
```c
#include <stdio.h>

long fibo_n(long N) {
    if (N <= 0)
        return 0;
    if (N == 1)
        return 1;
    if (N <= 4)
        return N - 1;
    return fibo_n(N - 1) + fibo_n(N - 2);
}
```

Python:
```python
def fibo_n(N):
    if N <= 0:
        return 0
    if N == 1:
        return 1
    if N <= 4:
        return N - 1
    return fibo_n(N - 1) + fibo_n(N - 2)
```