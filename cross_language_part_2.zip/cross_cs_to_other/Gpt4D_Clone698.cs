#input 
public IEnumerable < int [] > GetIntPermutations (int [] index, int offset, int len) {
    switch (len) {
        case 1 :
            yield return index;
            break;
        case 2 :
            yield return index;
            Swap (index, offset, offset + 1);
            yield return index;
            Swap (index, offset, offset + 1);
            break;
        default :
            foreach (var result in GetIntPermutations (index, offset + 1, len - 1)) {
                yield return result;
            }
            for (var i = 1; i < len; i ++) {
                Swap (index, offset, offset + i);
                foreach (var result in GetIntPermutations (index, offset + 1, len - 1)) {
                    yield return result;
                }
                Swap (index, offset, offset + i);
            }
            break;
    }
}


#====================
#gpt output=============
Java Implementation (using ArrayList instead of IEnumerable):
```java
public List<int[]> getIntPermutations(int[] index, int offset, int len) {
    List<int[]> results = new ArrayList<>();
    switch (len) {
        case 1:
            results.add(index.clone());
            break;
        case 2:
            results.add(index.clone());
            swap(index, offset, offset + 1);
            results.add(index.clone());
            swap(index, offset, offset + 1);
            break;
        default:
            results.addAll(getIntPermutations(index, offset + 1, len - 1));
            for (int i = 1; i < len; i++) {
                swap(index, offset, offset + i);
                results.addAll(getIntPermutations(index, offset + 1, len - 1));
                swap(index, offset, offset + i);
            }
            break;
    }
    return results;
}

void swap(int[] arr, int i, int j) {
    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}
```

C Implementation:
```c
void swap(int* arr, int i, int j) {
    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}

void get_int_permutations(int* index, int offset, int len) {
    switch (len) {
        case 1:
            print_array(index, len);
            break;
        case 2:
            print_array(index, len);
            swap(index, offset, offset + 1);
            print_array(index, len);
            swap(index, offset, offset + 1);
            break;
        default:
            get_int_permutations(index, offset + 1, len - 1);
            for (int i = 1; i < len; i++) {
                swap(index, offset, offset + i);
                get_int_permutations(index, offset + 1, len - 1);
                swap(index, offset, offset + i);
            }
    }
}

void print_array(int* arr, int len){
    for(int i = 0; i < len; i++){
        printf("%d ", arr[i]);
    }
    printf("\n");
}
```

Python Implementation:
```python
def swap(lst, i, j):
    lst[i], lst[j] = lst[j], lst[i]

def get_int_permutations(index, offset, len):
    if len == 1:
        yield list(index)
    elif len == 2:
        yield list(index)
        swap(index, offset, offset + 1)
        yield list(index)
        swap(index, offset, offset + 1)
    else:
        for result in get_int_permutations(index, offset + 1, len - 1):
            yield result
        for i in range(1, len):
            swap(index, offset, offset + i)
            for result in get_int_permutations(index, offset + 1, len - 1):
                yield result
            swap(index, offset, offset + i)
```
Please note that the C code above will print out the permutations directly to the console instead of collecting them in a list or array. Handling collections of dynamic size is out of scope for the C language.