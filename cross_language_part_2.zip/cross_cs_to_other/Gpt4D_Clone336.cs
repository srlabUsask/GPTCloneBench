#input 
protected void DiasShow () {
    var getFiles = Directory.GetFiles (HttpContext.Current.Server.MapPath ("/CSS/Design/Page_Design/Dias/1920x1080/"));
    var random = RandomiseList (getFiles);
    var txt = new StringBuilder ();
    foreach (var randomFileName in random) {
        var fileType = System.IO.Path.GetExtension (randomFileName).ToUpper ();
        if ((fileType == ".JPG") || (fileType == ".JPEG")) {
            var imageName = System.IO.Path.GetFileName (randomFileName);
            txt.Append ("<img src=\"CSS/Design/Page_Design/Dias/1920x1080/" + imageName + "\" />");
        }
    }
    lbl_Dias.Text += txt.ToString ();
}


#====================
#gpt output=============
Java code:

```java
void diasShow() {
    String path = "./CSS/Design/Page_Design/Dias/1920x1080";
    File directory = new File(path);
    String[] files = directory.list();
    Collections.shuffle(Arrays.asList(files));
    StringBuilder txt = new StringBuilder();
    for (String fileName : files) {
        String ext = FilenameUtils.getExtension(fileName).toUpperCase();
        if (".JPG".equals(ext) || ".JPEG".equals(ext)) {
            txt.append("<img src=\"CSS/Design/Page_Design/Dias/1920x1080/" + fileName + "\" />");
        }
    }
    lbl_Dias += txt.toString();
}
```

C code: (C doesn't support web library)

```c
N/A
```

Python code:

```python
import os
import random
def diasShow():
    path = "./CSS/Design/Page_Design/Dias/1920x1080/"
    files = os.listdir(path)
    random.shuffle(files)
    txt = ""
    for fileName in files:
        ext = os.path.splitext(fileName)[1].upper()
        if ext == ".JPG" or ext == ".JPEG":
            txt += '<img src="CSS/Design/Page_Design/Dias/1920x1080/' + fileName + '" />'
    global lbl_Dias
    lbl_Dias += txt
```

Note: This code snippets assume that lbl_Dias is a global string. In web frameworks like Servlets in Java or Flask in Python, the code for manipulating HTML could look different. For C, since it is not typically used in a web context, corresponding HTML generation and file system access could be quite different and complex.