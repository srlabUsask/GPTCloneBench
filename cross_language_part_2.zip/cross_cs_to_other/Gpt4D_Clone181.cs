#input 
static void Main (string [] args) {
    var fsm = new FiniteStateMachine ();
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.PlugIn);
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.TurnOn);
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.TurnOff);
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.TurnOn);
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.RemovePower);
    Console.WriteLine (fsm.State);
    Console.ReadKey ();
}


#====================
#gpt output=============
JAVA

public class Main {
    public static void main(String[] args) {
        FiniteStateMachine fsm = new FiniteStateMachine();
        System.out.println(fsm.getState());
        fsm.processEvent(FiniteStateMachine.Events.PLUG_IN);
        System.out.println(fsm.getState());
        fsm.processEvent(FiniteStateMachine.Events.TURN_ON);
        System.out.println(fsm.getState());
        fsm.processEvent(FiniteStateMachine.Events.TURN_OFF);
        System.out.println(fsm.getState());
        fsm.processEvent(FiniteStateMachine.Events.TURN_ON);
        System.out.println(fsm.getState());
        fsm.processEvent(FiniteStateMachine.Events.REMOVE_POWER);
        System.out.println(fsm.getState());
    }
}

PYTHON

import FiniteStateMachine

def main():
    fsm = FiniteStateMachine()
    
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.PLUG_IN)
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.TURN_ON)
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.TURN_OFF)
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.TURN_ON)
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.REMOVE_POWER)
    print(fsm.state)

if __name__ == "__main__":
    main()


For the C language, it's a bit more difficult to implement the concept of Finite State Machine as the language doesn't support object-oriented programming as other languages do. We can, however, represent a FSM using a switch case statement and a loop. Here is an example in C:

C

#include <stdio.h>

typedef enum {PLUG_IN, TURN_ON, TURN_OFF, REMOVE_POWER} Events;
typedef enum {StateOne, StateTwo} States;

typedef struct {
    States state;
} FiniteStateMachine;

int main() {
    
    FiniteStateMachine fsm;
    fsm.state = StateOne;

    printf("%d\n", fsm.state);
    fsm.state = TURN_ON;
    printf("%d\n", fsm.state);
    fsm.state = TURN_OFF;
    printf("%d\n", fsm.state);
    fsm.state = TURN_ON;
    printf("%d\n", fsm.state);
    fsm.state = REMOVE_POWER;
    printf("%d\n", fsm.state);

    return 0;
}

Note: You have to implement the FiniteStateMachine class in Java and Python, and the struct in C. Also, FSM logic (transitions between states) is missing. You will have to implement these yourself based on your FSM's requirements.