#input 
public void DrawSquare (int sideLength) {
    for (int row = 1; row <= sideLength; row ++) {
        for (int col = 1; col <= sideLength; col ++) {
            if (col <= row)
                Console.Write ('*');
            else
                Console.Write ('#');
        }
        Console.WriteLine ();
    }
}


#====================
#gpt output=============
Java:

```java
public void drawSquare(int sideLength) {
    for (int row = 1; row <= sideLength; row++) {
        for (int col = 1; col <= sideLength; col++) {
            if (col <= row)
                System.out.print('*');
            else
                System.out.print('#');
        }
        System.out.println();
    }
}
```

C:

```c
#include <stdio.h>

void drawSquare(int sideLength) {
    int row, col;
    for (row = 1; row <= sideLength; row++) {
        for (col = 1; col <= sideLength; col++) {
            if (col <= row)
                putchar('*');
            else
                putchar('#');
        }
        putchar('\n');
    }
}
```

Python:

```python
def draw_square(side_length):
    for row in range(1, side_length + 1):
        for col in range(1, side_length + 1):
            if col <= row:
                print('*', end='')
            else:
                print('#', end='')
        print()
```