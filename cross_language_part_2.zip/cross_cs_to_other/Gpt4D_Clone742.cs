#input 
static Result Play (Input userInput) {
    Input computer = Input.Scissors;
    switch (userInput) {
        case Input.Paper :
            switch (computer) {
                case Input.Paper :
                    return Result.Draw;
                case Input.Rock :
                    return Result.Win;
                case Input.Scissors :
                    return Result.Lose;
                default :
                    throw new Exception ("Logic fail.");
            }
        case Input.Rock :
            switch (computer) {
                case Input.Paper :
                    return Result.Lose;
                case Input.Rock :
                    return Result.Draw;
                case Input.Scissors :
                    return Result.Win;
                default :
                    throw new Exception ("Logic fail.");
            }
        case Input.Scissors :
            switch (computer) {
                case Input.Paper :
                    return Result.Win;
                case Input.Rock :
                    return Result.Lose;
                case Input.Scissors :
                    return Result.Draw;
                default :
                    throw new Exception ("Logic fail.");
            }
        default :
            throw new Exception ("Logic fail.");
    }
}


#====================
#gpt output=============
Java Code:
```java
enum Input {
    Rock, Paper, Scissors
}

enum Result {
    Win, Lose, Draw
}

static Result play(Input userInput) throws Exception {
    Input computer = Input.Scissors;
    switch (userInput) {
        case Paper:
            switch (computer) {
                case Paper: return Result.Draw;
                case Rock: return Result.Win;
                case Scissors: return Result.Lose;
                default: throw new Exception("Logic fail.");
            }
        case Rock:
            switch (computer) {
                case Paper: return Result.Lose;
                case Rock: return Result.Draw;
                case Scissors: return Result.Win;
                default: throw new Exception("Logic fail.");
            }
        case Scissors:
            switch (computer) {
                case Paper: return Result.Win;
                case Rock: return Result.Lose;
                case Scissors: return Result.Draw;
                default: throw new Exception("Logic fail.");
            }
        default: throw new Exception("Logic fail.");
    }
}
```

C Code:
```c
typedef enum { Rock, Paper, Scissors } Input;
typedef enum { Win, Lose, Draw } Result;

Result play(Input userInput) {
    Input computer = Scissors;
    switch (userInput) {
        case Paper:
            switch (computer) {
                case Paper: return Draw;
                case Rock: return Win;
                case Scissors: return Lose;
                default: return -1;
            }
        case Rock:
            switch (computer) {
                case Paper: return Lose;
                case Rock: return Draw;
                case Scissors: return Win;
                default: return -1;
            }
        case Scissors:
            switch (computer) {
                case Paper: return Win;
                case Rock: return Lose;
                case Scissors: return Draw;
                default: return -1;
            }
        default: return -1;
    }
}
```

Python Code:
```python
from enum import Enum

class Input(Enum):
    Rock = 1
    Paper = 2
    Scissors = 3

class Result(Enum):
    Win = 1
    Lose = 2
    Draw = 3

def play(userInput):
    computer = Input.Scissors
    if userInput == Input.Paper:
        if computer == Input.Paper:
            return Result.Draw
        elif computer == Input.Rock:
            return Result.Win
        elif computer == Input.Scissors:
            return Result.Lose
        else:
            raise Exception("Logic fail.")
    elif userInput == Input.Rock:
        if computer == Input.Paper:
            return Result.Lose
        elif computer == Input.Rock:
            return Result.Draw
        elif computer == Input.Scissors:
            return Result.Win
        else:
            raise Exception("Logic fail.")
    elif userInput == Input.Scissors:
        if computer == Input.Paper:
            return Result.Win
        elif computer == Input.Rock:
            return Result.Lose
        elif computer == Input.Scissors:
            return Result.Draw
        else:
            raise Exception("Logic fail.")
    else:
        raise Exception("Logic fail.")
```