#input 
[STAThread] static void Main () {
    bool result;
    var mutex = new System.Threading.Mutex (true, "UniqueAppId", out result);
    if (! result) {
        MessageBox.Show ("Another instance is already running.");
        return;
    }
    Application.Run (new Form1 ());
    GC.KeepAlive (mutex);
}


#====================
#gpt output=============
In Java:

```java
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) throws IOException {
        String tmpDir = System.getProperty("java.io.tmpdir");
        File lockFile = new File(tmpDir, "app.lock");

        if (lockFile.exists()) {
            JOptionPane.showMessageDialog(null, "Another instance is already running.");
            System.exit(1);
        }

        Files.createFile(lockFile.toPath());
        lockFile.deleteOnExit();

        // Put the code for launching your application here
    }
}
```

In C:

```c
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/file.h>

int main()
{
    int pid_file = open("/tmp/app.pid", O_CREAT | O_RDWR, 0666);
    int rv = flock(pid_file, LOCK_EX | LOCK_NB);

    if(rv) {
        printf("Another instance is already running.\n");
        exit(EXIT_FAILURE);
    }
    // Put the code for launching your application here

    return 0;
}
```

In Python:

```python
import os
import sys
import tempfile
import errno

pid_file = os.path.join(tempfile.gettempdir(), "app.pid")
try:
    if os.path.exists(pid_file):
        raise IOError(errno.EEXIST, "Another instance is already running.")
    file = open(pid_file, 'w')
    file.write(str(os.getpid()))
    file.close()
except IOError as e:
    if e.errno == errno.EEXIST:
        sys.exit("Another instance is already running.")
    else:
        raise
finally:
    if os.path.exists(pid_file):
        os.unlink(pid_file)

# Put the code for launching your application here
```