#input 
static void Main (string [] args) {
    IPAddress localAdd = IPAddress.Parse (SERVER_IP);
    TcpListener listener = new TcpListener (localAdd, PORT_NO);
    Console.WriteLine ("Listening...");
    listener.Start ();
    while (true) {
        TcpClient client = listener.AcceptTcpClient ();
        NetworkStream nwStream = client.GetStream ();
        byte [] buffer = new byte [client.ReceiveBufferSize];
        int bytesRead = nwStream.Read (buffer, 0, client.ReceiveBufferSize);
        string dataReceived = Encoding.ASCII.GetString (buffer, 0, bytesRead);
        Console.WriteLine ("Received : " + dataReceived);
        Console.WriteLine ("Sending back : " + dataReceived);
        nwStream.Write (buffer, 0, bytesRead);
        client.Close ();
    }
    listener.Stop ();
    Console.ReadLine ();
}


#====================
#gpt output=============
Java implementation:

```java
import java.io.*;
import java.net.*;

public class Main {
    public static void main(String[] args) throws IOException {
        final int PORT_NO = 8080;
        final String SERVER_IP = "127.0.0.1";
        ServerSocket serverSocket = new ServerSocket(PORT_NO, 50, InetAddress.getByName(SERVER_IP));
        System.out.println("Listening...");
        while (true) {
            Socket clientSocket = serverSocket.accept();
            DataInputStream dataInStream = new DataInputStream(new BufferedInputStream(clientSocket.getInputStream()));
            String dataReceived = dataInStream.readUTF();
            System.out.println("Received : " + dataReceived);
            DataOutputStream dataOutStream = new DataOutputStream(new BufferedOutputStream(clientSocket.getOutputStream()));
            dataOutStream.writeUTF(dataReceived);
            dataOutStream.flush();
            clientSocket.close();
        }
    }
}
```

C implementation (using POSIX API):

```c
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void main() {
    char buffer[1024];
    int serverSocket, acceptSocket, bytesRead;
    struct sockaddr_in serverAddr;
    socklen_t addr_size;

    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(8080); 
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    bind(serverSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));
    if(listen(serverSocket,50)==0) printf("Listening...\n");
    while(1) {
        acceptSocket = accept(serverSocket, (struct sockaddr *) NULL, NULL);
        bytesRead = read(acceptSocket, buffer, 1024);
        printf("Received: %s\n", buffer);
        write(acceptSocket, buffer, bytesRead);
        close(acceptSocket);
    }
}
```

Python implementation:

```python
import socket

SERVER_IP = '127.0.0.1'
PORT_NO = 8080

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((SERVER_IP, PORT_NO))
    s.listen()
    print('Listening...')
    while True:
        conn, addr = s.accept()
        with conn:
            while True:
                data = conn.recv(1024)
                if not data:
                    break
                print('Received: ', data.decode())
                print('Sending back: ', data.decode())
                conn.sendall(data)
```

Please replace `SERVER_IP` and `PORT_NO` with actual values. If you want to run the C code, please make sure your system supports POSIX API. Same way each above code snippet does not include error handling for simplicity. In a real-world scenario, it's vital to handle potential errors.