#input 
void Main () {
    Foo < int > fooObject = new Foo < int > ();
    fooObject.Items = new List < int > {1, 2, 3};
    object obj = (object) fooObject;
    PropertyInfo propInfo = obj.GetType ().GetProperty ("Items");
    object itemValue = propInfo.GetValue (obj, null);
    Console.WriteLine (itemValue);
    IList values = (IList) itemValue;
    foreach (var val in values)
        Console.WriteLine (val);
}


#====================
#gpt output=============
Java Implementation:

```java
import java.lang.reflect.*;
import java.util.*;

class Foo<T> {
    List<T> Items;

    public List<T> getItems() {
        return Items;
    }

    public void setItems(List<T> items) {
        Items = items;
    }
}

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        Foo<Integer> fooObject = new Foo<Integer>();
        fooObject.setItems(Arrays.asList(1, 2, 3));
        Object obj = fooObject;
        Method method = obj.getClass().getMethod("getItems");
        Object itemValue = method.invoke(obj);
        System.out.println(itemValue);
        List values = (List) itemValue;
        for (Object val:values)
            System.out.println(val);
    }
}
```

C Implementation (Please note that C does not support object oriented programming like Java, Python, C#, C++ and others):

```C
#include<stdio.h>

int main() {
    int Items[3] = {1, 2, 3};
    int *itemValue = Items;
    printf("%p\n", itemValue);
    for (int i=0; i<=2; i++)
        printf("%d\n", *(itemValue + i));
    return 0;
}
```

Python Implementation:

```python
class Foo:
    def __init__(self, Items):
        self.Items = Items

fooObject = Foo([1,2,3])
obj = fooObject
itemValue = getattr(obj, 'Items')
print(itemValue)
values = itemValue
for val in values:
    print(val)
```