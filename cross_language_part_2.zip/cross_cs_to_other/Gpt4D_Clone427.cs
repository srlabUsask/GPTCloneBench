#input 
public int [] solution (int N, int [] A) {
    var currentMax = 0;
    var resetValue = 0;
    var counters = Enumerable.Range (1, N).ToDictionary (i = > i, i = > 0);
    foreach (var a in A) {
        if (a == N + 1)
            resetValue = currentMax;
        else {
            counters [a] = Math.Max (counters [a], resetValue) + 1;
            currentMax = Math.Max (currentMax, counters [a]);
        }
    }
    return counters.Values.Select (v = > Math.Max (v, resetValue)).ToArray ();
}


#====================
#gpt output=============
In Java:

```java
public int[] solution(int N, int[] A) {
    int currentMax = 0;
    int resetValue = 0;
    int[] counters = new int[N];
    for (int a : A) {
        if (a == N + 1)
            resetValue = currentMax;
        else {
            counters[a - 1] = Math.max(counters[a - 1], resetValue) + 1;
            currentMax = Math.max(currentMax, counters[a - 1]);
        }
    }
    for (int i = 0; i < counters.length; i++)
        counters[i] = Math.max(counters[i], resetValue);
    return counters;
}
```

In C:

```c
#include <stdlib.h>
#include <string.h>

void solution(int N, int *A, int M, int *counters) {
    int currentMax = 0, resetValue = 0, i;
    memset(counters, 0, N * sizeof(int));
    for (i = 0; i < M; i++) {
        if (A[i] == N + 1)
            resetValue = currentMax;
        else {
            counters[A[i] - 1] = counters[A[i] - 1] > resetValue ? counters[A[i] - 1] : resetValue;
            counters[A[i] - 1]++;
            currentMax = counters[A[i] - 1] > currentMax ? counters[A[i] - 1] : currentMax;
        }
    }
    for (i = 0; i < N; i++)
        counters[i] = counters[i] > resetValue ? counters[i] : resetValue;
}
```

In Python:

```python
def solution(N, A):
    currentMax = 0
    resetValue = 0
    counters = [0] * N
    for a in A:
        if a == N + 1:
            resetValue = currentMax
        else:
            counters[a-1] = max(counters[a-1], resetValue) + 1
            currentMax = max(currentMax, counters[a-1])
    for i in range(N):
        counters[i] = max(counters[i], resetValue)
    return counters
```