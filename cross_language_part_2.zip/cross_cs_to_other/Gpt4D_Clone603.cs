#input 
private void CheckIfPalindrome (string str) {
    char [] array = str.ToCharArray ();
    int length = array.Length - 1;
    Boolean palindrome = true;
    for (int i = 0; i <= length; i ++) {
        if (array [i] != array [length]) {
            MessageBox.Show ("not");
            palindrome = false;
            break;
        } else {
            length --;
        }
    }
    if (palindrome)
        MessageBox.Show ("Palindrome");
}


#====================
#gpt output=============
Java Code: 

```java
private void CheckIfPalindrome (String str) {
    char [] array = str.toCharArray ();
    int length = array.length - 1;
    boolean palindrome = true;
    for (int i = 0; i <= length; i ++) {
        if (array [i] != array [length]) {
            System.out.println("not");
            palindrome = false;
            break;
        } else {
            length --;
        }
    }
    if (palindrome)
        System.out.println("Palindrome");
}
```

C Code: 

```c
#include <stdio.h> 
#include <string.h> 
void CheckIfPalindrome(char str[]) {
    int length = strlen(str) - 1;
    int check = 1;
    for (int i = 0; i <= length; i++) {
        if (str[i] != str[length]) {
            printf("not");
            check = 0;
            break;
        } else {
            length--;
        }
    }
    if (check) 
        printf("Palindrome");
}
```

Python Code:

```python
def check_if_palindrome(str):
    length = len(str) - 1
    palindrome = True
    for i in range(length + 1):
        if (str[i] != str[length]):
            print("not")
            palindrome = False
            break
        else:
            length -= 1
    if (palindrome): 
        print("Palindrome")
```