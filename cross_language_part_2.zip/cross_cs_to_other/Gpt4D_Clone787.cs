#input 
public static void ShowWithParentFormLock (this Form childForm, Form parentForm, Action actionAfterClose) {
    if (childForm == null)
        throw new ArgumentNullException ("childForm");
    if (parentForm == null)
        throw new ArgumentNullException ("parentForm");
    EventHandler activatedDelegate = (object sender, EventArgs e) = > {
        childForm.Focus ();
    };
    childForm.FormClosed += (sender, closedEventArgs) = > {
        try {
            parentForm.Focus ();
            if (actionAfterClose != null)
                actionAfterClose ();
        }
        finally {
            try {
                parentForm.Activated -= activatedDelegate;
                if (! childForm.IsDisposed || ! childForm.Disposing)
                    childForm.Dispose ();
            }
            catch {
            }
        }
    };
    parentForm.Activated += activatedDelegate;
    childForm.Show (parentForm);
}


#====================
#gpt output=============
Java:

```java
public static void showWithParentFormLock(JDialog childForm, JFrame parentForm, Runnable actionAfterClose) {
    if(childForm == null)
        throw new IllegalArgumentException ("childForm");
    if(parentForm == null)
        throw new IllegalArgumentException ("parentForm");
    
    childForm.addWindowListener(new WindowAdapter(){
        public void windowOpened(WindowEvent e){
            childForm.requestFocus();
        }
        public void windowClosed(WindowEvent e){
            try {
                parentForm.requestFocus();
                if(actionAfterClose != null)
                    actionAfterClose.run();
            } finally {
                childForm.dispose();
            }
        }
    });
    
    childForm.setAutoRequestFocus(true);
    childForm.setModal(true);
    childForm.setVisible(true);
}
```

C:

C does not have built-in UI support, you would need to use a library and it will depend on that library.

Python with tkinter:

```python
import tkinter as tk

def show_with_parent_form_lock(child_form, parent_form, action_after_close):
    if child_form == None:
        raise Exception("childForm")
    if parent_form == None:
        raise Exception("parentForm")

    def focus_child(event):
        child_form.focus_set()
    def focus_parent(event):
        try:
            parent_form.focus_force()
            if action_after_close != None:
                action_after_close
        finally:
            child_form.destroy()

    child_form.bind('<Map>', focus_child)
    child_form.bind('<Destroy>', focus_parent)

    child_form.transient(parent_form)
    child_form.grab_set()
    parent_form.wait_window(child_form)
```

Python code above uses tkinter for GUI.