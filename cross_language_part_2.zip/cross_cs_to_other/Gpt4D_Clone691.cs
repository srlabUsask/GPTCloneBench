#input 
public static string EnumValue (this MyEnum e) {
    switch (e) {
        case MyEnum.First :
            return "First Friendly Value";
        case MyEnum.Second :
            return "Second Friendly Value";
        case MyEnum.Third :
            return "Third Friendly Value";
    }
    return "Horrible Failure!!";
}


#====================
#gpt output=============
The language versions of implementation would look something like the below:

Java:

```java
public enum MyEnum {
    First, Second, Third;

    public String EnumValue() {
        switch (this) {
            case First:
                return "First Friendly Value";
            case Second:
                return "Second Friendly Value";
            case Third:
                return "Third Friendly Value";
            default:
                return "Horrible Failure!!";
        }
    }
}
```

C:

```c
#include <stdio.h>

typedef enum {First, Second, Third} MyEnum;

char* EnumValue(MyEnum e) {
    switch(e) {
        case First: 
            return "First Friendly Value";
        case Second: 
            return "Second Friendly Value";
        case Third: 
            return "Third Friendly Value";
        default: 
            return "Horrible Failure!!";
    }
}
```

Python:

```python
from enum import Enum

class MyEnum(Enum):
    First = 1
    Second = 2
    Third = 3

def EnumValue(e):
    if e == MyEnum.First:
        return "First Friendly Value"
    elif e == MyEnum.Second:
        return "Second Friendly Value"
    elif e == MyEnum.Third:
        return "Third Friendly Value"
    else:
        return "Horrible Failure!!"
```