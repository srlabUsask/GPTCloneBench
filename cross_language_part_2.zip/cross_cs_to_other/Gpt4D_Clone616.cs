#input 
public static Task < TResult > OnPropertyChanged < T, TResult > (this T target, Expression < Func < T, TResult > > propertyExpression) where T : INotifyPropertyChanged {
    var tcs = new TaskCompletionSource < TResult > ();
    PropertyChangedEventHandler handler = null;
    var member = propertyExpression.GetMemberInfo ();
    var propertyName = member.Name;
    if (member.MemberType != MemberTypes.Property)
        throw new ArgumentException (string.Format ("{0} is an invalid property expression", propertyName));
    handler = (sender, args) = > {
        if (string.Equals (args.PropertyName, propertyName, StringComparison.InvariantCultureIgnoreCase)) {
            target.PropertyChanged -= handler;
            var value = propertyExpression.Compile () (target);
            tcs.SetResult (value);
        }
    };
    target.PropertyChanged += handler;
    return tcs.Task;
}


#====================
#gpt output=============
The given code appears to be C# and involves functionality specific to the C# language and its libraries, such as `PropertyChangedEventHandler`, `TaskCompletionSource`, and `Expression` which might not perfectly translate to Java and Python. However, a pseudo code intending to do similar thing can be written as follows:

Java:
```java
class ObservableObject extends Observable {
    private boolean changed;

    @Override
    protected void setChanged() {
        changed = true;
    }

    @Override
    protected void clearChanged() {
        changed = false;
    }

    @Override
    public boolean hasChanged() {
        return changed;
    }
}

class Task<T> implements Observer {
    String propertyName;
    CompletableFuture<T> future = new CompletableFuture<>();

    public Task(String propertyName) {
        this.propertyName = propertyName;
    }

    public void addObserver(ObservableObject object) {
        object.addObserver(this);
    }

    @Override
    public void update(Observable o, Object arg) {
        if (arg.equals(propertyName)) {
            future.complete((T)arg);
        }
    }

    public CompletableFuture<T> getFuture() {
        return future;
    }
}
```

Python:
```python
import threading
import asyncio

class Task:
    def __init__(self, target, prop_name):
        self.target = target
        self.prop_name = prop_name
        self.prop_value = None
        self._condition = threading.Condition()

    def on_property_change(self, new_prop_name, new_value):
        if new_prop_name == self.prop_name:
            self.prop_value = new_value
            with self._condition:
                self._condition.notify_all()

    def get_property_change(self):
        with self._condition:
            while self.prop_value is None:
                self._condition.wait()
            value = self.prop_value
        return value

    async def await_property_change(self):
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self.get_property_change)
        return self.prop_value
```

Remember to register the `Task` instance with the `ObservableObject` or equivalent class that tracks property changes. See documentation for `java.util.Observable` and `java.util.Observer` in Java and event handling in Python. Bear in mind that these are simplifications and might not perfectly mimic the provided C# code's behavior. The assumption here is that something must be changed or triggered simultaneously or subsequently for the task to be completed.