#input 
static int GetPlayers () {
    int ? players;
    Console.Write ("How many people are playing?");
    while (players == null) {
        try {
            players = Convert.ToInt16 (Console.ReadLine ());
        }
        catch (Exception e) {
            Console.Write (e.Message + "\n" + "----------");
        }
    }
    return players.Value;
}


#====================
#gpt output=============
Java:

```java
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println(getPlayers());
    }

    public static int getPlayers() {
        Scanner scanner = new Scanner(System.in);
        Integer players = null;
        System.out.println("How many people are playing?");
        while (players == null) {
            try {
                players = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println(e.getMessage() + "\n" + "----------");
            }
        }
        return players;
    }
}
```

C++:

```cpp
#include <iostream>
#include <stdexcept>

int getPlayers() {
    int players;
    std::cout << "How many people are playing?\n";
    while (true) {
        try {
            std::cin >> players;
            if(std::cin.fail()) {
                throw std::invalid_argument("Invalid input");
            }
            break;
        } catch (std::invalid_argument& e) {
            std::cout << e.what() << "\n----------";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }
    }
    return players;
}

int main() {
    std::cout << getPlayers() << std::endl;
    return 0;
}
```

Python:

```python
def get_players():
    players = None
    while players is None:
        try:
            players = int(input("How many people are playing?\n"))
        except ValueError as e:
            print(str(e) + "\n" + "----------")
    return players


print(get_players())
```