#input 
public static Image Resize (this Image image, Single scale) {
    if (image == null)
        return null;
    scale = Math.Max (0.0F, scale);
    Int32 scaledWidth = Convert.ToInt32 (image.Width * scale);
    Int32 scaledHeight = Convert.ToInt32 (image.Height * scale);
    return image.Resize (new Size (scaledWidth, scaledHeight));
}


#====================
#gpt output=============
Here are the implementations in Java, C, and Python:

Java:
```
public static Image resize(Image image, float scale) {
    if (image == null)
        return null;
    scale = Math.max(0.0f, scale);
    int scaledWidth = Math.round(image.getWidth(null) * scale);
    int scaledHeight = Math.round(image.getHeight(null) * scale);
    Image scaledImage = image.getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_DEFAULT);
    return scaledImage;
}
```

C:
```c
#include <stdlib.h>
#include <math.h>

struct Image {
    int width;
    int height;
};


struct Image* resize(struct Image* image, float scale) {
    if (image == NULL)
        return NULL;
    scale = fmax(0.0f, scale);
    int scaledWidth = (int)roundf(image->width * scale);
    int scaledHeight = (int)roundf(image->height * scale);
    struct Image* scaledImage = malloc(sizeof(struct Image));
    scaledImage->width = scaledWidth;
    scaledImage->height = scaledHeight;
    return scaledImage;
}
```

Python:
```python
from PIL import Image as PilImage

def resize(image, scale):
    if image is None:
        return None
    scale = max(0.0, scale)
    scaled_width = int(image.width * scale)
    scaled_height = int(image.height * scale)
    return image.resize((scaled_width, scaled_height), PilImage.ANTIALIAS)
```
Note: The C implementation assumes that you have a custom Image struct defined somewhere, with width and height properties. The Python implementation uses the PIL (Pillow) library's Image class.