#input 
public override void OnAuthorization (AuthorizationContext filterContext) {
    if (filterContext == null) {
        throw new ArgumentNullException ("filterContext");
    }
    if (AuthorizeCore (filterContext.HttpContext)) {
        SetCachePolicy (filterContext);
    } else if (! filterContext.HttpContext.User.Identity.IsAuthenticated) {
        filterContext.Result = new HttpUnauthorizedResult ();
    } else if (filterContext.HttpContext.User.IsInRole ("SuperUser")) {
        SetCachePolicy (filterContext);
    } else {
        ViewDataDictionary viewData = new ViewDataDictionary ();
        viewData.Add ("Message", "You do not have sufficient privileges for this operation.");
        filterContext.Result = new ViewResult {MasterName = this.MasterName, ViewName = this.ViewName, ViewData = viewData};
    }
}


#====================
#gpt output=============
The code you provided is in C# .NET framework for handling the authorization of different user roles on a specific action. Directly translating this to C, Python or Java is not feasible because it uses specific .NET classes and methods. However, I'll provide a basic pseudo-code version that should be similar:

C:

Consider C does not support object-oriented programming. Here's its equivalent in C-like style:

```c
void OnAuthorization (AuthorizationContext *filterContext) {
    if (filterContext == NULL) {
        fprintf(stderr, "filterContext is null");
        return -1;
    }
    if (AuthorizeCore (&(filterContext->HttpContext))) {
        SetCachePolicy (filterContext);
    } else if (! IsAuthenticated(filterContext->HttpContext.User.Identity)) {
        filterContext->Result = HttpUnauthorizedResult();
    } else if (IsInRole(filterContext->HttpContext.User, "SuperUser")) {
        SetCachePolicy (filterContext);
    } else {
        ViewDataDictionary *viewData = (ViewDataDictionary*) malloc(sizeof(ViewDataDictionary));
        Add(viewData, "Message", "You do not have sufficient privileges for this operation.");
        filterContext->Result = ViewResult(&viewData);
    }
}
```

Java:

```java
void OnAuthorization(AuthorizationContext filterContext) {
	if (filterContext == null) {
		throw new IllegalArgumentException("filterContext");
	}
	if (AuthorizeCore(filterContext.getHttpContext())) {
		SetCachePolicy(filterContext);
	} else if (!filterContext.getHttpContext().getUser().getIdentity().IsAuthenticated()) {
		filterContext.setResult(new HttpUnauthorizedResult());
	} else if (filterContext.getHttpContext().getUser().IsInRole("SuperUser")) {
		SetCachePolicy(filterContext);
	} else {
		ViewDataDictionary viewData = new ViewDataDictionary();
		viewData.put("Message", "You do not have sufficient privileges for this operation.");
		filterContext.setResult(new ViewResult(MasterName, ViewName, viewData));
	}
}
```

Python:

```python
def OnAuthorization(filterContext):
	if filterContext == None:
		raise ValueError("filterContext")
	if AuthorizeCore(filterContext.HttpContext):
		SetCachePolicy(filterContext)
	elif not filterContext.HttpContext.User.Identity.IsAuthenticated:
		filterContext.Result = HttpUnauthorizedResult()
	elif filterContext.HttpContext.User.IsInRole("SuperUser"):
		SetCachePolicy(filterContext)
	else:
		viewData = {}
		viewData["Message"] = "You do not have sufficient privileges for this operation."
		filterContext.Result = ViewResult(MasterName, ViewName, viewData)
```
Remember to replace `MasterName`, `ViewName`, `AuthorizeCore`, `SetCachePolicy`, `HttpUnauthorizedResult`, and `ViewResult` with actual functions, methods or variables in your context. These codes just emulate the flow and may not work as expected because these are pseudo-codes which you would need to customize according to your needs.