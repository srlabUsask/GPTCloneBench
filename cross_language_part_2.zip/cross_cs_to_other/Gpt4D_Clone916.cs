#input 
static void Main (string [] args) {
    Console.WriteLine ("Enter the string");
    string x = Console.ReadLine ();
    Console.WriteLine ("enter the string to be searched");
    string SearchText = Console.ReadLine ();
    string [] myarr = new string [30];
    myarr = x.Split (' ');
    int i = 0;
    foreach (string s in myarr) {
        i = i + 1;
        if (s == SearchText) {
            Console.WriteLine ("The string found at position:" + i);
        }
    }
    Console.ReadLine ();
}


#====================
#gpt output=============
Java:

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the string");
        String x = input.nextLine();
        System.out.println("Enter the string to be searched");
        String searchText = input.nextLine();
        String[] myarr = x.split("\\s+");
        int i = 0;
        for(String s : myarr){
            i++;
            if(s.equals(searchText)){
                System.out.println("The string found at position: " + i);
            }
        }
    }  
}

C:
    
#include<stdio.h>
#include<string.h>
#define MAX 30

int main() {
    char x[MAX], search_text[MAX];
    printf("Enter the string\n");
    gets(x);
    printf("Enter the string to be searched\n");
    gets(search_text);
    char *myarr[MAX];
    char *token = strtok(x, " ");
    int i = 0;
    while(token) {
        myarr[i++] = token;
        token = strtok(NULL, " ");
    }
    for(int j=0; j<i; j++){
        if(!strcmp(myarr[j], search_text)){
            printf("The string found at position: %d\n", j+1);
        }
    }  
    return 0;
}

Python:

x = input("Enter the string\n")
search_text = input("Enter the string to be searched\n")
myarr = x.split()
for i, s in enumerate(myarr, 1):
    if s == search_text:
        print(f"The string found at position: {i}")