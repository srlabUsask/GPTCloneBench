#input 
private string GetControlValue (string controlId) {
    var control = FindControl (controlId);
    if (control is ITextControl) {
        return ((ITextControl) control).Text;
    } else if (control is ICheckBoxControl) {
        return ((ICheckBoxControl) control).Checked.ToString ();
    } else {
        return null;
    }
}


#====================
#gpt output=============
Here is the equivalent pseudocode in Java, C, and Python. Please note that this code doesn't directly or completely convert into the equivalent C language as C doesn't have classes or interfaces like Java or Python. Therefore, equivalent C example could be very context-dependent and would require complex struct and function pointer approaches. 

Java:

```java
public String GetControlValue (String controlId) {
    Control control = this.FindControl(controlId);
    if (control instanceof ITextControl) {
        return ((ITextControl) control).getText();
    } else if (control instanceof ICheckBoxControl) {
        return Boolean.toString(((ICheckBoxControl) control).isChecked());
    } else {
        return null;
    }
}
```

Python:

```python
def get_control_value(self, controlId):
    control = self.find_control(controlId)
    if isinstance(control, ITextControl):
        return control.text
    elif isinstance(control, ICheckBoxControl):
        return str(control.checked)
    else:
        return None
```

C:

Due to the nature of the C language which doesn't support object-oriented programming natively like Java or Python, there's no direct conversion of the given code. 

Assumed implementation could look something like this, but there's a lot of context missing to provide a more accurate conversion.

```c
const char* get_control_value(const char* controlId) {
   Control* control = find_control(controlId);
   if (control->type == TEXT_CONTROL)
     return control->text;
   else if (control->type == CHECKBOX_CONTROL)
     return control->checked ? "True" : "False";
   else
     return NULL;
}
```