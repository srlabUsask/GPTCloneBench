#input 
public string ReadCookie (string strCookieName) {
    foreach (string strCookie in HttpContext.Current.Response.Cookies.AllKeys) {
        if (strCookie == strCookieName) {
            return HttpContext.Current.Response.Cookies [strCookie].Value;
        }
    }
    foreach (string strCookie in HttpContext.Current.Request.Cookies.AllKeys) {
        if (strCookie == strCookieName) {
            return HttpContext.Current.Request.Cookies [strCookie].Value;
        }
    }
    return null;
}


#====================
#gpt output=============
Java:

```java
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public String readCookie(String cookieName, HttpServletRequest request, HttpServletResponse response) {
    Cookie[] requestCookies = request.getCookies();
    if (requestCookies != null) {
        for (Cookie c : requestCookies) {
            if (c.getName().equals(cookieName)) {
                return c.getValue();
            }
        }
    }
    
    Cookie[] responseCookies = response.getCookies();
    if (responseCookies != null) {
        for (Cookie c : responseCookies) {
            if (c.getName().equals(cookieName)) {
                return c.getValue();
            }
        }
    }
    return null;
}
```

C:

Note: The below example assumes the use of the C-based CGI library, as C itself does not have a built-in method for interacting with cookies.

```c
#include <cgi/cgic.h>

char * readCookie(char *cookieName) {
    char *cookieValue;
    if (cgiCookieString(cookieName, cookieValue, 0) != cgiFormSuccess) {
        return NULL;
    } else {
        return cookieValue;
    }
}
```

Python:

```python
from flask import request, make_response

def read_cookie(cookie_name):
    cookie = request.cookies.get(cookie_name)
    if cookie is not None:
        return cookie
    response = make_response()
    cookie = response.cookies.get(cookie_name)
    if cookie is not None:
        return cookie
    return None
```