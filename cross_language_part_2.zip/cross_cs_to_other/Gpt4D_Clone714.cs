#input 
private int CountDivisorsOfNumber (int number) {
    int count = 0;
    int end = (int) Math.Sqrt (number);
    for (int i = 1; i < end; i ++) {
        if (number % i == 0)
            count += 2;
    }
    if (end * end == number)
        count ++;
    return count;
}


#====================
#gpt output=============
Here are the equivalent codes for Java, C and Python:

Java:
```java
private int countDivisorsOfNumber(int number) {
    int count = 0;
    int end = (int) Math.sqrt (number);
    for (int i = 1; i < end; i++) {
        if (number % i == 0)
            count += 2;
    }
    if (end * end == number)
        count++;
    return count;
}
```

C:
```c
#include <math.h>

int countDivisorsOfNumber(int number) {
    int count = 0;
    int end = (int) sqrt (number);
    for (int i = 1; i < end; i++) {
        if (number % i == 0)
            count += 2;
    }
    if (end * end == number)
        count++;
    return count;
}
```

Python:
```python
import math

def count_divisors_of_number(number):
    count = 0
    end = int(math.sqrt(number))
    for i in range(1, end):
        if number % i == 0:
            count += 2
    if end * end == number:
        count += 1
    return count
```