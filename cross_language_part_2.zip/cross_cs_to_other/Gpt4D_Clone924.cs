#input 
public static IEnumerable < IList < T > > ChunkOn < T > (this IEnumerable < T > source, Func < T, bool > startChunk) {
    List < T > list = new List < T > ();
    foreach (var item in source) {
        if (startChunk (item) && list.Count > 0) {
            yield return list;
            list = new List < T > ();
        }
        list.Add (item);
    }
    if (list.Count > 0) {
        yield return list;
    }
}


#====================
#gpt output=============
Java:

```java
import java.util.*;
import java.util.function.Predicate;

public class Main {
    public static <T> List<List<T>> chunkOn(List<T> source, Predicate<T> startChunk) {
        List<List<T>> res = new ArrayList<>();
        List<T> list = new ArrayList<>();

        for (T item : source) {
            if (startChunk.test(item) && !list.isEmpty()) {
                res.add(list);
                list = new ArrayList<>();
            }
            list.add(item);
        }

        if (!list.isEmpty()) {
            res.add(list);
        }

        return res;
    }
}
```

C:

```c
#include <stdbool.h>

// Assuming an int type for simplicity
void chunkOn(int* source, int sourceSize, bool(*startChunk)(int), int*** result, int* resultSize) {
    int* list = malloc(sourceSize * sizeof(int));
    int listSize = 0;

    for (int i = 0; i < sourceSize; i++) {
        if (startChunk(source[i]) && listSize > 0) {
            *result = realloc(*result, (*resultSize + 1) * sizeof(int*));
            (*result)[*resultSize] = list;
            (*resultSize)++;
            list = malloc(sourceSize * sizeof(int));
            listSize = 0;
        }
        list[listSize] = source[i];
        listSize++;
    }

    if (listSize > 0) {
        *result = realloc(*result, (*resultSize + 1) * sizeof(int*));
        (*result)[*resultSize] = list;
        (*resultSize)++;
    }
}
```

Python:

```python
def chunk_on(source, start_chunk):
    result = []
    list = []

    for item in source:
        if start_chunk(item) and len(list) > 0:
            result.append(list)
            list = []
        list.append(item)

    if len(list) > 0:
        result.append(list)

    return result
```