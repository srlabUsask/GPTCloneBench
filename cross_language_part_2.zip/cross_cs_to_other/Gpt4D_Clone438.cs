#input 
public static void Rename (this FileSystemInfo item, string newName) {
    if (item == null) {
        throw new ArgumentNullException ("item");
    }
    FileInfo fileInfo = item as FileInfo;
    if (fileInfo != null) {
        fileInfo.Rename (newName);
        return;
    }
    DirectoryInfo directoryInfo = item as DirectoryInfo;
    if (directoryInfo != null) {
        directoryInfo.Rename (newName);
        return;
    }
    throw new ArgumentException ("Item", "Unexpected subclass of FileSystemInfo " + item.GetType ());
}


#====================
#gpt output=============
Java Implementation:

```
import java.nio.file.*;

public static void rename(Path item, String newName) throws Exception {
    if (item == null) {
        throw new IllegalArgumentException ("item");
    }
    try {
        Files.move(item, item.resolveSibling(newName));
    } catch (Exception e) {
        throw new Exception("Unexpected error " + e.getMessage());
    }
}
```

C Implementation:

```
#include <stdio.h>
#include <stdlib.h>

void rename_file_or_directory(const char *oldname, const char *newname) {
    if (oldname == NULL) {
        fprintf(stderr, "NULL pointer received\n");
        exit(EXIT_FAILURE);
    }
    if (rename(oldname, newname) != 0) {
        perror("Error renaming file or directory");
        exit(EXIT_FAILURE);
    }
}
```

Python Implementation:

```
import os

def rename(item, new_name):
    if item is None:
        raise ValueError("Item cannot be None")
    try:
        os.rename(item, new_name)
    except Exception as e:
        raise ValueError("Unexpected error " + str(e))
```