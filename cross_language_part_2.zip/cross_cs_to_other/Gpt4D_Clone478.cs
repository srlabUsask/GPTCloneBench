#input 
public int AddDataScalar (string strU) {
    string strQueryExistence = @"IF EXISTS(SELECT 1 FROM [OB].[h].[OP_PEONS] 
                                 WHERE Executive= @stru) SELECT 1 ELSE SELECT 0";
    int inNum = 0;
    using (SqlConnection con = new SqlConnection (strConn))
    using (SqlCommand cmd = new SqlCommand (strQueryExistence, con))
    {
        con.Open ();
        cmd.Parameters.AddWithValue ("@stru", strU);
        inNum = Convert.ToInt32 (cmd.ExecuteScalar ());
    } return inNum;
}


#====================
#gpt output=============
Java:

public int addDataScalar(String strU) throws SQLException {
    String strQueryExistence = "IF EXISTS(SELECT 1 FROM [OB].[h].[OP_PEONS] WHERE Executive= ?) SELECT 1 ELSE SELECT 0";
    int inNum = 0;
    try (
        Connection con = DriverManager.getConnection(strConn);
        PreparedStatement pst = con.prepareStatement(strQueryExistence);
    ) {
        pst.setString(1, strU);
        try (ResultSet rs = pst.executeQuery()) {
            if (rs.next()) {
                inNum = rs.getInt(1);
            }
        }
    }
    return inNum;
}

C:

Note: C doesn't natively support database operations, a library such as MySQL Connector/C can be used. Sample code using this library might be:

#include <mysql.h>
int addDataScalar(char *strU) {
    MYSQL *con = mysql_init(NULL);
    MYSQL_STMT *stmt;
    MYSQL_BIND bind[1];
    int inNum = 0;
    char *strQueryExistence = "IF EXISTS(SELECT 1 FROM [OB].[h].[OP_PEONS] WHERE Executive= ?) SELECT 1 ELSE SELECT 0";
    if(con == NULL) {
        fprintf(stderr, "%s\n", mysql_error(con));
        exit(1);
    }
    if(mysql_real_connect(con, "localhost", "user", "password", NULL, 0, NULL, 0) == NULL) {
        finish_with_error(con);
    }
    stmt = mysql_stmt_init(con);
    if(!stmt) {
        finish_with_error(con);
    }
    if(mysql_stmt_prepare(stmt, strQueryExistence, strlen(strQueryExistence))) {
        finish_with_error(con);
    }
    memset(bind, 0, sizeof(bind));
    bind[0].buffer_type = MYSQL_TYPE_STRING;
    bind[0].buffer = (char *)strU;
    bind[0].buffer_length = strlen(strU);
    if(mysql_stmt_bind_param(stmt, bind)) {
        finish_with_error(con);
    }
    if(mysql_stmt_execute(stmt)) {
        finish_with_error(con);
    }
    bind[0].buffer_type = MYSQL_TYPE_LONG;
    bind[0].buffer = (char *)&inNum;
    if(mysql_stmt_bind_result(stmt, bind)) {
        finish_with_error(con);
    }
    if(mysql_stmt_fetch(stmt)) {
        finish_with_error(con);
    }
    mysql_stmt_close(stmt);
    mysql_close(con);
    return inNum;
}

Python:

import pyodbc
def addDataScalar(strU):
    strQueryExistence = "IF EXISTS(SELECT 1 FROM [OB].[h].[OP_PEONS] WHERE Executive= ?) SELECT 1 ELSE SELECT 0"
    con = pyodbc.connect(strConn)
    cursor = con.cursor()
    cursor.execute(strQueryExistence, strU)
    inNum = cursor.fetchone()
    if inNum is None:
        inNum = 0
    else:
        inNum = inNum[0]
    return inNum
Note: All samples assume a variable 'strConn' is globally accessible, that holds the string connection to the database. For the C sample the db's user's access credentials (user, password) are used to access the database under the current architecture. It is not recommended to use root user or strong access permissions credentials for such operations, instead a user with the necessary permissions should be created and used.