#input 
public static Double Correlation (Double [] Xs, Double [] Ys) {
    Double sumX = 0;
    Double sumX2 = 0;
    Double sumY = 0;
    Double sumY2 = 0;
    Double sumXY = 0;
    int n = Xs.Length < Ys.Length ? Xs.Length : Ys.Length;
    for (int i = 0; i < n; ++ i) {
        Double x = Xs [i];
        Double y = Ys [i];
        sumX += x;
        sumX2 += x * x;
        sumY += y;
        sumY2 += y * y;
        sumXY += x * y;
    }
    Double stdX = Math.Sqrt (sumX2 / n - sumX * sumX / n / n);
    Double stdY = Math.Sqrt (sumY2 / n - sumY * sumY / n / n);
    Double covariance = (sumXY / n - sumX * sumY / n / n);
    return covariance / stdX / stdY;
}


#====================
#gpt output=============
Java:

```java
public static Double Correlation (Double [] Xs, Double [] Ys) {
    Double sumX = 0.0;
    Double sumX2 = 0.0;
    Double sumY = 0.0;
    Double sumY2 = 0.0;
    Double sumXY = 0.0;
    int n = Xs.length < Ys.length ? Xs.length : Ys.length;
    for (int i = 0; i < n; ++ i) {
        Double x = Xs [i];
        Double y = Ys [i];
        sumX += x;
        sumX2 += x * x;
        sumY += y;
        sumY2 += y * y;
        sumXY += x * y;
    }
    Double stdX = Math.sqrt (sumX2 / n - sumX * sumX / n / n);
    Double stdY = Math.sqrt (sumY2 / n - sumY * sumY / n / n);
    Double covariance = (sumXY / n - sumX * sumY / n / n);
    return covariance / stdX / stdY;
}
```

C:

```c
#include <math.h>

double Correlation (double* Xs, double* Ys, int xs_len, int ys_len) {
    double sumX = 0.0, sumX2 = 0.0, sumY = 0.0, sumY2 = 0.0, sumXY = 0.0;
    int n = xs_len < ys_len ? xs_len : ys_len;
    for (int i = 0; i < n; ++ i) {
        double x = Xs[i];
        double y = Ys[i];
        sumX += x;
        sumX2 += x * x;
        sumY += y;
        sumY2 += y * y;
        sumXY += x * y;
    }
    double stdX = sqrt(sumX2 / n - sumX * sumX / n / n);
    double stdY = sqrt(sumY2 / n - sumY * sumY / n / n);
    double covariance = (sumXY / n - sumX * sumY / n / n);
    return covariance / stdX / stdY;
}
```

Python:

```python
import math

def correlation(Xs, Ys):
    sumX = sumX2 = sumY = sumY2 = sumXY = 0.0
    n = min(len(Xs), len(Ys))
    for i in range(n):
        x, y = Xs[i], Ys[i]
        sumX += x
        sumX2 += x * x
        sumY += y
        sumY2 += y * y
        sumXY += x * y

    stdX = math.sqrt(sumX2 / n - sumX ** 2 / n / n)
    stdY = math.sqrt(sumY2 / n - sumY ** 2 / n / n)
    covariance = (sumXY / n - sumX * sumY / n / n)
    return covariance / stdX / stdY
```