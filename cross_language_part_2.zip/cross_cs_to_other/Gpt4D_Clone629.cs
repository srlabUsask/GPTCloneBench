#input 
protected void EndReceive (IAsyncResult async) {
    string msg = "";
    try {
        int received = SimNetSocket.EndReceive (async);
        var tmpArr = new byte [received];
        Buffer.BlockCopy (ReadBuffer, 0, tmpArr, 0, received);
        msg = ByteArrayToString (tmpArr);
        Debug.Log ("RAW RECEIVE: " + msg);
        MessageBuffer += msg;
        BeginReceive ();
    }
    catch (Exception e) {
        Debug.LogError (e);
    }
}


#====================
#gpt output=============
JAVA:

```java
protected void endReceive(Future<Integer> future) throws Exception {
    String msg = "";
    try {
        int received = future.get();
        byte[] tmpArr = new byte[received];
        System.arraycopy(readBuffer, 0, tmpArr, 0, received);
        msg = new String(tmpArr, StandardCharsets.UTF_8);
        System.out.println("RAW RECEIVE: " + msg);
        messageBuffer += msg;
        beginReceive();
    } catch (Exception e) {
        System.err.println(e);
        throw e;
    }
}
```

C:

```c
void EndReceive(struct Future* future) {
    char* msg = "";
    try {
        int received = future->val;
        char* tmpArr = (char *)malloc(sizeof(char) * received);
        memcpy(tmpArr, readBuffer, received);
        msg = tmpArr;
        printf("RAW RECEIVE: %s\n", msg);
        strcat(messageBuffer, msg);
        BeginReceive();
    } catch (Exception e) {
        printf("Error: %s\n", e->errorMessage);
    }
}
```

PYTHON:

```python
def end_receive(future):
    msg = ""
    try:
        received = future.result()
        tmpArr = readBuffer[:received]
        msg = tmpArr.decode('utf-8')
        print("RAW RECEIVE: " + msg)
        messageBuffer += msg
        begin_receive()
    except Exception as e:
        print(e)
```

Note: I am assuming that readBuffer and messageBuffer are global variables and beginReceive is a global function. These assumptions are similar to your original code. The use of async/ IAsyncResult / Futures varies from one language to another and might require handling threading and other complexities which goes beyond the scope of code translation.