#input 
private static string FormatNumber (long num) {
    long i = (long) Math.Pow (10, (int) Math.Max (0, Math.Log10 (num) - 2));
    num = num / i * i;
    if (num >= 1000000000)
        return (num / 1000000000D).ToString ("0.##") + "B";
    if (num >= 1000000)
        return (num / 1000000D).ToString ("0.##") + "M";
    if (num >= 1000)
        return (num / 1000D).ToString ("0.##") + "K";
    return num.ToString ("#,0");
}


#====================
#gpt output=============
Java:
```java
private static String formatNumber (long num) {
    long i = (long) Math.pow (10, (int) Math.max (0, Math.log10 (num) - 2));
    num = num / i * i;
    if (num >= 1000000000)
        return String.format("%.2f", (num / 1000000000.0)) + "B";
    if (num >= 1000000)
        return String.format("%.2f", (num / 1000000.0)) + "M";
    if (num >= 1000)
        return String.format("%.2f", (num / 1000.0)) + "K";
    return String.format("%,d", num);
}
```

C:
```c
#include <math.h>
#include <stdio.h>

char* format_number(long num){
    long i = (long) pow (10, (int) fmax (0, log10 (num) - 2));
    num = num / i * i;
    char* res = (char*) malloc(sizeof(char)* 20);
    if (num >= 1000000000)
        sprintf(res, "%.2fB", num / 1000000000.0);
    else if (num >= 1000000)
        sprintf(res, "%.2fM", num / 1000000.0);
    else if (num >= 1000)
        sprintf(res, "%.2fK", num / 1000.0);
    else 
        sprintf(res, "%ld", num);
    return res;
}
```

Python:
```python
def format_number(num):
    i = 10 ** max(0, int(math.log10(num)) - 2)
    num = num / i * i
    if num >= 1000000000:
        return "{:.2f}B".format(num / 1000000000)
    if num >= 1000000:
        return "{:.2f}M".format(num / 1000000)
    if num >= 1000:
        return "{:.2f}K".format(num / 1000)
    return "{:,}".format(num)
```