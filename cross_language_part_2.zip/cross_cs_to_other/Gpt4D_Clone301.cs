#input 
protected void Button1_Click (object sender, EventArgs e) {
    try {
        using (MySqlCommand SelectCommand = new MySqlCommand ("select count(*) from films.user where user_name=@username AND password = @password", cs))
        {
            SelectCommand.Parameters.AddWithValue ("@username", username.Text);
            SelectCommand.Parameters.AddWithValue ("@password", password.Text);
            cs.Open ();
            int count = (int) SelectCommand.ExecuteScalar ();
            if (count == 1) {
                Response.Write (@"<script language='javascript'>alert('wow your in !!');</script>");
            } else if (count > 1) {
                Response.Write (@"<script language='javascript'>alert('duplicate');</script>");
            } else
                Response.Write (@"<script language='javascript'>alert('wrong password');</script>");
        }}
    catch (Exception ex) {
        Response.Write (@"<script language='javascript'>alert(ex.message);</script>");
    }
}


#====================
#gpt output=============
Java implementation:

```java
public void Button1_Click(ActionEvent event) {
    try (Connection cs = DriverManager.getConnection(url, dbUser, dbPass);
         PreparedStatement selectCommand = cs.prepareStatement("select count(*) from films.user where user_name=? AND password = ?")) {
        selectCommand.setString(1, username.getText());
        selectCommand.setString(2, password.getText());
        ResultSet results = selectCommand.executeQuery();
        int count = 0;
        if(results.next()) {
            count = results.getInt(1);
        }
        if(count == 1) {
            JOptionPane.showMessageDialog(null, "wow you're in !!");
        } else if(count > 1) {
            JOptionPane.showMessageDialog(null,"duplicate");
        } else {
            JOptionPane.showMessageDialog(null, "wrong password");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, e.getMessage());
    }
}
```

Python implementation:

```python
import mysql.connector
from mysql.connector import Error
from tkinter import messagebox

def Button1_Click():
    try:
        cs = mysql.connector.connect(host='localhost',database='database_name',user='user_name',password='user_password')
        cursor = cs.cursor()
        cursor.execute("SELECT count(*) FROM films.user WHERE user_name=%s AND password=%s", (username.get(), password.get()))
        count=cursor.fetchone()[0]
        if count == 1:
            messagebox.showinfo('Info', "Wow you're in !!")
        elif count > 1:
            messagebox.showinfo('Info', "duplicate")
        else:
            messagebox.showinfo('Info', "wrong password")

    except Error as e:
        messagebox.showinfo('Error', e)
```

C implementation:

```c
// C language does not have built-in database handling abilities or graphical user interface capabilities. 
// You would need to use a third-party library for managing database connections and user interfaces. 
// This functionality is typically handled in higher-level languages like Java and Python.
```
