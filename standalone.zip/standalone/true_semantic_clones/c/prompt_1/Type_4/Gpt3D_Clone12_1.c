int main (void) {
    int x;
    scanf ("%d", & x);
    if (x == 1)
        printf ("ON");
    else if (x == 0)
        printf ("OFF");
    else
        printf ("Unexpected Input");
}


int main (void){
    int x;
    scanf("%d", &x);
    switch(x){
        case 1:
            printf("ON");
            break;
        case 0:
            printf("OFF");
            break;
        default:
            printf("Unexpected Input");
            break;
    }
}


