main () {
    int a, b, c, max;
    printf ("enter three numbers: ");
    scanf ("%d %d %d", & a, & b, & c);
    max = a;
    if (b >= a) {
        max = b;
    }
    if (max < c) {
        max = c;
    }
    printf ("%d is greatest", max);
}


main () {
    int a, b, c;
    printf ("enter three numbers: ");
    scanf ("%d %d %d", & a, & b, & c);
    if (a >= b) {
        if (a >= c) {
            printf ("%d is greatest", a);
        }
        else {
            printf ("%d is greatest", c);
        }
    }
    else {
        if (b >= c) {
            printf ("%d is greatest", b);
        }
        else {
            printf ("%d is greatest", c);
        }
    }
}


