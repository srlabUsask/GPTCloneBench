int main () {
    char str [] = "- This, a sample string.";
    char *pch;
    printf ("Splitting string \"%s\" into tokens:\n", str);
    pch = strtok (str, " ,.-");
    while (pch != NULL) {
        printf ("%s\n", pch);
        pch = strtok (NULL, " ,.-");
    }
    return 0;
}


int main () {
    char str [20] = "- This, a sample string.";
    int i;
    for (i = 0; i < (int)strlen (str); i++) {
        if (str[i] == ' ' || str[i] == ',' || str[i] == '.' || str[i] == '-') {
            printf ("\n");
        } else {
            printf ("%c", str[i]);
        }
    }
    return 0;
}


