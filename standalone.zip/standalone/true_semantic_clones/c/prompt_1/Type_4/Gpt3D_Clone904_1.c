int main () {
    printf ("1st Run:\n" "========\n" "\n");
    run (& testSetSafe1);
    printf ("\n");
    printf ("2nd Run:\n" "========\n" "\n");
    run (& testSetSafe2);
    printf ("\n");
    printf ("3rd Run:\n" "========\n" "\n");
    run (& testSetUnsafe);
    printf ("\n");
    printf ("Done.\n");
    return 0;
}


int main () {
    printf ("1st Run:\n" "========\n" "\n");
    int (*ptr_arr[3])();
    ptr_arr[0] = & testSetSafe1;
    ptr_arr[1] = & testSetSafe2;
    ptr_arr[2] = & testSetUnsafe;
    for (int i = 0; i < 3; ++i) {
        printf ("\n");
        printf ("%d %s:\n" "========\n" "\n", (i+1),  "Run");
        run(ptr_arr[i]);
    }

    printf ("Done.\n");
    return 0;
}


