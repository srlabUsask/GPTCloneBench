int main (void) {
    demo *ptr = &fieldDefinitions[0];
    int fieldDefSize = sizeof (fieldDefinitions) / sizeof (fieldDefinitions[0]);
    int i = 0;
    while (i < fieldDefSize - 1) {
        printf ("ptr: %p \n", (void *) (ptr + i));
        printf ("ptr: %d \n", (ptr + i) -> a);
        i++;
    }
    return 0;
}


int main (void) {
    demo *ptr = fieldDefinitions;
    demo *end = &fieldDefinitions[sizeof (fieldDefinitions) / sizeof (fieldDefinitions[0]) - 1];
    do {
        printf ("ptr: %p \n", (void *) ptr);
        printf ("ptr: %d \n", ptr -> a);
    }
    while (ptr++ < end);
    return 0;
}


