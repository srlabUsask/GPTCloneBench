int main () {
    memset (myUnion.c, 0, 8 * sizeof (char));
    printMyUnion (& myUnion);
    memset (myUnion.c, 0, 8 * sizeof (char));
    myUnion.i = 10;
    printMyUnion (& myUnion);
    memset (myUnion.c, 0, 8 * sizeof (char));
    myUnion.f = 10;
    printMyUnion (& myUnion);
    memset (myUnion.c, 0, 8 * sizeof (char));
    myUnion.f = 3.1415;
    printMyUnion (& myUnion);
    return 0;
}


int main () {
    myUnion.c[0] = 0;
    myUnion.c[1] = 0;
    myUnion.c[2] = 0;
    myUnion.c[3] = 0;
    myUnion.c[4] = 0;
    myUnion.c[5] = 0;
    myUnion.c[6] = 0;
    myUnion.c[7] = 0;
    printMyUnion (& myUnion);
    myUnion.i = 10;
    printMyUnion (& myUnion);
    myUnion.c[0] = 0;
    myUnion.c[1] = 0;
    myUnion.c[2] = 0;
    myUnion.c[3] = 0;
    myUnion.c[4] = 0;
    myUnion.c[5] = 0;
    myUnion.c[6] = 0;
    myUnion.c[7] = 0;
    myUnion.f = 10;
    printMyUnion (& myUnion);
    myUnion.c[0] = 0;
    myUnion.c[1] = 0;
    myUnion.c[2] = 0;
    myUnion.c[3] = 0;
    myUnion.c[4] = 0;
    myUnion.c[5] = 0;
    myUnion.c[6] = 0;
    myUnion.c[7] = 0;
    myUnion.f = 3.1415;
    printMyUnion (& myUnion);
    return 0;
}


