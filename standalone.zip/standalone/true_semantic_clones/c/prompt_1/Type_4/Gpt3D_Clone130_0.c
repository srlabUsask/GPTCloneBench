int main (void) {
    int arr1 [] = {1, 2, 3, 4, 5};
    int arr2 [] = {3, 4, 5, 1, 2};
    int arr3 [] = {3, 4, 5, 2, 1};
    int arr4 [] = {1, 0, 1, 1, 0};
    int arr5 [] = {1, 0, 1, 0, 1};
    size_t size = sizeof (arr1) / sizeof (*arr1);
    
    //Variant 1    
    int i;
    for (i = 0; i < size; i++) {
        if (arr1[i] != arr2[i]) {
            printf("Elements are not equal!\n");
            break;
        }
    }
    if (i == size) {
        printf("The two arrays are equal!\n");    
    }
    for (i = 0; i < size; i++) {
        if (arr1[i] != arr3[i]) {
            printf("Elements are not equal!\n");
            break;
        }
    }
    if (i == size) {
        printf("The two arrays are equal!\n");    
    }
    for (i = 0; i < size; i++) {
        if (arr4[i] != arr5[i]) {
            printf("Elements are not equal!\n");
            break;
        }
    }
    if (i == size) {
        printf("The two arrays are equal!\n");    
    }
    
    //Variant 2
    int j;
    for (j = 0; j < size; j++) {
        if (arr1[j] == arr2[j]) {
            printf("Elements are equal!\n");
            break;
        }
    }
    if (j == size) {
        printf("The two arrays are not equal!\n");    
    }
    for (j = 0; j < size; j++) {
        if (arr1[j] == arr3[j]) {
            printf("Elements are equal!\n");
            break;
        }
    }
    if (j == size) {
        printf("The two arrays are not equal!\n");    
    }
    for (j = 0; j < size; j++) {
        if (arr4[j] == arr5[j]) {
            printf("Elements are equal!\n");
            break;
        }
    }
    if (j == size) {
        printf("The two arrays are not equal!\n");    
    }    

}


int main (void) {
    int arr1 [] = {1, 2, 3, 4, 5};
    int arr2 [] = {3, 4, 5, 1, 2};
    int arr3 [] = {3, 4, 5, 2, 1};
    int arr4 [] = {1, 0, 1, 1, 0};
    int arr5 [] = {1, 0, 1, 0, 1};
    size_t size = sizeof (arr1) / sizeof (*arr1);
    TEST (size, arr1, arr2);
    TEST (size, arr1, arr3);
    TEST (size, arr4, arr5);
}


