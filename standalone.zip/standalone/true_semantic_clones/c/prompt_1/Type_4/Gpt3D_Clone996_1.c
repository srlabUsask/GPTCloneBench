int main (void) {
    test (INT_MIN);
    test (- 2);
    test (- 1);
    test (0);
    test (1);
    test (2);
    test (INT_MAX);
    return 0;
}


int main (void) {
    test (INT_MIN);
    test (-1 * 2);
    test (0 - 1);
    test (0 * 1);
    test (1 * 1);
    test (2 * 1);
    test (INT_MAX);
    return 0;
}


