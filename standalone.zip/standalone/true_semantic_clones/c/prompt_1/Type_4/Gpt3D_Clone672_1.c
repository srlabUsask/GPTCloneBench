main () {
    int a, b, c;
    printf ("enter three numbers: ");
    scanf ("%d %d %d", & a, & b, & c);
    if (a >= b) {
        if (a >= c) {
            printf ("%d is greatest", a);
        }
        else {
            printf ("%d is greatest", c);
        }
    }
    else {
        if (b >= c) {
            printf ("%d is greatest", b);
        }
        else {
            printf ("%d is greatest", c);
        }
    }
}



main () {
    int a, b, c, max;
    printf ("enter three numbers: ");
    scanf ("%d %d %d", & a, & b, & c);
    max = a;
    if (b > max)
        max = b;
    if (c > max)
        max = c;
    printf ("%d is greatest", max);
}


