int main (void) {
    demo *ptr = fieldDefinitions;
    demo *end = &fieldDefinitions[sizeof (fieldDefinitions) / sizeof (fieldDefinitions[0]) - 1];
    do {
        printf ("ptr: %p \n", (void *) ptr);
        printf ("ptr: %d \n", ptr -> a);
    }
    while (ptr++ < end);
    return 0;
}


int main (void) {
    demo *ptr = fieldDefinitions;
    int fieldDefSize = sizeof (fieldDefinitions) / sizeof (fieldDefinitions[0]);
    for (int i=0; i < fieldDefSize - 1; i++) {
        printf ("ptr: %p \n", (void *) (ptr + i));
        printf ("ptr: %d \n", (ptr + i) -> a);
    }
    return 0;
}


