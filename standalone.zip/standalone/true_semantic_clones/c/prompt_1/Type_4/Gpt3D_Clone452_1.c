int main () {
    char **tokens = tokenize ("test string.");
    char **it;
    for (it = tokens; it && *it; ++it) {
        printf ("%s\n", * it);
        free (*it);
    }
    free (tokens);
    return 0;
}


int main () {
    char **tokens = tokenize ("test string.");
    char *curr;
    int index = 0;
    while ((curr = tokens[index++]) != NULL) {
        printf ("%s\n", curr);
        free (curr);
    }
    free (tokens);
    return 0;
}


