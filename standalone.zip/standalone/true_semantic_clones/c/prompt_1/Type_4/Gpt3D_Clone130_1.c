int main (void) {
    int arr1 [] = {1, 2, 3, 4, 5};
    int arr2 [] = {3, 4, 5, 1, 2};
    int arr3 [] = {3, 4, 5, 2, 1};
    int arr4 [] = {1, 0, 1, 1, 0};
    int arr5 [] = {1, 0, 1, 0, 1};
    size_t size = sizeof (arr1) / sizeof (*arr1);
    TEST (size, arr1, arr2);
    TEST (size, arr1, arr3);
    TEST (size, arr4, arr5);
}


int main (void) {
    int arr1 [] = {1, 2, 3, 4, 5};
    int arr2 [] = {3, 4, 5, 1, 2};
    int arr3 [] = {3, 4, 5, 2, 1};
    int arr4 [] = {1, 0, 1, 1, 0};
    int arr5 [] = {1, 0, 1, 0, 1};
    size_t size = sizeof (arr1) / sizeof (*arr1);
    
    //Variant 1
    TestArrayElements(size,arr1,arr2);
    TestArrayElements(size,arr1,arr3);
    TestArrayElements(size,arr4,arr5);
    
    //Variant 2
    TestEqualArray(size,arr1,arr2);
    TestEqualArray(size,arr1,arr3);
    TestEqualArray(size,arr4,arr5);
    
    //Variant 3
    CompareArrays(size,arr1,arr2);
    CompareArrays(size,arr1,arr3);
    CompareArrays(size,arr4,arr5);
}


