int main () {
    char s1 [] = "oppa";
    char s2 [] = "gangnam";
    char s3 [] = "style";
    {
        char result [STR_SIZE] = {0};
        snprintf (result, sizeof (result), "%s %s %s", s1, s2, s3);
        printf ("%s\n", result);
    }
}


int main () {
    int a = 5;
    int b = 10;
    {
        int result = a + b;
        printf ("The result is %d\n", result);
    }
}


