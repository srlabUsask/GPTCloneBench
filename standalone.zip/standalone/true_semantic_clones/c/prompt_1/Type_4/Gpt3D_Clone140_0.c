int main (void) {
    int final_pos;
    char c = 0;
    char num[] = "123056";
    final_pos = 3;
    c = '4';
    num[final_pos] = c;
    printf ("%s\n", num);
    return 0;
}


int main (void) {
    char *num, *p;
    num = malloc (sizeof (char) * 100);
    if (num == NULL)
        exit (1);
    memset (num, 0, sizeof (char) * 100);
    p = num;
    strncpy (num, "123056", 100 - 1);
    *(p + 3) = '4';
    printf ("%s\n", num);
    free (num);
    return 0;
}


