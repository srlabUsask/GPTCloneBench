int main () {
    float m, n, p, max;
    if (scanf ("%f%f%f", &m, &n, &p) != 3) {
        puts ("Bad input");
        return 1;
    }
    max = m;
    if (n > max) {
        max = n;
    }
    if (p > max) {
        max = p;
    }
    printf ("%f", max);
    return 0;
}


int main () {
    float m, n, p, max = 0;
    
    if (scanf ("%f%f%f", &m, &n, &p) == 3) {
        if (m > n && m > p) {
            max = m;
        } else if (n > p) {
            max = n;
        } else {
            max = p;
        }    
        
        printf ("%f", max);
    }
    else { 
        puts ("Bad input");
        return 0; 
    }
}


