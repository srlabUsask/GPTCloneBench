int main () {
    {
        int i, n = 6;
        arr m = makearr (1, (int []) {n});
        for (i = 0; i < n; i++)
            *elem (m, i) = i;
        for (i = 0; i < n; i++, printf (" "))
            printf ("%d", *elem (m, i));
    }
    puts ("\n");
    {
        int i, j, n = 4;
        arr m = makearr (2, (int []) {n, n});
        for (i = 0; i < n; i++)
            for (j = 0; j < n; j++)
                *elem (m, i, j) = i * n + j;
        for (i = 0; i < n; i++, printf ("\n"))
            for (j = 0; j < n; j++, printf (" "))
                printf ("%d", *elem (m, i, j));
    }
    puts ("\n");
    {
        int i, j, k, n = 3;
        arr m = makearr (3, (int []) {n, n, n});
        for (i = 0; i < n; i++)
            for (j = 0; j < n; j++)
                for (k = 0; k < n; k++)
                    *elem (m, i, j, k) = (i * n + j) * n + k;
        for (i = 0; i < n; i++, printf ("\n"))
            for (j = 0; j < n; j++, printf ("\n"))
                for (k = 0; k < n; k++, printf (" "))
                    printf ("%d", *elem (m, i, j, k));
    }
    return 0;
}


int main () {
  int i, n = 6;
  int arr[n];

  for (i = 0; i < n; i++)
    arr[i] = i;
  for (i = 0; i < n; i++, printf (" "))
    printf ("%d", arr[i]);
  puts ("\n");
  n = 4;
  int arr2[n][n];

  for (i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      arr2[i][j] = i * n + j;
  for (i = 0; i < n; i++, printf ("\n"))
    for (int j = 0; j < n; j++, printf (" "))
      printf ("%d", arr2[i][j]);
  puts ("\n");
  n = 3;
  int arr3[n][n][n];

  for (i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      for (int k = 0; k < n; k++)
        arr3[i][j][k] = (i * n + j) * n + k;
  for (i = 0; i < n; i++, printf ("\n"))
    for (int j = 0; j < n; j++, printf ("\n"))
      for (int k = 0; k < n; k++, printf (" "))
        printf ("%d", arr3[i][j][k]);
  return 0;
}


