int main () {
    struct books {
        char name [100], author [100];
        int year, copies;
    } book1, book2;
    char c;
    printf ("Enter details of first book\n");
    gets (book1.name);
    gets (book1.author);
    scanf ("%d%d", & book1.year, & book1.copies);
    while ((c = getchar ()) != '\n' && c != EOF)
        ;
    printf ("Enter details for second book\n");
    gets (book2.name);
    gets (book2.author);
    scanf ("%d%d", & book2.year, & book2.copies);
    while ((c = getchar ()) != '\n' && c != EOF)
        ;
    printf ("%s\n%s\n%d\n%d\n", book1.name, book1.author, book1.year, book1.copies);
    printf ("%s\n%s\n%d\n%d\n", book2.name, book2.author, book2.year, book2.copies);
    return 0;
}


int main () {
    struct books {
        char name [100], author [100];
        int year, copies;
    } book1, book2;
    int year1, year2;
    int copies1, copies2;
    printf ("Enter details of first book\n");
    scanf ("%s %s %d %d", book1.name, book1.author, &year1, &copies1);
    printf ("Enter details for second book\n");
    scanf ("%s %s %d %d", book2.name, book2.author, &year2, &copies2);
    book1.year = year1;
    book1.copies = copies1;
    book2.year = year2;
    book2.copies = copies2;
    printf ("%s\n%s\n%d\n%d\n", book1.name, book1.author, book1.year, book1.copies);
    printf ("%s\n%s\n%d\n%d\n", book2.name, book2.author, book2.year, book2.copies);
    return 0;
}


