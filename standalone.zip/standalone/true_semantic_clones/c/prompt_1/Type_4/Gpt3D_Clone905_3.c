int main (void) {
    uint32_t *store_0;
    uint32_t *store_1;
    int *states_0;
    int *states_1;
    states_0 = (int []) {1, 0, 0, 1};
    states_1 = (int []) {0, 0, 0, 2};
    store_0 = states_0;
    store_1 = states_1;
}


int main (void) {
    uint32_t *store [2];
    int i;
    int *states [2];
    states[0] = (int []) {1, 0, 0, 1};
    states[1] = (int []) {0, 0, 0, 2};
    for (i = 0; i < 2; i++) {
        store[i] = states[i];
    }
}


