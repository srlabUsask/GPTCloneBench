int main (void) {
    double **matrix = read_matrix (stdin);
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j)
            printf (" %lf", matrix[i][j]);
        printf ("\n");
    }
    return 0;
}


int main (void) {
    double **matrix = read_matrix (stdin);
    int i = 0;
    while(i<m) {
        int j = 0;
        while(j<n) {
            printf (" %lf", matrix[i][j]);
            j++;
        }
        printf ("\n");
        i++;
    }
    return 0;
}


