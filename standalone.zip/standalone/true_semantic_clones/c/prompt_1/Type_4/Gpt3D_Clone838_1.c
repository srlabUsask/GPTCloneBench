main () {
    int c;
    while (1) {
        c = getchar ();
        if (c == EOF) {
            break;
        }
        putchar (c);
    }
}


main () {
    int c = getchar();
    do {
        putchar (c);
        c = getchar ();
    } while (c != EOF);
}


