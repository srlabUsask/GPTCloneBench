int main (void) {
    uint8_t c1 = 0xff, c2 = 0x44;
    uint8_t c3 = c1 + c2;
    printb (c1);
    printb ((char) 0xff);
    printb ((short) 0xff);
    printb (0xff);
    printb (c2);
    printb (0x44);
    printb (0x4411ff01);
    printb ((uint16_t) c3);
    printf ("\n");
    return 0;
}


int main (void) {
    uint8_t c1 = 0xff, c2 = 0x44;
    uint8_t c3 = c1 + c2;
    printf("%d", (int)c1);
    printf("%d", 255);
    printf("%d", 65280);
    printf("%d", 255);
    printf("%d", c2);
    printf("%d", 68);
    printf("%d", 704190145);
    printf("%d", (int)c3);
    printf ("\n");
    return 0;
}


