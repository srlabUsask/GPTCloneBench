int main(int argc, char *argv[])
{
    struct bitv *b = bitv_alloc(32);
    bitv_set(b, 1);
    bitv_set(b, 3);
    bitv_set(b, 5);
    bitv_set(b, 7);
    bitv_set(b, 9);
    bitv_set(b, 32);
    bitv_dump(b);
    bitv_free(b);
    return 0;
}

int main(int argc, char *argv[])
{
    unsigned int v = 0;
    bitv_set(&v, 1);
    bitv_set(&v, 3);
    bitv_set(&v, 5);
    bitv_set(&v, 7);
    bitv_set(&v, 9);
    bitv_set(&v, 32);
    bitv_dump(&v);
    return 0;
}
