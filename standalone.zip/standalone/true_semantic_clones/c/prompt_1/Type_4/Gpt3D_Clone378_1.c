int main () {
    int i;
    char str [1000], *p, c;
    scanf ("%s", str);
    for (i = 0; str[i]; i++) {

        c = str[i];
        for (p = str + i + 1; *p; p++) {
            if (c == *p) {
                printf ("%c", c);
                return 0;
            }
        }
    }
}


int main () {
    int i, j;
    char str [1000];
    scanf ("%s", str);
    for (i = 0; str[i] != '\0'; i++) {
        for (j = i + 1; str[j] != '\0'; j++) {
            if (str[i] == str[j]) {
                printf ("%c", str [i]);
                return 0;
            }
        }
    }
}


