int main()
{
    char string[4];
    int reverse = 0;
    printf("Enter the number to reverse:\n");
    scanf_s("%d", &reverse);
    if (reverse > 999)
        return 0;
    sprintf_s(string, "%d", reverse);
    char c1 = string[0];
    string[0] = string[2];
    string[2] = c1;
    reverse = atoi(string);
    printf(" The reverse is %d", reverse);
    return 0;
}

int main()
{
    int num, rem, rev = 0;
    printf("\n Enter the number to reverse: \n");
    scanf_s("%d", &num);
    while (num > 0)
    {
        rem = num % 10;
        rev = rev * 10 + rem;
        num = num / 10;
    }
    printf("\n The reverse is %d", rev);
    return 0;
}
