int main () {
    char str [] = "This is a simple string made with simple code";
    char *pch;
    int i = 0, count = 0;
    for (i = 0; i < strlen (str); i++) {
        if (str[i] == 's' && str[i + 1] == 'i' && str[i + 2] == 'm' && str[i + 3] == 'p' && str[i + 4] == 'l' && str[i + 5] == 'e') {
            count++;
        }
    }
    for (i = 1; i <= count; i++) {
        pch = strstr (str, "simple");
        strncpy (pch, "sample", 6);
    }
    puts (str);
    return 0;
}


int main () {
    char str [] = "This is a simple string made with simple code";
    int length = strlen (str);
    int i = 0, count = 0;
    int firstPosition = -1;

    for (i = 0; i < length; i++) {
        if (str[i] == 's' && str[i + 1] == 'i' && str[i + 2] == 'm' && str[i + 3] == 'p' && str[i + 4] == 'l' && str[i + 5] == 'e') {
            count++;
            if (firstPosition == -1) {
                firstPosition = i;
            }
        }
    }
    strncpy (str + firstPosition, "sample", 6);
    for (i = 1; i < count; i++) {
        int position = firstPosition + (6 * i);
        strncpy (str + position, "sample", 6);
    }
    puts (str);
    return 0;
}


