int main () {
    char *token;
    char *str = malloc (100);
    strcpy (str, "test string.");
    for (token = strtok (str, " ") ; token != NULL ; token = strtok (NULL, " ")) {
        printf ("%s\n", token);
    }
    free (str);
    return 0;
}


int main () {
    char **tokens = tokenize ("test string.");
    char **it;
    for (it = tokens; it && *it; ++it) {
        printf ("%s\n", * it);
        free (*it);
    }
    free (tokens);
    return 0;
}


