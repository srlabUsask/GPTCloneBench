int main () {
    char str [] = "- This, a sample string.";
    char *pch;
    printf ("Splitting string \"%s\" into tokens:\n", str);
    pch = strtok (str, " ,.-");
    while (pch != NULL) {
        printf ("%s\n", pch);
        pch = strtok (NULL, " ,.-");
    }
    return 0;
}


int main () {
    string str = "- This, a sample string.";
    int i;
    for (i = 0; i < str.length(); i++) {
        if (str[i] == ' ' || str[i] == ',' || str[i] == '.' || str[i] == '-') {
            cout << "\n";
        } else {
            cout << str[i];
        }
    }
    return 0;
}


