int main() 
{
    int value = ntohl(0x12345678);
    char *message;

    if (value == 0x12345678) {
        message = "big-endian\n";
    } else if (value == 0x78563412) {
        message = "little-endian\n";
    } else {
        message = "(stupid)-middle-endian\n";
    }
    printf(message);
    return 0;
}


int main () {
    if (ntohl (0x12345678) == 0x12345678) {
        printf ("big-endian\n");
    }
    else if (ntohl (0x12345678) == 0x78563412) {
        printf ("little-endian\n");
    }
    else {
        printf ("(stupid)-middle-endian\n");
    }
    return 0;
}


