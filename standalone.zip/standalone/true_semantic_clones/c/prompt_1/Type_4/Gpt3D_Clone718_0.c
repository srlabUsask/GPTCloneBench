int main (void) {
    demo *ptr = fieldDefinitions;
    demo *end = &fieldDefinitions[sizeof (fieldDefinitions) / sizeof (fieldDefinitions[0]) - 1];
    do {
        printf ("ptr: %p \n", (void *) ptr);
        printf ("ptr: %d \n", ptr -> a);
    }
    while (ptr++ < end);
    return 0;
}


int main (void) {
    size_t datasize = sizeof (fieldDefinitions) / sizeof (fieldDefinitions[0]);
    demo *end = &fieldDefinitions[datasize - 1];
    while (1) {
        printf ("ptr: %p \n", (void *) fieldDefinitions);
        printf ("ptr: %d \n", fieldDefinitions -> a);
        if (fieldDefinitions == end)
            break;
        fieldDefinitions++;
    }
    return 0;
}


