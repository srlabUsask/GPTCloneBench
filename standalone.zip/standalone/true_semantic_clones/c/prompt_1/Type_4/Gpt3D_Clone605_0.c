void main () {
    clrscr ();
    printf ("Welcome\n\n\n");
    unsigned char x = 'A';
    char ch_array [8];
    for (int i = 0; x != 0; i++) {
        ch_array[i] = x & 1;
        x = x >> 1;
    }
    for (--i; i >= 0; i--)
        printf ("%d", ch_array[i]);
    getch ();
}


int main()
{
    clrscr();
    printf("Welcome\n\n\n");
    int n = 'A';
    int ch_array[8];
    int i = 0;
    while (n > 0) {
        ch_array[i] = n % 2;
        n = n >> 1;
        ++i;
    }
    i--;
    while (i >= 0)
    {
        printf("%d", ch_array[i]);
        --i;
    }
    getch();
    return 0;
}


