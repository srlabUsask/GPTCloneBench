int main () {
    char str [] = "test string.";
    char *firstname = strtok (str, " ");
    char *lastname = strtok (NULL, " ");
    if (!lastname)
        lastname = "";
    printf ("%s, %s\n", lastname, firstname);
    return 0;
}


int main () {
    char str [] = "test string.";
    char *word;
    char *firstname = NULL;
    char *lastname = NULL;
    word = strtok (str, " ");
    while (word != NULL) {
        firstname = lastname;
        lastname = word;
        word = strtok (NULL, " "); 
    }
    if (!lastname)
        lastname = "";
    printf ("%s, %s\n", lastname, firstname);
    return 0;
}


