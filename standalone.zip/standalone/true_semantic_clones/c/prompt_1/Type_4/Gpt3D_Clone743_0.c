int main () { 
    char first [20];
    char last [20]; 
    string full = ""; 
    char ch;
    printf ("Your first name?: "); 
    while ((ch = getchar ()) != '\n') 
      first[strlen (first)] = ch;
    printf ("Your last name?: "); 
    while ((ch = getchar ()) != '\n') 
      last[strlen (last)] = ch;
    first[strlen (first) - 1] = '\0'; 
    full.append (first); 
    full.append (" "); 
    full.append (last); 
    printf ("Your full name is: %s", full.c_str()); 
}


int main () {
    char first [20];
    char last [20];
    char full [40];
    printf ("Your first name?: ");
    fgets (first, sizeof (first), stdin);
    printf ("your last name?: ");
    fgets (last, sizeof (last), stdin);
    first[strlen (first) - 1] = '\0';
    strcpy (full, first);
    strcat (full, " ");
    strcat (full, last);
    printf ("Your full name is: %s", full);
}


