int main (int argc, char **argv) {
    char *prompt = "Please Insert X value\n";
    int iResponseCode;
    char cInputBuffer [100];
    int x, y = 0;
    int *p = &x;
    while (y < 5) {
        iResponseCode = getLine (prompt, cInputBuffer, sizeof (cInputBuffer));
        validate_input (iResponseCode, prompt, cInputBuffer, sizeof (cInputBuffer));
        sscanf (cInputBuffer, "%d", p);
        y++;
    }
}


int main (int argc, char **argv) {
    int iResponseCode;
    int x = 0, y = 0;
    int *p = &x;
    for (int i = 0; i < 5; i++) {
        char prompt[100] = "Please Insert ";
        if (i % 2 == 0) {
            strcat(prompt , "X value\n");
            p = &x;
        } else {
            strcat(prompt, "Y value\n");
            p = &y;
        }
        char cInputBuffer[100];
        iResponseCode = getLine (prompt, cInputBuffer, sizeof (cInputBuffer));
        validate_input (iResponseCode, prompt, cInputBuffer, sizeof (cInputBuffer));
        sscanf (cInputBuffer, "%d", p);
    }
}


