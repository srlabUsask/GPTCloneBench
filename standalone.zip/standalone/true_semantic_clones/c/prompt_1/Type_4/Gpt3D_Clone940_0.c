int main (void) {
    int oldar [2] [3] = {{1, 2, 3}, {4, 5, 6}};
    int newar [3] [2];
    transpose (& oldar [0] [0], & newar [0] [0], 2, 3);
    int rowSum1 = 0, colSum1 = 0;
    int i, j;
    for (i = 0; i < 2; i++) {
        colSum1 = 0;
        for (j = 0; j < 3; j++) {
            printf ("%d ", oldar[i][j]);
            colSum1 += oldar[i][j];
        }
        rowSum1 += colSum1;
        printf (" = %d\n", colSum1);
    }
    int rowSum2 = 0;
    for (i = 0; i < 3; i++) {
        colSum1 = 0;
        for (j = 0; j < 2; j++) {
            printf ("%d ", newar[i][j]);
            colSum1 += newar[i][j];
        }
        rowSum2 += colSum1;
        printf (" = %d\n", colSum1);
    }
    printf("Total Sum of original matrix = %d\n", rowSum1);
    printf("Total Sum of transposed matrix = %d\n", rowSum2);
}


int main (void) {
    int oldar [2] [3] = {{1, 2, 3}, {4, 5, 6}};
    int newar [3] [2];
    transpose (& oldar [0] [0], & newar [0] [0], 2, 3);
    int i, j;
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 3; j++)
            printf ("%d ", oldar[i][j]);
        printf ("\n");
    }
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 2; j++)
            printf ("%d ", newar[i][j]);
        printf ("\n");
    }
}


