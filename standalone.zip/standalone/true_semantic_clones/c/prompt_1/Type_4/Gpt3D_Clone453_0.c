int main () {
    char str [] = "test string.";
    char* firstname; 
    char* lastname;
    char* token;
    
    token = strtok (str, " ");
    firstname = token;
    token = strtok (NULL, " ");
    lastname = token;
    if (!lastname)
        lastname = "";
    printf ("%s, %s\n", lastname, firstname);
    return 0;
}


int main () {
    char str [] = "test string.";
    char *firstname = strtok (str, " ");
    char *lastname = strtok (NULL, " ");
    if (!lastname)
        lastname = "";
    printf ("%s, %s\n", lastname, firstname);
    return 0;
}


