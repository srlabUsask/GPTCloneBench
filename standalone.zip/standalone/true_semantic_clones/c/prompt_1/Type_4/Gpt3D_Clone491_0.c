int main () {
    int n, reverse = 0;
    printf ("Enter a number to reverse\n");
    scanf ("%d", & n);
    while (n != 0) {
        reverse = reverse * 10;
        reverse = reverse + n % 10;
        n = n / 10;
    }
    printf ("Reverse of entered number is = %d\n", reverse);
    return 0;
}


int main () {
    int n, temp_number, mod;
    long int rev_number = 0;
    printf ("Enter a number to reverse\n");
    scanf ("%d", & n);
    temp_number = n;
    while (temp_number > 0) {
        mod = temp_number % 10;
        rev_number = rev_number * 10 + mod;
        temp_number /= 10;
    }
    printf ("Reverse of entered number is = %ld\n", rev_number);
    return 0;
}


