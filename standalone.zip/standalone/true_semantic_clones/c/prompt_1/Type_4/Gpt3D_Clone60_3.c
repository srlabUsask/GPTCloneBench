int main () {
    using namespace std;
    char c;
    short s;
    int i;
    cout << "sizeof(char): " << sizeof (char) << endl;
    cout << "sizeof(short): " << sizeof (short) << endl;
    cout << "sizeof(int): " << sizeof (int) << endl;
    cout << "short is " << (int) &s - (int) &c << " bytes away from a char" << endl;
    cout << "int is " << (int) &i - (int) &s << " bytes away from a short" << endl;
}


int main () {
    using namespace std;
    char c;
    unsigned long u;
    double d;
    cout << "sizeof(char): " << sizeof (char) << endl;
    cout << "sizeof(unsigned long): " << sizeof (unsigned long) << endl;
    cout << "sizeof(double): " << sizeof (double) << endl;
    cout << "unsigned long is " << (double) &u - (double) &c << " bytes away from a char" << endl;
    cout << "double is " << (double) &d - (double) &u << " bytes away from a unsigned long" << endl;
}


