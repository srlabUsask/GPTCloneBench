int main () {
    using namespace std;
    char c;
    short s;
    int i;
    cout << "sizeof(char): " << sizeof (char) << endl;
    cout << "sizeof(short): " << sizeof (short) << endl;
    cout << "sizeof(int): " << sizeof (int) << endl;
    cout << "short is " << (int) &s - (int) &c << " bytes away from a char" << endl;
    cout << "int is " << (int) &i - (int) &s << " bytes away from a short" << endl;
}


int main () {
    using namespace std;
    char c;
    unsigned int u;
    long l;
    cout << "sizeof(char): " << sizeof (char) << endl;
    cout << "sizeof(unsigned int): " << sizeof (unsigned int) << endl;
    cout << "sizeof(long): " << sizeof (long) << endl;
    cout << "unsigned int is " << (long) &u - (long) &c << " bytes away from a char" << endl;
    cout << "long is " << (long) &l - (long) &u << " bytes away from a unsigned int" << endl;
}


