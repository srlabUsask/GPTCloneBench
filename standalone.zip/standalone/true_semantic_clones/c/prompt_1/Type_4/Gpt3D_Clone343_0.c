int main () {
    int i, j, length;
    char space = ' ';
    char phrase [80];
    printf ("Give me the phrase: ");
    gets (phrase);
    length = strlen (phrase);
    for (i = 0, j = length - 1; i < j; i++, j--) {
        while (phrase[i] == space)
            i++;
        while (phrase[j] == space)
            j--;
        if (phrase[i] != phrase[j]) {
            printf ("It's not a palindrome\n");
            return 0;
        }
    }
    printf ("It's a palindrome\n");
    return 0;
}


int recurrentPalin(int i, int j, char phrase[80], int length){ 
	if (i<j){	
		while (phrase[i] == ' ')
            i++;
        while (phrase[j] == ' ')
            j--;
         if (phrase[i] != phrase[j]) {
            printf ("It's not a palindrome\n");
            return 0;
        }
		return recurrentPalin(i+1,j-1,phrase,length);
	}
	printf ("It's a palindrome\n");
    return 1;
}


