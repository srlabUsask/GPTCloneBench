int main (int argc, char *argv []) {
    int b[5] = {1, 3, 5, 7, 9};
    for (int i = 0; i < 5; i++)
        bitv_set (b[i], 1); 
    bitv_set (b, 32);
    bitv_dump (b); 
    return 0; 
}


int main (int argc, char *argv []) {
    struct bitv *b = bitv_alloc (32);
    bitv_set (b, 1);
    bitv_set (b, 3);
    bitv_set (b, 5);
    bitv_set (b, 7);
    bitv_set (b, 9);
    bitv_set (b, 32);
    bitv_dump (b);
    bitv_free (b);
    return 0;
}


