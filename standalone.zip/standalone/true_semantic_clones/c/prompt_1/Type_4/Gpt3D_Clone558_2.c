int main () {
    char c;
    while (scanf ("%c", &c) > 0) {
        if(c != 'q' && c != 'Q') {
            printf ("%c", c);
        }
    }
}


int main () {
    char c;
    while (scanf ("%c", &c) > 0) {
        switch (c) {
        case 'q' :
        case 'Q' :
            break;
        default :
            printf ("%c", c);
        }
    }
}


