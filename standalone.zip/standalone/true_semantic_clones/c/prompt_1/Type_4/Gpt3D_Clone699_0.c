int main() {
    char string1 [11];
    char string2 [11];
    char string3 [11];
    char string4 [11];
    char string5 [11];
    char string6 [11];
    char string7 [11];
    char string8 [11];
    char string9 [11];
    FILE *fileReader = fopen("text.txt", "r");
    if (fileReader) {
        int i = 0;
        char c = fgetc(fileReader);
        while(c != EOF && i < 9){
            switch (i)
            {
            case 0:
                if(c != ' '){
                    string1[i] = c;
                    i++;
                }
                else{
                    string1[i] = '\0';
                    i++;
                }
                break;
            case 1:
                if(c != ' '){
                    string2[i - 1] = c;
                    i++;
                }
                else{
                    string2[i - 1] = '\0';
                    i++;
                }
                break;
            case 2:
                if(c != ' '){
                    string3[i - 2] = c;
                    i++;
                }
                else{
                    string3[i - 2] = '\0';
                    i++;
                }
                break;
            case 3:
                if(c != ' '){
                    string4[i - 3] = c;
                    i++;
                }
                else{
                    string4[i - 3] = '\0';
                    i++;
                }
                break;
            case 4:
                if(c != ' '){
                    string5[i - 4] = c;
                    i++;
                }
                else{
                    string5[i - 4] = '\0';
                    i++;
                }
                break;
            case 5:
                if(c != ' '){
                    string6[i - 5] = c;
                    i++;
                }
                else{
                    string6[i - 5] = '\0';
                    i++;
                }
                break;
            case 6:
                if(c != ' '){
                    string7[i - 6] = c;
                    i++;
                }
                else{
                    string7[i - 6] = '\0';
                    i++;
                }
                break;
            case 7:
                if(c != ' '){
                    string8[i - 7] = c;
                    i++;
                }
                else{
                    string8[i - 7] = '\0';
                    i++;
                }
                break;
            case 8:
                if(c != ' '){
                    string9[i - 8] = c;
                    i++;
                }
                else{
                    string9[i - 8] = '\0';
                    i++;
                }
                break;
            default:
                break;
            }
            c = fgetc(fileReader);
        } 

        printf ("Found: %s %s %s %s %s %s %s %s %s\n", string1, string2, string3, string4, string5, string6, string7, string8, string9);
        fclose (fileReader);
    }
    else {
        puts ("Error opening filestream!");
    }
    return 0;
}


int main () {
    char string1 [11];
    char string2 [11];
    char string3 [11];
    char string4 [11];
    char string5 [11];
    char string6 [11];
    char string7 [11];
    char string8 [11];
    char string9 [11];
    FILE *fileReader = fopen ("text.txt", "r");
    if (fileReader) {
        fscanf (fileReader, "%10s %10s %10s %10s %10s %10s %10s %10s %10s", string1, string2, string3, string4, string5, string6, string7, string8, string9);
        printf ("Found: %s %s %s %s %s %s %s %s %s\n", string1, string2, string3, string4, string5, string6, string7, string8, string9);
        fclose (fileReader);
    }
    else {
        puts ("Error opening filestream!");
    }
    return 0;
}


