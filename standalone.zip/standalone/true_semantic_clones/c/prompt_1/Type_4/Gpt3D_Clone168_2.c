
int main (void) {
    const char *str = "Polly";
    unsigned int len = strlen (str);
    char buffer [len + 1];
    int end = (int) len - 1;
    while (end >= 0) {
        size_t start = 0;
        while (start < len) {
            slice_str (str, buffer, start, end);
            printf ("%s\n", buffer);
            start++;
        }
        end--;
    }
    return 0;
}


int main (void) {
    const char *str = "Polly";
    const size_t len = strlen (str);
    char buffer [len + 1];
    for (size_t start = 0; start < len; ++start) {
        for (int end = len - 1; end >= (int) start; --end) {
            slice_str (str, buffer, start, end);
            printf ("%s\n", buffer);
        }
    }
    return 0;
}


