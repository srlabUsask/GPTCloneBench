int main (void) {
    char *num, *p;
    num = malloc (sizeof (char) * 100);
    if (num == NULL)
        exit (1);
    memset (num, 0, sizeof (char) * 100);
    p = num;
    strncpy (num, "123056", 100 - 1);
    *(p + 3) = '4';
    printf ("%s\n", num);
    free (num);
    return 0;
}


int main (void) {
    int next_pos;
    char num[100] = {0};
    strncpy (num, "123056", 99);
    next_pos = 4;
    num[next_pos] = '4';
    printf ("%s\n", num);
    return 0;
}


