int main (int argc, char *argv []) {
    FILE *fp1 = NULL, *fp2 = NULL;
    char buff1 [BUFSIZE], buff2 [BUFSIZE];
    fp1 = fopen (argv[1], "r");
    while (fgets (buff1, BUFSIZE -1, fp1) != NULL) {
        printf ("%s\n", buff1);
    }
    fclose (fp1);
    fp2 = fopen (argv[2], "r");
    while (fgets (buff2, BUFSIZE -1, fp2) != NULL) {
        printf ("%s\n", buff2);
    }
    fclose (fp2);
}


int main (int argc, char *argv []) {
    FILE *fp1 = NULL, *fp2 = NULL;
    char buff1 [BUFSIZE], buff2 [BUFSIZE];   
    char* filename1 = argv[1];
    char* filename2 = argv[2];
    
    fp1 = fopen (filename1, "r");
    while (fgets (buff1, BUFSIZE -1, fp1) != NULL) {
        char* line1 = buff1;
        print_string(line1);
    }
    fclose (fp1);
    fp2 = fopen (filename2, "r");
    while (fgets (buff2, BUFSIZE -1, fp2) != NULL) {
        char* line2 = buff2;
        print_string(line2);
    }
    fclose (fp2);
}


