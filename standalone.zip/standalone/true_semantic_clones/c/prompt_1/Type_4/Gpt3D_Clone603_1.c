int main (void) {
    uint8_t c1 = 0xff, c2 = 0x44;
    uint8_t c3 = c1 + c2;
    printb (c1);
    printb ((char) 0xff);
    printb ((short) 0xff);
    printb (0xff);
    printb (c2);
    printb (0x44);
    printb (0x4411ff01);
    printb ((uint16_t) c3);
    printf ("\n");
    return 0;
}


int main (void) {
    int8_t c1 = -1, c2 = 68;
    int8_t c3 = c1 + c2;
    printf("%x", (unsigned)c1);
    printf("%x", 0xff);
    printf("%x", 0xff00);
    printf("%x", 255);
    printf("%x", c2);
    printf("%x", 0x44);
    printf("%x", 0x4411ff01);
    printf("%x", (unsigned)c3);
    printf ("\n");
    return 0;
}


