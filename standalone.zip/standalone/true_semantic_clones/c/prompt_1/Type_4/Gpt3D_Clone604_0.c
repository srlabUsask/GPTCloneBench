int main (void) {
    uint8_t c1 = 0xff, c2 = 0x44;
    uint8_t c3 = c1 + c2;
    printb (c1);
    printb ((char) 0xff);
    printb ((short) 0xff);
    printb (0xff);
    printb (c2);
    printb (0x44);
    printb (0x4411ff01);
    printb ((uint16_t) c3);
    printf ("\n");
    return 0;
}


int main (void) {
    uint8_t c1 = 0xff, c2 = 0x44;
    uint8_t c3 = c1 + c2;
    uint8_t shift1 = 4;
    uint16_t shift2 = 8;
    printb (c1);
    printb ((char) (0xff << shift1));
    printb ((short) (0xff << shift2));
    printb (0xff << shift1);
    printb (c2);
    printb (0x44 << shift2);
    printb (0x4411ff01 << shift1);
    printb ((uint16_t) c3 << shift1);
    printf ("\n");
    return 0;
}


