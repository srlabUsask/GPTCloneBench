int main (int argc, const char *argv []) {
    const char *fileName = "MyFile.txt";
    int size = 1024;
    int ret = 0;
    if (3 == argc) {
        fileName = argv[1];
        size = atoi (argv[2]);
    }
    ret = CreateFileSetSize (fileName, size);
    return ret;
}


int main (int argc, const char *argv []) {
    const char *fileName;
    int size;
    int ret;
    switch (argc) {
        case 2:
            fileName = argv[1];
            size = 1024;
            break;
        case 3:
            fileName = argv[1];
            size = atoi (argv[2]);
            break;
        default:
            fileName = "MyFile.txt";
            size = 1024;
            break;
    }
    ret = CreateFileSetSize (fileName, size);
    return ret;
}


