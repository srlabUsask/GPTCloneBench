int main (void) {
    int start, end;
    char valid;
    valid = scanf ("%d", &start);
    if (!valid)
    exit (1);
    end = start;
    valid = scanf ("%d", &end);
    while (valid == 1)
        valid = scanf ("%d", &end);
    for (int i = start; i <= end; i++){
        printf ("%d\n", i);
    }
}


int main (void) {
    int start;
    if (scanf ("%d", &start) != 1)
        exit (1);
    int end = start;
    while (scanf ("%d", &end) == 1)
        ;
    for (int i = start; i <= end; i++)
        printf ("%d\n", i);
}


