int main (void) {
    enum {skip = -1, run, jump, scamper} label = skip;
computeGoto :
    switch (label) {
    case skip :
        break;
        STATE (run);
        STATE (jump);
        STATE (scamper);
    default :
        printf ("Unknown state: %d\n", label);
        exit (0);
    }
    label = foo ();
    goto computeGoto;
}


int main (void) {
    enum {skip = -1, run, jump, scamper} label = skip;
computeGoto:
    if (label == skip) goto end;
    if (label == run) goto stateRun;
    if (label == jump) goto stateJump;
    if (label == scamper) goto stateScamper;
    printf ("Unknown state: %d\n", label);
    exit (0);
stateRun:
    // ...
    goto end;
stateJump:
    // ...
    goto end;
stateScamper:
    // ...
    goto end;
end:
    label = foo ();
    goto computeGoto;
}


