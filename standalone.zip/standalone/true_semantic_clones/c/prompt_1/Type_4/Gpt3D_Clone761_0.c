int main () {
    double integralSum = 0;
    int i;
    for (i = 1; i < (parts + 1); ++i) {
        integralSum = integralSum + (step * fabs (pow ((x + (step * i)), 2) + 4));
    }
    printf ("%f\n", integralSum);
    return 0;
}


int main () {
    double integralSum = 0;
    int i;
    int upperBound = parts + 1;
    for (i = 1; i < upperBound; ++i) {
        double summand;
        double power = x + (step * i);
        double squareAndAbsolute = fabs (pow (power, 2) + 4);
        summand = step * squareAndAbsolute;
        integralSum = integralSum + summand;
    }
    printf ("%f\n", integralSum);
    return 0;
}


