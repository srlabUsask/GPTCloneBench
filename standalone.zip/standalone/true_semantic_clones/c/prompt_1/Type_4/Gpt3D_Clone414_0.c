int main () {
    struct books {
        char name [100], author [100];
        int year, copies;
    } book1, book2;
    char c;
    printf ("Enter details of first book\n");
    gets (book1.name);
    gets (book1.author);
    scanf ("%d%d", & book1.year, & book1.copies);
    while ((c = getchar ()) != '\n' && c != EOF)
        ;
    printf ("Enter details for second book\n");
    gets (book2.name);
    gets (book2.author);
    scanf ("%d%d", & book2.year, & book2.copies);
    while ((c = getchar ()) != '\n' && c != EOF)
        ;
    printf ("%s\n%s\n%d\n%d\n", book1.name, book1.author, book1.year, book1.copies);
    printf ("%s\n%s\n%d\n%d\n", book2.name, book2.author, book2.year, book2.copies);
    return 0;
}


int main () {
    struct books {
        char name [100], author [100];
        int year, copies;
    } book1, book2;
    char c;
    char book1Name[100];
    char book1Author[100];
    int book1Year;
    int book1Copies;
    char book2Name[100];
    char book2Author[100];
    int book2Year;
    int book2Copies;
    printf ("Enter details of first book\n");
    scanf ("%s %s %d %d", book1Name, book1Author, &book1Year, &book1Copies);
    while ((c = getchar ()) != '\n' && c != EOF)
        ;
    printf ("Enter details for second book\n");
    scanf ("%s %s %d %d", book2Name, book2Author, &book2Year, &book2Copies);
    while ((c = getchar ()) != '\n' && c != EOF)
        ;
    strcpy(book1.name,book1Name);
    strcpy(book1.author,book1Author);
    book1.year=book1Year;
    book1.copies=book1Copies;
    strcpy(book2.name,book2Name);
    strcpy(book2.author,book2Author);
    book2.year=book2Year;
    book2.copies=book2Copies;

    printf ("%s\n%s\n%d\n%d\n", book1.name, book1.author, book1.year, book1.copies);
    printf ("%s\n%s\n%d\n%d\n", book2.name, book2.author, book2.year, book2.copies);
    return 0;
}


