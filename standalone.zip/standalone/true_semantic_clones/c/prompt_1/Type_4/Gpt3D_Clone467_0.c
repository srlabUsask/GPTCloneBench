int main () {
    int n, a [4], final;
    scanf ("%d", & n);
    for (int i = 3; i >= 0; i--) {
        a[i] = n % 10 + 2;
        n /= 10;
    }
    final = (a[0] * 1000) + (a[1] * 100) + (a[2] * 10) + a[3];
    printf ("%d", final);
    return 0;
}


int main () {
    int n, x, y, final;
    scanf ("%d", & n);
    x = n % 10 + 2;
    y = (n / 10) % 10 + 2;
    final = (x * 1000) + (y * 100) + ((n / 100) % 10 + 2)*10 + ((n / 1000) % 10 + 2);
    printf ("%d", final);
    return 0;
}


