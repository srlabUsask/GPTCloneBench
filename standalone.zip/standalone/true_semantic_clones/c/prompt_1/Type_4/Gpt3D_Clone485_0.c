int main (int argc, char *argv []) {
    struct termios termios;
    tcgetattr (STDIN_FILENO, & termios);
    termios.c_lflag &= ~ECHO;
    tcsetattr (STDIN_FILENO, TCSAFLUSH, & termios);
    char line [MAX_LINE_SIZE] = {0};
    fgets (line, sizeof (line), stdin);
    termios.c_lflag &= ~ECHO;
    tcsetattr (STDIN_FILENO, TCSAFLUSH, & termios);
    printf ("line: %s", line);
    return 0;
}


int readInput(struct termios *termios) {
    tcgetattr (STDIN_FILENO, termios);
    termios->c_lflag &= ~ECHO;
    tcsetattr (STDIN_FILENO, TCSAFLUSH, termios);
    char line [MAX_LINE_SIZE] = {0};
    fgets (line, sizeof (line), stdin);
    termios->c_lflag &= ~ECHO;
    tcsetattr (STDIN_FILENO, TCSAFLUSH, termios);
    printf ("line: %s", line);
    return 0;
}


