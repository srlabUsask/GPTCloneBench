int main () {
    int var;
    scanf ("%d", & var);
    if (var > 5)
        printf ("var > 5\n");
    else
        printf ("var <= 5\n");
    return 0;
}


 
int main () 
{ 
    int var; 
  
    // taking input from user 
    printf("Please enter an integer: "); 
    scanf("%d", &var); 
  
    // checking condition 
    if (var > 5) 
        printf("Above 5\n"); 
    else
        printf("Atmost 5\n"); 
  
    return 0; 
} 
