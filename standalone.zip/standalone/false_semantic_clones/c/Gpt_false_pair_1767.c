int main () {
    int x, y;
    for (;;) {
        x = poll (&attention, 1, 100);
        if (x < 0) {
            printf ("problem %d\n", errno);
            break;
        }
        else if (x) {
            printf ("you rang %x ?", x);
            y = getc (stdin);
            printf (" %c of course\n", y);
            if (y == '.')
                break;
        }
    }
    return 0;
}



int main () {
    int x, y;
    for (;;) {
        x = poll (&attention, 1, 100);
        if (x < 0) {
            printf ("error %d\n", errno);
            break;
        }
        else if (x > 0) {
            printf ("hey did you call us %x ?", x);
            y = getc (stdin);
            printf (" definitely %c\n", y);
            if (y == '.')
                break;
        }
    }
    return 0;
}
