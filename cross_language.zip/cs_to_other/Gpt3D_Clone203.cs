#input 
public bool removeStock (string user_name, string stock_symbol) {
    user_name = user_name.Trim ();
    stock_symbol = stock_symbol.Trim ();
    string statement = "DELETE FROM users_stocks " + "WHERE user_name = @name AND stock_symbol = @stock";
    SqlCommand cmdnon = new SqlCommand (statement, connection);
    try {
        cmdnon.Parameters.AddWithValue ("@name", user_name);
        cmdnon.Parameters.AddWithValue ("@stock", stock_symbol);
        connection.Open ();
        int num = cmdnon.ExecuteNonQuery ();
        connection.Close ();
        return true;
    }
    catch (SqlException ex) {
        Console.WriteLine (ex.ToString ());
        connection.Close ();
        return false;
    }
}


#====================
#gpt output=============

//Python:
def remove_stock(user_name, stock_symbol):
    user_name = user_name.strip()
    stock_symbol = stock_symbol.strip()
    statement = "DELETE FROM users_stocks WHERE user_name = %s AND stock_symbol = %s"
    try:
        cnx = mysql.connector.connect(user='user', password='password', port=3306, host='host', database='test_db')
        cursor = cnx.cursor()
        cursor.execute (statement, (user_name, stock_symbol))
        cnx.commit ()
        cnx.close()
        return True
    except mysql.connector.Error as err:
        print(err)
        return False


//C:
bool removeStock(char *user_name, char *stock_symbol){
	char *stmt = "DELETE FROM users_stocks WHERE user_name = ? AND stock_symbol = ?";
	sqlite3_stmt *sql_stmt;
	int result = sqlite3_prepare_v2(db, stmt, strlen(stmt)+1, &sql_stmt, NULL);

	if( result == SQLITE_OK ){
		sqlite3_bind_text(sql_stmt,1,user_name,strlen(user_name),NULL);
		sqlite3_bind_text(sql_stmt,2,stock_symbol,strlen(stock_symbol),NULL);
		sqlite3_step(sql_stmt);
		sqlite3_finalize(sql_stmt);
		return true;
	}
	else{
		return false;
	}
 
 
//Java:
public boolean removeStock(String user_name, String stock_symbol) {
	String statement = "DELETE FROM users_stocks WHERE user_name = ? AND stock_symbol = ?";
	PreparedStatement stmt;
	try {
		stmt = conn.prepareStatement(statement);
		stmt.setString(1, user_name);
		stmt.setString(2, stock_symbol);
		int result = stmt.executeUpdate();
		stmt.close();
		return true;
	} catch (SQLException ex) {
		System.err.println(ex);
		return false;
	}
}

