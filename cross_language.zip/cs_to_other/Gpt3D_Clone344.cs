#input 
public override object BindModel (ControllerContext controllerContext, ModelBindingContext bindingContext, PropertyDescriptor propertyDescriptor, IModelBinder propertyBinder) {
    var propertyType = propertyDescriptor.PropertyType;
    if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition () == typeof (Nullable < >)) {
        var provider = bindingContext.ValueProvider.GetValue (bindingContext.ModelName);
        if (provider != null && provider.RawValue != null && Type.GetTypeCode (provider.RawValue.GetType ()) == TypeCode.Int32) {
            var value = new System.Web.Script.Serialization.JavaScriptSerializer ().Deserialize (provider.AttemptedValue, bindingContext.ModelMetadata.ModelType);
            return value;
        }
    }
    return base.GetPropertyValue (controllerContext, bindingContext, propertyDescriptor, propertyBinder);
}


#====================
#gpt output=============

Python:
def BindModel(self, controller_context, binding_context, property_descriptor, property_binder):
    property_type = property_descriptor.PropertyType
    if property_type.IsGenericType and property_type.GetGenericTypeDefinition() == type(None):
        provider = binding_context.ValueProvider.GetValue(binding_context.ModelName)
        if provider and provider.RawValue and type(provider.RawValue) == type(int):
            value = json.loads(provider.AttemptedValue, binding_context.ModelMetadata.ModelType)
            return value

    return super(BindModel, self).BindModel(controller_context, binding_context, property_descriptor, property_binder)

C:
object BindModel(ControllerContext* controllerContext, ModelBindingContext* bindingContext, PropertyDescriptor* propertyDescriptor, IModelBinder* propertyBinder) {
    Type* propertyType = propertyDescriptor->PropertyType;
    if (propertyType->IsGenericType && propertyType->GetGenericTypeDefinition() == typeof(Nullable<>)) {
        ValueProvider* provider = bindingContext->ValueProvider->GetValue(bindingContext->ModelName);
        if (provider != NULL && provider->RawValue != NULL && TypeGetTypeCode(provider->RawValue->GetType()) == TypeCode_Int32) {
            var value = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize(provider->AttemptedValue, bindingContext->ModelMetadata->ModelType);
            return value;
        }
    }
    return base.BindModel(controllerContext, bindingContext, propertyDescriptor, propertyBinder);
}

Java:
public Object bindModel(ControllerContext controllerContext, ModelBindingContext bindingContext, PropertyDescriptor propertyDescriptor, IModelBinder propertyBinder) {
    Class<?> propertyType = propertyDescriptor.getPropertyType();
    if (propertyType.isGenericType() && propertyType.getGenericTypeDefinition() == typeof(Nullable<?>)) {
        ValueProvider provider = bindingContext.getValueProvider().getValue(bindingContext.getModelName());
        if (provider != null && provider.getRawValue() != null && Type.getTypeCode(provider.getRawValue().getClass()) == TypeCode.INTEGER) {
            Object value = new System.Web.Script.Serialization.JavaScriptSerializer().deserialize(provider.getAttemptedValue(), bindingContext.getModelMetadata().getModelType());
            return value;
        }
    }
    return super.bindModel(controllerContext, bindingContext, propertyDescriptor, propertyBinder);
}

