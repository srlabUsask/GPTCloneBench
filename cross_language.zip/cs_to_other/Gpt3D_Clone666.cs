#input 
public void InputGrade () {
    int grade;
    string input;
    Console.WriteLine ("{0}\n{1}", "Enter the integer grades in the range 0-100", "Type <Ctrl> z and press Enter to terminate input:");
    counter ++;
    System.Console.Write ("score " + counter + ":");
    input = Console.ReadLine ();
    while (input != null) {
        grade = Convert.ToInt32 (input);
        total += grade;
        gradeCounter ++;
        IncrementLetterGradeCounter (grade);
        counter ++;
        System.Console.Write ("score " + counter + ":");
        input = Console.ReadLine ();
    }
}


#====================
#gpt output=============

Python Implementation:
def InputGrade():
  grade = 0
  input_data = ""
  print ("Enter the integer grades in the range 0-100\nType <Ctrl> z and press Enter to terminate input:")
  counter = counter + 1
  input_data = input('score ' + str(counter) + ':')
  
  while input_data != None:
    grade = int(input_data)
    total += grade
    gradeCounter += 1
    IncrementLetterGradeCounter(grade)
    counter += 1
    input_data = input('score ' + str(counter) + ':')

C Implementation:
void InputGrade (void) {
  int grade; 
  char input[100];
  printf ("%s\n%s", "Enter the integer grades in the range 0-100", "Type <Ctrl> z and press Enter to terminate input:");
  counter ++;
  printf ("score %d:", counter);
  scanf ("%s", input);
  
  while (input != null) {
    grade = atoi(input);
    total += grade;
    gradeCounter ++;
    IncrementLetterGradeCounter (grade);
    counter ++;
    printf ("score %d:", counter);
    scanf ("%s", input);
}

Java Implementation:
public void InputGrade () { 
  int grade;
  String input;
  System.out.println ("Enter the integer grades in the range 0-100\nType <Ctrl> z and press Enter to terminate input:");
  counter ++;
  System.out.print ("score " + counter + ":");
  input = System.console().readLine();
  
  while (input != null) {
    grade = Integer.parseInt(input);
    total += grade;
    gradeCounter ++;
    IncrementLetterGradeCounter (grade);
    counter ++;
    System.out.print ("score " + counter + ":");
    input = System.console().readLine();
  }
}

