#input 
static public bool URLExists (string url) {
    bool result = false;
    WebRequest webRequest = WebRequest.Create (url);
    webRequest.Timeout = 1200;
    webRequest.Method = "HEAD";
    HttpWebResponse response = null;
    try {
        response = (HttpWebResponse) webRequest.GetResponse ();
        result = true;
    }
    catch (WebException webException) {
        Debug.Log (url + " doesn't exist: " + webException.Message);
    }
    finally {
        if (response != null) {
            response.Close ();
        }
    }
    return result;
}


#====================
#gpt output=============


Python: 
def URLExists(url): 
  result = False
  try: 
    webRequest = web.urlopen(url)
    webRequest.set_timeout(1200)
    result = True
  except web.HTTPError as e:
    print(url + ' doesn\'t exist: ' + e.msg)
  
  finally: 
    if webRequest is not None:
      webRequest.close()
  return result
  

C:
bool URLExists (char *url) {
	bool result = false;
	webRequest webRequest = (webRequest) webRequest_create(url);
	webRequest.timeout = 1200;
	webRequest.method = "HEAD";
	httpWebResponse response = NULL;
	
	try {
		response = (httpWebResponse) webRequest_getResponse(webRequest);
		result = true;
	} catch (webException e) {
		debugLog(url + " doesn't exist:" + webException_mesg(e));
	} finally {
		if (response != NULL) {
			webRequest_cleanup(response);
		}
	}
	return result;
}


Java: 
public static boolean URLExists(String url) {
    boolean result = false;
    HttpURLConnection webRequest = (HttpURLConnection) new URL(url).openConnection();
    webRequest.setConnectTimeout(1200);
    webRequest.setRequestMethod("HEAD");
    HttpURLConnection response = null;
    try {
        response = (HttpURLConnection) webRequest.getResponse();
        result = true;
    } 
    catch(IOException webException) {
        System.out.println(url + " doesn't exist: " + webException.getMessage());
    }
    finally {
        if(response != null) {
            response.disconnect();
        }
    }
    return result;
}

