#input 
public static string GetStringValue (this AuthenticationMethod value) {
    string output = null;
    Type type = value.GetType ();
    FieldInfo fi = type.GetField (value.ToString ());
    StringValue [] attrs = fi.GetCustomAttributes (typeof (StringValue), false) as StringValue [];
    if (attrs.Length > 0)
        output = attrs [0].Value;
    return output;
}


#====================
#gpt output=============

Python: 
def get_string_value(self, value):
  output = None
  type = value.__class__
  fi = type.__dict__[value.name]
  for attr in fi.__dict__.values():
    if isinstance(attr, StringValue):
      output = attr.value
  return output



C: 
char* GetStringValue (enum AuthenticationMethod value) {
  char* output = NULL;
  Type type = (Type)value; 
  FieldInfo fi = GetField(type, value.ToString()); 
  StringValue attributes = GetCustomAttributes(fi, typeof (StringValue)); 
  int size = sizeof(attributes) / sizeof(StringValue); 
  if(size > 0){
    output = attributes[0].Value; 
  }
  return output; 
}


Java: 
public static String getStringValue(AuthenticationMethod value) {
    String output = null;
    Class type = value.getClass();
    Field field = type.getField(value.toString());
    StringValue[] attrs = field.getAnnotationsByType(StringValue.class);
    if (attrs.length > 0) {
        output = attrs[0].value();
    }
    return output;
}

