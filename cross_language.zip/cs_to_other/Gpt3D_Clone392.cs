#input 
static void Main (string [] args) {
    var dt = new DataTable {Columns = {{"Lastname", typeof (string)}, {"Firstname", typeof (string)}}};
    dt.Rows.Add ("Lennon", "John");
    dt.Rows.Add ("McCartney", "Paul");
    dt.Rows.Add ("Harrison", "George");
    dt.Rows.Add ("Starr", "Ringo");
    List < string > s = dt.AsEnumerable ().Select (x = > x [0].ToString ()).ToList ();
    foreach (string e in s)
        Console.WriteLine (e);
    Console.ReadLine ();
}


#====================
#gpt output=============

Python:
import pandas as pd

dt = pd.DataFrame(columns=["Lastname", "Firstname"])
dt.loc[len(dt)] = ["Lennon", "John"]
dt.loc[len(dt)] = ["McCartney", "Paul"]
dt.loc[len(dt)] = ["Harrison", "George"]
dt.loc[len(dt)] = ["Starr", "Ringo"]

s = dt.iloc[:,0].tolist()
for e in s:
    print(e)
    
    
C:
#include <stdio.h>
#include <stdlib.h>

struct DataTable {
  char * Lastname;
  char * Firstname;
};

struct DataTable row[4];

void getTable(struct DataTable *dt) {
  dt[0].Lastname = "Lennon";
  dt[0].Firstname = "John";
  dt[1].Lastname = "McCartney";
  dt[1].Firstname = "Paul";
  dt[2].Lastname = "Harrison";
  dt[2].Firstname = "George";
  dt[3].Lastname = "Starr";
  dt[3].Firstname = "Ringo";
}

int main() {
  struct DataTable *dt;
  dt = malloc(sizeof(struct DataTable) * 4);
  getTable(dt);

  for (int i = 0; i < 4; i++) {
    printf("%s\n", dt[i].Lastname);
  }
  free(dt);
  return 0;
}



Java:
import java.util.ArrayList;
import java.util.List;
       
public class PythonDataTable {
       
  public static void main(String[] args) {
    List<String> dataTableList = new ArrayList<String>();
    dataTableList.add("Lennon,John");
    dataTableList.add("McCartney,Paul");
    dataTableList.add("Harrison,George");
    dataTableList.add("Starr,Ringo");
       
    String[] columns = dataTableList.get(0).split(",");
       
    for (int i = 0; i < dataTableList.size(); i++) {
      String[] row = dataTableList.get(i).split(",");
      System.out.println(row[0]);
    }
  }
       
}

