#input 
private void ScaleControls (Control c, ref Graphics g, double s) {
    List < Control > hold = null;
    foreach (Control ctrl in c.Controls) {
        if (ctrl is GroupBox || ctrl is Panel) {
            hold = new List < Control > ();
            foreach (Control gctrl in ctrl.Controls) {
                hold.Add (gctrl);
            }
            ctrl.Controls.Clear ();
        }
        Point oldLoc = ctrl.Location;
        Size oldSize = ctrl.Size;
        Font oldFont = ctrl.Font;
        ctrl.Location = new Point (ctrl.Location.X * s, ctrl.Location.Y * s);
        ctrl.Size = new Size (ctrl.Size.Width * s, ctrl.Height * s);
        ctrl.Font = new Font (ctrl.Font.FontFamily, ctrl.Font.Size * 5, ctrl.Font.Style, ctrl.Font.Unit);
        using (Bitmap bmp = new Bitmap (ctrl.Size.Width, ctrl.Size.Height))
        {
            ctrl.DrawToBitmap (bmp, ctrl.ClientRectangle);
            g.DrawImage (bmp, ctrl.Location);
        } ctrl.Location = oldLoc;
        ctrl.Size = oldSize;
        ctrl.Font = oldFont;
        if (ctrl is GroupBox || ctrl is Panel) {
            foreach (Control gctrl in hold) {
                ctrl.Controls.Add (gctrl);
            }
            ScaleControls (ctrl, g, s);
        }
    }
}


#====================
#gpt output=============


Python Implementation:
def scale_controls(c, g, s):
    hold = None
    for ctrl in c.controls:
        if isinstance(ctrl, GroupBox) or isinstance(ctrl, Panel):
            hold = []
            for gctrl in ctrl.controls:
                hold.append(gctrl)
            ctrl.controls.clear()
        old_loc = ctrl.location
        old_size = ctrl.size
        old_font = ctrl.font
        ctrl.location = (ctrl.location[0] * s, ctrl.location[1] * s)
        ctrl.size = (ctrl.size[0] * s, ctrl.height * s)
        ctrl.font = Font(ctrl.font.fontFamily, ctrl.font.size * 5, ctrl.font.style, ctrl.font.unit)
        with Bitmap(ctrl.size[0],  ctrl.size[1]) as bmp:
            ctrl.draw_to_bitmap(bmp, ctrl.client_rectangle)
            g.draw_image(bmp, ctrl.location)
        ctrl.location = old_loc
        ctrl.size = old_size
        ctrl.font = old_font
        if isinstance(ctrl, GroupBox) or isinstance(ctrl, Panel):
            for gctrl in hold:
                ctrl.controls.append(gctrl)
            scale_controls(ctrl, g, s)



C Implementation:
void scale_controls(Control c, Graphics *g, double s) {
    List *hold = NULL;
    for (int i = 0; i < c.controls.len; i++) {
        Control ctrl = c.controls.items + i;
        if (ctrl is GroupBox || ctrl is Panel) {
            hold = new_list();
            for (int j = 0; j < ctrl.controls.len; j++) {
                add_to_list(hold, ctrl.controls.items + j);
            }
            clear_list(ctrl.controls);
        }
        Point old_loc = ctrl.location;
        Size old_size = ctrl.size;
        Font old_font = ctrl.font;
        ctrl.location.x *= s;
        ctrl.location.y *= s;
        ctrl.size.width *= s;
        ctrl.size.height *= s;
        ctrl.font.size *= 5;
        Bitmap bmp = new_bitmap(ctrl.size.width, ctrl.size.height);
        draw_to_bitmap(& bmp, ctrl.client_rectangle);
        draw_image(g, & bmp, ctrl.location);
        ctrl.location = old_loc;
        ctrl.size = old_size;
        ctrl.font = old_font;
        if (ctrl is GroupBox || ctrl is Panel) {
            for (int i = 0; i < hold->len; i++) {
                add_to_list(ctrl.controls, hold->items + i);
            }
            scale_controls(ctrl, g, s);
        }
    }
}



Java Implementation:
private void scaleControls(Control c, Graphics g, double s) {
    List<Control> hold = null;
    for (Control ctrl : c.getControls()) {
        if (ctrl instanceof GroupBox || ctrl instanceof Panel) {
            hold = new ArrayList<Control>();
            for (Control gctrl : ctrl.getControls()) {
                hold.add(gctrl);
            }
            ctrl.getControls().clear();
        }
        Point oldLoc = ctrl.getLocation();
        Size oldSize = ctrl.getSize();
        Font oldFont = ctrl.getFont();
        ctrl.setLocation(new Point((int) (ctrl.getLocation().getX() * s), (int) (ctrl.getLocation().getY() * s)));
        ctrl.setSize(new Size((int) (ctrl.getSize().getWidth() * s), (int) (ctrl.getHeight() * s)));
        ctrl.setFont(new Font(ctrl.getFont().getFontFamily(), (int) (ctrl.getFont().getSize() * 5), ctrl.getFont().getStyle(), ctrl.getFont().getUnit()));
        try {
            BufferedImage bmp = new BufferedImage(ctrl.getSize().getWidth(), ctrl.getSize().getHeight(), BufferedImage.TYPE_INT_ARGB);
            ctrl.drawToBitmap(bmp, ctrl.getClientRectangle());
            g.drawImage(bmp, ctrl.getLocation().getX(), ctrl.getLocation().getY(), null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ctrl.setLocation(oldLoc);
        ctrl.setSize(oldSize);
        ctrl.setFont(oldFont);
        if (ctrl instanceof GroupBox || ctrl instanceof Panel) {
            for (Control gctrl : hold) {
                ctrl.getControls().add(gctrl);
            }
            scaleControls(ctrl, g, s);
        }
    }
}

