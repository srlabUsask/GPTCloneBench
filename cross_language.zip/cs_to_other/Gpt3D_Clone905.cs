#input 
public static bool IsWindowOnAnyScreen (Window Window, short WindowSizeX, short WindowSizeY, bool AutoAdjustWindow) {
    var Screen = System.Windows.Forms.Screen.FromHandle (new WindowInteropHelper (Window).Handle);
    bool LeftSideTest = false, TopSideTest = false, BottomSideTest = false, RightSideTest = false;
    if (Window.Left >= Screen.WorkingArea.Left)
        LeftSideTest = true;
    if (Window.Top >= Screen.WorkingArea.Top)
        TopSideTest = true;
    if ((Window.Top + WindowSizeY) <= Screen.WorkingArea.Bottom)
        BottomSideTest = true;
    if ((Window.Left + WindowSizeX) <= Screen.WorkingArea.Right)
        RightSideTest = true;
    if (LeftSideTest && TopSideTest && BottomSideTest && RightSideTest)
        return true;
    else {
        if (AutoAdjustWindow) {
            if (! LeftSideTest)
                Window.Left = Window.Left - (Window.Left - Screen.WorkingArea.Left);
            if (! TopSideTest)
                Window.Top = Window.Top - (Window.Top - Screen.WorkingArea.Top);
            if (! BottomSideTest)
                Window.Top = Window.Top - ((Window.Top + WindowSizeY) - Screen.WorkingArea.Bottom);
            if (! RightSideTest)
                Window.Left = Window.Left - ((Window.Left + WindowSizeX) - Screen.WorkingArea.Right);
        }
    }
    return false;
}


#====================
#gpt output=============

Python:
def IsWindowOnAnyScreen (Window, WindowSizeX, WindowSizeY, AutoAdjustWindow): 
    Screen = System.Windows.Forms.Screen.FromHandle (new WindowInteropHelper (Window).Handle) 
    LeftSideTest = False 
    TopSideTest = False 
    BottomSideTest = False 
    RightSideTest = False 
    if (Window.Left >= Screen.WorkingArea.Left): 
        LeftSideTest = True 
    if (Window.Top >= Screen.WorkingArea.Top): 
        TopSideTest = True 
    if ((Window.Top + WindowSizeY) <= Screen.WorkingArea.Bottom): 
        BottomSideTest = True 
    if ((Window.Left + WindowSizeX) <= Screen.WorkingArea.Right): 
        RightSideTest = True 
    if (LeftSideTest and TopSideTest and BottomSideTest and RightSideTest): 
        return True 
    else: 
        if (AutoAdjustWindow): 
            if (not LeftSideTest): 
                Window.Left = Window.Left - (Window.Left - Screen.WorkingArea.Left) 
            if (not TopSideTest): 
                Window.Top = Window.Top - (Window.Top - Screen.WorkingArea.Top) 
            if (not BottomSideTest): 
                Window.Top = Window.Top - ((Window.Top + WindowSizeY) - Screen.WorkingArea.Bottom) 
            if (not RightSideTest): 
                Window.Left = Window.Left - ((Window.Left + WindowSizeX) - Screen.WorkingArea.Right) 
    return False

C: 
bool IsWindowOnAnyScreen (Window Window, short WindowSizeX, short WindowSizeY, bool AutoAdjustWindow) {
    Screen* Screen = System.Windows.Forms.Screen.FromHandle (new WindowInteropHelper (Window).Handle);
    bool LeftSideTest = false, TopSideTest = false, BottomSideTest = false, RightSideTest = false;
    if (Window.Left >= Screen->WorkingArea.Left)
        LeftSideTest = true;
    if (Window.Top >= Screen->WorkingArea.Top)
        TopSideTest = true;
    if ((Window.Top + WindowSizeY) <= Screen->WorkingArea.Bottom)
        BottomSideTest = true;
    if ((Window.Left + WindowSizeX) <= Screen->WorkingArea.Right)
        RightSideTest = true;
    if (LeftSideTest && TopSideTest && BottomSideTest && RightSideTest)
        return true;
    else {
        if (AutoAdjustWindow) {
            if (! LeftSideTest)
                Window.Left = Window.Left - (Window.Left - Screen->WorkingArea.Left);
            if (! TopSideTest)
                Window.Top = Window.Top - (Window.Top - Screen->WorkingArea.Top);
            if (! BottomSideTest)
                Window.Top = Window.Top - ((Window.Top + WindowSizeY) - Screen->WorkingArea.Bottom);
            if (! RightSideTest)
                Window.Left = Window.Left - ((Window.Left + WindowSizeX) - Screen->WorkingArea.Right);
        }
    }
    return false;
}

Java:
public static boolean isWindowOnAnyScreen(Window window, short windowSizeX, short windowSizeY, boolean autoAdjustWindow) {
    Screen screen = System.Windows.Forms.Screen.fromHandle(new WindowInteropHelper(window).Handle);
    boolean leftSideTest = false, topSideTest = false, bottomSideTest = false, rightSideTest = false;
    if (window.Left >= screen.WorkingArea.Left)
        leftSideTest = true;
    if (window.Top >= screen.WorkingArea.Top)
        topSideTest = true;
    if ((window.Top + windowSizeY) <= screen.WorkingArea.Bottom)
        bottomSideTest = true;
    if ((window.Left + windowSizeX) <= screen.WorkingArea.Right)
        rightSideTest = true;
    if (leftSideTest && topSideTest && bottomSideTest && rightSideTest)
        return true;
    else {
        if (autoAdjustWindow) {
            if (!leftSideTest)
                window.Left = window.Left - (window.Left - screen.WorkingArea.Left);
            if (!topSideTest)
                window.Top = window.Top - (window.Top - screen.WorkingArea.Top);
            if (!bottomSideTest)
                window.Top = window.Top - ((window.Top + windowSizeY) - screen.WorkingArea.Bottom);
            if (!rightSideTest)
                window.Left = window.Left - ((window.Left + windowSizeX) - screen.WorkingArea.Right);
        }
    }
    return false;
}

