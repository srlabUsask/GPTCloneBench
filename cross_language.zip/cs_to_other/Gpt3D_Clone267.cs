#input 
public static string GetServByPort (short port, ProtocolType proto) {
    StringBuilder ans = new StringBuilder ();
    switch (proto) {
        case ProtocolType.Tcp :
            ans.Append ((TcpServices) port);
            break;
        case ProtocolType.Udp :
            ans.Append ((UdpServices) port);
            break;
    }
    ans.Append ("(").Append (port).Append (")");
    return ans.ToString ();
}


#====================
#gpt output=============


Python:
def get_serv_by_port(port, proto):
    ans = ""
    if proto == "Tcp":
        ans = TcpServices(port)
    elif proto == "Udp":
        ans = UdpServices(port)
    ans = ans + '(' + str(port) + ')'
    return ans
    
    
C:
char* get_serv_by_port(short port, ProtocolType proto){
    char *answer = malloc(1024);
    if(proto == Tcp){
        strcpy(answer, getTcpServices(port));
    }
    else{
        strcpy(answer, getUdpServices(port));
    }
    sprintf(answer + strlen(answer), "(%d)", port);
    return answer;
}

Java:
public static String getServByPort(short port, ProtocolType proto)  {
    StringBuilder ans = new StringBuilder();
    switch(proto) {
    case Tcp:
        ans.append((TcpServices)port);
        break;
    case Udp:
        ans.append((UdpServices)port);
        break;
    }
    ans.append("(").append(port).append(")");
    return ans.toString();
}

