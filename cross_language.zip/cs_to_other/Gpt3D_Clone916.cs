#input 
static void Main (string [] args) {
    Console.WriteLine ("Enter the string");
    string x = Console.ReadLine ();
    Console.WriteLine ("enter the string to be searched");
    string SearchText = Console.ReadLine ();
    string [] myarr = new string [30];
    myarr = x.Split (' ');
    int i = 0;
    foreach (string s in myarr) {
        i = i + 1;
        if (s == SearchText) {
            Console.WriteLine ("The string found at position:" + i);
        }
    }
    Console.ReadLine ();
}


#====================
#gpt output=============

Python:
def main():
  print("Enter the string:")
  x = input()
  print("Enter the string to be searched:")
  search_text = input()
  my_arr = x.split(' ')
  i = 0
  for s in my_arr:
    i += 1
    if s == search_text:
      print("The string found at position: " + str(i)) 
main()

C:
#include <stdio.h>
#include <string.h>
#define MAX_CHAR 30
 
int main()
{
    char str[MAX_CHAR];
    char searchText[MAX_CHAR];
    int i = 0;
    printf("Enter the string: ");
    scanf("%[^\n]s", str);
    printf("enter the string to be searched: ");
    scanf("%s", searchText);
    char* token = strtok(str, " ");
    while (token != NULL)
    {
        i += 1;
        if (strcmp(token, searchText) == 0) {
            printf("The string found at position: %d\n", i);
        }
        token = strtok(NULL, " ");
    }
    return 0;
}

Java:
import java.util.Scanner;

public static void main(String[] args) 
{
    Scanner scanner = new Scanner(System.in);

    System.out.println("Enter the string");
    String x = scanner.nextLine();
    System.out.println("enter the string to be searched");
    String SearchText = scanner.nextLine();
    String[] myarr = x.split(" ");
    int i = 0;
    for(String s : myarr) 
    {
        i += 1;
        if (s.equals(SearchText)) 
        {
            System.out.println("The string found at position:" + i);
        }
    }
    scanner.close();
}

