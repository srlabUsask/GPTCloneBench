#input 
public override void WriteJson (JsonWriter writer, object value, JsonSerializer serializer) {
    var contextBase = value as ContextBase;
    var valueToken = JToken.FromObject (value, new ForcedObjectSerializer ());
    if (contextBase.Properties != null) {
        var propertiesToken = JToken.FromObject (contextBase.Properties);
        foreach (var property in propertiesToken.Children < JProperty > ()) {
            valueToken [property.Name] = property.Value;
        }
    }
    valueToken.WriteTo (writer);
}


#====================
#gpt output=============

// Python
def write_json(writer, value, serializer):
    contextBase = value
    valueToken = json.loads(json.dumps(value, cls=ForcedObjectSerializer))
    if contextBase.properties is not None:
        propertiesToken = json.loads(json.dumps(contextBase.properties))
        for property in filter(lambda tkn: type(tkn) == dict, propertiesToken):
            valueToken[property.name] = property.value
    json.dump(valueToken, writer)

// C
void write_json(tipJSONWriter *writer, void *value, tipJSONSerializer *serializer) {
    ContextBase *contextBase = (ContextBase*)value;
    tipKeychain *valueToken = mod_value_keychain_create(value, forced_object_serializer_create());
    if(contextBase->properties != NULL) {
        tipKeychain *propertiesToken = mod_keychain_create(contextBase->properties);
        tipKeychain *keychainIterator = mod_keychain_get_first(propertiesToken);
        while(keychainIterator != NULL) {
            mod_keychain_add(valueToken, mod_keychain_get_name(keychainIterator), mod_keychain_get_value(keychainIterator));
            keychainIterator = mod_keychain_get_next(keychainIterator);
        }
    }
    tipJSON_export(valueToken, writer);
}

// Java
public void writeJson(JsonWriter writer, Object value, JsonSerializer serializer) {
    ContextBase contextBase = (ContextBase)value;
    JToken valueToken = JToken.fromObject(value, new ForcedObjectSerializer());
    if (contextBase.getProperties() != null) {
        JToken propertiesToken = JToken.fromObject(contextBase.getProperties());
        for (JProperty property : propertiesToken.getChildren()) {
            valueToken.put(property.getName(), property.getValue());
        }
    }
    valueToken.writeTo(writer);
}

