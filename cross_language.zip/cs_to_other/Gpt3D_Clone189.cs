#input 
public ActionResult Index (string searchBy, string orderBy, string orderDir) {
    var query = fca.GetResultsByFilter (searchBy);
    if (orderBy == "Campus") {
        query = (orderDir == "Asc") ? query.OrderBy (s = > s.Campus).ThenBy (s = > s.Student_Name) : query.OrderByDescending (s = > s.Campus);
    } else if (orderBy == "Student Name") {
        query = (orderDir == "Asc") ? query.OrderBy (s = > s.Student_Name) : query.OrderByDescending (s = > s.Student_Name);
    } else if (orderBy == "Course Count") {
        query = (orderDir == "Asc") ? query.OrderBy (s = > s.Student_Name) : query.OrderByDescending (s = > s.Course_Count);
    }
}


#====================
#gpt output=============

Python:
def index(searchBy, orderBy, orderDir):
    query = fca.get_results_by_filter(searchBy)
    if orderBy == 'Campus':
        query = query.order_by(s => s.campus) if orderDir == "Asc" else query.order_by(descending=s => s.campus)
    elif orderBy == 'Student Name':
        query = query.order_by(s => s.student_name) if orderDir == "Asc" else query.order_by(descending=s => s.student_name)
    elif orderBy == 'Course Count':
        query = query.order_by(s => s.student_name) if orderDir == "Asc" else query.order_by(descending=s => s.course_count)

C:
ActionResult index (char* searchBy, char* orderBy, char* orderDir) {
    query query = fca.get_results_by_filter(searchBy);
    if (strcmp(orderBy, "Campus") == 0) {
        query = orderDir == "Asc" ? query.order_by (s = > s.campus).then_by (s = > s.student_name) : query.order_by_descending (s = > s.campus);
    } else if (strcmp(orderBy, "Student Name") == 0) {
        query = orderDir == "Asc" ? query.order_by (s = > s.student_name) : query.order_by_descending (s = > s.student_name);
    } else if (strcmp(orderBy, "Course Count") == 0) {
        query = orderDir == "Asc" ? query.order_by (s = > s.student_name) : query.order_by_descending (s = > s.course_count);
    }

Java:
public ActionResult index(String searchBy, String orderBy, String orderDir){
    Query query = fca.getResultsByFilter(searchBy);
    if(orderBy.equals("Campus")){
        query = (orderDir.equals("Asc")) ? query.orderBy(s -> s.getCampus()).thenBy(s -> s.getStudentName()) : query.orderByDescending(s -> s.getCampus()); 
    } else if(orderBy.equals("Student Name")){
        query = (orderDir.equals("Asc")) ? query.orderBy(s -> s.getStudentName()) : query.orderByDescending(s -> s.getStudentName());
    } else if(orderBy.equals("Course Count")){
        query = (orderDir.equals("Asc")) ? query.orderBy(s -> s.getStudentName()) : query.orderByDescending(s -> s.getCourseCount());
    }
}

