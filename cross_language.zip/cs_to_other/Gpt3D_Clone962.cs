#input 
public static long BinomCoefficient (long n, long k) {
    if (k > n) {
        return 0;
    }
    if (n == k) {
        return 1;
    }
    if (k > n - k) {
        k = n - k;
    }
    long c = 1;
    for (long i = 1; i <= k; i ++) {
        c *= n --;
        c /= i;
    }
    return c;
}


#====================
#gpt output=============


// Python Implementation
def BinomCoefficient (n, k): 
    if (k > n): 
        return 0
    elif (n == k): 
        return 1
    elif (k > n - k): 
        k = n - k
    c = 1
    for i in range(1, k+1): 
        c *= n 
        n -= 1
        c //= i 
    return c 
    

// C Implementation
long BinomCoefficient (long n, long k) {
    if (k > n) {
        return 0;
    }
    if (n == k) {
        return 1;
    }
    if (k > n - k) {
        k = n - k;
    }
    long c = 1;
    long i;
    for (i = 1; i <= k; i ++) {
        c *= n--;
        c /= i;
    }
    return c;
}


// Java Implementation
public static long BinomCoefficient (long n, long k) {
    if (k > n) {
        return 0;
    }
    if (n == k) {
        return 1;
    }
    if (k > n - k) {
        k = n - k;
    }
    long c = 1;
    for (long i = 1; i <= k; i ++) {
        c *= n--;
        c /= i;
    }
    return c;
}

