#input 
static void Main (string [] args) {
    Stopwatch stopWatch = new Stopwatch ();
    stopWatch.Start ();
    Thread.Sleep (10000);
    stopWatch.Stop ();
    TimeSpan ts = stopWatch.Elapsed;
    string elapsedTime = String.Format ("{0:00}:{1:00}:{2:00}.{3:00}", ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10);
    Console.WriteLine ("RunTime " + elapsedTime);
}


#====================
#gpt output=============

Python:
import time
stopWatch = time.time()
time.sleep(10)
elapsedTime = time.strftime("%H:%M:%S:%s", time.gmtime(time.time() - stopWatch))
print("RunTime " + elapsedTime)

C:
#include <stdio.h>
#include <time.h>
#include <unistd.h>
int main(void)
{
    struct timespec start, finish;
    double elapsed;

clock_gettime(CLOCK_MONOTONIC, &start);
sleep(10);
clock_gettime(CLOCK_MONOTONIC, &finish);

elapsed = (finish.tv_sec - start.tv_sec);
elapsed += (finish.tv_nsec - start.tv_nsec) / 1000000000.0;
printf("Runtime %.f:%.f:%.f:%.f", elapsed/3600,(elapsed/60)%60,(elapsed)%60,elapsed*1000); 
}

Java:
import java.util.concurrent.TimeUnit;
 public static void main(String[] args) {
        Stopwatch stopWatch = new Stopwatch();
        stopWatch.start();
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        stopWatch.stop();
        long millis =  stopWatch.elapsed(TimeUnit.MILLISECONDS);
        int hours = (int) (millis / 3600000);
        int minutes = (int) (millis / 60000 % 60);
        int seconds = (int) (millis / 1000 % 60);
        int milliseconds = (int) (millis % 1000);
        System.out.printf("RunTime %02d:%02d:%02d.%03d \n", hours, minutes, seconds, milliseconds);
    }

