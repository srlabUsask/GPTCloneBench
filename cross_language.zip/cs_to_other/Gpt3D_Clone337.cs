#input 
public static void Main () {
    int numTasks = 20;
    int maxParallelism = 3;
    BlockingCollection = new BlockingCollection < Task < int > > (maxParallelism);
    Task.Factory.StartNew (() = > Producer (numTasks));
    foreach (var task in BlockingCollection.GetConsumingEnumerable ()) {
        task.Wait ();
        Console.WriteLine ("              Consumed: " + task.Result);
        task.Dispose ();
    }
}


#====================
#gpt output=============

Python:
def main():
  numTasks = 20
  maxParallelism = 3
  blockingCollection = queue.Queue(maxParallelism)
  producerThread = threading.Thread(target=producer, args=(numTasks,))
  producerThread.start()
  while(True):
    task = blockingCollection.get()
    task.join()
    print('              Consumed: ', task.result)
    task.close()


C:
int main(){ 
  int numTasks = 20;
  int maxParallelism = 3;
  blockingCollection *q = new blockingCollection(maxParallelism);
  pthread_t producerThread;
  pthread_create(&producerThread, NULL, producer, (void*)&numTasks);
  while(1){
    blockingCollection *task = blockingCollection_pop(q);
    pthread_join(task->thread_id, NULL);
    printf("              Consumed: %d\n", task->result);
    free(task);
  }
  return 0;
}


Java:
public static void main() {
  int numTasks = 20;
  int maxParallelism = 3;
  BlockingQueue<Task> blockingQueue = new ArrayBlockingQueue<Task>(maxParallelism);
  Thread producerThread = new Thread(() -> Producer(numTasks));
  producerThread.start();
  while(true) {
    Task task = blockingQueue.take();
    task.join();
    System.out.println("              Consumed: " + task.getResult());
    task.dispose();
  }
}

