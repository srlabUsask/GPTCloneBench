#input 
public static IEnumerable < T > EnumToList < T > () where T : struct {
    Type enumType = typeof (T);
    if (enumType.BaseType != typeof (Enum))
        throw new ArgumentException ("T must be of type System.Enum");
    Array enumValArray = Enum.GetValues (enumType);
    List < T > enumValList = new List < T > ();
    foreach (T val in enumValArray) {
        enumValList.Add (val.ToString ());
    }
    return enumValList;
}


#====================
#gpt output=============

Python Implementation:
def enum_to_list(T):
    if not isinstance(T, enum.Enum):
        raise ValueError("T must be of type System.Enum")
    enum_val_array = list(T)
    enum_val_list = []
    for val in enum_val_array:
        enum_val_list.append(val.name)
    return enum_val_list

Java Implementation:
public static <T extends Enum<T>> List<T> enumToList() {
    List<T> enumValList = new ArrayList<>();
    for (T val: T.values()) {
        enumValList.add(val);
    }
    return enumValList;
}

C Implementation:
typedef void* IEnumerable;

IEnumerable* enum_to_list(void* T) {
    if (!T || T->BaseType != Enum_type)
        return NULL;
    Array* enumValArray = Enum_getValues(T->Type);
    List* enumValList = list_create();
    for each val in enumValArray {
        list_push_back(enumValList, val.ToString);
    }
    return enumValList;
}

