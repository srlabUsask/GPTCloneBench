#input 
public static Image RotateImage (Image img, float rotationAngle) {
    Bitmap bmp = new Bitmap (img.Width, img.Height);
    Graphics gfx = Graphics.FromImage (bmp);
    gfx.TranslateTransform ((float) bmp.Width / 2, (float) bmp.Height / 2);
    gfx.RotateTransform (rotationAngle);
    gfx.TranslateTransform (- (float) bmp.Width / 2, - (float) bmp.Height / 2);
    gfx.InterpolationMode = InterpolationMode.HighQualityBicubic;
    gfx.DrawImage (img, new Point (0, 0));
    gfx.Dispose ();
    return bmp;
}


#====================
#gpt output=============

Python:
def rotate_image(img, angle): 
    width, height = img.size
    rotated_image = Image.new('RGB', (width, height))

    rotated_graphics = ImageDraw.Draw(rotated_image)
    
    rotated_graphics.translate(width/2,height/2)
    rotated_graphics.rotate(angle)
    rotated_graphics.translate(-width/2,-height/2)
    rotated_graphics.highqualitybicubic()
    rotated_graphics.draw(img)
    rotated_graphics.dispose()

    return rotated_image
    
    
C:
Image* RotateImage(Image* img, float rotationAngle) {
    Bitmap* bmp = new Bitmap(img->getWidth(), img->getHeight());
    Graphics* gfx = Graphics::fromImage(bmp);
    gfx->translateTransform((float) bmp->getWidth() / 2, (float) bmp->getHeight() / 2);
    gfx->rotateTransform(rotationAngle);
    gfx->translateTransform(- (float) bmp->getWidth() / 2, - (float) bmp->getHeight() / 2);
    gfx->setInterpolationMode(InterpolationModeHighQualityBicubic);
    gfx->drawImage(img, Point(0, 0));
    gfx->dispose();

    return bmp;
}

Java: 
public static Image rotateImage(Image img, float rotationAngle) {
    Bitmap bmp = new Bitmap(img.getWidth(), img.getHeight());
    Graphics gfx = Graphics.fromImage(bmp);
    gfx.translateTransform((float) bmp.getWidth() / 2, (float) bmp.getHeight() / 2);
    gfx.rotateTransform(rotationAngle);
    gfx.translateTransform(- (float) bmp.getWidth() / 2, - (float) bmp.getHeight() / 2);
    gfx.setInterpolationMode(InterpolationMode.HIGH_QUALITY_BICUBIC);
    gfx.drawImage(img, new Point(0, 0));
    gfx.dispose();

    return bmp;
}

