#input 
public string GetResultsWithHyphen (string inText) {
    var counter = 0;
    var outString = string.Empty;
    while (counter < inText.Length) {
        if (counter % 4 == 0)
            outString = string.Format ("{0}-{1}", outString, inText.Substring (counter, 1));
        else
            outString += inText.Substring (counter, 1);
        counter ++;
    }
    return outString;
}


#====================
#gpt output=============

Python: 
def GetResultsWithHyphen(inText):
    counter = 0
    outString = ''
    while counter < len(inText):
        if counter % 4 == 0:
            outString = '{0}-{1}'.format(outString, inText[counter])
        else:
            outString += inText[counter]
        counter += 1
    return outString

C: 
char *GetResultsWithHyphen (char* inText) {
    int counter = 0;
    char* outString = (char*)malloc(sizeof(char) * strlen(inText));
    while (counter < strlen(inText)) {
        if (counter % 4 == 0) {
          strcat(outString, "-");
          strncat(outString, &inText[counter], 1);
        } else {
          strncat(outString, &inText[counter], 1);
        }
        counter ++;
    }
    return outString;
}

Java:
public String GetResultsWithHyphen(String inText) {
    int counter = 0;
    String outString = "";
    while (counter < inText.length()) {
        if (counter % 4 == 0)
            outString = String.format("%s-%s", outString, inText.substring(counter, counter + 1));
        else
            outString += inText.substring(counter, counter + 1);
        counter ++;
    }
    return outString;
}

