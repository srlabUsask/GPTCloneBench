#input 
static void Main (string [] args) {
    var sourceFileNames = new List < FileList > ();
    sourceFileNames.Add (new FileList {FileNames = "1.txt"});
    sourceFileNames.Add (new FileList {FileNames = "2.txt"});
    sourceFileNames.Add (new FileList {FileNames = "3.txt"});
    sourceFileNames.Add (new FileList {FileNames = "4.txt"});
    List < FileList > destinationFileNames = new List < FileList > ();
    destinationFileNames.Add (new FileList {FileNames = "1.txt"});
    destinationFileNames.Add (new FileList {FileNames = "2.txt"});
    var except = sourceFileNames.Except (destinationFileNames);
    foreach (var f in except)
        Console.WriteLine (f.FileNames);
    Console.ReadLine ();
}


#====================
#gpt output=============


Python Implementation: 
sourceFileNames = []
sourceFileNames.append(FileList("1.txt"))
sourceFileNames.append(FileList("2.txt"))
sourceFileNames.append(FileList("3.txt"))
sourceFileNames.append(FileList("4.txt"))
destinationFileNames = []
destinationFileNames.append(FileList("1.txt"))
destinationFileNames.append(FileList("2.txt"))
except = set(sourceFileNames) - set(destinationFileNames)
for f in except:
    print (f.FileNames)

C Implementation: 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char FileNames[50];
} FileList;

void Main (int argc, char **argv) {
    FileList sourceFileNames[4];
    strcpy(sourceFileNames[0].FileNames, "1.txt");
    strcpy(sourceFileNames[1].FileNames, "2.txt");
    strcpy(sourceFileNames[2].FileNames, "3.txt");
    strcpy(sourceFileNames[3].FileNames, "4.txt");

    FileList destinationFileNames[2];
    strcpy(destinationFileNames[0].FileNames, "1.txt");
    strcpy(destinationFileNames[1].FileNames, "2.txt");

    int flSize = 4, dfSize = 2;
    int i, j;
    int flag = 0;
    for (i = 0; i < flSize; i++) {
        flag = 0;
        for (j = 0; j < dfSize; j++) {
            if (strcmp(sourceFileNames[i].FileNames, destinationFileNames[j].FileNames) == 0) {
                flag = 1;
            }
        }
        if (flag == 0)
            printf("%s\n", sourceFileNames[i].FileNames);
    }
}

Java Implementation:
import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<FileList> sourceFileNames = new ArrayList<>();
        sourceFileNames.add(new FileList("1.txt"));
        sourceFileNames.add(new FileList("2.txt"));
        sourceFileNames.add(new FileList("3.txt"));
        sourceFileNames.add(new FileList("4.txt"));

        List<FileList> destinationFileNames = new ArrayList<>();
        destinationFileNames.add(new FileList("1.txt"));
        destinationFileNames.add(new FileList("2.txt"));

        List<FileList> except = new ArrayList<>(sourceFileNames);
        except.removeAll(destinationFileNames);

        for(FileList f: except) {
            System.out.println(f.FileNames);
        }
    }
}

class FileList {
    public String FileNames;

    public FileList(String fileNames) {
        this.FileNames = fileNames;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof FileList && FileNames.equals(((FileList) o).FileNames);
    }
}

