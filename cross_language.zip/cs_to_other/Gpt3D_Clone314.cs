#input 
private string GetJavaInstallationPath () {
    string environmentPath = Environment.GetEnvironmentVariable ("JAVA_HOME");
    if (! string.IsNullOrEmpty (environmentPath)) {
        return environmentPath;
    }
    string javaKey = "SOFTWARE\\JavaSoft\\Java Runtime Environment\\";
    using (Microsoft.Win32.RegistryKey rk = Microsoft.Win32.Registry.LocalMachine.OpenSubKey (javaKey))
    {
        string currentVersion = rk.GetValue ("CurrentVersion").ToString ();
        using (Microsoft.Win32.RegistryKey key = rk.OpenSubKey (currentVersion))
        {
            return key.GetValue ("JavaHome").ToString ();
        }}}


#====================
#gpt output=============

Python:
def get_java_installation_path():
    environment_path = os.getenv('JAVA_HOME')
    if environment_path is not None:
        return environment_path
    java_key = 'SOFTWARE\\JavaSoft\\Java Runtime Environment\\'
    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, java_key) as key:
        current_version = winreg.QueryValueEx(key, "CurrentVersion")[0]
        with winreg.OpenKey(key, current_version) as subkey:
            return winreg.QueryValueEx(subkey, "JavaHome")[0]


C:
char* get_java_installation_path(){
    char* environment_path = getenv ("JAVA_HOME");
    if (environment_path != NULL){
        return environment_path;
    }

    HKEY java_key;
    char java_key_name[] = "SOFTWARE\\JavaSoft\\Java Runtime Environment\\";
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, java_key_name, 0, KEY_READ, &java_key) == ERROR_SUCCESS){
        char current_version[512];
        DWORD buffer_size = sizeof(current_version);
        if (RegQueryValueEx(java_key, "CurrentVersion", NULL, NULL, (LPBYTE)current_version, &buffer_size) == ERROR_SUCCESS){
            
            HKEY java_subkey;
            if (RegOpenKeyEx(java_key, current_version, 0, KEY_READ, &java_subkey) == ERROR_SUCCESS){
                char java_home[512];
                DWORD buffer_size = sizeof(java_home);
                if (RegQueryValueEx(java_subkey, "JavaHome", NULL, NULL, (LPBYTE)java_home, &buffer_size) == ERROR_SUCCESS){
                    RegCloseKey(java_subkey);
                    return java_home;
                }
            }
        }
    }

    return NULL;
}


Java:
public static String getJavaInstallationPath() {
    String environmentPath = System.getenv("JAVA_HOME");
    if (environmentPath != null && !environmentPath.isEmpty()) {
        return environmentPath;
    }

    String javaKeyName = "SOFTWARE\\JavaSoft\\Java Runtime Environment\\";
    try {
        var javaKey = WindowsRegistry.getInstance().openKey(HKEY_LOCAL_MACHINE, javaKeyName, KEY_READ);
        String currentVersion = javaKey.getStringValue("CurrentVersion");
        var javaSubkey = javaKey.openSubKey(currentVersion, KEY_READ);
        String javaHome = javaSubkey.getStringValue("JavaHome");
        return javaHome;
    } catch (WindowsRegistryException e) {
        e.printStackTrace();
    }

    return null;
}

