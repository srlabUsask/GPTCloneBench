#input 
static void Main (string [] args) {
    var first = new List < double > {1, 2, 3};
    var second = new List < double > {3, 4, 5};
    var lists = new List < List < double > > {first, second};
    var flatten = lists.SelectMany (a = > a).ToArray ();
    foreach (var i in flatten) {
        Console.WriteLine (i);
    }
}


#====================
#gpt output=============


Python:
first = [1,2,3]
second = [3,4,5]
lists = [first, second]

flatten = [item for sublist in lists for item in sublist] 
  
for i in flatten: 
	 print(i)

C:
#include<stdio.h>
#include<stdlib.h>
 
int main ()
{
  double first[] = {1, 2, 3}; 
  double second[] = {3, 4, 5}; 
   
  double *lists[2] = {first, second}; 
  double *flatten; 
  int size = 0; 
   
  for (int i = 0; i < 2; i++){  
    size += sizeof(lists[i])/sizeof(lists[i][0]); 
  }
  
  flatten = (double *)malloc(size * sizeof(double)); 
 
  int k = 0; 
  for (int i = 0; i < 2; i++) { 
    for (int j = 0; j < 3; j++) { 
      flatten[k++] = lists[i][j]; 
    } 
  } 
  
  for (int i = 0; i < size; i++) 
    printf("%f  ", flatten[i]); 
 
  free(flatten); 
  return 0; 
} 

Java:
import java.util.*;  
public class Example { 
  public static void main(String[] args) 
  { 
    List<Double> first = Arrays.asList(1.0, 2.0, 3.0); 
    List<Double> second = Arrays.asList(3.0, 4.0, 5.0); 
    List<List<Double>> lists = Arrays.asList(first, second);  
    double[] flatten = lists.stream().flatMapToDouble(x -> x.stream().mapToDouble(y ->y)).toArray(); 
      
    for (double i : flatten) 
    { 
      System.out.println(i); 
    } 
  } 
}

