#input 
static void Main () {
    int total = 0;
    var vowels = new HashSet < char > {'a', 'e', 'i', 'o', 'u'};
    Console.WriteLine ("Enter a Sentence");
    string sentence = Console.ReadLine ().ToLower ();
    for (int i = 0; i < sentence.Length; i ++) {
        if (vowels.Contains (sentence [i])) {
            total ++;
        }
    }
    Console.WriteLine ("Your total number of vowels is: {0}", total);
    Console.ReadLine ();
}


#====================
#gpt output=============

Python: 

def main():
    total = 0
    vowels = set('aeiou')
    sentence = str(input('Enter a sentence: \n')).lower()
    for char in sentence:
        if char in vowels:
            total += 1
    print("Your total number of vowels is: {}".format(total))


C: 

#include<stdio.h> 
#include<string.h> 
#include<stdlib.h> 

#define MAX_SIZE 100 

char vowels[] = {'a', 'e', 'i', 'o', 'u'}; 

int main() 
{ 
	// Take a string as Input 
	char str[MAX_SIZE]; 
	printf("Enter a string: \n"); 
	scanf("%[^\n]s", str); 
	
	// Counting the vowels 
	int countVowel = 0; 

	for(int i=0;i<strlen(str);i++)
	{ 
		for(int j=0;j<5;j++)
		{ 
			// comparison of string character with vowel characters 
			if(tolower(str[i]) == vowels[j])
			{ 
				countVowel++; 
				break; 
			} 
		} 
	} 
	printf("Total number of vowels: %d\n", countVowel); 

	return 0; 
} 


Java: 

public class Main { 
  
    // Function to count number of vowels in a sentence 
    static int totalVowel(String s) 
    { 
        HashSet<Character> hs = new HashSet<>(); 
  
        // Adding vowels in a HashSet 
        hs.add('a'); hs.add('e'); hs.add('i'); 
        hs.add('o'); hs.add('u'); 
  
        // Initialize counter to 0 
        int count = 0; 
  
        for (int i = 0; i < s.length(); i++) { 
  
            // If set contains current character 
            // then increment counter 
            if (hs.contains(s.charAt(i))) 
                count++; 
        } 
        return count; 
    } 
  
    public static void main(String[] args) 
    { 
        String s = "Enter a Sentence";
        s.toLowerCase();
  
        System.out.println("Total number of vowels: "
                           + totalVowel(s)); 
    } 
}

