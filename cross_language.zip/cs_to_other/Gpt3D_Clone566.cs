#input 
public Image ResizeImage (Image source, RectangleF destinationBounds) {
    RectangleF sourceBounds = new RectangleF (0.0f, 0.0f, (float) source.Width, (float) source.Height);
    RectangleF scaleBounds = new RectangleF ();
    Image destinationImage = new Bitmap ((int) destinationBounds.Width, (int) destinationBounds.Height);
    Graphics graph = Graphics.FromImage (destinationImage);
    graph.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
    graph.FillRectangle (new SolidBrush (System.Drawing.Color.White), destinationBounds);
    float resizeRatio, sourceRatio;
    float scaleWidth, scaleHeight;
    sourceRatio = (float) source.Width / (float) source.Height;
    if (sourceRatio >= 1.0f) {
        resizeRatio = destinationBounds.Width / sourceBounds.Width;
        scaleWidth = destinationBounds.Width;
        scaleHeight = sourceBounds.Height * resizeRatio;
        float trimValue = destinationBounds.Height - scaleHeight;
        graph.DrawImage (source, 0, (trimValue / 2), destinationBounds.Width, scaleHeight);
    } else {
        resizeRatio = destinationBounds.Height / sourceBounds.Height;
        scaleWidth = sourceBounds.Width * resizeRatio;
        scaleHeight = destinationBounds.Height;
        float trimValue = destinationBounds.Width - scaleWidth;
        graph.DrawImage (source, (trimValue / 2), 0, scaleWidth, destinationBounds.Height);
    }
    return destinationImage;
}


#====================
#gpt output=============

Python:
def ResizeImage (source, destinationBounds):
    sourceBounds = (0.0, 0.0, source.Width, source.Height)
    scaleBounds = ()
    destinationImage = Bitmap ((int) destinationBounds.Width, (int) destinationBounds.Height)
    graph = Graphics.FromImage (destinationImage)
    graph.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic
    graph.FillRectangle (SolidBrush (System.Drawing.Color.White), destinationBounds)
    sourceRatio = source.Width / source.Height
    if (sourceRatio >= 1.0):
        resizeRatio = destinationBounds.Width / sourceBounds.Width
        scaleWidth = destinationBounds.Width
        scaleHeight = sourceBounds.Height * resizeRatio
        trimValue = destinationBounds.Height - scaleHeight
        graph.DrawImage (source, 0, (trimValue / 2), destinationBounds.Width, scaleHeight)
    else:
        resizeRatio = destinationBounds.Height / sourceBounds.Height
        scaleWidth = sourceBounds.Width * resizeRatio
        scaleHeight = destinationBounds.Height
        trimValue = destinationBounds.Width - scaleWidth
        graph.DrawImage (source, (trimValue / 2), 0, scaleWidth, destinationBounds.Height)
    return destinationImage


C:
Image ResizeImage (Image source, RectangleF destinationBounds) {
    RectangleF sourceBounds; 
    sourceBounds.x = 0.0f; 
    sourceBounds.y = 0.0f; 
    sourceBounds.width = (float) source.Width; 
    sourceBounds.height = (float) source.Height; 
    RectangleF scaleBounds; 
    Image destinationImage; 
    destinationImage.width = (int) destinationBounds.Width; 
    destinationImage.height = (int) destinationBounds.Height; 
    Graphics graph = Graphics_FromImage (destinationImage); 
    graph.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic; 
    SolidBrush brush;
    brush.color = System.Drawing.Color.White;
    graph.FillRectangle (brush, destinationBounds); 
    float resizeRatio, sourceRatio; 
    float scaleWidth, scaleHeight; 
    sourceRatio = source.Width / source.Height;
    if (sourceRatio >= 1.0f) {
        resizeRatio = destinationBounds.Width / sourceBounds.Width; 
        scaleWidth = destinationBounds.Width; 
        scaleHeight = sourceBounds.Height * resizeRatio; 
        float trimValue = destinationBounds.Height - scaleHeight; 
        graph.DrawImage (source, 0, (trimValue / 2), destinationBounds.Width, scaleHeight);
    } else {
        resizeRatio = destinationBounds.Height / sourceBounds.Height; 
        scaleWidth = sourceBounds.Width * resizeRatio; 
        scaleHeight = destinationBounds.Height; 
        float trimValue = destinationBounds.Width - scaleWidth; 
        graph.DrawImage (source, (trimValue / 2), 0, scaleWidth, destinationBounds.Height); 
    }
    return destinationImage; 
}


Java:
public Image ResizeImage (Image source, RectangleF destinationBounds) {
    RectangleF sourceBounds = new RectangleF (0.0f, 0.0f, (float) source.getWidth(), (float) source.getHeight());
    RectangleF scaleBounds = new RectangleF ();
    Image destinationImage = new Bitmap ((int) destinationBounds.getWidth(), (int) destinationBounds.getHeight());
    Graphics graph = Graphics.createImage (destinationImage);
    graph.setInterpolationMode (System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic);
    graph.fillRectangle (new SolidBrush (System.Drawing.Color.White), destinationBounds);
    float resizeRatio, sourceRatio;
    float scaleWidth, scaleHeight;
    sourceRatio = (float) source.getWidth () / (float) source.getHeight ();
    if (sourceRatio >= 1.0f) {
        resizeRatio = destinationBounds.getWidth () / sourceBounds.getWidth ();
        scaleWidth = destinationBounds.getWidth ();
        scaleHeight = sourceBounds.getHeight () * resizeRatio;
        float trimValue = destinationBounds.getHeight () - scaleHeight;
        graph.drawImage (source, 0, (trimValue / 2), destinationBounds.getWidth (), scaleHeight);
    } else {
        resizeRatio = destinationBounds.getHeight () / sourceBounds.getHeight ();
        scaleWidth = sourceBounds.getWidth () * resizeRatio;
        scaleHeight = destinationBounds.getHeight ();
        float trimValue = destinationBounds.getWidth () - scaleWidth;
        graph.drawImage (source, (trimValue / 2), 0, scaleWidth, destinationBounds.getHeight ());
    }
    return destinationImage;
}

