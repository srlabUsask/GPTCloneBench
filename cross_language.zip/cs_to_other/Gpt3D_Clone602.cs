#input 
public static long fibo_n (long N) {
    if (N <= 0)
        return 0;
    if (N == 1)
        return 1;
    if (N <= 4)
        return N - 1;
    return fibo_n (N - 1) + fibo_n (N - 2);
}


#====================
#gpt output=============

// Python
def fibo_n(N): 
    if N <= 0: 
        return 0
    elif N == 1: 
        return 1
    elif N <= 4: 
        return N - 1
    else: 
        return fibo_n(N - 1) + fibo_n(N - 2) 

// C
long fibo_n (long N) {
    if (N <= 0)
        return 0;
    else if (N == 1)
        return 1;
    else if (N <= 4)
        return N - 1;
    else 
        return fibo_n (N - 1) + fibo_n (N - 2);
}

// Java 
public static long fibo_n (long N) {
    if (N <= 0)
        return 0;
    else if (N == 1)
        return 1;
    else if (N <= 4)
        return N - 1;
    else 
        return fibo_n (N - 1) + fibo_n (N - 2);
}

