#input 
private bool IsOk (string str) {
    char ? last = null;
    var i = 1;
    foreach (var c in str) {
        if (last == c) {
            i ++;
            if (i > 2)
                return false;
        } else {
            i = 1;
        }
        last = c;
    }
    return true;
}


#====================
#gpt output=============


Python :
def IsOk(string): 
    last = None
    i = 1
    for c in string:
        if last == c: 
            i += 1
            if i > 2: 
                return False
        else: 
            i = 1
        last = c
    return True


C :
bool IsOk(char *str) 
{ 
    char *last = NULL; 
    int i = 1; 
    while (*str) 
    { 
        if (last && *last == *str) 
        { 
            i++; 
            if (i > 2) 
                return false; 
        } 
        else
        { 
            i = 1; 
        } 
        last = str; 
    } 

    return true; 
} 



Java :
public static boolean isOk(String str) {
    char last = 0;
    int i = 1;
    
    for (char c : str.toCharArray()) {
        if (last == c) {
            i++;
            if (i > 2) {
                return false;
            }
        } else {
            i = 1;
        }
        last = c;
    }
    return true;
}

