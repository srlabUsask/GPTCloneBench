#input 
public static T [,] To2dArray (this List < List < T > > list) {
    if (list.Count == 0 || list [0].Count == 0)
        throw new ArgumentException ("The list must have non-zero dimensions.");
    var result = new T [list.Count, list [0].Count];
    for (int i = 0; i < list.Count; i ++) {
        for (int j = 0; j < list [i].Count; j ++) {
            if (list [i].Count != list [0].Count)
                throw new InvalidOperationException ("The list cannot contain elements (lists) of different sizes.");
            result [i, j] = list [i] [j];
        }
    }
    return result;
}


#====================
#gpt output=============


Python:
def to2d_array(list):
    if len(list) == 0 or len(list[0]) == 0:
        raise Exception('The list must have non-zero dimensions.')
    result = [[None for x in range(len(list[0]))]
              for y in range(len(list))]
    for i in range(len(list)):
        for j in range(len(list[i])):
            if len(list[i]) != len(list[0]):
                raise Exception('The list cannot contain elements (lists) of different sizes.')
            result[i][j] = list[i][j]
    return result


C:
T **To2DArray(List* list){
    if(list->size == 0 || list->list[0].size == 0)
        return NULL; // Throw argument exception
    T** result;
    result = malloc(sizeof(T*) * list->size);
    for (int i = 0; i < list->size; i++){
        result[i] = malloc(sizeof(T) * list->list[0].size);
        for(int j = 0; j < list->list[i].size; j++){
            if(list->list[i].size != list->list[0].size)
                return NULL; //Throw exception
            result[i][j] = list->list[i].list[j];
        }
    }
    return result;
}


Java:
static <T> T[][] To2dArray(List<List<T>> list) {
    if (list.isEmpty() || list.get(0).isEmpty())
        throw new IllegalArgumentException("The list must have non-zero dimensions.");
    T[][] result = new T[list.size()][list.get(0).size()];
    for (int i = 0; i < list.size(); i++) {
        for (int j = 0; j < list.get(i).size(); j++) {
            if (list.get(i).size() != list.get(0).size())
                throw new IllegalArgumentException("The list cannot contain elements (lists) of different sizes.");
            result[i][j] = list.get(i).get(j);
        }
    }
    return result;
}

