#input 
public bool Equals (int [] x, int [] y) {
    if (Object.ReferenceEquals (x, y))
        return true;
    if (Object.ReferenceEquals (x, null) || Object.ReferenceEquals (y, null))
        return false;
    if (x.Length != y.Length)
        return false;
    for (int i = 0; i < x.Length; i ++) {
        if (x [i] != y [i])
            return false;
    }
    return true;
}


#====================
#gpt output=============

Python Implementation: 
def Equals (x, y):
    if x is y:
        return True
    if x is None or y is None:
        return False
    if len(x) != len(y):
        return False
    for i in range(len(x)):
        if x[i] != y[i]:
            return False
    return True
        
C Implementation:
bool Equals(int x[], int y[]) {
    if (x == y) 
        return true;
    if (x == NULL || y == NULL)
        return false;
    if (sizeof(x)/sizeof(int) != sizeof(y)/sizeof(int))
        return false;
    for (int i = 0; i < sizeof(x)/sizeof(int); i++) {
        if (x[i] != y[i])
            return false;
    }
    return true;
}

Java Implementation: 
public static boolean Equals(int[] x, int[] y) {
    if(Objects.equals(x, y)) 
        return true;
    if(x == null || y == null) 
        return false;
    if(x.length != y.length) 
        return false;
    for(int i = 0; i < x.length; i++) {
        if(x[i] != y[i]) 
            return false;
    }
    return true;
}

