#input 
public static void Main (string [] args) {
    List < Demo > all = new List < Demo > ();
    all.Add (new Demo {Name = "a"});
    all.Add (new Demo {Name = "ab"});
    all.Add (new Demo {Name = "abc"});
    all.Add (new Demo {Name = "cba"});
    all.Add (new Demo {Name = "bac"});
    all.Add (new Demo {Name = "ddd"});
    var t = Filter (all, "Name", "a");
    Console.WriteLine (t.Count);
}


#====================
#gpt output=============

Python:
all = []
all.append(Demo(Name="a")) 
all.append(Demo(Name="ab")) 
all.append(Demo(Name="abc")) 
all.append(Demo(Name="cba"))
all.append(Demo(Name="bac")) 
all.append(Demo(Name="ddd"))

t = [obj for obj in all if obj.name == "a"]
print(len(t))

C: 
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct 
{
    char* Name;

}Demo;

int filter(Demo *all, int n, char* key, char* value){
    int count = 0;
    for (int i = 0; i < n; i++){
        if (strcmp(all[i].Name, value) == 0){
            count++;
        }
    }
    return count;
}

int main(){
    int n = 6;
    Demo *all;
    all = (Demo*)malloc(n * sizeof(Demo));
    
    all[0].Name = "a";
    all[1].Name = "ab";
    all[2].Name = "abc";
    all[3].Name = "cba";
    all[4].Name = "bac";
    all[5].Name = "ddd";
    
    int t = filter(all, 6, "Name", "a");
    printf("%d\n", t);

    free(all);

    return 0;
}

Java:
public class Main {
    public static int filter(List<Demo> all, String key, String value) {
        int count = 0;
        for (Demo d : all) {
            if (d.getName().equals(value)) {
                count++;
            }
        }
        return count;
    }
 
    public static void main(String[] args) {
        List<Demo> all = new ArrayList<>();
        all.add(new Demo("a"));
        all.add(new Demo("ab"));
        all.add(new Demo("abc"));
        all.add(new Demo("cba"));
        all.add(new Demo("bac"));
        all.add(new Demo("ddd"));
        
        int t = filter(all, "Name", "a");
        System.out.println(t);
    }
}

class Demo {
    private String name;

    public Demo(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}

