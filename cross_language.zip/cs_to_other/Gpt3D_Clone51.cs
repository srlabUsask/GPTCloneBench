#input 
public static bool IsInPolygon (Point [] poly, Point point) {
    var coef = poly.Skip (1).Select ((p, i) = > (point.Y - poly [i].Y) * (p.X - poly [i].X) - (point.X - poly [i].X) * (p.Y - poly [i].Y)).ToList ();
    if (coef.Any (p = > p == 0))
        return true;
    for (int i = 1; i < coef.Count (); i ++) {
        if (coef [i] * coef [i - 1] < 0)
            return false;
    }
    return true;
}


#====================
#gpt output=============

Python:
def is_in_polygon(poly, point):
    coefs = [ ( point.y - poly[i].y ) * ( poly[i+1].x - poly[i].x ) - ( point.x - poly[i].x ) * ( poly[i+1].y - poly[i].y ) for i in range(len(poly)-1) ]
    if any(c == 0 for c in coefs):
        return True
    for i in range(1, len(coefs)):
        if coefs[i] * coefs[i-1] < 0:
            return False
    return True


C:
bool is_in_polygon(Point *poly, int size, Point point) {
    double *coef = malloc(sizeof(double) * (size - 1));
    
    for (int i = 0; i < size - 1; i++) {
        coef[i] = (point.y - poly[i].y) * (poly[i+1].x - poly[i].x) - (point.x - poly[i].x) * (poly[i+1].y - poly[i].y);
    }
    
    for (int i = 0; i < size - 1; i++) {
        if (coef[i] == 0) {
            return true;
        }
    }
    for (int i = 1; i < size - 1; i++) {
        if (coef[i]*coef[i - 1] < 0) {
            free(coef);
            return false;
        }
    }
    free(coef);
    return true;
}

Java:
public static boolean isInPolygon(Point[] poly, Point point) {
    double[] coef = new double[poly.length - 1];
    
    for (int i = 0; i < poly.length - 1; i++) {
        coef[i] = (point.y - poly[i].y) * (poly[i + 1].x - poly[i].x) - (point.x - poly[i].x) * (poly[i + 1].y - poly[i].y);
    }
    
    for (int i = 0; i < coef.length; i++) {
        if (coef[i] == 0) {
            return true;
        }
    }
    for (int i = 1; i < coef.length; i++) {
        if (coef[i] * coef[i - 1] < 0) {
            return false;
        }
    }
    return true;
}

