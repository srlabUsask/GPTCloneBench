#input 
public bool MoveNext () {
    if (idx == - 1) {
        idx = 0;
        current = 1;
    } else {
        current = current * 2;
    }
    return true;
}


#====================
#gpt output=============

Python:
def MoveNext(): 
    global idx, current
    if idx == -1:
        idx = 0
        current = 1
    else:
        current = current * 2
    return True

C:
int MoveNext () {
    static int idx = -1;
    static int current = 0;
    if (idx == - 1) {
        idx = 0;
        current = 1;
    } else {
        current = current * 2;
    }
    return 1;
}

Java:
public boolean MoveNext () {
    static int idx = -1;
    static int current = 0;
    if (idx == - 1) {
        idx = 0;
        current = 1;
    } else {
        current = current * 2;
    }
    return true;
}

