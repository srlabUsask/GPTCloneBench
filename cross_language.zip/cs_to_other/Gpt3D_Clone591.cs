#input 
public static Dictionary < Header, Detail > Ungroup (Dictionary < Header, Detail > input) {
    var output = new Dictionary < Header, Detail > ();
    foreach (var key in input.Keys) {
        var lookup = input [key].Parts.ToLookup (part = > part);
        bool done = false;
        for (int i = 0; ! done; i ++) {
            var parts = lookup.GetNthValues (i).ToList ();
            if (parts.Any ()) {
                output.Add (new Header (key.Value), new Detail {Parts = parts});
            } else {
                done = true;
            }
        }
    }
    return output;
}


#====================
#gpt output=============

//Python
def Ungroup(input):
    output = {}
    for key in input.keys():
        lookup = list(input[key].parts)
        done = False
        i = 0
        while not done:
            parts = [part for part in lookup if part == i]
            if parts:
                output[key.value] = Detail(parts=parts)
            else:
                done = True
            i += 1
    return output

//C
Dictionary_Header_Detail Ungroup (Dictionary_Header_Detail input) {
    Dictionary_Header_Detail output;
    Dictionary_Header_Detail_Iterate iter;
    
    iter = Dictionary_Header_Detail_Iterate_create(input);
    output = Dictionary_Header_Detail_create();
    
    while(Dictionary_Header_Detail_Iterate_valid(iter)){
        Header key;
        Detail lookup;
        int done;
        int i;
        
        key = *Dictionary_Header_Detail_Iterate_current_key(*iter);
        lookup = *Dictionary_Header_Detail_Iterate_current_value(*iter);
        
        done = 0;
        i = 0;
        
        while(!done){
            Detail parts = Detail_Parts_ToLookup(lookup.parts, part => part == i);
            if(parts != NULL){
                Dictionary_Header_Detail_insert(output, Header_copy(&key), Detail_copy(&parts));
            }else{
                done = 1;
            }
            i++;
        }
        
        Dictionary_Header_Detail_Iterate_next(*iter);
    }
    Dictionary_Header_Detail_Iterate_destroy(&iter);
    
    return output;
}

//Java
public static HashMap<Header, Detail> Ungroup(HashMap<Header, Detail> input) {
    HashMap<Header, Detail> output = new HashMap<>();
    for (Header key : input.keySet()) {
        Detail lookup = input.get(key);
        boolean done = false;
        for (int i = 0; !done; i++) {
            List<Detail> parts = lookup.Parts.stream()
                                           .filter(part -> part == i)
                                           .collect(Collectors.toList());
            if (parts.size() > 0) {
                output.put(new Header(key.Value), new Detail(parts));
            } else {
                done = true;
            }
        }
    }
    return output;
}

