#input 
private void SaevAsMultiPageTiff (string sOutFile, string [] pagesbase64Array) {
    System.Drawing.Imaging.Encoder encoder = System.Drawing.Imaging.Encoder.SaveFlag;
    ImageCodecInfo encoderInfo = ImageCodecInfo.GetImageEncoders ().First (i = > i.MimeType == "image/tiff");
    EncoderParameters encoderParameters = new EncoderParameters (1);
    encoderParameters.Param [0] = new EncoderParameter (encoder, (long) EncoderValue.MultiFrame);
    Bitmap firstImage = null;
    try {
        using (MemoryStream ms1 = new MemoryStream ())
        {
            using (MemoryStream ms = new MemoryStream (Convert.FromBase64String (pagesbase64Array [0])))
            {
                Image.FromStream (ms).Save (ms1, ImageFormat.Tiff);
                firstImage = (Bitmap) Image.FromStream (ms1);
            } firstImage.Save (sOutFile, encoderInfo, encoderParameters);
        } encoderParameters.Param [0] = new EncoderParameter (encoder, (long) EncoderValue.FrameDimensionPage);
        Bitmap imagePage;
        for (int i = 1; i < pagesbase64Array.Length; i ++) {
            using (MemoryStream ms1 = new MemoryStream ())
            {
                using (MemoryStream ms = new MemoryStream (Convert.FromBase64String (pagesbase64Array [i])))
                {
                    Image.FromStream (ms).Save (ms1, ImageFormat.Tiff);
                    imagePage = (Bitmap) Image.FromStream (ms1);
                } firstImage.SaveAdd (imagePage, encoderParameters);
            }}
    }
    catch (Exception) {
        throw;
    }
    finally {
        encoderParameters.Param [0] = new EncoderParameter (encoder, (long) EncoderValue.Flush);
        firstImage.SaveAdd (encoderParameters);
    }
}


#====================
#gpt output=============

Python implementation:
def SaveAsMultiPageTiff(sOutFile, pagesbase64Array):
    from PIL import Image
    from io import BytesIO
    from base64 import b64decode

    encoder = System.Drawing.Imaging.Encoder.SaveFlag
    encoderInfo = [i for i in ImageCodecInfo.getimageencoders() if i.mimetype==  "image/tiff"]
    encoderParameters = EncoderParameters(1)
    encoderParameters.params[0] = EncoderParameter(encoder, EncoderValue.MultiFrame)

    firstImage = None
    try:
        with BytesIO() as ms1:
            with BytesIO(b64decode(pagesbase64Array[0])) as mem:
                image_from_mem = Image.open(mem)
                image_from_mem.save(ms1, format="TIFF")
                firstImage = Image.open(ms1)
            firstImage.save(sOutFile, encoderInfo, encoderParameters)

        # For the rest of the images
        encoderParameters.params[0] = EncoderParameter(encoder, EncoderValue.FrameDimensionPage)
        imagePage = None
        for i in range(1, len(pagesbase64Array)):
            with BytesIO() as ms1:
                with BytesIO(b64decode(pagesbase64Array[i])) as mem:
                    image_from_mem = Image.open(mem)
                    image_from_mem.save(ms1, format="TIFF")
                    imagePage = Image.open(ms1)
                    firstImage.saveadd(imagePage, encoderParameters)        
    except Exception:
        raise
    
    finally:
        encoderParameters.params[0] = EncoderParameter(encoder, EncoderValue.Flush)
        firstImage.saveadd(encoderParameters)


Java Implementation: 
public void saveAsMultiPageTiff(String sOutFile, String[] pagesbase64Array) {
    ImageCodecInfo encoderInfo = Arrays.stream(ImageCodecInfo.getImageEncoders())
            .filter(i -> i.getMimeType().equals("image/tiff")).findFirst().orElse(null);
    EncoderParameters encoderParameters = new EncoderParameters(1);
    encoderParameters.SetParameter(Encoder.SaveFlag, EncoderValue.MultiFrame);
    BufferedImage firstImage = null;
    try {
        ByteArrayInputStream ms1 = new ByteArrayInputStream(Base64.getDecoder().decode(pagesbase64Array[0]));
        Graphics2D graphics2D = (Graphics2D) firstImage.getGraphics();
        graphics2D.drawImage(ImageIO.read(ms1), null, null);
        ImageIO.write(firstImage, "tiff", new File(sOutFile));
        encoderParameters.SetParameter(Encoder.SaveFlag, EncoderValue.FrameDimensionPage);
        BufferedImage imagePage;
        for (int i = 1; i < pagesbase64Array.length; i++) {
            ByteArrayInputStream ms = new ByteArrayInputStream(Base64.getDecoder().decode(pagesbase64Array[i]));
            imagePage = ImageIO.read(ms);
            Graphics2D g2d = (Graphics2D) firstImage.getGraphics();
            g2d.drawImage(imagePage, null, null);
            ImageIO.write(firstImage, "tiff", new File(sOutFile));
        }
    } catch (IOException e) {
        throw e;
    } finally {
        encoderParameters.SetParameter(Encoder.SaveFlag, EncoderValue.Flush);
        ImageIO.write(firstImage, "tiff", new File(sOutFile));
    }
}

C Implementation: 
void SaveAsMultiPageTiff(const char * sOutFile, const char ** pagesbase64Array, int pagesbase64ArraySize)
{
    ImageCodecInfo *encoderInfo;
    EncoderParameters *encoderParameters;
    Bitmap *firstImage;
    int encoderVal;
    int i;

    encoderVal = EncoderSaveFlag;
    encoderInfo = getImageEncodersByMIMEType("image/tiff");
    encoderParameters = CreateEncoderParameters(1);
    SetEncoderParameter(encoderParameters, 0, encoderVal, EncoderValueMultiFrame);

    firstImage = NULL;
    try
    {
        MemoryStream *ms1;
        MemoryStream *ms;
        Image *img;
        ms1 = CreateMemoryStream();
        ms = CreateMemoryStreamFromBase64String(pagesbase64Array[0]);
        img = CreateImageFromStream(ms);
        SaveImage(img, ms1, ImageFormatTiff);
        firstImage = (Bitmap*)CreateImageFromStream(ms1);
        SaveImageToFile(firstImage, sOutFile, encoderInfo, encoderParameters);
        SetEncoderParameter(encoderParameters, 0, encoderVal, EncoderValueFrameDimensionPage);

        for (i = 1; i < pagesbase64ArraySize; i++)
        {
            MemoryStream *ms1;
            MemoryStream *ms;
            Image *imagePage;

            ms1 = CreateMemoryStream();
            ms = CreateMemoryStreamFromBase64String(pagesbase64Array[i]);
            img = CreateImageFromStream(ms);
            SaveImage(img, ms1, ImageFormatTiff);
            imagePage = CreateImageFromStream(ms1);
            SaveAddImage(firstImage, imagePage, encoderParameters);
        }
    }
    catch (Exception *ex)
    {
        throw ex;
    }
    finally
    {
        SetEncoderParameter(encoderParameters, 0, encoderVal, EncoderValueFlush);
        SaveAddImage(firstImage, NULL, encoderParameters);
    }

}

