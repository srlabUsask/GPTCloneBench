#input 
protected override void WndProc (ref Message m) {
    const int WM_NCLBUTTONDOWN = 0x00A1;
    const int WM_NCLBUTTONUP = 0x00A2;
    const int HTCLOSE = 20;
    if (m.Msg == WM_NCLBUTTONDOWN) {
        switch ((int) m.WParam) {
            case HTCLOSE :
                break;
            default :
                base.WndProc (ref m);
                break;
        }
    } else {
        if (m.Msg == WM_NCLBUTTONUP) {
            switch ((int) m.WParam) {
                case HTCLOSE :
                    Trace.WriteLine ("Close Button clicked");
                    Close ();
                    break;
            }
        }
        base.WndProc (ref m);
    }
}


#====================
#gpt output=============

// Python Implementation
def WndProc(self, m):
    WM_NCLBUTTONDOWN = 0x00A1
    WM_NCLBUTTONUP = 0x00A2
    HTCLOSE = 20
    if (m.Msg == WM_NCLBUTTONDOWN):
        if (m.WParam == HTCLOSE):
            pass
        else:
            super().WndProc(m)
    else:
        if (m.Msg == WM_NCLBUTTONUP):
            if (m.WParam == HTCLOSE):
                print("Close Button clicked")
                Close()
        super().WndProc(m)

// C Implementation
void WndProc(struct Message* m) {
    const int WM_NCLBUTTONDOWN = 0x00A1;
    const int WM_NCLBUTTONUP = 0x00A2;
    const int HTCLOSE = 20;
    if (m->Msg == WM_NCLBUTTONDOWN) {
        switch (m->WParam) {
            case HTCLOSE :
                break;
            default :
                base_WndProc(m);
                break;
        }
    } else {
        if (m->Msg == WM_NCLBUTTONUP) {
            switch (m->WParam) {
                case HTCLOSE :
                    printf("Close Button clicked");
                    Close();
                    break;
            }
        }
        base_WndProc(m);
    }
}

// Java Implementation
protected void WndProc(Message m) {
    final int WM_NCLBUTTONDOWN = 0x00A1;
    final int WM_NCLBUTTONUP = 0x00A2;
    final int HTCLOSE = 20;
    if (m.Msg == WM_NCLBUTTONDOWN) {
        switch ((int) m.WParam) {
            case HTCLOSE :
                break;
            default :
                super.WndProc(m);
                break;
        }
    } else {
        if (m.Msg == WM_NCLBUTTONUP) {
            switch ((int) m.WParam) {
                case HTCLOSE :
                    System.out.println("Close Button clicked");
                    Close ();
                    break;
            }
        }
        super.WndProc(m);
    }
}

