#input 
public void FindPath () {
    ManagementObjectSearcher entity = new ManagementObjectSearcher ("SELECT * FROM Win32_DiskDrive");
    foreach (ManagementObject obj in entity.Get ()) {
        if (obj ["PNPDeviceID"].ToString ().Contains ("USBSTOR")) {
            if (! USBobjects.Contains (obj ["PNPDeviceID"].ToString ()))
                USBobjects.Add (obj ["PNPDeviceID"].ToString ());
        }
    }
}


#====================
#gpt output=============

Python: 
def FindPath():
    entity = ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive")
    for obj in entity.Get():
        if "USBSTOR" in obj["PNPDeviceID"].ToString():
            if obj["PNPDeviceID"].ToString() not in USBobjects:
                USBobjects.append(obj["PNPDeviceID"].ToString())

C: 
void FindPath() {
    ManagementObjectSearcher* entity = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
    foreach (ManagementObject* obj in entity.Get()) {
        if (strstr(obj->PNPDeviceID->ToString(), "USBSTOR")) {
            if (!USBobjects.Contains(obj->PNPDeviceID->ToString()))
                USBobjects.Add(obj->PNPDeviceID->ToString());
        }
    }
}

Java:
public void FindPath() {
    ManagementObjectSearcher entity = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
    for (ManagementObject obj : entity.Get()) {
        if (obj.get("PNPDeviceID").toString().contains("USBSTOR")) {
            if (!USBobjects.contains(obj.get("PNPDeviceID").toString()))
                USBobjects.add(obj.get("PNPDeviceID").toString());
        }
    }
}

