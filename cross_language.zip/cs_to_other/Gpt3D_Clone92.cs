#input 
static void Main (string [] args) {
    int n;
    Console.WriteLine ("Enter A Number :");
    n = int.Parse (Console.ReadLine ());
    if (n % 3 == 0) {
        if (n % 5 == 0) {
            Console.WriteLine ("This Number is Divisible by 3 and 5!");
        } else {
            printf ("\nThe number is divisible by 3 but not by 5");
        }
    } else if (n % 5 == 0) {
        Console.WriteLine ("The number is divisible by 5 but not by 3");
    } else {
        Console.WriteLine ("\nThis Number is Not Divisible by 3 and 5!");
    }
    Console.ReadLine ();
}


#====================
#gpt output=============

Python:

n = int(input("Enter a Number: "))

if (n % 3 == 0):
    if (n % 5 == 0):
        print("This number is divisible by 3 and 5!")
    else:
        print("The number is divisible by 3 but not 5")
elif (n % 5 == 0):
    print("The number is divisible by 5 but not 3")
else:
    print("This number is not divisible by 3 and 5!")

C: 

#include<stdio.h>

int main()  
{  
    int n;
    printf("Enter A Number: ");  
    scanf("%d", &n);
    if (n % 3 == 0) {
        if (n % 5 == 0) {
            printf("This Number is Divisible by 3 and 5!\n");
        } else {
            printf("\nThe number is divisible by 3 but not by 5\n");
        }
    } else if (n % 5 == 0) {
        printf("The number is divisible by 5 but not by 3\n");
    } else {
        printf("\nThis Number is Not Divisible by 3 and 5!\n");
    }
    return 0;  
} 

Java: 
import java.util.Scanner;

public class Main
{
    public static void main(String args[])
    {
        int n;
        System.out.println("Enter A Number :");
        Scanner scanner = new Scanner(System.in);
        n = scanner.nextInt();

        if (n % 3 == 0) {
            if (n % 5 == 0) {
                System.out.println("This Number is Divisible by 3 and 5!");
            } else {
                System.out.println("\nThe number is divisible by 3 but not by 5");
            }
        } else if (n % 5 == 0) {
            System.out.println("The number is divisible by 5 but not by 3");
        } else {
            System.out.println("\nThis Number is Not Divisible by 3 and 5!");
        }
        scanner.close();
    }
}

