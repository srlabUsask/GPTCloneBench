#input 
private HttpContextBase GetMockedHttpContext () {
    var context = new Mock < HttpContextBase > ();
    var request = new Mock < HttpRequestBase > ();
    var response = new Mock < HttpResponseBase > ();
    var session = new Mock < HttpSessionStateBase > ();
    var server = new Mock < HttpServerUtilityBase > ();
    var user = new Mock < IPrincipal > ();
    var identity = new Mock < IIdentity > ();
    var urlHelper = new Mock < UrlHelper > ();
    var routes = new RouteCollection ();
    MvcApplication.RegisterRoutes (routes);
    var requestContext = new Mock < RequestContext > ();
    requestContext.Setup (x = > x.HttpContext).Returns (context.Object);
    context.Setup (ctx = > ctx.Request).Returns (request.Object);
    context.Setup (ctx = > ctx.Response).Returns (response.Object);
    context.Setup (ctx = > ctx.Session).Returns (session.Object);
    context.Setup (ctx = > ctx.Server).Returns (server.Object);
    context.Setup (ctx = > ctx.User).Returns (user.Object);
    user.Setup (ctx = > ctx.Identity).Returns (identity.Object);
    identity.Setup (id = > id.IsAuthenticated).Returns (true);
    identity.Setup (id = > id.Name).Returns ("test");
    request.Setup (req = > req.Url).Returns (new Uri ("http://www.google.com"));
    request.Setup (req = > req.RequestContext).Returns (requestContext.Object);
    requestContext.Setup (x = > x.RouteData).Returns (new RouteData ());
    request.SetupGet (req = > req.Headers).Returns (new NameValueCollection ());
    return context.Object;
}


#====================
#gpt output=============

Python:
def get_mocked_http_context():
    context = Mock()
    request = Mock()
    response = Mock()
    session = Mock()
    server = Mock()
    user = Mock()
    identity = Mock()
    url_helper = Mock()
    routes = RouteCollection()
    MvcApplication.register_routes(routes)
    request_context = Mock()
    request_context.setup(x = > x.http_context).returns(context.object)
    context.setup(ctx = > ctx.request).returns(request.object)
    context.setup(ctx = > ctx.response).returns(response.object)
    context.setup(ctx = > ctx.session).returns(session.object)
    context.setup(ctx = > ctx.server).returns(server.object)
    context.setup(ctx = > ctx.user).returns(user.object)
    user.setup(ctx = > ctx.identity).returns(identity.object)
    identity.setup(id = > id.is_authenticated).returns(true)
    identity.setup(id = > id.name).returns('test')
    request.setup(req = > req.url).returns(Uri('http://www.google.com'))
    request.setup(req = > req.request_context).returns(request_context.object)
    request_context.setup(x = > x.route_data).returns(RouteData())
    request.setup_get(req = > req.headers).returns(NameValueCollection())
    return context.object

C:
HttpContextBase* GetMockedHttpContext()
{
    Mock<HttpContextBase>* context = new Mock<HttpContextBase>();
    Mock<HttpRequestBase>* request = new Mock<HttpRequestBase>();
    Mock<HttpResponseBase>* response = new Mock<HttpResponseBase>();
    Mock<HttpSessionStateBase>* session = new Mock<HttpSessionStateBase>();
    Mock<HttpServerUtilityBase>* server = new Mock<HttpServerUtilityBase>();
    Mock<IPrincipal>* user = new Mock<IPrincipal>();
    Mock<IIdentity>* identity = new Mock<IIdentity>();
    Mock<UrlHelper>* urlHelper = new Mock<UrlHelper>();
    RouteCollection* routes = new RouteCollection();
    MvcApplication.RegisterRoutes(routes);
    Mock<RequestContext>* requestContext = new Mock<RequestContext>();
    requestContext->Setup(x = > x.HttpContext).Returns(context->Object);
    context->Setup(ctx = > ctx.Request).Returns(request->Object);
    context->Setup(ctx = > ctx.Response).Returns(response->Object);
    context->Setup(ctx = > ctx.Session).Returns(session->Object);
    context->Setup(ctx = > ctx.Server).Returns(server->Object);
    context->Setup(ctx = > ctx.User).Returns(user->Object);
    user->Setup(ctx = > ctx.Identity).Returns(identity->Object);
    identity->Setup(id = > id.IsAuthenticated).Returns(true);
    identity->Setup(id = > id.Name).Returns("test");
    request->Setup(req = > req.Url).Returns(new Uri("http://www.google.com"));
    request->Setup(req = > req.RequestContext).Returns(requestContext->Object);
    requestContext->Setup(x = > x.RouteData).Returns(new RouteData());
    request->SetupGet(req = > req.Headers).Returns(new NameValueCollection());
    return context->Object;
}

Java:
public HttpContextBase getMockedHttpContext() {
    Mock<HttpContextBase> context = new Mock<>();
    Mock<HttpRequestBase> request = new Mock<>();
    Mock<HttpResponseBase> response = new Mock<>();
    Mock<HttpSessionStateBase> session = new Mock<>();
    Mock<HttpServerUtilityBase> server = new Mock<>();
    Mock<IPrincipal> user = new Mock<>();
    Mock<IIdentity> identity = new Mock<>();
    Mock<UrlHelper> urlHelper = new Mock<>();
    RouteCollection routes = new RouteCollection();
    MvcApplication.registerRoutes(routes);
    Mock<RequestContext> requestContext = new Mock<>();
    requestContext.setup(x -> x.getHttpContext()).returns(context.object);
    context.setup(ctx -> ctx.getRequest()).returns(request.object);
    context.setup(ctx -> ctx.getResponse()).returns(response.object);
    context.setup(ctx -> ctx.getSession()).returns(session.object);
    context.setup(ctx -> ctx.getServer()).returns(server.object);
    context.setup(ctx -> ctx.getUser()).returns(user.object);
    user.setup(ctx -> ctx.getIdentity()).returns(identity.object);
    identity.setup(id -> id.isAuthenticated()).returns(true);
    identity.setup(id -> id.getName()).returns("test");
    request.setup(req -> req.getUrl()).returns(new URI("http://www.google.com"));
    request.setup(req -> req.getRequestContext()).returns(requestContext.object);
    requestContext.setup(x -> x.getRouteData()).returns(new RouteData());
    request.setupGet(req -> req.getHeaders()).returns(new NameValueCollection());
    return context.object;
}

