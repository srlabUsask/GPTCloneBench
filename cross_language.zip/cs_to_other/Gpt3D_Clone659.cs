#input 
protected override void OnPaint (PaintEventArgs e) {
    const int inset = 2;
    using (Image offscreenImage = new Bitmap (this.Width, this.Height))
    {
        using (Graphics offscreen = Graphics.FromImage (offscreenImage))
        {
            Rectangle rect = new Rectangle (0, 0, this.Width, this.Height);
            if (ProgressBarRenderer.IsSupported)
                ProgressBarRenderer.DrawHorizontalBar (offscreen, rect);
            rect.Inflate (new Size (- inset, - inset));
            rect.Width = (int) (rect.Width * ((double) this.Value / this.Maximum));
            if (rect.Width == 0)
                rect.Width = 1;
            LinearGradientBrush brush = new LinearGradientBrush (rect, this.BackColor, this.ForeColor, LinearGradientMode.Vertical);
            offscreen.FillRectangle (brush, inset, inset, rect.Width, rect.Height);
            e.Graphics.DrawImage (offscreenImage, 0, 0);
            offscreenImage.Dispose ();
        }}}


#====================
#gpt output=============

//Python
def OnPaint(self, e):
  inset = 2
  offscreenImage = Bitmap(self.Width, self.Height)
  offscreen = Graphics.FromImage(offscreenImage)
  rect = Rectangle(0, 0, self.Width, self.Height)
  if (ProgressBarRenderer.IsSupported):
    ProgressBarRenderer.DrawHorizontalBar(offscreen, rect)
  rect.Inflate(Size(- inset, - inset))
  rect.Width = round(rect.Width * (self.Value / self.Maximum))
  brush = LinearGradientBrush(rect, self.BackColor, self.ForeColor, LinearGradientMode.Vertical)
  offscreen.FillRectangle(brush, inset, inset, rect.Width, rect.Height)
  e.Graphics.DrawImage(offscreenImage, 0, 0)
  offscreenImage.Dispose()


//C
void OnPaint(PaintEventArgs e) {
  const int inset = 2;
  Image* offscreenImage = new Bitmap(this->Width, this->Height);
  Graphics* offscreen = Graphics::FromImage(offscreenImage);
  Rectangle rect = Rectangle(0, 0, this->Width, this->Height);
  if (ProgressBarRenderer->IsSupported){
    ProgressBarRenderer->DrawHorizontalBar(offscreen, rect);
  }
  rect.Inflate(Size(- inset, - inset));
  rect.Width = (int) (rect.Width * ((double) this->Value / this->Maximum));
  if (rect.Width == 0)
    rect.Width = 1;
  LinearGradientBrush* brush = new LinearGradientBrush(rect, this->BackColor, this->ForeColor, LinearGradientMode::Vertical);
  offscreen->FillRectangle(brush, inset, inset, rect.Width, rect.Height);
  e->Graphics->DrawImage(offscreenImage, 0, 0);
  offscreenImage->Dispose();
}


//Java
@Override
protected void OnPaint (PaintEventArgs e) {
  final int inset = 2;
  Image offscreenImage = new Bitmap (this.Width, this.Height);
  Graphics offscreen = Graphics.FromImage (offscreenImage);
  Rectangle rect = new Rectangle (0, 0, this.Width, this.Height);
  if (ProgressBarRenderer.IsSupported){
    ProgressBarRenderer.DrawHorizontalBar(offscreen, rect);
  }
  rect.Inflate (new Size(- inset, - inset));
  rect.Width = (int) (rect.Width * ((double) this.Value / this.Maximum));
  if (rect.Width == 0)
    rect.Width = 1;
  LinearGradientBrush brush = new LinearGradientBrush(rect, this.BackColor, this.ForeColor, LinearGradientMode.Vertical);
  offscreen.FillRectangle(brush, inset, inset, rect.Width, rect.Height);
  e.Graphics.DrawImage (offscreenImage, 0, 0);
  offscreenImage.Dispose ();
}

