#input 
public static string JoinAnd < T > (string separator, string sepLast, IEnumerable < T > values) {
    var sb = new StringBuilder ();
    var enumerator = values.GetEnumerator ();
    if (enumerator.MoveNext ()) {
        sb.Append (enumerator.Current);
    }
    object obj = null;
    if (enumerator.MoveNext ()) {
        obj = enumerator.Current;
    }
    while (enumerator.MoveNext ()) {
        sb.Append (separator);
        sb.Append (obj);
        obj = enumerator.Current;
    }
    if (obj != null) {
        sb.Append (sepLast);
        sb.Append (obj);
    }
    return sb.ToString ();
}


#====================
#gpt output=============

Python:
def join_and(separator, sep_last, values):
    sb = list()
    enumerator = iter(values)
    first_value = next(enumerator)
    if first_value is not None:
        sb.append(str(first_value))
    second_value = None
    try:
        second_value = next(enumerator)
    except StopIteration:
        pass
    for value in enumerator:
        sb.append(separator)
        sb.append(str(second_value))
        second_value = value
    if second_value is not None:
        sb.append(sep_last)
        sb.append(str(second_value))
    return ''.join(sb)

C:
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char * join_and(char * separator, char * sep_last, int * values, int count) {
    char * result = malloc((strlen(separator) + strlen(sep_last)) * count * 2);
    size_t result_len = 0;
    for(int i = 0;i < count;i++) {
        char numBuf[100];
        sprintf(numBuf,"%d",values[i]);
        if(i == 0) {
            // first item
            strcpy(result + result_len, numBuf);
            result_len += strlen(numBuf);
        } else {
            if(i == count - 1) {
                strcpy(result + result_len, sep_last);
            } else {
                strcpy(result + result_len, separator);
            }
            result_len += strlen(separator);
            strcpy(result + result_len, numBuf);
            result_len += strlen(numBuf);
        }
    }
    return result;
}

Java: 
public static String joinAnd(String separator, String sepLast, Collection<Integer> values) {
    if (values == null) {
        return "";
    }

    StringBuilder sb = new StringBuilder();
    Iterator<Integer> iter = values.iterator();
    Integer firstValue = iter.next();
    if ( firstValue != null ) {
        sb.append(firstValue);
    }
    Integer secondValue = null;
    while(iter.hasNext()) {
        secondValue = iter.next();
        if (secondValue != null ) {
            if ( iter.hasNext() ) {
                sb.append(separator).append(secondValue);
            } else {
                sb.append(sepLast).append(secondValue);
            }
        }
    }
    return sb.toString();
}

