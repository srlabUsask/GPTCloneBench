#input 
public void ShotHit (Point shot, bool sunk) {
    HitShots.AddLast (shot);
    MissCount = 0;
    EndPoints [1] = shot;
    if (EndPoints [0] == null)
        EndPoints [0] = shot;
    if (sunk)
        NullOutTarget ();
}


#====================
#gpt output=============


Python:
def ShotHit (shot, sunk):
    HitShots.append(shot)
    MissCount = 0
    EndPoints[1] = shot
    if EndPoints[0] is None:
        EndPoints[0] = shot
    if sunk:
        NullOutTarget()

C:
void ShotHit(Point shot, bool sunk){
    HitShots = add_last(HitShots, shot);
    MissCount = 0;
    EndPoints[1] = shot;
    if(EndPoints[0] == NULL)
        EndPoints[0] = shot;
    if(sunk)
        NullOutTarget();
}

Java:
public void ShotHit (Point shot, boolean sunk) {
    HitShots.addLast(shot);
    MissCount = 0;
    EndPoints[1] = shot;
    if (EndPoints[0] == null)
        EndPoints[0] = shot;
    if (sunk)
        nullOutTarget();
}

