#input 
static void Main (string [] args) {
    List < Discount > list = new List < Discount > ();
    list.Add (new Discount {Id = 1, Title = "Adam"});
    list.Add (new Discount {Id = 2, Title = "Ben"});
    list.Add (new Discount {Id = 3, Title = "Alex"});
    list.Add (new Discount {Id = 4, Title = "Daniel"});
    list.Add (new Discount {Id = 5, Title = "Ethan"});
    list.Add (new Discount {Id = 6, Title = "Howard"});
    list.Add (new Discount {Id = 7, Title = "Peter"});
    list.Add (new Discount {Id = 8, Title = "Tazz"});
    list.Add (new Discount {Id = 9, Title = "Steve"});
    list.Add (new Discount {Id = 10, Title = "Lyle"});
    Dictionary < string, List < Discount > > dic = new Dictionary < string, List < Discount > > ();
    foreach (Discount d in list) {
        string range = GetRange (d.Title);
        if (dic.ContainsKey (range))
            dic [range].Add (d);
        else
            dic.Add (range, new List < Discount > {d});
    }
}


#====================
#gpt output=============

Python: 
discount_list = [] 
discount_list.append({"Id": 1, "Title": "Adam"}) 
discount_list.append({"Id": 2, "Title": "Ben"}) 
discount_list.append({"Id": 3, "Title": "Alex"}) 
discount_list.append({"Id": 4, "Title": "Daniel"}) 
discount_list.append({"Id": 5, "Title": "Ethan"})
discount_list.append({"Id": 6, "Title": "Howard"}) 
discount_list.append({"Id": 7, "Title": "Peter"}) 
discount_list.append({"Id": 8, "Title": "Tazz"}) 
discount_list.append({"Id": 9, "Title": "Steve"}) 
discount_list.append({"Id": 10, "Title": "Lyle"}) 

dic = {} 
for discount in discount_list: 
    range_ = GetRange(discount["Title"])
    if range_ in dic:
        dic[range_].append(discount)
    else:
        dic[range_] = [discount]


C: 
Discount list[10] = {
  {1, "Adam"}, 
  {2, "Ben"}, 
  {3, "Alex"}, 
  {4, "Daniel"}, 
  {5, "Ethan"}, 
  {6, "Howard"}, 
  {7, "Peter"}, 
  {8, "Tazz"}, 
  {9, "Steve"},
  {10, "Lyle"}
};

Dictionary dic;

size_t i; 
for (i = 0; i < 10; i++) { 
  char *range = GetRange(list[i].title);
  if (dic.containsKey(range)) { 
    // add element to existing list
     dic[range].add(list[i]); 
  } else { 
    // create a new list and add element
    list[i] = { list[i] };
    dic.add(range, list[i]);
  }
}


Java: 
 List<Discount> list = new ArrayList<>(); 
 list.add(new Discount(1, "Adam")); 
 list.add(new Discount(2, "Ben")); 
 list.add(new Discount(3, "Alex")); 
 list.add(new Discount(4, "Daniel")); 
 list.add(new Discount(5, "Ethan")); 
 list.add(new Discount(6, "Howard"));
 list.add(new Discount(7, "Peter")); 
 list.add(new Discount(8, "Tazz")); 
 list.add(new Discount(9, "Steve")); 
 list.add(new Discount(10, "Lyle")); 

 Map<String, List<Discount>> dic = new HashMap<>(); 
 for (Discount d : list) { 
     String range = getRange(d.getTitle()); 
     if (dic.containsKey(range)) { 
         dic.get(range).add(d); 
     } else { 
         dic.put(range, new ArrayList<>(Arrays.asList(d))); 
     }
 }

