#input 
static int CharToValue (char c) {
    char cl = char.ToLower (c);
    if (cl == 'a')
        return 0;
    if (cl == 'b')
        return 1;
    if (cl == 'c')
        return 2;
    if (cl == 'd')
        return 3;
    if (cl == 'e')
        return 4;
    if (cl == 'f')
        return 5;
    if (cl == 'g')
        return 6;
    if (cl == 'h')
        return 7;
    if (cl == 'i')
        return 8;
    if (cl == 'j')
        return 9;
    if (cl == 'k')
        return 10;
    if (cl == 'l')
        return 11;
    if (cl == 'm')
        return 12;
    if (cl == 'n')
        return 13;
    if (cl == 'o')
        return 14;
    if (cl == 'p')
        return 15;
    if (cl == 'q')
        return 16;
    if (cl == 'r')
        return 17;
    if (cl == 's')
        return 18;
    if (cl == 't')
        return 19;
    if (cl == 'u')
        return 20;
    if (cl == 'v')
        return 21;
    if (cl == 'w')
        return 22;
    if (cl == 'x')
        return 23;
    if (cl == 'y')
        return 24;
    if (cl == 'z')
        return 25;
    if (cl == '2')
        return 26;
    if (cl == '3')
        return 27;
    if (cl == '4')
        return 28;
    if (cl == '5')
        return 29;
    if (cl == '6')
        return 30;
    if (cl == '7')
        return 31;
    throw new Exception ("Not a base32 string");
}


#====================
#gpt output=============

Python:
def CharToValue(c):
    cl = c.lower()
    if cl == 'a':
        return 0
    if cl == 'b':
        return 1
    if cl == 'c':
        return 2
    if cl == 'd':
        return 3
    if cl == 'e':
        return 4
    if cl == 'f':
        return 5
    if cl == 'g':
        return 6
    if cl == 'h':
        return 7
    if cl == 'i':
        return 8
    if cl == 'j':
        return 9
    if cl == 'k':
        return 10
    if cl == 'l':
        return 11
    if cl == 'm':
        return 12
    if cl == 'n':
        return 13
    if cl == 'o':
        return 14
    if cl == 'p':
        return 15
    if cl == 'q':
        return 16
    if cl == 'r':
        return 17
    if cl == 's':
        return 18
    if cl == 't':
        return 19
    if cl == 'u':
        return 20
    if cl == 'v':
        return 21
    if cl == 'w':
        return 22
    if cl == 'x':
        return 23
    if cl == 'y':
        return 24
    if cl == 'z':
        return 25
    if cl == '2':
        return 26
    if cl == '3':
        return 27
    if cl == '4':
        return 28
    if cl == '5':
        return 29
    if cl == '6':
        return 30
    if cl == '7':
        return 31
    raise Exception("Not a base32 string")

C: 
int CharToValue (char c) {
    char cl = tolower (c);
    switch (cl) {
        case 'a': return 0;
        case 'b': return 1;
        case 'c': return 2;
        case 'd': return 3;
        case 'e': return 4;
        case 'f': return 5;
        case 'g': return 6;
        case 'h': return 7;
        case 'i': return 8;
        case 'j': return 9;
        case 'k': return 10;
        case 'l': return 11;
        case 'm': return 12;
        case 'n': return 13;
        case 'o': return 14;
        case 'p': return 15;
        case 'q': return 16;
        case 'r': return 17;
        case 's': return 18;
        case 't': return 19;
        case 'u': return 20;
        case 'v': return 21;
        case 'w': return 22;
        case 'x': return 23;
        case 'y': return 24;
        case 'z': return 25;
        case '2': return 26;
        case '3': return 27;
        case '4': return 28;
        case '5': return 29;
        case '6': return 30;
        case '7': return 31; 
        default: 
            fprintf(stderr, "Not a base32 string\n"); 
            exit(EXIT_FAILURE); 
    }
    return 0;
}

Java:
static int CharToValue(char c) {
     char cl = Character.toLowerCase(c);
     switch (cl) {
         case 'a': return 0;
         case 'b': return 1;
         case 'c': return 2;
         case 'd': return 3;
         case 'e': return 4;
         case 'f': return 5;
         case 'g': return 6;
         case 'h': return 7;
         case 'i': return 8;
         case 'j': return 9;
         case 'k': return 10;
         case 'l': return 11;
         case 'm': return 12;
         case 'n': return 13;
         case 'o': return 14;
         case 'p': return 15;
         case 'q': return 16;
         case 'r': return 17;
         case 's': return 18;
         case 't': return 19;
         case 'u': return 20;
         case 'v': return 21;
         case 'w': return 22;
         case 'x': return 23;
         case 'y': return 24;
         case 'z': return 25;
         case '2': return 26;
         case '3': return 27;
         case '4': return 28;
         case '5': return 29;
         case '6': return 30;
         case '7': return 31;
         default: 
             throw new Exception("Not a base32 string");
     }
 }

