#input 
public override object ReadJson (JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer) {
    JToken token = JToken.Load (reader);
    if (token.Type == JTokenType.Float || token.Type == JTokenType.Integer) {
        return token.ToObject < decimal > ();
    }
    if (token.Type == JTokenType.String) {
        return Decimal.Parse (token.ToString (), System.Globalization.CultureInfo.GetCultureInfo ("es-ES"));
    }
    if (token.Type == JTokenType.Null && objectType == typeof (decimal ?)) {
        return null;
    }
    throw new JsonSerializationException ("Unexpected token type: " + token.Type.ToString ());
}


#====================
#gpt output=============

Python: 
def ReadJson(self, reader, objectType, existingValue, serializer):
    token = JToken.Load(reader)
    if token.Type == JTokenType.Float or token.Type == JTokenType.Integer:
        return token.ToObject <decimal>()
    elif token.Type == JTokenType.String:
        return Decimal.Parse(token.ToString(), System.Globalization.CultureInfo.GetCultureInfo("es-ES"))
    elif token.Type == JTokenType.Null and objectType == typeof (decimal?):
        return None
    else:
        raise JsonSerializationException("Unexpected token type: " + token.Type.ToString())


C:
object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer) {
    JToken token = JToken.Load(reader);
    if (token.Type == JTokenType.Float || token.Type == JTokenType.Integer) {
        return token.ToObject<decimal>();
    }
    else if (token.Type == JTokenType.String) {
        return Decimal.Parse(token.ToString(), System.Globalization.CultureInfo.GetCultureInfo("es-ES"));
    }
    else if (token.Type == JTokenType.Null && objectType == typeof(decimal?)) {
        return NULL;
    }
    else {
        throw new JsonSerializationException("Unexpected token type: " + token.Type.ToString());
    }
}



Java: 
@Override 
public Object ReadJson(JsonReader reader, Type objectType, Object existingValue, JsonSerializer serializer) {
    JToken token = JToken.Load(reader);
    if (token.Type == JTokenType.Float || token.Type == JTokenType.Integer) {
        return token.ToObject<Decimal>(Decimal.class);
    }
    if (token.Type == JTokenType.String) {
        return Decimal.Parse(token.ToString(), System.Globalization.CultureInfo.GetCultureInfo("es-ES"));
    }
    if (token.Type == JTokenType.Null && objectType == typeof (Decimal?)) {
        return null;
    }
    throw new JsonSerializationException("Unexpected token type: " + token.Type.ToString());
}

