#input 
private static int ParseNybble (char c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    if (c >= 'A' && c <= 'F') {
        return c - 'A' + 10;
    }
    if (c >= 'a' && c <= 'f') {
        return c - 'A' + 10;
    }
    throw new ArgumentOutOfRangeException ("Invalid hex digit: " + c);
}


#====================
#gpt output=============

Python
def ParseNybble(c): 
  if c >= '0' and c <= '9': 
    return int(c) - ord('0') 
  if c >= 'A' and c <= 'F': 
    return int(c) - ord('A') + 10
  if c >= 'a' and c <= 'f': 
    return int(c) - ord('a') + 10
  raise ArgumentOutOfRangeException("Invalid hex digit: " + c) 

C
int ParseNybble(char c){
    if( c >= '0' && c <= '9' )
        return c - '0';
    else if( c >= 'A' && c <= 'F' )
        return c - 'A' + 10;
    else if( c >= 'a' && c <= 'f' )
        return c - 'a' + 10;
    else 
        throw ArgumentOutOfRangeException("Invalid hex digit: " + c);
    }

Java
public static int ParseNybble(char c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    if (c >= 'A' && c <= 'F') {
        return c - 'A' + 10;
    }
    if (c >= 'a' && c <= 'f') {
        return c - 'a' + 10;
    }
    throw new ArgumentOutOfRangeException("Invalid hex digit: " + c);
}

