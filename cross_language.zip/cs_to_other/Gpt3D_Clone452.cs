#input 
public static void Main (string [] args) {
    var KP = Console.ReadKey ();
    if (KP.Key == ConsoleKey.F2) {
        return;
    }
    string UserName = KP.KeyChar + Console.ReadLine ();
    Console.WriteLine (UserName);
    Console.ReadLine ();
}


#====================
#gpt output=============



Python

def main(): 
    KP = input("")
    if KP == "F2":
        return
    UserName = KP + input("")
    print(UserName)
    input("")


C

int main(void) {
    char KP;
    scanf("%c", &KP);
    if (KP == 'F2') {
        return 0;
    }
    char username[50];
    scanf("%s", username);
    strcat(&username, KP);
    printf("%s\n", username);
    scanf("%c", &KP); 

Java

public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    char KP = keyboard.next().charAt(0);
    if (KP == 'F2') {
        return;
    }
    String username = KP + keyboard.nextLine();
    System.out.println(username);
    keyboard.nextLine();
}

