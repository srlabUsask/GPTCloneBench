#input 
private void CheckLog () {
    bool found = false;
    while (! found) {
        while ((s = sr.ReadLine ()) != null) {
            if (s.Contains ("test")) {
                _found = true;
                break;
            }
        }
        if (found) {
        } else {
        }
    }
}


#====================
#gpt output=============

PYTHON:

def check_log():
    found = False
    while not found:
        s = sr.readline()
        if s is None:
            break
        if "test" in s:
            found = True
            break
    if found:
        # Do something if found
        pass
    else:
        # Do something if not found
        pass

C:

void check_log() {
    int found = 0;
    while(found == 0) {
        char* s = sr.readLine();
        if(s == NULL) {
            break;
        }
        if(strstr(s, "test")) {
            found = 1;
            break;
        }
    }
    if(found) {
        // Do something if found
    } else {
        // Do something if not found
    }
}

JAVA:

private void checkLog() {
    boolean found = false;
    while (!found) {
        String s = sr.readLine();
        if (s == null) {
            break;
        }
        if (s.contains("test")) {
            found = true;
            break;
        }
    }
    if (found) {
        // Do something if found
    } else {
        // Do something if not found
    }
}

