#input 
private static IEnumerable < Enum > GetFlags (Enum value, Enum [] values) {
    ulong bits = Convert.ToUInt64 (value);
    List < Enum > results = new List < Enum > ();
    for (int i = values.Length - 1; i >= 0; i --) {
        ulong mask = Convert.ToUInt64 (values [i]);
        if (i == 0 && mask == 0L)
            break;
        if ((bits & mask) == mask) {
            results.Add (values [i]);
            bits -= mask;
        }
    }
    if (bits != 0L)
        return Enumerable.Empty < Enum > ();
    if (Convert.ToUInt64 (value) != 0L)
        return results.Reverse < Enum > ();
    if (bits == Convert.ToUInt64 (value) && values.Length > 0 && Convert.ToUInt64 (values [0]) == 0L)
        return values.Take (1);
    return Enumerable.Empty < Enum > ();
}


#====================
#gpt output=============

//Python Implementation
def getFlags (value, values):
    bits = value
    results = []
    for i in range (len (values) - 1, -1, -1): 
        mask = values[i]
        if (i == 0 and mask == 0) :   
            break 
        if ((bits & mask) == mask): 
            results.append (values[i])
            bits -= mask 
    if (bits != 0):
        return []
    if (value != 0):
        return reversed (results)
    if (bits == value and len(values) > 0 and values[0] == 0):
        return values[:1] 
    return []

//C Implementation
IEnumerable * GetFlags(Enum * value, Enum ** values, int length)
{
	long bits = (long) *value;
	IEnumerable * results = new IEnumerable[length];
	
	for (int i = length - 1; i >= 0; i--) 
	{
		long mask = (long) values[i];
		
		if (i == 0 && mask == 0L)
		{
			break;
		} 
		
		if ( (bits & mask) == mask ) 
		{
			results[i] = values[i];
			bits -= mask;
		}
	}
	
	if (bits != 0L)
	{
 		return NULL;
	}

	if ( (long) *value != 0L )
	{
		return ReverseArray(results);
	}

	// Check if the values array's first value is 0L
	if (bits == (long) *value && length > 0 && (long) values[0] == 0L) 
	{ 
		return ArrayTakeFirst(&results[0]);
	}

	return NULL; 
}

//Java Implementation 
public static Enum[] getFlags(Enum value, Enum[] values) { 
    long bits = (long) value; 
    List<Enum> results = new ArrayList<>(); 
    
    for(int i = values.length - 1; i >= 0; i--) {
       long mask = (long) values[i]; 
       
       if(i == 0 && mask == 0L) { 
           break; 
       }
       
       if((bits & mask) == mask) {
           results.add(values[i]); 
           bits -= mask; 
       }
    }
    
    if(bits != 0L) {
        return new ArrayList<Enum>().toArray(new Enum[0]); 
    }
    
    if((long) value != 0L) {
        Collections.reverse(results); 
        return results.toArray(new Enum[results.size()]);
    }
    
    if(bits == (long) value && values.length > 0 && (long)values[0] == 0L) {
        Enum[] arr = new Enum[1]; 
        arr[0] = values[0]; 
        return arr; 
    }
    
    return new ArrayList<Enum>().toArray(new Enum[0]); 
}

