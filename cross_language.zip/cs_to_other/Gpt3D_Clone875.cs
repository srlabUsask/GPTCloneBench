#input 
protected void Page_Load (object sender, EventArgs e) {
    string subject = Request.Params ["subject"];
    string message = Request.Params ["body-plain"];
    using (SqlConnection cn = new SqlConnection (ConfigurationManager.ConnectionStrings ["YOURCONNECTIONSTRING"].ConnectionString))
    {
        cn.Open ();
        using (SqlCommand cm = cn.CreateCommand ())
        {
            cm.CommandType = CommandType.Text;
            cm.CommandText = "INSERT INTO SMS (subject, message, DateTime) VALUES (@Subject, @Message, @Dateandtime);";
            cm.Parameters.Add ("@Subject", SqlDbType.NVarChar).Value = subject;
            cm.Parameters.Add ("@Message", SqlDbType.NVarChar).Value = message;
            cm.Parameters.Add ("@Dateandtime", SqlDbType.DateTime).Value = DateTime.Now.ToString ();
            SqlDataReader dr = cm.ExecuteReader ();
            dr.Dispose ();
            cm.Dispose ();
        }}}


#====================
#gpt output=============

Python: 
def page_load(sender,e): 
    subject = request.params['subject']
    message = request.params['body-plain']
    con = MYSQLdb.connect(ConfigurationManager.ConnectionStrings['YOURCONNECTIONSTRING'].connectionstring)
    cur = con.cursor()
    sql = 'INSERT INTO SMS (subject, message, DateTime) VALUES "%s", "%s", "%s"'
    args = (subject, message, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    cur.execute(sql % args) 
    con.commit()
    cur.close() 
    con.close() 

C: 
void page_load(object sender, EventArgs e) 
{ 
    char* subject = Request.Params["subject"]; 
    char* message = Request.Params["body-plain"]; 
    MYSQL * con; 
    MYSQL_RES * res; 
    con = mysql_init(NULL); 
    char* query = "INSERT INTO SMS (subject, message, DateTime) VALUES (%s, %s, %s)"
    char * cSubject = malloc(strlen(subject) + 1); 
    strcpy(cSubject, subject); 
    char * cMessage = malloc(strlen(message) + 1); 
    strcpy(cMessage, message); 
    time_t t = time(NULL); 
    struct tm * timeNow= localtime(&t); 
    char dateTime[30]; 
    strftime(dateTime, sizeof(dateTime), "%Y-%m-%d %H:%M:%S", timeNow); 
    
    char* args[] = {cSubject, cMessage, dateTime}; 
    res = mysql_query_params(con, query, 3, args); 
    
    free(cSubject); 
    free(cMessage); 
    mysql_free_result(res); 
    mysql_close(con); 
            
} 

Java: 
protected void Page_Load (Object sender, EventArgs e) {
    String subject = Request.Params["subject"];
    String message = Request.Params["body-plain"];
    try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://ConfigurationManager.ConnectionStrings["YOURCONNECTIONSTRING"].ConnectionString);
        PreparedStatement stmt = con.prepareStatement("INSERT INTO SMS (subject, message, DateTime) VALUES (?, ?, ?)");
        stmt.setString(1, subject);
        stmt.setString(2, message);
        stmt.setString(3, new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime()));
        stmt.executeUpdate();
    } catch (Exception ex) {
        System.out.println(ex);
    }
}

