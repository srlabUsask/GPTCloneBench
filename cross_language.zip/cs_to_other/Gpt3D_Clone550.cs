#input 
public static void Main (String [] args) {
    using (SqlConnection sqlConn = new SqlConnection ("some connection string"))
    {
        sqlConn.Open ();
        using (SqlCommand comm = new SqlCommand ("some query; some other query;", conn))
        using (var sqlReader = comm.ExecuteReader ())
        {
            while (sqlReader.Read ()) {
            }
            if (sqlReader.NextResult ()) {
                while (sqlReader.Read ()) {
                }
            }
        }}}


#====================
#gpt output=============

Python 
import sqlite3 
  
conn = sqlite3.connect (...some connection string...) 
  
cursor = conn.cursor () 
  
cursor.execute ("some query; some other query;") 
  
try:
    rows = cursor.fetchall () 
    for row in rows:
        pass
        
    if cursor.nextset ():
        rows = cursor.fetchall ()
        for row in rows:
            pass
  
except sqlite3.Error as e:
    print (e)

C
#include <stdio.h> 
#include <sqlite3.h> 
  
int main (int argc, char **argv) 
{ 
    sqlite3 *conn; 
    sqlite3_stmt    *res; 
    int rc = sqlite3_open ("...some connection string...", &conn); 
  
    rc = sqlite3_prepare_v2 (conn,"some query; some other query;", -1, &res, 0);
  
    while (sqlite3_step (res) == SQLITE_ROW) 
    { 
    }
    if (sqlite3_next_result (res) == SQLITE_OK) {
        while (sqlite3_step (res) == SQLITE_ROW)
        { 
        }
    } 
  
    sqlite3_finalize (res); 
    sqlite3_close (conn); 
    return 0; 
} 

Java 
import java.sql.*;

public class Main 
{
    public static void main( String[] args ) 
    {
        String connectionString = "...some connection string...";
        try (Connection conn = DriverManager.getConnection(connectionString))
        {
            String query = "some query; some other query;";
            try (PreparedStatement ps = conn.prepareStatement(query))
            {
                ResultSet rs = ps.executeQuery();
                while (rs.next()) 
                {
                }
                if (ps.getMoreResults()) {
                    rs = ps.getResultSet();
                    while (rs.next())
                    {
                    }                    
                }
            }
        }
        catch (SQLException e)
        {
            System.err.println("SQLException: " + e.getMessage());
            System.err.println("SQLState: " + e.getSQLState());
            System.err.println("VendorError: " + e.getErrorCode());
        }
    }
}

