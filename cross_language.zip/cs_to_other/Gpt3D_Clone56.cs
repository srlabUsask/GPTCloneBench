#input 
private void button1_Click (object sender, EventArgs e) {
    textBox2.Clear ();
    float result;
    if (float.TryParse (textBox1.Text, out result)) {
        textBox2.AppendText (Math.Sin (result).ToString ());
    } else {
        textBox2.Text = "Invalid Input";
    }
}


#====================
#gpt output=============

Python: 
def button1_Click(sender, e):
    textBox2.clear()
    result = float(textBox1.Text)
    try:
        textBox2.append(math.sin(result))
    except ValueError:
        textBox2.text = 'Invalid Input'


C: 
void button1_Click (Object sender, EventArgs e) {
    textBox2.clear ();
    float result;
    bool success = float.TryParse (textBox1.Text, result);
    if (success) {
        textBox2.appendText (sin (result));
    } else {
        textBox2.text = "Invalid Input";
    }
}


Java: 
private void button1_Click(Object sender, EventArgs e) {
    textBox2.clear();
    float result;
    try {
        result = Float.parseFloat(textBox1.getText());
        textBox2.appendText(Math.sin(result).toString());
    } catch(NumberFormatException exception) {
        textBox2.setText("Invalid Input");
    }
}

