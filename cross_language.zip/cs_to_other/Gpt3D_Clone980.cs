#input 
protected void Page_Load (object sender, EventArgs e) {
    var tblTextboxes = new Table ();
    for (int i = 0; i < 10; i ++) {
        var tr = new TableRow ();
        var tc = new TableCell ();
        var tb = new TextBox {ID = i.ToString ()};
        tc.Controls.Add (tb);
        tr.Cells.Add (tc);
        var tc1 = new TableCell ();
        var lnk = new LinkButton {ID = i + "lnk", Text = "Show"};
        lnk.Click += lnk_Click;
        tc1.Controls.Add (lnk);
        tr.Cells.Add (tc1);
        tblTextboxes.Rows.Add (tr);
    }
    placeTest.Controls.Add (tblTextboxes);
}


#====================
#gpt output=============

// Python
def Page_Load (self, args): 
    tblTextboxes = Table()
    for i in range(10): 
        tr = TableRow()
        tc = TableCell()
        tb = TextBox()
        tb.ID = str(i)
        tc.Controls.Add(tb)
        tr.Cells.Add(tc)
        tc1 = TableCell()
        lnk = LinkButton()
        lnk.ID = str(i) + "lnk"
        lnk.Text = "Show"
        lnk.Click += lnk_Click
        tc1.Controls.Add(lnk)
        tr.Cells.Add(tc1)
        tblTextboxes.Rows.Add(tr)
    placeTest.Controls.Add(tblTextboxes)

// C
protected void Page_Load(object sender, EventArgs e)
{
    var tblTextboxes = new Table();
    for (int i = 0; i < 10; i++)
    {
        var tr = new TableRow();
        var tc = new TableCell();
        var tb = new TextBox { ID = i.ToString() };
        tc.Controls.Add(tb);
        tr.Cells.Add(tc);
        var tc1 = new TableCell();
        var lnk = new LinkButton { ID = i + "lnk", Text = "Show" };
        lnk.Click += lnk_Click;
        tc1.Controls.Add(lnk);
        tr.Cells.Add(tc1);
        tblTextboxes.Rows.Add(tr);
    }
    placeTest.Controls.Add(tblTextboxes);
}

// Java 
protected void Page_Load(Object sender, EventArgs e){
    Table tblTextboxes = new Table();
    for (int i=0; i<10; i++){
        TableRow tr = new TableRow();
        TableCell tc = new TableCell();
        TextBox tb = new TextBox();
        tb.setID(String.valueOf(i));
        tc.getControls().add(tb);
        tr.getCells().add(tc);
        TableCell tc1 = new TableCell();
        LinkButton lnk = new LinkButton();
        lnk.setID(String.valueOf(i)+"lnk");
        lnk.setText("Show");
        lnk.addClickListener(new ActionListener(){public void actionPerformed(ActionEvent e){lnk_Click(e);}});
        tc1.getControls().add(lnk);
        tr.getCells().add(tc1);
        tblTextboxes.getRows().add(tr);
    }
    placeTest.getControls().add(tblTextboxes);
}

