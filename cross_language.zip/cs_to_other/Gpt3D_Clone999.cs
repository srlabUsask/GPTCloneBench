#input 
public static void Move < T > (this List < T > list, int oldIndex, int newIndex) {
    if ((oldIndex == newIndex) || (0 > oldIndex) || (oldIndex >= list.Count) || (0 > newIndex) || (newIndex >= list.Count))
        return;
    var i = 0;
    T tmp = list [oldIndex];
    if (oldIndex < newIndex) {
        for (i = oldIndex; i < newIndex; i ++) {
            list [i] = list [i + 1];
        }
    } else {
        for (i = oldIndex; i > newIndex; i --) {
            list [i] = list [i - 1];
        }
    }
    list [newIndex] = tmp;
}


#====================
#gpt output=============

Python:
def move(list, old_index, new_index):
    if (old_index == new_index) or (0 > old_index) or (old_index >= len(list)) or (0 > new_index) or (new_index >= len(list)):
        return
    tmp = list[old_index]
    if old_index < new_index:
        for i in range(old_index, new_index):
            list[i] = list[i+1]
    else: 
        for i in range (old_index, new_index, -1):
            list[i] = list[i-1]
    list[new_index] = tmp

C:
void move(int list[], int oldIndex, int newIndex, int size)
{
    if ((oldIndex == newIndex) || (0 > oldIndex) || (oldIndex >= size) || (0 > newIndex) || (newIndex >= size))
        return;

    int tmp = list[oldIndex];
    int i;
    if (oldIndex < newIndex)   
    {
        for (i = oldIndex; i < newIndex; i++) 
        {
            list[i] = list[i+1];
        }
    }
    else{
        for (i = oldIndex; i > newIndex; i--) 
        {
            list[i] = list[i-1];
        }
    }
    list[newIndex] = tmp;
}

Java:
public static<T> void move(List<T> list, int oldIndex, int newIndex) {
    if ((oldIndex == newIndex) || (0 > oldIndex) || (oldIndex >= list.size()) || (0 > newIndex) || (newIndex >= list.size()))
        return;
    T tmp = list.get(oldIndex);
    int i;
    if (oldIndex < newIndex) {
        for (i = oldIndex; i < newIndex; i++){
            list.set(i, list.get(i+1));
        }
    } else {
        for (i = oldIndex; i > newIndex; i--) {
            list.set(i, list.get(i-1));
        }
    }
    list.set(newIndex, tmp);
}

