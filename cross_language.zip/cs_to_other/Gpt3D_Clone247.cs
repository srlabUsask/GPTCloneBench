#input 
public override String ToString () {
    String output = "";
    String horzDiv = "   +----+----+----+----+----+----+----+----+----+----+\n";
    String disp;
    int x, y;
    output += "      A    B    C    D    E    F    G    H    I    J    \n" + horzDiv;
    for (y = 0; y < size.Height; ++ y) {
        output += String.Format ("{0} ", y + 1).PadLeft (3);
        for (x = 0; x < size.Width; ++ x) {
            switch (grid [x, y]) {
                case (int) Shot.None :
                    disp = "";
                    break;
                case (int) Shot.Hit :
                    disp = "#";
                    break;
                case (int) Shot.Miss :
                    disp = ".";
                    break;
                case (int) Shot.Unresolved :
                    disp = "?";
                    break;
                default :
                    disp = "!";
                    break;
            }
            output += String.Format ("| {0} ", disp.PadLeft (2));
        }
        output += "|\n" + horzDiv;
    }
    return output;
}


#====================
#gpt output=============

Python Implementation:
def ToString(self):
    output = ""
    horzDiv = "   +----+----+----+----+----+----+----+----+----+----+\n"
    disp = ""
    x, y = 0, 0
    output += "      A    B    C    D    E    F    G    H    I    J    \n" + horzDiv
    for y in range(self.size.height):
        output += "{0} ".format(y + 1).ljust(3)
        for x in range(self.size.width):
            if self.grid[x,y] == Shot.None:
                disp = ""
            elif self.grid[x,y] == Shot.Hit:
                disp = "#"
            elif self.grid[x,y] == Shot.Miss:
                disp = "."
            elif self.grid[x,y] == Shot.Unresolved:
                disp = "?"
            else:
                disp = "!"
            output += "| {0} ".format(disp.ljust(2))
        output += "|\n" + horzDiv
    return output


C Implementation:
char* ToString(struct Size size, LockedGrid* grid) {
	char* output = "";
	char* horzDiv = "   +----+----+----+----+----+----+----+----+----+----+\n";
	char* disp;
	int x, y;
	output = strcat(output, "      A    B    C    D    E    F    G    H    I    J    \n");
	output = strcat(output, horzDiv);
	for (y = 0; y < size.Height; ++y) {
		char buffer[3];
		sprintf(buffer, "%d", y + 1);
		output = strcat(output, "  ");
		output = strcat(output, buffer);
		for (x = 0; x < size.Width; ++x) {
			switch (grid[x][y]) {
				case Shot_None:
					disp = "";
					break;
				case Shot_Hit:
					disp = "#";
					break;
				case Shot_Miss:
					disp = ".";
					break;
				case Shot_Unresolved:
					disp = "?";
					break;
				default:
					disp = "!";
					break;
			}
			char buffer2[3];
			sprintf(buffer2, "%s", disp);
			output = strcat(output, "|  ");
			output = strcat(output, buffer2);
		}
		output = strcat(output, "|\n");
		output = strcat(output, horzDiv);
	}
	return output;
}


Java Implementation:
public String ToString(){
    String output = "";
    String horzDiv = "   +----+----+----+----+----+----+----+----+----+----+\n";
    String disp;
    int x, y;
    output += "      A    B    C    D    E    F    G    H    I    J    \n" + horzDiv;
    for(y = 0; y < size.getHeight(); y++){
        output += String.format("%3s", y + 1);
        for(x = 0; x < size.getWidth(); x++){
            switch(grid[x][y]){
                case Shot.None:
                    disp = "";
                    break;
                case Shot.Hit:
                    disp = "#";
                    break;
                case Shot.Miss:
                    disp = ".";
                    break;
                case Shot.Unresolved:
                    disp = "?";
                    break;
                default:
                    disp = "!";
                    break;
            }
            output += String.format(" | %2s", disp);
        }
        output += " |\n" + horzDiv;
    }
    return output;
}

