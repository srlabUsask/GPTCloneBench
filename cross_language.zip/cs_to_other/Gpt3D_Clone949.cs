#input 
[TestMethod] public void Should_Add_User () {
    var mockSet = new Mock < DbSet < User > > ();
    var mockContext = new Mock < DTContext > ();
    mockContext.Setup (m = > m.Users).Returns (mockSet.Object);
    var usrCRUD = new UserCRUD (mockContext.Object);
    var usr = new User ();
    usr.Login = "Login_Name";
    usr.Email = "loginName@test.com";
    usr.Password = "***";
    usr.InvalidLogins = 0;
    usr.RememberID = 0;
    usrCRUD.AddUser (usr);
    mockSet.Verify (m = > m.Add (It.Is < User > (arg = > arg.Login == "Login_Name")));
    mockContext.Verify (m = > m.SaveChanges (), Times.Once ());
}


#====================
#gpt output=============

Python: 

import unittest
from unittest.mock import Mock

class TestShouldAddUser(unittest.TestCase):
    def setUp(self):
        mock_set = Mock()
        mock_context = Mock()
        mock_context.setup_mock(m = mock_set.object)
        self.usr_crud = UserCRUD(mock_context.object)
    
    @unittest.mock.TestMethod
    def test_should_add_user(self):
        usr = User()
        usr.login = "Login_Name"
        usr.email = "loginName@test.com"
        usr.password = "***"
        usr.invalid_logins = 0
        usr.remember_id = 0
        self.usr_crud.add_user(usr)
        mock_set.verify(m=mock_set.add(It.Is(arg=arg.login == "Login_Name")))
        mock_context.verify(m=mock_context.save_changes(), Times.once())

C: 

#include <assert.h>
#include <mock.h>
#include <dtcontext.h>
#include <user.h>

void should_add_user() {
  // Create mocks
  mock_t mock_set;
  mock_t mock_context;

  // Setup mocks
  mock_context_setup(&mock_context);
  mock_context_setup_mock(&mock_context, M_USERS, “mock_set.object”);
  UserCRUD usrCRUD = userCRUD_new(&mock_context);

  // Create User
  User usr;
  user_init(&usr);
  usr.Login = “Login_Name”;
  usr.Email = “loginName@test.com”;
  usr.Password = “***”;
  usr.InvalidLogins = 0;
  usr.RememberID = 0;

  // Expectation
  usrCRUD_addUser(&usrCRUD, &usr);
  assert(mock_set_verify(&mock_set, M_ADD, It_Is(User *arg, arg->Login == “Login_Name”)));
  assert(mock_context_verify(&mock_context, M_SAVE_CHANGES, Times_Once());
}

Java: 

import org.junit.Test;
import org.mockito.Mockito;

public class ShouldAddUserTest {
  @Test
  public void shouldAddUserTest() {
    DbSet<User> mockSet = Mockito.mock(DbSet.class);
    DTContext mockContext = Mockito.mock(DTContext.class);
    Mockito.when(mockContext.getUsers()).thenReturn(mockSet);
    UserCRUD usrCRUD = new UserCRUD(mockContext);
    
    User usr = new User();
    usr.setLogin("Login_Name");
    usr.setEmail("loginName@test.com");
    usr.setPassword("***");
    usr.setInvalidLogins(0);
    usr.setRememberID(0);
    
    usrCRUD.addUser(usr);
    Mockito.verify(mockSet).add(Mockito.argThat(arg -> arg.getLogin() == "Login_Name"));
    Mockito.verify(mockContext).saveChanges();
  }
}

