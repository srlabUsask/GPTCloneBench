#input 
public override void WriteJson (JsonWriter writer, object value, JsonSerializer serializer) {
    var contextBase = value as ContextBase;
    var valueToken = JToken.FromObject (value, new ForcedObjectSerializer ());
    if (contextBase.Properties != null) {
        var propertiesToken = JToken.FromObject (contextBase.Properties);
        foreach (var property in propertiesToken.Children < JProperty > ()) {
            valueToken [property.Name] = property.Value;
        }
    }
    valueToken.WriteTo (writer);
}


#====================
#gpt output=============

//Python
def write_json(writer, value, serializer): 
  context_base = value as ContextBase
  value_token = json.dumps(value)
  if not context_base.properties is None: 
    properties_token = json.dumps(context_base.properties)
    for property in properties_token.children(): 
      value_token[property.name] = property.value 
  
  writer.write(value_token) 

//C 
void write_json(JsonWriter* writer, void* value, JsonSerializer* serializer) { 
  ContextBase* context_base = (ContextBase*) value; 
  JToken* value_token = json_from_object(value, &ForcedObjectSerializer); 
  if (context_base->Properties != NULL) { 
    JToken* properties_token = json_from_object(ContextBase->Properties); 
    for (JProperty* property = properties_token->children; *property; property++) { 
      json_token_set((void*) value_token, property->Name, property->Value); 
    }
  } 
  
  json_write_to(writer, value_token); 
} 

//Java
public void writeJson(JsonWriter writer, Object value, JsonSerializer serializer) { 
  ContextBase contextBase = (ContextBase) value; 
  ObjectMapper mapper = new ObjectMapper(); 
  JToken valueToken = mapper.valueToTree(value); 
  
  if (contextBase.getProperties() != null) { 
    JToken propertiesToken = mapper.valueToTree(contextBase.getProperties()); 
    for (Iterator<JProperty> propertyIter = propertiesToken.children().iterator(); propertyIter.hasNext();) { 
      JProperty property = propertyIter.next(); 
      valueToken.set(property.name(), property.value()); 
    } 
  } 
  
  valueToken.writeTo(writer); 
}

