#input 
public static IEnumerable < IEnumerable < T > > QuickPerm < T > (this IEnumerable < T > set) {
    int N = set.Count ();
    int [] a = new int [N];
    int [] p = new int [N];
    var yieldRet = new T [N];
    List < T > list = new List < T > (set);
    int i, j, tmp;
    for (i = 0; i < N; i ++) {
        a [i] = i + 1;
        p [i] = 0;
    }
    yield return list;
    i = 1;
    while (i < N) {
        if (p [i] < i) {
            j = i % 2 * p [i];
            tmp = a [j];
            a [j] = a [i];
            a [i] = tmp;
            for (int x = 0; x < N; x ++) {
                yieldRet [x] = list [a [x] - 1];
            }
            yield return yieldRet;
            p [i] ++;
            i = 1;
        } else {
            p [i] = 0;
            i ++;
        }
    }
}


#====================
#gpt output=============


// Python 
def QuickPerm(set):
    N = len(set)
    a = [0]*N
    p = [0]*N
    yield_ret = [0]*N
    list = list(set)
    i, j, tmp = 0, 0, 0
    for i in range(N):
        a[i] = i+1
        p[i] = 0
    yield list
    i = 1
    while(i<N):
        if(p[i]<i):
            j=i%2*p[i]
            tmp=a[j]
            a[j]=a[i]
            a[i]=tmp
            for x in range(N):
                yield_ret[x] = list[a[x]-1]
            yield yield_ret
            p[i]+= 1
            i = 1
        else:
            p[i]= 0
            i+= 1


// C
void QuickPerm(int* set, int size) {
	int N = size;
    int* a = (int*)malloc(sizeof(int)*N);
    int* p = (int*)malloc(sizeof(int)*N);
    int* yield_ret = (int*)malloc(sizeof(int)*N);
    int i, j, tmp;
    for (i = 0; i < N; i ++) {
        a[i] = i + 1;
        p[i] = 0;
    }
    printArray(set, size);
    i = 1;
    while (i < N) {
        if (p[i] < i) {
            j = i % 2 * p[i];
            tmp = a[j];
            a[j] = a[i];
            a[i] = tmp;
            for (int x = 0; x < N; x ++) {
                yield_ret[x] = set[a[x] - 1];
            }
            printArray(yield_ret, size);
            p[i] ++;
            i = 1;
        } else {
            p[i] = 0;
            i ++;
        }
    }
   free(a);
   free(p);
   free(yield_ret);
}


// Java
public static <T> List<List<T>> QuickPerm(List<T> set){
    int N = set.size();
    int[] a = new int[N];
    int[] p = new int[N];
    List<T> yieldRet = new ArrayList<T>();
    List<T> list = new ArrayList<T>(set);
    int i, j, tmp;
    for (i = 0; i < N; i ++) {
        a [i] = i + 1;
        p [i] = 0;
    }
    List<List<T>> permutations = new ArrayList<>();
    permutations.add(list);
    i = 1;
    while (i < N) {
        if (p [i] < i) {
            j = i % 2 * p [i];
            tmp = a [j];
            a [j] = a [i];
            a [i] = tmp;
            yieldRet.clear();
            for (int x = 0; x < N; x ++) {
                yieldRet.add(list.get(a[x] - 1));
            }
            permutations.add(new ArrayList<>(yieldRet));
            p [i] ++;
            i = 1;
        } else {
            p [i] = 0;
            i ++;
        }
    }
	return permutations;
}

