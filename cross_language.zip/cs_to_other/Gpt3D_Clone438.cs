#input 
public static void Rename (this FileSystemInfo item, string newName) {
    if (item == null) {
        throw new ArgumentNullException ("item");
    }
    FileInfo fileInfo = item as FileInfo;
    if (fileInfo != null) {
        fileInfo.Rename (newName);
        return;
    }
    DirectoryInfo directoryInfo = item as DirectoryInfo;
    if (directoryInfo != null) {
        directoryInfo.Rename (newName);
        return;
    }
    throw new ArgumentException ("Item", "Unexpected subclass of FileSystemInfo " + item.GetType ());
}


#====================
#gpt output=============

Python:
def rename(fs_info, new_name):
    if not fs_info:
        raise ArgumentNullException('item')
    if isinstance(fs_info, FileInfo):
        fs_info.rename(new_name)
    elif isinstance(fs_info, DirectoryInfo):
        fs_info.rename(new_name)
    else:
        raise ArgumentException('Unexpected subclass of FileSystemInfo ' + str(type(fs_info)))

C:
void rename(FileSystemInfo* item, const char *newName){
    if (!item){
         throw new ArgumentNullException("item");
     } 
    
    FileInfo* fileInfo =  CastToFileInfo(item); 
        if (fileInfo ){
            fileInfo->Rename(newName);
            return;
        } 
        DirectoryInfo* directoryInfo =  CastToDirectoryInfo(item);
        if (directoryInfo){
            directoryInfo->Rename(newName);
            return;
        }
 
     throw new ArgumentException("Item", "Unexpected subclass of FileSystemInfo " +item);

}

Java:
public static void rename(FileSystemInfo item, String newName) {
    if (item == null) {
        throw new IllegalArgumentException("item");
    }
    if (item instanceof FileInfo) {
        ((FileInfo) item).rename(newName);
        return;
    }
    if (item instanceof DirectoryInfo) {
        ((DirectoryInfo) item).rename(newName);
        return;
    }
    throw new IllegalArgumentException("Unexpected subclass of FileSystemInfo " + item.getClass());
}

