#input 
public static int Delta (int a, int b) {
    int delta = 0;
    if (a == b) {
        return 0;
    } else if (a < b) {
        while (a < b) {
            a ++;
            delta ++;
        }
        return delta;
    } else {
        while (b < a) {
            b ++;
            delta ++;
        }
        return delta;
    }
}


#====================
#gpt output=============

Python: 
def Delta(a, b):
  delta = 0
  if a == b:
    return 0
  elif a < b:
    while a < b:
      a += 1
      delta += 1
    return delta
  else:
    while b < a:
      b += 1
      delta += 1
    return delta
	

C: 
int Delta(int a, int b) {
  int delta = 0;
  if (a == b) {
    return 0;
  } 
  else if (a < b) {
    while (a < b) {
      a ++;
      delta ++;
    }
    return delta;
  } 
  else {
    while (b < a) {
      b ++;
      delta ++;
    }
    return delta;
  }
}

Java: 
public static int Delta (int a, int b) {
    int delta = 0;
    if (a == b) {
        return 0;
    } else if (a < b) {
        while (a < b) {
            a ++;
            delta ++;
        }
        return delta;
    } else {
        while (b < a) {
            b ++;
            delta ++;
        }
        return delta;
    }
}

