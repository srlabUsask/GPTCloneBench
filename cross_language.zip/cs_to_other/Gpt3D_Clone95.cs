#input 
public static bool Validate (string encodedResponse) {
    if (string.IsNullOrEmpty (encodedResponse))
        return false;
    var client = new System.Net.WebClient ();
    var secret = ConfigurationManager.AppSettings ["Google.ReCaptcha.Secret"];
    if (string.IsNullOrEmpty (secret))
        return false;
    var googleReply = client.DownloadString (string.Format ("https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}", secret, encodedResponse));
    var serializer = new System.Web.Script.Serialization.JavaScriptSerializer ();
    var reCaptcha = serializer.Deserialize < ReCaptcha > (googleReply);
    return reCaptcha.Success;
}


#====================
#gpt output=============

Python:
def Validate(encodedResponse):
    if encodedResponse is None or len(encodedResponse) == 0:
        return False
    secret = os.getenv('Google.ReCaptcha.Secret')
    if secret is None or len(secret) == 0: 
        return False
    client = requests.Session()
    googleReply = client.get('https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}'.format(secret, encodedResponse))
    reCaptcha = googleReply.json()
    return reCaptcha['success']

C:
bool Validate(char * encodedResponse) {
    if (strlen(encodedResponse) == 0) 
        return false;
    char secret[MAX_ENV_VALUE];
    if (getenv("Google.ReCaptcha.Secret") == 0)
        return false;
    CURL *client;
    client = curl_easy_init();
    if (client) {
        char url[150];
        sprintf(url, "https://www.google.com/recaptcha/api/siteverify?secret=%s&response=%s", secret, encodedResponse);
        curl_easy_setopt(client, CURLOPT_URL, url);
        struct curl_slist *headers = NULL;
        headers = curl_slist_append(headers, "Accept: application/json");
        headers = curl_slist_append(headers, "Content-Type: application/json");
        curl_easy_setopt(client, CURLOPT_HTTPHEADER, headers);
 
        CURLcode res = curl_easy_perform(client);
        if (res != CURLE_OK) {
            curl_easy_cleanup(client);
            curl_slist_free_all(headers);
            return false;
        }
 
        long status_code;
        curl_easy_getinfo(client, CURLINFO_RESPONSE_CODE, &status_code);
        if (status_code != 200) {
            curl_easy_cleanup(client);
            curl_slist_free_all(headers);
            return false;
        }
 
        char *googleReply;
        curl_easy_getinfo(client, CURLINFO_REPLY_DATA, &googleReply);
        struct ReCaptcha reCaptcha = parse_google_reply(googleReply);
        curl_easy_cleanup(client);
        curl_slist_free_all(headers);
        return reCaptcha.success;
    }
    else
        return false;
}

Java:
public static boolean validate(String encodedResponse){
    if(encodedResponse == null || encodedResponse.isEmpty()){
        return false;
    }
    String secret = System.getenv("Google.ReCaptcha.Secret");
    if(secret == null || secret.isEmpty()){
        return false;
    }
    String urlString = String.format("https://www.google.com/recaptcha/api/siteverify?secret=%s&response=%s",secret,encodedResponse);
    try{
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept","application/json");
        connection.setRequestProperty("Content-Type","application/json");
        connection.connect();
 
        int statusCode = connection.getResponseCode();
        if(statusCode != 200){
            return false;
        }
 
        InputStream inputStream = connection.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        Gson gson = new Gson();
        ReCaptcha reCaptcha = gson.fromJson(bufferedReader,ReCaptcha.class);
        bufferedReader.close();
        return reCaptcha.getSuccess();
 
    } catch(IOException e){
        e.printStackTrace();
        return false;
    }
 
}

