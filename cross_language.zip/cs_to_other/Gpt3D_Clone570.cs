#input 
public string Export () {
    StringBuilder sb = new StringBuilder ();
    foreach (string field in fields)
        sb.Append (field).Append (delim);
    sb.AppendLine ();
    foreach (Dictionary < string, object > row in rows) {
        foreach (string field in fields)
            sb.Append (MakeValueCsvFriendly (row [field])).Append (delim);
        sb.AppendLine ();
    }
    return sb.ToString ();
}


#====================
#gpt output=============

Python: 
def export():
    sb = []
    for field in fields:
        sb.append(field)
        sb.append(delim)
    sb.append('\n')
    for row in rows:
        for field in fields:
            sb.append(make_value_csv_friendly(row[field]))
            sb.append(delim)
        sb.append('\n')
    return ''.join(sb)

C: 
char* export() {
    char *sb;
    int i;
    sb = malloc(sizeof(char);
    
    for(i = 0; i < num_of_fields; i++){
        strcat(sb, fields[i]);
        strcat(sb, delim);
    }
    strcat(sb, "\n");
    
    for(i = 0; i < num_of_rows; i++){
        for(int j = 0; j < num_of_fields; j++){
            strcat(sb, make_value_csv_friendly(row[j]));
            strcat(sb, delim);
        }
        strcat(sb, "\n");
    }
    
 return sb;
}

Java: 
public String export() {
    StringBuilder sb = new StringBuilder();
    for(String field : fields) {
        sb.append(field).append(delim);
    }
    sb.append("\n");
    for(Map<String, Object> row : rows) {
        for(String field : fields) {
            sb.append(makeValueCsvFriendly(row.get(field))).append(delim);
        }
        sb.append("\n");
    }
    return sb.toString();
}

