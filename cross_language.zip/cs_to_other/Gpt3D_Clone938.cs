#input 
public int Compare (string s1, string s2) {
    if (IsNumeric (s1) && IsNumeric (s2)) {
        if (Convert.ToInt32 (s1) > Convert.ToInt32 (s2))
            return 1;
        if (Convert.ToInt32 (s1) < Convert.ToInt32 (s2))
            return - 1;
        if (Convert.ToInt32 (s1) == Convert.ToInt32 (s2))
            return 0;
    }
    if (IsNumeric (s1) && ! IsNumeric (s2))
        return 1;
    if (! IsNumeric (s1) && IsNumeric (s2))
        return - 1;
    return string.Compare (s1, s2, true);
}


#====================
#gpt output=============

Python:
def Compare(s1, s2):
  if (s1.isdigit() and s2.isdigit()):
    if int(s1) > int(s2):
      return 1
    elif int(s1) < int(s2):
      return -1
    elif int(s1) == int(s2):
      return 0
  if (s1.isdigit() and not s2.isdigit()):
    return 1
  if (not s1.isdigit() and s2.isdigit()):
    return -1
  return str.casefold(s1) < str.casefold(s2)


C:
int Compare(char* s1, char* s2) { 
  int num1, num2;  
  if(sscanf(s1, "%d", &num1) == 1 && sscanf(s2, "%d", &num2) == 1) {
    if (num1 > num2) 
      return 1;
    if (num1 < num2) 
      return -1;
    if (num1 == num2) 
      return 0;
  }
  if (strstr(s1, "0123456789") && !strstr(s2, "0123456789")) 
    return 1;
  if (!strstr(s1, "0123456789") && strstr(s2,"0123456789")) 
    return -1;
  return strcmp(s1, s2); 
} 


Java:
public int Compare(String s1, String s2) {
    if(isNumeric(s1) && isNumeric(s2)) {
        int num1 = Integer.parseInt(s1);
        int num2 = Integer.parseInt(s2);

        if(num1 > num2) return 1;
        if(num1 < num2) return -1;
        if(num1 == num2) return 0;
    }

    if(isNumeric(s1) && !isNumeric(s2)) return 1;
    if(!isNumeric(s1) && isNumeric(s2)) return -1;

    return s1.compareToIgnoreCase(s2);    
}

private boolean isNumeric(String s) {
    if(s == null || s.isEmpty()) {
        return false;
    }
    for(char c : s.toCharArray()) {
        if(!Character.isDigit(c)) return false;
    }
    return true;
}

