#input 
static int IndexOfLongestRun (string input) {
    int longestRunStart = - 1, longestRunLength = 0;
    for (int i = 0; i < input.Length;) {
        var runValue = input [i];
        int runStart = i;
        while (++ i < input.Length && input [i] == runValue) {
        }
        int runLength = i - runStart;
        if (longestRunLength < runLength) {
            longestRunStart = runStart;
            longestRunLength = runLength;
        }
    }
    return longestRunStart;
}


#====================
#gpt output=============

Python:

def IndexOfLongestRun(input): 
    longestRunStart = -1
    longestRunLength = 0
    i = 0
    while i < len(input): 
        runValue = input[i] 
        runStart = i 
        while i + 1 < len(input) and input[i + 1] == runValue: 
            i += 1
        runLength = i - runStart 
        if longestRunLength < runLength: 
            longestRunStart = runStart
            longestRunLength = runLength
        i += 1

    return longestRunStart

C:

int IndexOfLongestRun (string input) { 
    int longestRunStart = -1; 
    int longestRunLength = 0; 
    int i = 0; 
    while (i < strlen(input)) { 
        char runValue = input[i]; 
        int runStart = i; 
        while (i + 1 < strlen(input) && input[i + 1] == runValue) { 
            i++; 
        } 
        int runLength = i - runStart; 
        if (longestRunLength < runLength) { 
            longestRunStart = runStart; 
            longestRunLength = runLength; 
        } 
        i++; 
    } 
    return longestRunStart; 
} 

Java:

public static int IndexOfLongestRun(String input){
    int longestRunStart = -1;
    int longestRunLength = 0;
    int i = 0;
    while(i < input.length()){
        char runValue = input.charAt(i);
        int runStart = i;
        while(i + 1 < input.length() && input.charAt(i+1) == runValue){
            i++;
        }
        int runLength = i - runStart;
        if(longestRunLength < runLength){
            longestRunStart = runStart;
            longestRunLength = runLength;
        }
        i++;
    }
    return longestRunStart;
}

