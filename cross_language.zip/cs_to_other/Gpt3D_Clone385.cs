#input 
public static int [] RowSums (int [] [] arr2D) {
    int [] sums = new int [arr2D.GetLength (0)];
    int rowSums = 0;
    foreach (int [] arr in arr2D) {
        sums [rowSums] = ArraySum (arr);
        rowSums ++;
    }
    return sums;
}


#====================
#gpt output=============

// Python 
def RowSums (arr2D):
    sums = [0] * len(arr2D[0])
    rowSum = 0 
    for arr in arr2D:
        sums[rowSum] = sum(arr)
        rowSum += 1 
    return sums 

// C 
int * RowSums (int arr2D[][], int lenArr2D) {
    int *sums = (int*) malloc(sizeof(int)*lenArr2D);
    int rowSums = 0;
    for (int i=0; i<lenArr2D; i++) {
        int sumArr = 0;
        for (int j=0; j<sizeof(arr2D[0]); j++) {
            sumArr += arr2D[i][j];
        }
        sums[rowSums] = sumArr;
        rowSums++;
    }
    return sums;
}

// Java 
public static int [] RowSums (int [][] arr2D) {
    int [] sums = new int [arr2D.length];
    int rowSums = 0;
    for (int[] arr : arr2D) {
        int sumArr = 0;
        for (int i = 0; i < arr.length; i++) {
            sumArr += arr[i];
        }
        sums[rowSums] = sumArr;
        rowSums++;
    }
    return sums;
}

