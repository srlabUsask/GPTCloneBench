#input 
private void CalculateGridColWidthsRaport () {
    int diffWidth = 0;
    int colWidthsSum = 0;
    foreach (DataGridViewColumn col in this.dataGrid.Columns) {
        if (col.Visible) {
            colWidthsSum += col.Width;
            if (col.Resizable == DataGridViewTriState.False)
                diffWidth += col.Width;
        }
    }
    colWidthsSum += 24;
    int totalResizableWith = colWidthsSum - diffWidth;
    if (this.ParentForm.WindowState == FormWindowState.Maximized) {
        totalResizableWith = this.dataGrid.Width - diffWidth;
    }
    this.colWidthRaport = new List < decimal > ();
    foreach (DataGridViewColumn col in this.dataGrid.Columns) {
        this.colWidthRaport.Add ((decimal) totalResizableWith / (decimal) col.Width);
    }
}


#====================
#gpt output=============

Python:
def calculate_grid_col_widths_raport():
    diff_width = 0
    col_widths_sum = 0

    for col in data_grid.columns:
        if col.visible:
            col_widths_sum += col.width
            if col.resizable == DataGridViewTriState.False:
                diff_width += col.width
    
    col_widths_sum += 24
    resizable_width = col_widths_sum - diff_width

    if parent_form.window_state == FormWindowState.Maximized:
        resizable_width = data_grid.width - diff_width

    col_width_raport = []

    for col in data_grid.columns:
        col_width_raport.append((decimal) resizable_width/(decimal) col.width)

C:
void calculate_grid_col_widths_raport(){
    int diff_width = 0;
    int col_widths_sum = 0;
    
    for(DataGridViewColumn *col = data_grid.columns; *col != NULL; ++col) {
        if(col->visible){
            col_widths_sum += col->width;
            if(col->resizable == DataGridViewTriState.False)
                diff_width += col->width;
        }
    }

    col_widths_sum += 24;
    int total_resizable_width = col_widths_sum - diff_width;

    if(this->parent_form->window_state == FormWindowState.Maximized){
        total_resizable_width = this->data_grid->width - diff_width;
    }

    decimal** col_width_raport = malloc(sizeof(decimal*) * col_len);
    for(int i = 0; i < col_len; ++i){
        col_width_raport[i] = (decimal) total_resizable_width/(decimal) data_grid.columns[i].width;
    }
}

Java:
private void calculateGridColWidthsRaport() {
    int diffWidth = 0;
    int colWidthsSum = 0;

    for(DataGridViewColumn col : this.dataGrid.Columns) {
        if (col.Visible) {
            colWidthsSum += col.Width;
            if (col.Resizable == DataGridViewTriState.False)
                diffWidth += col.Width;
        }
    }

    colWidthsSum += 24;
    int totalResizableWidth = colWidthsSum - diffWidth;
    if (this.ParentForm.WindowState == FormWindowState.Maximized) {
        totalResizableWidth = this.dataGrid.Width - diffWidth;
    }

    this.colWidthRaport = new ArrayList<>();
    for (DataGridViewColumn col : this.dataGrid.Columns) {
        this.colWidthRaport.add( (decimal) totalResizableWidth / (decimal) col.Width);
    }
}

