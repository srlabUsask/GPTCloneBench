#input 
private void loadFromFile (String file) {
    foreach (String line in System.IO.File.ReadAllLines (file)) {
        if ((! String.IsNullOrEmpty (line)) && (! line.StartsWith (";")) && (! line.StartsWith ("#")) && (! line.StartsWith ("'")) && (line.Contains ('='))) {
            int index = line.IndexOf ('=');
            String key = line.Substring (0, index).Trim ();
            String value = line.Substring (index + 1).Trim ();
            if ((value.StartsWith ("\"") && value.EndsWith ("\"")) || (value.StartsWith ("'") && value.EndsWith ("'"))) {
                value = value.Substring (1, value.Length - 2);
            }
            try {
                list.Add (key, value);
            }
            catch {
            }
        }
    }
}


#====================
#gpt output=============

Python: 
def loadFromFile(file):
    for line in open(file, "r"):
        if not line or line.startswith(';') or line.startswith('#') or line.startswith ("'") or '=' not in line:
            continue
        index = line.index('=')
        key = line[:index].strip()
        value = line[index+1:].strip()
        if (value.startswith("\"") and value.endswith("\"") or (value.startswith("'") and value.endswith("'"))):
            value = value[1:-1]
        try:
            list.append((key, value))
        except:
            pass

C: 
void loadFromFile (char* file) {
    char line[256];
	FILE *f = fopen(file, "r");
    if (f == NULL) {
        fprintf(stderr, "Error opening file\n");
        return;
    }
    while (fgets(line, sizeof(line), f) != NULL) {
        int index = indexOf(line, '=');
        if (index == -1)
            continue;
        char* key = trim(substring(line, 0, index));
        char* value = trim(substring(line, index + 1, strlen(line) - (index + 1)));
        if (hasQuotes(value))
            value = substring(value, 1, strlen(value) - 2);
        addToList(list, key, value);
    }
    fclose(f);
}

Java: 
private void loadFromFile (String file) {
    List<String> lines = Files.readAllLines (Paths.get (file));
    for (String line: lines) {
        if (! line.isEmpty () && ! line.startsWith (";") && ! line.startsWith ("#") && ! line.startsWith ("'") && line.contains ("=")) {
            int index = line.indexOf ("=");
            String key = line.substring (0, index).trim ();
            String value = line.substring (index + 1).trim ();
            if ((value.startsWith ("\"") && value.endsWith ("\"")) || (value.startsWith ("'") && value.endsWith ("'"))) {
                value = value.substring (1, value.length () - 2);
            }
            try {
                list.add (key, value);
            } catch (Exception e) {
            }
        }
    } 
}

