#input 
private static string RemoveExcessPeriods (string text) {
    if (string.IsNullOrEmpty (text))
        return string.Empty;
    if (! text.Contains (".."))
        return text;
    string extension = Path.GetExtension (text);
    string fileName = Path.GetFileNameWithoutExtension (text);
    StringBuilder result = new StringBuilder (text.Length);
    bool lastCharacterWasPeriod = false;
    bool thisCharacterIsPeriod = fileName.Length > 0 && fileName [0] == '.';
    bool nextCharacterIsPeriod;
    for (int index = 0; index < fileName.Length; index ++) {
        nextCharacterIsPeriod = fileName.Length == index + 1 || fileName [index + 1] == '.';
        if (! thisCharacterIsPeriod)
            result.Append (fileName [index]);
        else if (thisCharacterIsPeriod && ! lastCharacterWasPeriod && ! nextCharacterIsPeriod)
            result.Append ('.');
        else if (thisCharacterIsPeriod && ! lastCharacterWasPeriod)
            result.Append (' ');
        lastCharacterWasPeriod = thisCharacterIsPeriod;
        thisCharacterIsPeriod = nextCharacterIsPeriod;
    }
    return result.ToString () + extension;
}


#====================
#gpt output=============

Python Implementation:
def remove_excess_periods(text):
    if not text or not text.contains(".."):
        return ""
    extension = os.path.splitext(text)[1]
    filename = os.path.splitext(text)[0]
    result = ''
    last_character_period = False
    this_character_period = len(filename) > 0 and filename[0] == '.'
    next_character_period = False
    for i in range(len(filename)):
        if i + 1 < len(filename):
            next_character_period = filename[i + 1] == '.'
        if not this_character_period:
            result += filename[i]
        elif this_character_period and not last_character_period and not next_character_period:
            result += '.'
        elif this_character_period and not last_character_period:
            result += ' '
            
        last_character_period = this_character_period
        this_character_period = next_character_period
    return result + extension
		

C Implementation:
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char* remove_excess_periods(char* text){
    char *extension;
    char *filename;
    
    if (text == NULL || strstr(text, "..") == NULL){
        return "";
    }
    extension = strrchr(text, '.');
    filename = strtok(text, ".");
    
    int last_character_period = 0;
    int this_character_period = 0;
    int next_character_period = 0;

    char* result = malloc(strlen(text));
    int pos = 0;

    if (filename[0] == '.')
        this_character_period = 1;

    for (int i = 0; i < strlen(filename); i++){
        if (i + 1 < strlen(filename))
            next_character_period = (filename[i + 1] == '.');
        if (!this_character_period){
            result[pos] = filename[i];
            pos++;
        }
        else if (this_character_period && !last_character_period && !next_character_period){
            result[pos] = '.';
            pos++;
        }
        else if (this_character_period && !last_character_period){
            result[pos] = ' ';
            pos++;
        }
        last_character_period = this_character_period;
        this_character_period = next_character_period;
    }
    strcat(result, extension);
    return result;
}

Java Implementation:
public class RemoveExcessPeriods {
    
    public static String removeExcessPeriods(String text) {
        if (text == null || text.isEmpty())
            return "";
        if (!text.contains(".."))
            return text;
        String extension = Path.getExtension(text);
        String filename = Path.getFilenameWithoutExtension(text);
        StringBuilder result = new StringBuilder(text.length());
        boolean lastCharacterWasPeriod = false;
        boolean thisCharacterIsPeriod = filename.length() > 0 && filename.charAt(0) == '.';
        boolean nextCharacterIsPeriod = false;
        for(int index = 0; index < filename.length(); index++) {
            if (index + 1 < filename.length())
                nextCharacterIsPeriod = filename.charAt(index + 1) == '.';
            if (!thisCharacterIsPeriod)
                result.append(filename.charAt(index));
            else if (thisCharacterIsPeriod && !lastCharacterWasPeriod && !nextCharacterIsPeriod)
                result.append('.');
            else if (thisCharacterIsPeriod && !lastCharacterWasPeriod)
                result.append(' ');
            lastCharacterWasPeriod = thisCharacterIsPeriod;
            thisCharacterIsPeriod = nextCharacterIsPeriod;
        }
        return result.toString() + extension;
    }
}

