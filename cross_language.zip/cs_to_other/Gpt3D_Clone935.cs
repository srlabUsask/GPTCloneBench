#input 
static void Main () {
    var dict = new Dictionary < string, int > ();
    dict.Add ("cat", 2);
    dict.Add ("dog", 3);
    dict.Add ("x", 4);
    var dict2 = new Dictionary < string, int > ();
    dict2.Add ("cat", 2);
    dict2.Add ("dog", 3);
    dict2.Add ("x", 4);
    bool equal = false;
    if (dict.Count == dict2.Count) {
        equal = true;
        foreach (var pair in dict) {
            int value;
            if (dict2.TryGetValue (pair.Key, out value)) {
                if (value != pair.Value) {
                    equal = false;
                    break;
                }
            } else {
                equal = false;
                break;
            }
        }
    }
    Console.WriteLine (equal);
}


#====================
#gpt output=============

Python Implementation: 
dict = {}
dict['cat'] = 2
dict['dog'] = 3
dict['x'] = 4
dict2 = {}
dict2['cat'] = 2
dict2['dog'] = 3
dict2['x'] = 4
equal = False
if len(dict) == len(dict2):
    equal = True
    for k,v in dict.items():
        value2 = dict2.get(k, None)
        if value2 != None:
            if value2 != v:
                equal = False
                break
        else:
            equal = False
            break
print(equal)


C Implementation: 
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int main(){
   //declare dictionaries
   int dict[20];     
   int dict2[20]; 

   //add data to dictionaries
   dict[0] = 2;
   dict[1] = 3;
   dict[2] = 4;
   dict2[0] = 2;
   dict2[1] = 3;
   dict2[2] = 4;

   bool equal = false;  //boolean comparison

   //if elements in the dictionaries are equal   
   if (dict[2] == dict2[2]){
        equal = true;
        for (int i=0; i<3; i++){  //for loop to compare values
            int value;
            if (dict2[i] != -1){
               if (dict2[i] == dict[i]){
                    equal = true;
               }
               else {
                    equal = false;
                    break;
               } 
            } 
            else {
               equal = false;
               break;
            }
        }
   } 
   //print result 
   printf("%d\n", equal); 
   return 0;
} 


Java Implementation: 
public static void main(String[] args) { 
  //Declare dictionaries
  Map<String, Integer> dict = new HashMap<String, Integer>();
  Map<String, Integer> dict2 = new HashMap<String, Integer>();
 
  //Add data to dictionaries
  dict.put("cat", 2);
  dict.put("dog", 3);
  dict.put("x", 4);
  dict2.put("cat", 2);
  dict2.put("dog", 3);
  dict2.put("x", 4);

  //Compare dictionaries
  boolean equal = false;
  if(dict.size() == dict2.size()) {
    equal = true;
    for(Map.Entry entry : dict.entrySet()) {
      int value = 0;
      if(dict2.containsKey(entry.getKey())) {
        if((int)dict2.get(entry.getKey()) != (int)entry.getValue()) {
          equal = false;
          break;
        }
      } else {
        equal = false;
        break;
      }
    }
  }

  //Print result
  System.out.println(equal);
}

