#input 
private void button1_Click (object sender, EventArgs e) {
    textBox2.Clear ();
    try {
        float v = float.Parse (textBox1.Text);
        textBox2.AppendText ((Math.Sin (v)).ToString ());
    }
    catch {
        textBox2.Clear ();
        textBox2.AppendText ("Invalid Input");
    }
}


#====================
#gpt output=============

Python:
def button1_click(sender, e): 
  try: 
    v = float(textBox1.text) 
    textBox2.appendText(str(math.sin(v))) 
  except: 
    textBox2.clear() 
    textBox2.appendText('Invalid Input') 

C: 
void button1_Click(object sender, EventArgs e) {
    textBox2.Clear(); 
    try { 
        float v = atof(textBox1.Text); 
        textBox2.AppendText(sprintf("%f", sin(v))); 
    } 
    catch {
        textBox2.Clear(); 
        textBox2.AppendText("Invalid Input"); 
    } 
}

Java:
private void button1_Click(Object sender, EventArgs e){
    textBox2.clear();
    try {
        float v = Float.parseFloat(textBox1.getText());
        textBox2.append(Math.sin(v) + "");
    } catch (Exception ex) {
        textBox2.clear();
        textBox2.appendText("Invalid Input");
    }
}

