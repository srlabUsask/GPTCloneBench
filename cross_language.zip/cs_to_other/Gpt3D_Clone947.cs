#input 
static void Main (string [] args) {
    var str = generateString ();
    var stopwatch = new Stopwatch ();
    var list1 = new List < int > (ElementCount);
    var list2 = new List < int > (ElementCount);
    var split = str.Split (';');
    stopwatch.Start ();
    list1.AddRange (split.Select (ToInt32OrNull).Where (i = > i != null).Cast < int > ());
    stopwatch.Stop ();
    TimeSpan nonParallel = stopwatch.Elapsed;
    stopwatch.Restart ();
    list2.AddRange (split.AsParallel ().Select (ToInt32OrNull).Where (i = > i != null).Cast < int > ());
    stopwatch.Stop ();
    TimeSpan parallel = stopwatch.Elapsed;
    Debug.WriteLine ("Non-parallel: {0}", nonParallel);
    Debug.WriteLine ("Parallel: {0}", parallel);
}


#====================
#gpt output=============

// Python
def Main(args):
    str = generateString()
    stopwatch = Stopwatch()
    list1 = []
    list2 = []
    split = str.split(';')
    stopwatch.start()
    for i in split:
        res = ToInt32OrNull(i) # returns None if not a valid int
        if res != None:
            list1.append(res)
    stopwatch.stop()
    nonParallel = stopwatch.elapsed
    
    stopwatch.reset()
    stopwatch.start()
    list2 = list(filter(lambda x: x != None, map(ToInt32OrNull, split)))
    stopwatch.stop()
    parallel = stopwatch.elapsed
    
    print('Non-parallel:', nonParallel)
    print('Parallel:', parallel)

// C
 void Main(char* args[]){
    char* str = generateString();
    Stopwatch stopwatch;
    int list1[ElementCount];
    int list2[ElementCount];
    char* split[ElementCount];
    char* p;
    int c = 0;
    p = strtok (str, ";");
    while (p != NULL){
        split[c++] = p;
        p = strtok (NULL, ";");
    }
    stopwatch.start();
    for (int i = 0; i < ElementCount; i++){
        list1[i] = ToInt32OrNull(split[i]);
        if (list1[i] == NULL){
            --i;
        }
    }
    stopwatch.stop();
    TimeSpan nonParallel = stopwatch.elapsed;
    stopwatch.reset();
    stopwatch.start();
    #pragma omp parallel 
    {
        #pragma omp for
        for (int i = 0; i < ElementCount; i++){
            list2[i] = ToInt32OrNull(split[i]);
            if (list2[i] == NULL){
                --i;
            }
        }
    }
    stopwatch.stop();
    TimeSpan parallel = stopwatch.elapsed;
    
    printf ("Non-parallel: %d\n", nonParallel);
    printf ("Parallel: %d\n", parallel);
}

// Java
public static void Main (String [] args) {
    String str = generateString ();
    Stopwatch stopwatch = new Stopwatch ();
    List<Integer> list1 = new ArrayList<Integer>(ElementCount);
    List<Integer> list2 = new ArrayList<Integer>(ElementCount);
    String[] split = str.split (";");
    stopwatch.start ();
    for (String s : split) {
        Integer res = ToInt32OrNull (s);
        if (res != null) {
            list1.add(res);
        }
    }
    stopwatch.stop ();
    TimeSpan nonParallel = stopwatch.elapsed;
    stopwatch.reset ();
    stopwatch.start ();
    parallelStream (split).forEach (s -> {
        Integer res = ToInt32OrNull (s);
        if (res != null)
            list2.add(res);
    });
    stopwatch.stop ();
    TimeSpan parallel = stopwatch.elapsed;
    System.out.println ("Non-parallel: " + nonParallel);
    System.out.println ("Parallel: " + parallel);
}

