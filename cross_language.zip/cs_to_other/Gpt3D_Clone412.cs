#input 
private static string ReplaceBBCode (string inStr) {
    StringBuilder outStr = new StringBuilder ();
    bool addBR = false;
    for (int i = 0; i < inStr.Length; i ++) {
        if (addBR) {
            outStr.Append ("<br />");
            addBR = false;
        }
        if (inStr [i] == '\r' || inStr [i] == '\n') {
            if (! addBR)
                addBR = true;
        } else {
            addBR = false;
            if (i + 2 < inStr.Length && inStr [i] == '[' && (inStr [i + 1] == 'b' || inStr [i + 1] == 'i' || inStr [i + 1] == 'u') && inStr [i + 2] == ']') {
                outStr.Append ("<").Append (inStr [i + 1]).Append ("><![CDATA[");
                i += 2;
            } else if (i + 3 < inStr.Length && inStr [i] == '[' && inStr [i + 1] == '/' && (inStr [i + 2] == 'b' || inStr [i + 2] == 'i' || inStr [i + 2] == 'u') && inStr [i + 3] == ']') {
                outStr.Append ("</").Append (inStr [i + 2]).Append ("><![CDATA[");
                i += 3;
            } else
                outStr.Append (inStr [i]);
        }
    }
    return outStr.ToString ();
}


#====================
#gpt output=============

Python: 
def replaceBBCode(inStr):
    outStr = ""
    addBR = False
    for i in range(len(inStr)):
        if addBR:
            outStr += "<br />"
            addBR = False
        if inStr[i] == '\r' or inStr[i] == '\n':
            if not addBR:
                addBR = True
        else:
            addBR = False
            if i + 2 < len(inStr) and inStr[i] == '[' and (inStr[i + 1] == 'b' or inStr[i + 1] == 'i' or inStr[i + 1] == 'u') and inStr[i + 2] == ']':
                outStr += "<" + inStr[i + 1] + "><![CDATA["
                i += 2
            elif i + 3 < len(inStr) and inStr[i] == '[' and inStr[i + 1] == '/' and (inStr[i + 2] == 'b' or inStr[i + 2] == 'i' or inStr[i + 2] == 'u') and inStr[i + 3] == ']':
                outStr += "</" + inStr[i + 2] + "><![CDATA["
                i += 3
            else:
                outStr += inStr[i]
    return outStr

C: 
char* replaceBBCode(char* inStr){
    char* outStr = malloc(strlen(inStr));
    int addBR = 0;
    for(int i=0; i<strlen(inStr); i++){
        if(addBR){
            strcat(outStr, "<br />");
            addBR = 0;
        }
        if(inStr[i] == '\r' || inStr[i] == '\n'){
            if(!addBR)
                addBR = 1;
        } else {
            addBR = 0;
            if(i+2 < strlen(inStr) && inStr[i] == '[' && (inStr[i+1] == 'b' || inStr[i+1] == 'i' || inStr[i+1] == 'u') && inStr[i+2] == ']'){
                char tag[3] = {inStr[i+1], '\0'}, toAdd[11];
                sprintf(toAdd, "<%s><![CDATA[", tag);
                strcat(outStr, toAdd);
                i += 2;
            } else if(i+3 < strlen(inStr) && inStr[i] == '[' && inStr[i+1] == '/' && (inStr[i+2] == 'b' || inStr[i+2] == 'i' || inStr[i+2] == 'u') && inStr[i+3] == ']'){
                char tag[3] = {inStr[i+2], '\0'}, toAdd[12];
                sprintf(toAdd, "</%s><![CDATA[", tag);
                strcat(outStr, toAdd);
                i += 3;
            } else {
                char toAdd[2] = {inStr[i], '\0'};
                strcat(outStr, toAdd);
            }
        }
    }
    return outStr;
}

Java: 
public static String replaceBBCode(String inStr) {
    StringBuilder outStr = new StringBuilder();
    boolean addBR = false;
    for (int i = 0; i < inStr.length(); i++) {
        if (addBR) {
            outStr.append("<br />");
            addBR = false;
        }
        if (inStr.charAt(i) == '\r' || inStr.charAt(i) == '\n') {
            if (! addBR)
                addBR = true;
        } else {
            addBR = false;
            if (i + 2 < inStr.length() && inStr.charAt(i) == '[' && (inStr.charAt(i + 1) == 'b' || inStr.charAt(i + 1) == 'i' || inStr.charAt(i + 1) == 'u') && inStr.charAt(i + 2) == ']') {
                outStr.append("<").append(inStr.charAt(i + 1)).append("><![CDATA[");
                i += 2;
            } else if (i + 3 < inStr.length() && inStr.charAt(i) == '[' && inStr.charAt(i + 1) == '/' && (inStr.charAt(i + 2) == 'b' || inStr.charAt(i + 2) == 'i' || inStr.charAt(i + 2) == 'u') && inStr.charAt(i + 3) == ']') {
                outStr.append("</").append(inStr.charAt(i + 2)).append("><![CDATA[");
                i += 3;
            } else
                outStr.append(inStr.charAt(i));
        }
    }
    return outStr.toString();
}

