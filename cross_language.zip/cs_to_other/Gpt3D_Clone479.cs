#input 
public static void ExportToCSV (DataTable contentToexport) {
    StringBuilder csvData = new StringBuilder ();
    StringBuilder headers = new StringBuilder ();
    foreach (DataRow row in contentToexport.Rows) {
        headers = string.Empty;
        foreach (DataColumn column in contentToexport.Columns) {
            csvData.Append (row [column].ToString () + ",");
            headers.Append (column.ColumnName + ",");
        }
        csvData.Append ("\r\n");
        headers.Append ("\r\n");
    }
    string contentToExport = headers.Append (csvData.ToString ()).ToString ();
    string attachment = "attachment; filename=export.csv";
    HttpContext.Current.Response.Clear ();
    HttpContext.Current.Response.ClearHeaders ();
    HttpContext.Current.Response.ClearContent ();
    HttpContext.Current.Response.AddHeader ("content-disposition", attachment);
    HttpContext.Current.Response.ContentType = "application/csv";


    HttpContext.Current.Response.AddHeader ("Pragma", "public");
    HttpContext.Current.Response.Write (contentToExport);
    HttpContext.Current.Response.Flush ();
    HttpContext.Current.Response.End ();
}

#====================
#gpt output=============

Python Implementation: 

def export_to_csv(content_to_export):
    csv_data = []
    headers = []

    for row in content_to_export.rows:
        row_data = []
        headers = []
        for column in content_to_export.columns:
            row_data.append(row[column])
            headers.append(column.column_name)
        csv_data.append(",".join(row_data))

    headers.append("\r\n")
    content_to_export = ",".join(headers) + "\r\n" + "\r\n".join(csv_data)

    attachment = "attachment; filename=export.csv"
    response = HttpResponse(content=content_to_export, content_type='application/csv')
    response['Content-Disposition'] = attachment
    response['Pragma'] = 'public'

    return response

C Implementation:

void exportToCSV(struct DataTable *contentToexport) { 
    char csvData[100]; 
	char headers[100];
	int row, column;
    for ( row= 0; row < contentToexport->rows; row++) { 
        strcpy(headers, "");    
        for ( column = 0; column < contentToexport->columns; column++) { 
			strcat(csvData, DataTableGet(contentToexport, row, column));
            strcat(csvData, ","); 
			strcat(headers, DataTableGetColumnName(contentToExport, col));
            strcat(headers, ","); 
        } 
        strcat(csvData, "\r\n");
		strcat(headers, "\r\n");
    } 

	char contentToExport[120];
	strcpy(contentToExport, headers);
	strcat(contentToExport, "");
	strcat(contentToExport, csvData);

    char attachment[30] = "attachment; filename=export.csv";
	
	responseClear();
	responseClearHeaders();
	responseClearContent();

	responseAddHeader("content-disposition", attachment);
	responseContentType("application/csv");
	responseAddHeader("Pragma", "public");
	responseWrite(contentToExport);
	responseFlush();
	responseEnd();
}

Java Implementation:

public static void exportToCSV(DataTable contentToexport){
    StringBuilder csvData = new StringBuilder();
    StringBuilder headers = new StringBuilder();
 
    //loop through the DataTable
    for(DataRow row : contentToexport.getRows()){
        headers = new StringBuilder();
        for(DataColumn column : contentToexport.getColumns()){
            csvData.append(row.get(column) + ",");
            headers.append(column.getName() + ",");
        }
        csvData.append("\r\n");
        headers.append("\r\n");
    }
    
    String contentToExport = headers.append(csvData.toString()).toString();
    String attachment = "attachment; filename=export.csv";

    HttpContext.current().response().clear();
    HttpContext.current().response().clearHeaders();
    HttpContext.current().response().clearContent();
    HttpContext.current().response().addHeader("content-disposition", attachment);
    HttpContext.current().response().setContentType("application/csv");
    HttpContext.current().response().addHeader("Pragma","public");
    HttpContext.current().response().write(contentToExport);
    HttpContext.current().response().flush();
    HttpContext.current().response().end();
}

