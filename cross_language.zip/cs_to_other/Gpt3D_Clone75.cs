#input 
public static string ReplaceHashtagsWithInt (string input, int integer) {
    Regex regex = new Regex ("#+");
    StringBuilder output = new StringBuilder (input);
    int allig = 0;
    for (Match match = regex.Match (input); match.Success; match = match.NextMatch ()) {
        string num = integer.ToString ();
        if (num.Length <= match.Length)
            for (int i = 0; i < match.Length; i ++) {
                if (i < match.Length - num.Length)
                    output [match.Index + i + allig] = '0';
                else
                    output [match.Index + i + allig] = num [i - match.Length + num.Length];
            }
        else {
            output.Remove (match.Index + allig, match.Length);
            output.Insert (match.Index + allig, num);
            allig += num.Length - match.Length;
        }
    }
    return output.ToString ();
}


#====================
#gpt output=============

Python:

def replace_hashtags_with_int(input_string, value):
    import re
    output = ""
    count = 0
    for match in re.finditer("#+",input_string):
        val = str(value)
        if len(val) <= match.end()-match.start():
            for i in range(match.start()+count,match.end()+count):
                if i < match.end()+count-len(val):
                    output += '0'
                else:
                    output +=val[i-match.end()-count+len(val)]
        else:
            output +=input_string[:match.start()+count] + val +input_string[match.end()+count:]
            count +=len(val)-(match.end() + count - match.start())
    return output


C:

char *ReplaceHashtagsWithInt(char *input, int value){
	char *output, *str = (char *)malloc(sizeof(char)*strlen(input)+1);
	strcpy(str,input);
	int allig=0,str32=0;
	char num[32];
	output = (char *)malloc(sizeof(char)*strlen(input)+1);
	memset(num,0,32);
	sprintf(num,"%d",value);
	for(char *match=str; *match; ){
		if(strlen(num) <= strlen(match)){
			for(int i=0;i<strlen(match);i++){
				if(i < strlen(match)-strlen(num))
					output[str32++] = '0';
				else
					output[str32++] = num[i-strlen(match)+strlen(num)];
			}
			match += strlen(match);
		}else{
			for(int i=0;i<strlen(match);i++)
				output[str32++] = *(match++);
			match += strlen(match);
			allig += strlen(num)-strlen(match)+1;
			output[str32++] = *num;
			num++;
		}
	}
	output[str32] = '\0';
	free(str);
	return output;
}


Java: 

public static String ReplaceHashtagsWithInt(String input, int integer) {
	StringBuilder output = new StringBuilder(input);
	int allig = 0;
	Pattern pattern = Pattern.compile("#+");
	Matcher matcher = pattern.matcher(input);
	while (matcher.find()) {
		String num = Integer.toString(integer);
		if (num.length() <= matcher.end() - matcher.start()) {
			for (int i = 0; i < matcher.end() - matcher.start(); i++) {
				if (i < (matcher.end() - matcher.start()) - num.length()) {
					output.setCharAt(matcher.start() + i + allig, '0');
				} else {
					output.setCharAt(matcher.start() + i + allig, num.charAt(i - (matcher.end() - matcher.start()) + num.length()));
				}
			}
		} else {
			output.delete(matcher.start() + allig, matcher.end() + allig);
			output.insert(matcher.start() + allig, num);
			allig += num.length() - (matcher.end() - matcher.start());
		}
	}
	return output.toString();
}

