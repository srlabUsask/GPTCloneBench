#input 
public override void WellKnownBinary (Stream sout) {
    byte order = BitConverter.IsLittleEndian ? (byte) 1 : (byte) 0;
    sout.WriteByte (order);
    sout.Write (GeoBase.MultiLineStringWkbs, 0, 4);
    sout.Write (BitConverter.GetBytes (this.LineStrings.Count), 0, 4);
    foreach (var lineString in this.LineStrings) {
        sout.WriteByte (order);
        sout.Write (GeoBase.LineStringWkbs, 0, 4);
        sout.Write (BitConverter.GetBytes (lineString.Count), 0, 4);
        foreach (var position in lineString) {
            position.WellKnownBinary (sout);
        }
    }
}


#====================
#gpt output=============

Python:
def WellKnownBinary(sout):
    order = 1 if BitConverter.IsLittleEndian else 0
    sout.write(bytes([order]))
    sout.write(GeoBase.MultiLineStringWkbs[:4])
    sout.write(BitConverter.GetBytes(len(self.LineStrings)))
    for lineString in self.LineStrings:
        sout.write(bytes([order]))
        sout.write(GeoBase.LineStringWkbs[:4])
        sout.write(BitConverter.GetBytes(len(lineString)))
        for position in lineString:
            position.WellKnownBinary(sout)
            

C: 
void WellKnownBinary (Stream *sout) {
    byte order = BitConverter.IsLittleEndian? (byte) 1 : (byte) 0;
    sout->WriteByte(order);
    sout->Write(GeoBase.MultiLineStringWkbs, 0, 4);
    sout->Write(BitConverter.GetBytes(this->LineStrings->Count), 0, 4);
    for(int i=0; i<this->LineStrings->Count; i++) {
        sout->WriteByte(order);
        sout->Write(GeoBase.LineStringWkbs, 0, 4);
        sout->Write(BitConverter.GetBytes(this->LineStrings->at(i)->Count), 0, 4);
        for(int j=0; j<this->LineStrings->at(i)->Count; j++) {
            this->LineStrings->at(i)->at(j)->WellKnownBinary(sout);
        }
    }
}

Java: 
public void wellKnownBinary (OutputStream sout) {
    byte order = BitConverter.IsLittleEndian ? (byte) 1 : (byte) 0;
    sout.write (order);
    sout.write (GeoBase.MultiLineStringWkbs, 0, 4);
    sout.write (BitConverter.GetBytes (this.lineStrings.length), 0, 4);
    for (LineString lineString : this.lineStrings) {
        sout.write (order);
        sout.write (GeoBase.LineStringWkbs, 0, 4);
        sout.write (BitConverter.GetBytes (lineString.getPositions().length), 0, 4);
        for (Position position : lineString.getPositions()) {
            position.wellKnownBinary (sout);
        }
    }
}

