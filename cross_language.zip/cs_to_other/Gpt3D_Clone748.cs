#input 
static List < string > Perm (string input, int M) {
    var chars = input.ToCharArray ();
    int N = chars.Length;
    List < List < char > > result = new List < List < char > > ();
    for (int i = 0; i < Math.Pow (2, N); i ++) {
        if (BitCount (i) == M) {
            List < char > line = new List < char > ();
            for (int j = 0; j < N; j ++) {
                if (((i > > j) & 1) == 1) {
                    line.Add (chars [j]);
                }
            }
            result.Add (line);
        }
    }
    return result.Select (l = > String.Join ("", l)).OrderBy (s = > s).ToList ();
}


#====================
#gpt output=============

//Python Implementation
def perm(input_string, M): 
    chars = list(input_string) 
    N = len(chars) 
    result = [] 
    for i in range(1 << N): 
        if bin(i).count('1') == M: 
            line = [] 
            for j in range(N):
        if i & (1 << j): 
            line.append(chars[j]) 
        result.append(line) 
    return sorted([ ''.join(sub) for sub in result ]) 
  
//Java Implementation
public static List < String > Perm (String input, int M) {
    char [] chars = input.toCharArray ();
    int N = chars.length;
    List < List < Character > > result = new ArrayList < > ();
    for (int i = 0 ; i < (1 << N); i++) {
        if (Integer.bitCount(i) == M) {
            List < Character > line = new ArrayList < > ();
            for (int j = 0; j < N; j++) {
                if (((i >> j) & 1) == 1) {
                    line.add(chars[j]);
                }
            }
            result.add(line);
        }
    }
    return result.stream().map(l -> String.join("", l)).sorted().collect(Collectors.toList());
}


//C Implementation
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct List{
    char *data;
    struct List *next;
    struct List *head;
} List;

int BitCount(int n)
{
    int count = 0;
    while (n)
    {
        count += n & 1;
        n >>= 1;
    }
    return count;
}

List *Perm(char *input, int M) 
{
    int N = strlen(input);
    List *result = NULL;
    for (int i = 0; i < (1 << N); i++)
    {
        if (BitCount(i) == M)
        {
            List *node = (List*)malloc(sizeof(List));
            char *line = (char*)malloc(M + 1);
            for (int j = 0; j < N; j++)
            {
                if (((i >> j) & 1) == 1)
                {
                    *(line + j) = *(input + j);
                }
            }
            // Sort the line before adding it to the result
            // <add your code here>
            *(line + M) = '\0';
            node->data = line;
            node->next = result;
            node->head = result? result->head : node;
            result = node;
        }
    }
    return result->head;
}

int main(int argc, char const *argv[])
{
    char input[] = "ABCDE";
    List *result = Perm(input, 2);
    while (result)
    {
        printf("%s\n", result->data);
        result = result->next;
    }
    return 0;
}

