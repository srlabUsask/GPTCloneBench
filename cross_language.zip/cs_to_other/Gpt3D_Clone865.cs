#input 
static void Main (string [] args) {
    memberLocation student, teacher, manager;
    student = new memberLocation ();
    teacher = new memberLocation ();
    manager = new memberLocation ();
    String filePath = "data.txt";
    StreamReader sr = new StreamReader (filePath);
    String fileData = sr.ReadToEnd ();
    student.start = fileData.IndexOf ("[Student]");
    teacher.start = fileData.IndexOf ("[Teacher]");
    manager.start = fileData.IndexOf ("[Manager]");
    student.end = fileData.IndexOf (']', student.start + 9) - 9;
    teacher.end = fileData.IndexOf (']', teacher.start + 9) - 9;
    manager.end = fileData.IndexOf (']', manager.start + 9) - 9;
    String studentStr, teacherStr, managerStr;
    if (student.end > 0)
        studentStr = fileData.Substring (student.start, student.end - student.start);
    else
        studentStr = fileData.Substring (student.start);
    if (teacher.end > 0)
        teacherStr = fileData.Substring (teacher.start, teacher.end - teacher.start);
    else
        teacherStr = fileData.Substring (teacher.start);
    if (manager.end > 0)
        managerStr = fileData.Substring (manager.start, manager.end - manager.start);
    else
        managerStr = fileData.Substring (manager.start);
}


#====================
#gpt output=============
Python:

def main(args):
    student = memberLocation()
    teacher = memberLocation()
    manager = memberLocation()
    file_path = 'data.txt'
    file_data = open(file_path).read()
    student.start = file_data.index('[Student]')
    teacher.start = file_data.index('[Teacher]')
    manager.start = file_data.index('[Manager]')
    student.end = file_data.index(']', student.start + 9) - 9
    teacher.end = file_data.index(']', teacher.start + 9) - 9
    manager.end = file_data.index(']', manager.start + 9) - 9
    student_str = file_data[student.start : (student.end if student.end > 0 else None)]
    teacher_str = file_data[teacher.start : (teacher.end if teacher.end > 0 else None)]
    manager_str = file_data[manager.start : (manager.end if manager.end > 0 else None)]

C:

void main(int args, char *argv[]) {
    struct memberLocation student, teacher, manager;
    student = newMemberLocation();
    teacher = newMemberLocation();
    manager = newMemberLocation();
    char *filePath = "data.txt";
    FILE *sr = fopen(filePath, "r");
    char *fileData;
    fseek(sr, 0L, SEEK_END);
    long size = ftell(sr);
    rewind(sr);
    fileData = calloc(1, size + 1);
    fread(fileData, size, 1, sr);
    student.start = findIndex('[Student]', fileData, 0);
    teacher.start = findIndex('[Teacher]', fileData, 0);
    manager.start = findIndex('[Manager]', fileData, 0);
    student.end = findIndex(']', fileData, student.start + 9) - 9;
    teacher.end = findIndex(']', fileData, teacher.start + 9) - 9;
    manager.end = findIndex(']', fileData, manager.start + 9) - 9;
    char *studentStr, *teacherStr, *managerStr;
    if (student.end > 0)
        studentStr = calloc(1, student.end - student.start + 1);
    else
        studentStr = calloc(1, strlen(fileData) * sizeof(char));
    if (teacher.end > 0)
        teacherStr = calloc(1, teacher.end - teacher.start + 1);
    else
        teacherStr = calloc(1, strlen(fileData) * sizeof(char));
    if (manager.end > 0)
        managerStr = calloc(1, manager.end - manager.start + 1);
    else
        managerStr = calloc(1, strlen(fileData) * sizeof(char));
    if (student.end > 0)
        strncpy(studentStr, &fileData[student.start], student.end - student.start);
    else
        strcpy(studentStr, &fileData[student.start]);
    if (teacher.end > 0)
        strncpy(teacherStr, &fileData[teacher.start], teacher.end - teacher.start);
    else
        strcpy(teacherStr, &fileData[teacher.start]);
    if (manager.end > 0)
        strncpy(managerStr, &fileData[manager.start], manager.end - manager.start);
    else
        strcpy(managerStr, &fileData[manager.start]);
    free(fileData);
    fclose(sr);
}

Java: 

public static void main(String[] args){
    MemberLocation student, teacher, manager;
    student = new MemberLocation();
    teacher = new MemberLocation();
    manager = new MemberLocation();
    String filePath = "data.txt";
    BufferedReader br = new BufferedReader(new FileReader(filePath));
    StringBuilder sb = new StringBuilder();
    String line = br.readLine();
    while (line != null){
        sb.append(line);
        sb.append(System.lineSeparator());
        line = br.readLine();
    }
    student.start = sb.indexOf("[Student]");
    teacher.start = sb.indexOf("[Teacher]");
    manager.start = sb.indexOf("[Manager]");
    student.end = sb.indexOf(']', student.start + 9) - 9;
    teacher.end = sb.indexOf(']', teacher.start + 9) - 9;
    manager.end = sb.indexOf(']', manager.start + 9) - 9;
    String studentStr, teacherStr, managerStr;
    if (student.end > 0)
        studentStr = sb.substring(student.start, student.end);
    else
        studentStr = sb.substring(student.start);
    if (teacher.end > 0)
        teacherStr = sb.substring(teacher.start, teacher.end);
    else
        teacherStr = sb.substring(teacher.start);
    if (manager.end > 0)
        managerStr = sb.substring(manager.start, manager.end);
    else
        managerStr = sb.substring(manager.start);
    br.close();
}

