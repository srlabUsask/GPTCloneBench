#input 
static void Main (string [] args) {
    List < Phone > phones = new List < Phone > ();
    bool shouldContinue = true;
    do
        {
            phones.Add (GetPhone ());
            Console.Write ("Would like to process another phone? [Y or N]: ", shouldContinue);
            shouldContinue = Console.ReadLine ().ToUpper () == "Y";
        } while (shouldContinue == true);
    if (shouldContinue == false) {
        DisplayPhones (phones);
    }
}


#====================
#gpt output=============

Python:

def Main (args): 
    phones = list() 
    shouldContinue = True 
    while shouldContinue: 
        phones.append(GetPhone()) 
        shouldContinue = (input("Would like to process another phone? [Y or N]: ").upper() == "Y") 
    if shouldContinue == False: 
        DisplayPhones(phones)

Java: 

public static void main(String[] args) {
    List<Phone> phones = new ArrayList<Phone>();
    boolean shouldContinue = true;
    do {
        phones.add(GetPhone());
        System.out.print("Would like to process another phone? [Y or N]: ");
        shouldContinue = System.console().readLine().toUpperCase().equals("Y");
    } while (shouldContinue);

    if (!shouldContinue) {
        DisplayPhones(phones);
    }	
}

C:

void Main(char * args[]) 
{ 
    List phones; 
    int shouldContinue = 1; 
    do 
    { 
        phones->Add(GetPhone()); 
        printf("Would like to process another phone? [Y or N]: ", shouldContinue); 
        char input[2]; 
        scanf("%s", input); 
        shouldContinue = (input[0] == 'Y' || input[0] == 'y'); 
    } while (shouldContinue == 1); 
    if (shouldContinue == 0) 
    { 
        DisplayPhones(phones); 
    } 
}

