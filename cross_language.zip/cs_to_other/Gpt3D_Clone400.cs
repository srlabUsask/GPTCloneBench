#input 
public Bitmap BitmapFromSource (System.Windows.Media.Imaging.BitmapSource bitmapsource) {
    var src = new System.Windows.Media.Imaging.FormatConvertedBitmap ();
    src.BeginInit ();
    src.Source = bitmapsource;
    src.DestinationFormat = System.Windows.Media.PixelFormats.Bgra32;
    src.EndInit ();
    Bitmap bitmap = new Bitmap (src.PixelWidth, src.PixelHeight, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
    var data = bitmap.LockBits (new Rectangle (Point.Empty, bitmap.Size), System.Drawing.Imaging.ImageLockMode.WriteOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
    src.CopyPixels (System.Windows.Int32Rect.Empty, data.Scan0, data.Height * data.Stride, data.Stride);
    bitmap.UnlockBits (data);
    return bitmap;
}


#====================
#gpt output=============

Python:
def BitmapFromSource(bitmapsource):
    src = System.Windows.Media.Imaging.FormatConvertedBitmap()
    src.BeginInit()
    src.Source = bitmapsource
    src.DestinationFormat = System.Windows.Media.PixelFormats.Bgra32
    src.EndInit()
    bitmap = Bitmap(src.PixelWidth, src.PixelHeight, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
    data = bitmap.LockBits(Rectangle(Point.Empty, bitmap.Size), System.Drawing.Imaging.ImageLockMode.WriteOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb)
    src.CopyPixels(System.Windows.Int32Rect.Empty, data.Scan0, data.Height * data.Stride, data.Stride)
    bitmap.UnlockBits(data)
    return bitmap

C:
Bitmap BitmapFromSource(BitmapSource bitmapsource) {
  FormatConvertedBitmap src;
  src.BeginInit();
  src.Source = bitmapsource;
  src.DestinationFormat = PixelFormats.Bgra32;
  src.EndInit();
  Bitmap bitmap = new Bitmap(src.PixelWidth, src.PixelHeight, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
  int dataSize = src.PixelHeight * src.PixelWidth;
  int dataStride = src.PixelWidth * 4;
  byte[] data = new byte[dataSize * 4];
  src.CopyPixels(data, dataStride , 0);
  BitmapData bitmapData = bitmap.LockBits(new Rectangle(0, 0, bitmap.Width, bitmap.Height), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
  Marshal.Copy( data, 0, bitmapData.Scan0, dataSize * 4);
  bitmap.UnlockBits(bitmapData);
  return bitmap;
}

Java:
public static Bitmap BitmapFromSource( BitmapSource bitmapsource )  {
    FormatConvertedBitmap src = new FormatConvertedBitmap();
    src.BeginInit();
    src.Source = bitmapsource;
    src.DestinationFormat = PixelFormats.Bgra32;
    src.EndInit();
    Bitmap bitmap = new Bitmap( src.PixelWidth, src.PixelHeight, System.Drawing.Imaging.PixelFormat.Format32bppArgb );
    byte[] data = new byte[src.PixelWidth * src.PixelHeight * 4];
    src.CopyPixels( data, src.PixelWidth * 4 , 0 );
    int[] intData = new int[data.length / 4];
    for( int i = 0; i < intData.length; i++ ){
        intData[i] = ByteBuffer.wrap( Arrays.copyOfRange( data, i*4, i*4+4 ) ).getInt();
    }
    bitmap.setRGB( 0, 0, src.PixelWidth, src.PixelHeight, intData, 0, src.PixelWidth );
    return bitmap;  
}

