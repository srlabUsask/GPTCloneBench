#input 
public void UndoAll (DbContext context) {
    context.ChangeTracker.DetectChanges ();
    var entries = context.ChangeTracker.Entries ().Where (e = > e.State != EntityState.Unchanged).ToList ();
    foreach (var dbEntityEntry in entries) {
        var entity = dbEntityEntry.Entity;
        if (entity == null)
            continue;
        if (dbEntityEntry.State == EntityState.Added) {
            var set = context.Set (entity.GeType ());
            set.Remove (entity);
        } else if (dbEntityEntry.State == EntityState.Modified) {
            dbEntityEntry.Reload ();
        } else if (dbEntityEntry.State == EntityState.Deleted)
            dbEntityEntry.State = EntityState.Modified;
    }
}


#====================
#gpt output=============

Python:
def undo_all(context): 
    context.change_tracker.detect_changes() 
    entries = context.change_tracker.entries().where(lambda e: e.state != EntityState.unchanged).to_list()
    for entity in entries: 
        if entity is None: 
            continue
        if entity.state == EntityState.added: 
            set_ = context.set(entity.get_type())
            set_.remove(entity)
        elif entity.state == EntityState.modified:
            entity.reload()
        elif entity.state == EntityState.deleted:
            entity.state = EntityState.modified

C:
void undo_all (DbContext *context) { 
    context->change_tracker->detect_changes (); 
    ChangeTrackerEntry **entries = context->change_tracker->entries->where(
        entry->state != EntityState_Unchanged
    )->to_list();
    for (int i = 0; i < entries->length; i++) {
        ChangeTrackerEntry *entry = entries[i];
        if (entry->entity == NULL)
            continue;
        if (entry->state == EntityState_Added) {
            ListSet *set = context->set(entry->entity->get_type());
            set->remove(entry->entity);
        } else if (entry->state == EntityState_Modified) {
            entry->reload();
        } else if (entry->state == EntityState_Deleted) {
            entry->state = EntityState_Modified;
        }
    }
}

Java:
public void undoAll(DbContext context) {
    context.getChangeTracker().detectChanges();
    Collection<ChangeTrackerEntry> entries = context.getChangeTracker().getEntries().stream().filter(e -> e.getState() != EntityState.UNCHANGED).collect(Collectors.toList());
    for (ChangeTrackerEntry entry : entries) {
        if (entry.getEntity() == null)
            continue;
        if (entry.getState() == EntityState.ADDED) {
            Set set = context.getSet(entry.getEntity().getType());
            set.remove(entry.getEntity());
        } else if (entry.getState() == EntityState.MODIFIED) {
            entry.reload();
        } else if (entry.getState() == EntityState.DELETED) {
            entry.setState(EntityState.MODIFIED);
        }
    }
}

