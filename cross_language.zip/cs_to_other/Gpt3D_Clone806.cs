#input 
static void HasRows (SqlConnection connection) {
    using (connection)
    using (SqlCommand command = new SqlCommand ("SELECT CategoryID, CategoryName FROM Categories;", connection))
    {
        connection.Open ();
        using (SqlDataReader reader = command.ExecuteReader ())
        {
            if (reader.HasRows) {
                while (reader.Read ()) {
                    Console.WriteLine ("{0}\t{1}", reader.GetInt32 (0), reader.GetString (1));
                }
            } else {
                Console.WriteLine ("No rows found.");
            }
            reader.Close ();
        }}}


#====================
#gpt output=============

Python Implementation: 
def hasRows(connection): 
  with connection:
    cursor = connection.cursor()
    cursor.execute("SELECT CategoryID, CategoryName FROM Categories;")
    if cursor.rowcount > 0:
      records = cursor.fetchall()
      for row in records:
        print(f"{row[0]}\t{row[1]}")
    else:
      print("No rows found.")
    cursor.close()


C Implementation:
    void hasRows(MYSQL * connection){
        MYSQL_RES * result;
        MYSQL_ROW row;
        
        mysql_query(connection, "SELECT CategoryID, CategoryName FROM Categories");
        result = mysql_store_result(connection);
        
        if(mysql_num_rows(result) > 0){
            while ((row = mysql_fetch_row(result)) != NULL){
                printf("%d\t%s\n", row[0], row[1]);
            }
        }
        else
            printf("No rows found.\n");
            
        mysql_free_result(result);
            
    }


Java Implementation: 
public static void hasRows(Connection connection) { 
    try { 
        Statement stmt = connection.createStatement(); 
        ResultSet rs = stmt.executeQuery("SELECT CategoryID, CategoryName FROM Categories;"); 
 
        if(rs.next()) { 
            while(rs.next()) { 
                System.out.println(rs.getInt(1) + "\t" + rs.getString(2)); 
            } 
        } else { 
            System.out.println("No rows found."); 
        } 
    } catch (SQLException e) { 
        e.printStackTrace(); 
    } 
}

