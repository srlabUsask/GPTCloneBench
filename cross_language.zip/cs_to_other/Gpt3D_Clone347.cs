#input 
static void Main (string [] args) {
    string [] ahri = {"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"};
    string [] leeSin = {"Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"};
    Console.WriteLine ("Conor's Random League of Legends Skin Selector v0.1");
    Console.WriteLine (" ");
    Console.WriteLine (" ");
    Random rnd = new Random ();
    Console.ForegroundColor = ConsoleColor.Gray;
    Console.WriteLine ("What champion would you like to select a skin for?..    ");
    string champion = Console.ReadLine ();
    Console.Write ("Press the 'enter' key for a random champion..     ");
    string question = Console.ReadLine ();
    if (champion == "ahri") {
        int randomNumber = rnd.Next (ahri.Length - 1);
        Console.WriteLine (ahri [randomNumber]);
    } else {
        int randomNumber = rnd.Next (leeSin.Length - 1);
        Console.WriteLine (leeSin [randomNumber]);
    }
}


#====================
#gpt output=============

Python:

def main():
    ahri = ["Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"]
    leeSin = ["Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"]
    print("Connor's Random League of Legends Skin Selector v0.1")
    print()
    print()
    champion = input("What champion would you like to select a skin for?..    ")
    question = input("Press the 'enter' key for a random champion..     ")
    if champion == "ahri":
        randomNumber = random.randint(0, len(ahri)-1)
        print(ahri[randomNumber])
    else:
        randomNumber = random.randint(0, len(leeSin)-1)
        print(leeSin[randomNumber])

C:

void main(int argc, char **argv) {
    char *ahri[] = {"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"};
    char *leeSin[] = {"Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"};
    printf("Conor's Random League of Legends Skin Selector v0.1\n");
    printf("\n\n");
    char champion[50];
    printf("What champion would you like to select a skin for?..    ");
    scanf("%s", champion);
    char question[50];
    printf("Press the 'enter' key for a random champion..     ");
    scanf("%s", question);
    if (strcmp(champion, "ahri") == 0) {
        int randomNumber = rand() % (sizeof(ahri)/sizeof(char *));
        printf("%s\n", ahri[randomNumber]);
    } else {
        int randomNumber = rand() % (sizeof(leeSin)/sizeof(char *));
        printf("%s\n", leeSin[randomNumber]);
    }
    
Java: 

public static void main(String[] args) {
    String[] ahri = {"Academy", "Challenger", "Dynasty", "Foxfire", "Midnight", "Popstar"};
    String[] leeSin = {"Traditional", "Acolyte", "Dragon Fist", "Musy Thai", "Pool Party", "SKT T1", "Knockout"};
    System.out.println("Conor's Random League of Legends Skin Selector v0.1");
    System.out.println();
    System.out.println();
    System.out.print("What champion would you like to select a skin for?..    ");
    Scanner scanner = new Scanner(System.in);
    String champion = scanner.nextLine();
    System.out.print("Press the 'enter' key for a random champion..     ");
    String question = scanner.nextLine();
    if (champion.equals("ahri")) {
        int randomNumber = new Random().nextInt(ahri.length - 1);
        System.out.println(ahri[randomNumber]);
    } else {
        int randomNumber = new Random().nextInt(leeSin.length - 1);
        System.out.println(leeSin[randomNumber]);
    }
}

