#input 
public string ConvertCsvFileToJsonObject (string path) {
    var csv = new List < string [] > ();
    var lines = File.ReadAllLines (path);
    foreach (string line in lines)
        csv.Add (line.Split (','));
    var properties = lines [0].Split (',');
    var listObjResult = new List < Dictionary < string, string > > ();
    for (int i = 1; i < lines.Length; i ++) {
        var objResult = new Dictionary < string, string > ();
        for (int j = 0; j < properties.Length; j ++)
            objResult.Add (properties [j], csv [i] [j]);
        listObjResult.Add (objResult);
    }
    return JsonConvert.SerializeObject (listObjResult);
}


#====================
#gpt output=============


Python:
def ConvertCsvFileToJsonObject(path):
    csv = []
    with open(path) as f_obj:
        lines = f_obj.readlines()
    for line in lines:
        csv.append(line.split(','))
    properties = lines[0].split(',')
    listObjResult = []
    for i in range(1, len(lines)):
        objResult = {}
        for j in range(len(properties)):
            objResult[properties[j]] = csv[i][j]
        listObjResult.append(objResult)
    return json.dumps(listObjResult)


C:
char* ConvertCsvFileToJsonObject(char* path) {
    char** csv;
    int len = 0;
    char* string = readFile(path, &len);
    csv = malloc(sizeof(char*) * len); 
    char* line = strtok(string, "\r\n");
    int i = 0;
    while(line) {
    	csv[i++] = malloc(sizeof(char*) * strlen(line));
        strcpy(csv[i-1], line);
        line = strtok(NULL, "\r\n");
    }
    char* properties = (char*) malloc(sizeof(char) * strlen(csv[0]));
    strcpy(properties, csv[0]);
    cJSON* listObjResult = cJSON_CreateArray();
    for (int i = 1; i < len; i++) {
        cJSON* objResult = cJSON_CreateObject();
		char* token;
		int j = 0;
		token = strtok (properties,",");  
		while (token != NULL) { 
		    cJSON_AddItemToObject(objResult, token, cJSON_CreateString(csv[i])); 
		    token = strtok (NULL, ",");
		    j++;
		} 
        cJSON_AddItemToArray(listObjResult, objResult);
    }
    char* jsonString = cJSON_Print(listObjResult);
    freeCsv(csv, len);
    free(string);
    free(properties);
    return jsonString;
}


Java:
public String ConvertCsvFileToJsonObject (String path) {
    List<String[]> csv = new ArrayList<String[]>();
    List<String> lines = Files.readAllLines (Paths.get (path));

    for (String line : lines) {
        csv.add (line.split (","));
    }
    String[] properties = lines.get (0).split (",");

    List<Map<String, String> > listObjResult = new ArrayList<Map<String, String> >();

    for (int i = 1; i < lines.size (); i ++) {
        Map<String, String> objResult = new HashMap<String, String>();
        for (int j = 0; j < properties.length; j ++) {
            objResult.put (properties [j], csv.get (i) [j]);
        }

        listObjResult.add (objResult);
    }

    Gson gson = new Gson ();
    return gson.toJson (listObjResult);
}

