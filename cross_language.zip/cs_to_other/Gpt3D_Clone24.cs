#input 
static void Main (string [] args) {
    var assemblyFilename = args.FirstOrDefault ();
    if (assemblyFilename != null && File.Exists (assemblyFilename)) {
        try {
            var assembly = Assembly.ReflectionOnlyLoadFrom (assemblyFilename);
            var name = assembly.GetName ();
            using (var file = File.AppendText ("C:\\AssemblyInfo.txt"))
            {
                file.WriteLine ("{0} - {1}", name.FullName, name.Version);
            }}
        catch (Exception ex) {
            throw;
        }
    }
}


#====================
#gpt output=============

Python Implementation: 

def main(arg): 
    if arg[0] and os.path.exists(arg[0]): 
        try: 
            assembly = Assembly.ReflectionOnlyLoadFrom(arg[0])
            name = assembly.GetName()
            
            with open("C:\\AssemblyInfo.txt", "a+") as f:
                f.write("{} - {}".format(name.FullName, name.Version)) 
                
        except Exception as ex: 
            raise ex 
    

C Implementation: 

int main(int argc, char* argv[]) { 
    if (argv[0] != NULL && fileExists(argv[0])) { 
        try { 
            Assembly* assembly = ReflectionOnlyLoadFrom(argv[0]);
            Name* name = assembly.GetName();
            
            FILE* assembly_info = fopen("C:\\AssemblyInfo.txt", "a+");
            if (assembly_info != NULL) { 
                fprintf(assembly_info, "%s - %s", name->FullName, name->Version);
            }
        } catch (Exception* ex) { 
            // Propagate exception
            throw ex; 
        }
    }
    return 0; 
}


Java Implementation: 

public static void main(final String[] args) { 
    if (args[0] == null || !Files.exists(Paths.get(args[0])) { 
        try { 
            final Assembly assembly = Assembly.ReflectionOnlyLoadFrom(args[0]); 
            final Name name = assembly.getName(); 
            
            final File assemblyInfo = new File("C:\\AssemblyInfo.txt");
            final PrintWriter output = new PrintWriter(new FileWriter(assemblyInfo, true));
            output.println("%s - %s", name.getFullName(), name.getVersion());
        } catch (Exception ex) { 
            throw ex;
        }
    }
}

