#input 
public static void TrimWavFile (string inPath, string outPath, TimeSpan cutFromStart, TimeSpan cutFromEnd) {
    using (WaveFileReader reader = new WaveFileReader (inPath))
    {
        using (WaveFileWriter writer = new WaveFileWriter (outPath, reader.WaveFormat))
        {
            int bytesPerMillisecond = reader.WaveFormat.AverageBytesPerSecond / 1000;
            int startPos = (int) cutFromStart.TotalMilliseconds * bytesPerMillisecond;
            startPos = startPos - startPos % reader.WaveFormat.BlockAlign;
            int endBytes = (int) cutFromEnd.TotalMilliseconds * bytesPerMillisecond;
            endBytes = endBytes - endBytes % reader.WaveFormat.BlockAlign;
            int endPos = (int) reader.Length - endBytes;
            TrimWavFile (reader, writer, startPos, endPos);
        }}}


#====================
#gpt output=============

Python: 
def trim_wav_file(in_path, out_path, cut_from_start, cut_from_end):
    reader = wave.open(in_path, 'rb')
    writer = wave.open(out_path, 'w')
    bytes_per_millisecond = reader.getframerate() // 1000
    start_pos = int(cut_from_start.total_seconds() * bytes_per_millisecond)
    start_pos = start_pos - start_pos % reader.getsampwidth()
    end_bytes = int(cut_from_end.total_seconds() * bytes_per_millisecond)
    end_bytes = end_bytes - end_bytes % reader.getsampwidth()
    end_pos = int(reader.getnframes() - end_bytes)
    trim_wav_file(reader, writer, start_pos, end_pos)
  
  
C: 
void trimWavFile(char* inPath, char* outPath, int cutFromStart, int cutFromEnd) {
  int startPos, endBytes, endPos, bytesPerMillisecond;
  FILE* inFile;
  FILE* outFile;    
  inFile = fopen(inPath, "rb");
  outFile = fopen(outPath, "wb");

  // Calculate start and end pos.
  bytesPerMillisecond = (int) (inFile->sampleRate / 1000); // Assuming 8-bit audio
  startPos = (int) (cutFromStart * bytesPerMillisecond);
  startPos -= startPos % inFile->blockAlign;
  endBytes = (int) (cutFromEnd * bytesPerMillisecond);
  endBytes -= endBytes % inFile->blockAlign;
  endPos = (int) (inFile->length - endBytes);

  trimWavFile(inFile, outFile, startPos, endPos)}



Java: 
public static void trimWavFile(String inPath, String outPath, long cutFromStart, long cutFromEnd) {
    WaveFileReader reader = new WaveFileReader(inPath);
    WaveFileWriter writer = new WaveFileWriter(outPath, reader.getWaveFormat());
    long bytesPerMillisecond = reader.getWaveFormat().getAverageBytesPerSecond() / 1000;
    long startPos = cutFromStart * bytesPerMillisecond;
    startPos -= startPos % reader.getWaveFormat().getBlockAlign();
    long endBytes = cutFromEnd * bytesPerMillisecond;
    endBytes -= endBytes % reader.getWaveFormat().getBlockAlign();
    long endPos = reader.getLength() - endBytes;
    trimWavFile(reader, writer, startPos, endPos); 
  }

