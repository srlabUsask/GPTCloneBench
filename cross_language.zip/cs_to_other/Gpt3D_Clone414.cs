#input 
public override string ReadLine () {
    int c;
    c = Read ();
    if (c == - 1) {
        return null;
    }
    StringBuilder sb = new StringBuilder ();
    do
        {
            char ch = (char) c;
            if (ch == ',') {
                return sb.ToString ();
            } else {
                sb.Append (ch);
            }
        } while ((c = Read ()) != - 1);
    return sb.ToString ();
}


#====================
#gpt output=============

Python: 
def ReadLine (): 
    c = Read() 
    if c == -1: 
        return None 
    sb = "" 
    while True: 
        ch = chr(c)
        if ch == ',': 
            return sb 
        else: 
            sb += ch
        c = Read() 
        if c == -1: 
            break 
    return sb 
        

C:
char *ReadLine (void) {
	int c;
	c = Read();
	if (c == -1) {
		return NULL;
	}
	char *sb = "";
	do {
		char ch = (char)c;
		if (ch == ',') {
			return sb;
		} else {
			strcat(sb, &ch);
		}
	} while ((c = Read()) != -1);
	return sb;
}


Java: 
public String ReadLine () {
    int c;
    c = Read ();
    if (c == - 1) {
        return null;
    }
    StringBuilder sb = new StringBuilder ();
    do
        {
            char ch = (char) c;
            if (ch == ',') {
                return sb.toString ();
            } else {
                sb.append (ch);
            }
        } while ((c = Read ()) != - 1);
    return sb.toString ();
}

