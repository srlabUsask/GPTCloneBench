#input 
[HttpPost] public ActionResult Register (UserVIewModel reg) {
    if (! ModelState.IsValid) {
        return View (model);
    }
    bool userExists = db.Users.FirstOrDefault (x = > x.UserName == reg.UserName) != null;
    if (userExists) {
        ModelState.AddModelError ("UserName", "UserName taken");
        return View (model);
    }
    var m = new User {UserName = reg.UserName, Email = reg.Email, FirstName = reg.FirstName, LastName = reg.LastName, Password = reg.Password};
    db.Users.Add (m);
    db.SaveChanges ();
    return RedirectToAction ("Login");
}


#====================
#gpt output=============

Python:
@app.route('/register', methods=['POST'])
def register():
    if request.method == 'POST':
        reg = request.form
        if reg:
            userExists = User.query.filter(User.username == reg['UserName']).first() is not None
            if userExists:
                error = 'Username taken'
                return render_template('register.html', error=error)
            else:
                m = User(reg['UserName'], reg['Email'], reg['FirstName'], reg['LastName'], reg['Password'])
                db.session.add(m)
                db.session.commit()
                return redirect(url_for('login'))


C:
[HttpPost] public ActionResult Register (UserVIewModel reg) { 
    if (! ModelState.IsValid) { 
        return View (model); 
    } 
    int userExists = 0; 
    User user = db.Users.FirstOrDefault (x = > x.UserName == reg.UserName); 
    if ( user != null ){ 
        userExists = 1; 
        ModelState.AddModelError ("UserName", "UserName taken"); 
        return View (model);
    } 
    if ( userExists == 0 ) { 
        User *m = (User*)malloc(sizeof(User)); 
        m->username = reg.UserName; 
        m->email = reg.Email; 
        m->firstname = reg.FirstName; 
        m->lastname = reg.LastName; 
        m->password = reg.Password; 
        db.user.Add(*m); 
        db.SaveChanges(); 
        return RedirectToAction ("Login"); 
    } 
} 

Java:
@PostMapping("/register")
public String register(@ModelAttribute UserVIewModel reg, Model model) {
    if(!ModelState.isValid()) {
        return "register";
    }
    boolean userExists = db.Users.stream().anyMatch(x -> x.UserName == reg.UserName);
    if(userExists) {
        ModelState.addError("UserName", "UserName taken");
        return "register";
    }
    User user = new User(reg.UserName, reg.Email, reg.FirstName, reg.LastName, reg.Password); 
    db.Users.add(user);
    db.saveChanges();
    return "redirect:/login";
}

