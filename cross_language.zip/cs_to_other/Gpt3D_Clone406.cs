#input 
public static void Main () {
    try {
        Console.WriteLine ("Before throwing");
        throw new Exception ("Exception!");
    }
    finally {
        Console.WriteLine ("In finally");
        Console.ReadLine ();
    }
}


#====================
#gpt output=============

Python
try:
    print('Before throwing')
    raise Exception('Exception!')
finally:
    print('In finally')
    input()

C
#include<stdio.h>
int main()
{
    try
    {
        printf("Before throwing");
        throw("Exception!");
    }
    finally
    {
        printf("In finally");
        getchar();
    }
    return 0;
}

Java
public static void main() {
    try {
        System.out.println("Before throwing");
        throw new Exception("Exception!");
    }
    finally {
        System.out.println("In finally");
        System.in.read();
    }
}

