#input 
static void Main (string [] args) {
    demo obj = new demo ();
    int n = 5;
    string uname, pass;
    Console.ForegroundColor = ConsoleColor.Green;
    label1 : Console.WriteLine ("\n");
    Console.WriteLine ("Enter username");
    uname = Console.ReadLine ();
    Console.WriteLine ("Enter Password");
    pass = Console.ReadLine ();
    obj.setName (uname);
    obj.setPass (pass);
    if (obj.getName () == "niit" && obj.getPass () == "1234") {
        Console.WriteLine ("welcome");
    } else {
        if (n < 1) {
            Console.Clear ();
            Console.WriteLine ("ScreenLock");
        } else {
            Console.WriteLine ("\n Invalid");
            Console.WriteLine ("\n To try again enter y");
            string yes = Console.ReadLine ();
            Console.WriteLine ("\n");
            if (yes == "y") {
                while (n >= 1) {
                    Console.Write (n + " Tries left");
                    n = -- n;
                    goto label1;
                }
            }
        }
    }
    Console.ReadKey ();
}


#====================
#gpt output=============

//Python Implementation
class Demo(object):
    def __init__(self):
        self.name = ""
        self.password = ""
        
    def setName(self, name):
        self.name = name
        
    def setPass(self, pass):
        self.password = pass
        
    def getName(self):
        return self.name
    
    def getPass(self):
        return self.password
    
if __name__ == '__main__':
    obj = Demo()
    n = 5
    print("\n")
    username = input("Enter username: ")
    password = input("Enter password: ")
    obj.setName(username)
    obj.setPass(password)
    if obj.getName() == "niit" and obj.getPass() == "1234":
        print("Welcome")
    else:
        if n < 1:
            print("ScreenLock")
        else:
            print("\n Invalid")
            yes = input("To try again enter y: ")
            if yes == "y":
                while n >= 1:
                    print(n, "Tries left")
                    n -=1
  

//C Implementation
#include<stdio.h>
#include<string.h>
#include <stdlib.h>

typedef struct{
    char username[20];
    char password[20];
}Demo;

void setUsername(Demo *obj, char *userName) {
    strcpy(obj->username, userName);
}

void setPassword(Demo *obj, char *passWord) {
    strcpy(obj->password, passWord);
}

char* getUsername(Demo *obj) {
    return obj->username;
}

char* getPassword(Demo *obj) {
    return obj->password;
}

void main(void){
    Demo obj;
    int n = 5;
    char userName[20], passWord[20];

    printf("\n");
    printf("Enter username: ");
    scanf("%s", userName);
    printf("Enter Password: ");
    scanf("%s", passWord);
    setUsername(&obj, userName);
    setPassword(&obj, passWord);

    if(strcmp(getUsername(&obj), "niit") == 0 && strcmp(getPassword(&obj), "1234") == 0){
        printf("Welcome");
    } else {
        if(n < 1){
            printf("ScreenLock");
        } else {
            printf("\n Invalid");
            printf("\n To try again enter y");
            char yes[20];
            scanf("%s", yes);
            printf("\n");
            if(strcmp(yes, "y") == 0){
                while(n >= 1){
                    printf("%d Tries left\n", n);
                    n--;
                }
            }
        }
    }
}

//Java Implementation
public class Demo {
    int n = 5;
    String username;
    String password;

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public static void main(String[] args) {
        Demo obj = new Demo();
        System.out.println("\n");
        System.out.println("Enter username");
        String username = System.console().readLine();
        System.out.println("Enter Password");
        String pass = System.console().readLine();
        obj.setUsername(username);
        obj.setPassword(pass);
        if (obj.getUsername().equals("niit") && obj.getPassword().equals("1234")) {
            System.out.println("welcome");
        } 
        else {
            if (obj.n < 1) {
                System.out.println("Screen Lock");
            } 
            else {
                System.out.println("\n Invalid");
                System.out.println("\n To try again enter y");
                String yes = System.console().readLine();            
                System.out.println("\n");
                if (yes.equalsIgnoreCase("y")) {
                    while (obj.n >= 1) {
                        System.out.print(obj.n + " Tries left");
                        obj.n = --obj.n;
                    }
                }
            }
        }
    }

}

