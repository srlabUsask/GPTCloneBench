#input 
private int CountDivisorsOfNumber (int number) {
    int count = 0;
    int end = (int) Math.Sqrt (number);
    for (int i = 1; i < end; i ++) {
        if (number % i == 0)
            count += 2;
    }
    if (end * end == number)
        count ++;
    return count;
}


#====================
#gpt output=============

Python: 
def CountDivisorsOfNumber(number):
    count = 0
    end = int(math.sqrt(number))
    for i in range(1, end):
        if(number % 1 == 0): 
            count += 2
    if(end*end == number):
        count += 1
    return count

C:
int CountDivisorsOfNumber(int number){
    int count = 0;
    int end = (int) sqrt(number);
    for(int i = 1; i < end; i ++){
        if(number % i == 0)
            count += 2;
    }
    if(end*end == number)
        count += 1;
    return count;
}

Java: 
public static int CountDivisorsOfNumber(int number) {
    int count = 0;
    int end = (int) Math.sqrt(number);
    for (int i = 1; i < end; i ++) {
        if (number % i == 0)
            count += 2;
    }
    if (end * end == number)
        count ++;
    return count;
}

