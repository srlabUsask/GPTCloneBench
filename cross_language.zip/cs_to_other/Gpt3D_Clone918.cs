#input 
public static void Main () {
    var sw = new Stopwatch ();
    sw.Start ();
    bool f;
    for (int i = 1; i < 1001; i ++) {
        f = _arr.Contains ("Item " + i, StringComparer.OrdinalIgnoreCase);
    }
    Console.WriteLine (sw.Elapsed);
    sw.Restart ();
    for (int i = 1; i < 1001; i ++) {
        f = _hs.Any (w = > string.Equals (w, "Item " + i, StringComparison.InvariantCultureIgnoreCase));
    }
    Console.WriteLine (sw.Elapsed);
}


#====================
#gpt output=============

// PYTHON
import time

sw = time.time()
f = False
for i in range(1, 1001): 
  if 'Item ' + str(i) in arr : 
    f = True
print(time.time() - sw)

sw = time.time()
f = False
for i in range(1, 1001):
  for j in range(len(hs)):
    if string.equals(hs[j], "Item " + str(i), stringComparison.InvariantCultureIgnoreCase):
      f = True
print(time.time() - sw)

// C
#include <time.h>
#include <stdio.h>
#include <string.h>

time_t sw;
int f = 0;

sw = time(NULL);
for (int i = 1; i < 1001; i++) {
  for(int j = 0; j < arr_len; j++) {  
    if(strcasecmp(arr[j], "Item " + i) == 0) {
      f = 1;
    }
  }
}

printf("%d\n", (int) (time(NULL) - sw));

sw = time(NULL);
for (int i = 1; i < 1001; i++) {
  for(int j = 0; j < hs_len; j++) {
    if (strcasecmp(hs[j], "Item " + i) == 0) {
      f = 1;
    }
  }
}

printf("%d\n", (int) (time(NULL) - sw));

// JAVA
import java.util.concurrent.TimeUnit;  
  
public static void main() throws InterruptedException{  
  long sw = System.currentTimeMillis(); 
  boolean f = false;
  for(int i=1; i<1001;i++) { 
    for(String s : arr){  
      if (s.equalsIgnoreCase("Item "+i))  
        f = true;
      }
  }
  long elapsedMillis = (System.currentTimeMillis() - sw);
  System.out.println(TimeUnit.MILLISECONDS.toSeconds(elapsedMillis));  
  
  sw = System.currentTimeMillis();
  f = false;  
  for(int i=1; i<1001; i++){
    for(String s : hs){
      if (s.equalsIgnoreCase("Item "+i)) 
        f = true;
    }
  }
  elapsedMillis = (System.currentTimeMillis() -sw);
  System.out.println(TimeUnit.MILLISECONDS.toSeconds(elapsedMillis));  
}

