#input 
void DataGridCellPreviewMouseLeftButtonDown (object sender, System.Windows.Input.MouseButtonEventArgs e) {
    DataGridCell cell = sender as DataGridCell;
    if (cell != null && ! cell.IsEditing && ! cell.IsReadOnly) {
        if (! cell.IsFocused) {
            cell.Focus ();
        }
        DataGrid dataGrid = LogicalTreeWalker.FindParentOfType < DataGrid > (cell);
        if (dataGrid != null) {
            if (dataGrid.SelectionUnit != DataGridSelectionUnit.FullRow) {
                if (! cell.IsSelected)
                    cell.IsSelected = true;
            } else {
                DataGridRow row = LogicalTreeWalker.FindParentOfType < DataGridRow > (cell);
                if (row != null && ! row.IsSelected) {
                    row.IsSelected = true;
                }
            }
        }
    }
}


#====================
#gpt output=============

Python:
def DataGridCellPreviewMouseLeftButtonDown(sender, e):
    cell = sender
    if cell and not cell.IsEditing and not cell.IsReadOnly:
        if not cell.IsFocused:
            cell.Focus()
        dataGrid = LogicalTreeWalker.FindParentOfType(cell, DataGrid)
        if dataGrid:
            if dataGrid.SelectionUnit != DataGridSelectionUnit.FullRow:
                if not cell.IsSelected:
                    cell.IsSelected = True
            else:
                row = LogicalTreeWalker.FindParentOfType(cell, DataGridRow)
                if row and not row.IsSelected:
                    row.IsSelected = True

C:
void DataGridCellPreviewMouseLeftButtonDown(void* sender, System_Windows_Input_MouseButtonEventArgs* e) {
    DataGridCell* cell = (DataGridCell*)sender;
    if (cell && !cell->IsEditing && !cell->IsReadOnly) {
        if (!cell->IsFocused) {
            cell->Focus();
        }
        DataGrid* dataGrid = LogicalTreeWalker_FindParentOfType(cell, DataGrid);
        if (dataGrid) {
            if (dataGrid->SelectionUnit != DataGridSelectionUnit_FullRow) {
                if (!cell->IsSelected)
                    cell->IsSelected = 1;
            }
            else {
                DataGridRow* row = LogicalTreeWalker_FindParentOfType(cell, DataGridRow);
                if (row && !row->IsSelected) {
                    row->IsSelected = 1;
                }
            }
        }
    }
}

Java:
void dataGridCellPreviewMouseLeftButtonDown(Object sender, System.Windows.Input.MouseButtonEventArgs e) {
    DataGridCell cell = (DataGridCell) sender;
    if (cell != null && !cell.isEditing() && !cell.isReadOnly()) {
        if (!cell.isFocused()) {
            cell.focus();
        }
        DataGrid dataGrid = LogicalTreeWalker.findParentOfType(cell, DataGrid.class);
        if (dataGrid != null) {
            if (dataGrid.getSelectionUnit() != DataGridSelectionUnit.FULL_ROW) {
                if (!cell.isSelected())
                    cell.setSelected(true);
            } else {
                DataGridRow row = LogicalTreeWalker.findParentOfType(cell, DataGridRow.class);
                if (row != null && !row.isSelected()) {
                    row.setSelected(true);
                }
            }
        }
    }
}

