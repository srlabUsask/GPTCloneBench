#input 
public IEnumerable < int [] > GetIntPermutations (int [] index, int offset, int len) {
    switch (len) {
        case 1 :
            yield return index;
            break;
        case 2 :
            yield return index;
            Swap (index, offset, offset + 1);
            yield return index;
            Swap (index, offset, offset + 1);
            break;
        default :
            foreach (var result in GetIntPermutations (index, offset + 1, len - 1)) {
                yield return result;
            }
            for (var i = 1; i < len; i ++) {
                Swap (index, offset, offset + i);
                foreach (var result in GetIntPermutations (index, offset + 1, len - 1)) {
                    yield return result;
                }
                Swap (index, offset, offset + i);
            }
            break;
    }
}


#====================
#gpt output=============


Python: 
def get_int_permutations(index, offset, len):
    if len == 1:
        yield index
    elif len == 2:
        yield index
        swap(index, offset, offset + 1)
        yield index
        swap(index, offset, offset + 1)
    else:
        for result in get_int_permutations(index, offset + 1, len - 1):
            yield result
        for i in range(1, len):
            swap(index, offset, offset + i)
            for result in get_int_permutations(index, offset + 1, len - 1):
                yield result
            swap(index, offset, offset + i)
				
C: 
IEnumerable *getIntPermutations(int index[], int offset, int len) {
    switch (len) {
        case 1 :
            yield return index;
            break;
        case 2 :
            yield return index;
            swap(index, offset, offset + 1);
            yield return index;
            swap(index, offset, offset + 1);
            break;
        default :
            for (IEnumerable *result = getIntPermutations(index, offset + 1, len - 1); result != NULL; result = result->next) {
                yield return result->value;
            }
            for (int i = 1; i < len; i ++) {
                swap(index, offset, offset + i);
                for (IEnumerable *result = getIntPermutations(index, offset + 1, len - 1); result != NULL; result = result->next) {
                    yield return result->value;
                }
                swap(index, offset, offset + i);
            }
            break;
    }
}

Java: 
public Iterable<int[]> getIntPermutations(int[] index, int offset, int len) {
    switch (len) {
        case 1:
            return Collections.singletonList(index);
        case 2:
            List<int[]> results = new ArrayList<>();
            results.add(index);
            swap(index, offset, offset + 1);
            results.add(index);
            swap(index, offset, offset + 1);
            return results;
        default:
            List<int[]> resultList = new ArrayList<>();
            for (int[] permutation : getIntPermutations(index, offset + 1, len - 1)) {
                resultList.add(permutation);
            }
            for (int i = 1; i < len; i++) {
                swap(index, offset, offset + i);
                for (int[] permutation : getIntPermutations(index, offset + 1, len - 1)) {
                    resultList.add(permutation);
                }
                swap(index, offset, offset + i);
            }
            return resultList;
    }
}

