#input 
protected void DiasShow () {
    var getFiles = Directory.GetFiles (HttpContext.Current.Server.MapPath ("/CSS/Design/Page_Design/Dias/1920x1080/"));
    var random = RandomiseList (getFiles);
    var txt = new StringBuilder ();
    foreach (var randomFileName in random) {
        var fileType = System.IO.Path.GetExtension (randomFileName).ToUpper ();
        if ((fileType == ".JPG") || (fileType == ".JPEG")) {
            var imageName = System.IO.Path.GetFileName (randomFileName);
            txt.Append ("<img src=\"CSS/Design/Page_Design/Dias/1920x1080/" + imageName + "\" />");
        }
    }
    lbl_Dias.Text += txt.ToString ();
}


#====================
#gpt output=============

// Python implementation 
def DiasShow(): 
    getFiles = os.listdir(os.path.join(os.getcwd(), '/CSS/Design/Page_Design/Dias/1920x1080/'))
    random = randomiseList(getFiles) 
    txt= "" 
    for randomFileName in random: 
        fileType = os.path.splitext(randomFileName)[1].upper()
        if fileType == ".JPG" or fileType == ".JPEG"
            imageName = os.path.basename(randomFileName)
            txt += '<img src=\"CSS/Design/Page_Design/Dias/1920x1080/' + imageName + '\" />'
    lbl_Dias.text += txt 


// Java Implementation 
protected void DiasShow () {
    String[] getFiles = new File(HttpContext.Current.Server.MapPath ("/CSS/Design/Page_Design/Dias/1920x1080/")).listFiles(); 
    List<String> random = randomiseList (getFiles);
    StringBuilder txt = new StringBuilder ();
    for (int i = 0; i < random.size (); i++) {
        String randomFileName = random.get (i);
        String fileType = randomFileName.subString(randomFileName.indexOf("."), randomFileName.length()).toUpperCase(); 
        if ((fileType.equals(".JPG")) || (fileType.equals(".JPEG"))) {
            String imageName = 
            txt.append ("<img src=\"CSS/Design/Page_Design/Dias/1920x1080/" + imageName + "\" />");
        }
    }
    lbl_Dias.Text += txt.toString();
}


// C Implementation 
void DiasShow () {
    char *getFiles = getFiles (HttpContext.Current.Server.MapPath ("/CSS/Design/Page_Design/Dias/1920x1080/")); 
    char **random = randomiseList (getFiles);
    char *txt = "";
    int i; 
    for (i = 0; i < sizeof(random); i++){
        char *randomFileName = random[i];
        char fileType[8]; 
        strncpy(fileType, randomFileName + (strlen(randomFileName)-4), 4); 
        upperString(fileType);
        if (strcmp(fileType, ".JPG") == 0 || strcmp(fileType, ".JPEG") == 0) {
            char *imageName = getFilename(randomFileName);
            strcat(txt, "<img src=\"CSS/Design/Page_Design/Dias/1920x1080/");
            strcat(txt, imageName);
            strcat(txt, "\">");
        }
    }
    strcat(lbl_Dias.Text, txt);
}

