#input 
private static void GetNavigationProperties (Type baseType, Type type, string parentPropertyName, IList < string > accumulator) {
    var properties = type.GetProperties ();
    var navigationPropertyInfoList = properties.Where (prop = > prop.IsDefined (typeof (NavigationPropertyAttribute)));
    foreach (PropertyInfo prop in navigationPropertyInfoList) {
        var propertyType = prop.PropertyType;
        var elementType = propertyType.GetTypeInfo ().IsGenericType ? propertyType.GetGenericArguments () [0] : propertyType;
        var properyName = string.Format ("{0}{1}{2}", parentPropertyName, string.IsNullOrEmpty (parentPropertyName) ? string.Empty : ".", prop.Name);
        accumulator.Add (properyName);
        var isJsonIgnored = prop.IsDefined (typeof (JsonIgnoreAttribute));
        if (! isJsonIgnored && elementType != baseType) {
            GetNavigationProperties (baseType, elementType, properyName, accumulator);
        }
    }
}


#====================
#gpt output=============

// Python
def getNavigationProperties(baseType, type, parentPropertyName, accumulator):
    properties = type.GetProperties()
    navigationPropertyInfoList = [prop for prop in properties if prop.IsDefined(NavigationPropertyAttribute)]
    for prop in navigationPropertyInfoList:
        propertyType = prop.PropertyType
        elementType = propertyType.GetTypeInfo().IsGenericType if propertyType.GetGenericArguments() else propertyType
        properyName = f'{parentPropertyName}{prop.Name}' if not parentPropertyName else f'{parentPropertyName}.{prop.Name}'
        accumulator.append(properyName)
        isJsonIgnored = prop.IsDefined(JsonIgnoreAttribute)
        if not isJsonIgnored and elementType != baseType:
            getNavigationProperties(baseType, elementType, properyName, accumulator)


// C
void GetNavigationProperties(Type baseType, Type type, char* parentPropertyName, IList <string>* accumulator){
    PropertyInfo* properties = type.GetProperties();
    PropertyInfo* navigationPropertyInfoList[];
    for (int i = 0; i < sizeof(properties)/sizeof(properties[0]); i++) {
        if (properties[i].IsDefined(typeof(NavigationPropertyAttribute))){
            navigationPropertyInfoList[i] = properties[i];
        }
    }
    for (int i = 0; i < sizeof(navigationPropertyInfoList)/sizeof(navigationPropertyInfoList[0]); i++) {
        Type propertyType = navigationPropertyInfoList[i].PropertyType;
        Type elementType;
        if (propertyType.GetTypeInfo().IsGenericType){
            elementType = propertyType.GetGenericArguments()[0];
        } else {
            elementType = propertyType;
        }
        char properyName[200];
        if(strlen(parentPropertyName) == 0){
            sprintf(properyName, "%s", navigationPropertyInfoList[i].Name);  
        } else {
            sprintf(properyName, "%s.%s", parentPropertyName, navigationPropertyInfoList[i].Name);
        }
        accumulator.add(properyName);
        bool isJsonIgnored = navigationPropertyInfoList[i].IsDefined(typeof(JsonIgnoreAttribute));
        if(!isJsonIgnored && elementType != baseType){
            GetNavigationProperties(baseType, elementType, properyName, accumulator);
        }
    }
}


// Java
private static void getNavigationProperties(Type baseType, Type type, String parentPropertyName, List <String> accumulator){
    Property [] properties = type.getProperties();
    Property [] navigationPropertyInfoList = Arrays.stream(properties).filter(prop -> prop.isDefined(NavigationPropertyAttribute)).toArray(Property[]::new);
    for (Property prop : navigationPropertyInfoList) {
        Type propertyType = prop.getPropertyType();
        Type elementType;
        if (propertyType.getTypeInfo().isGenericType()) {
            elementType = propertyType.getGenericArguments()[0];
        } else {
            elementType = propertyType;
        }
        String properyName = parentPropertyName;
        if (parentPropertyName == null || parentPropertyName.isEmpty()) {
            properyName = prop.getName();
        } else {
            properyName = String.format("%s.%s", parentPropertyName, prop.getName());
        }
        accumulator.add(properyName);
        boolean isJsonIgnored = prop.isDefined(JsonIgnoreAttribute);
        if (!isJsonIgnored && elementType != baseType) {
            getNavigationProperties(baseType, elementType, properyName, accumulator);
        }
    }
}

