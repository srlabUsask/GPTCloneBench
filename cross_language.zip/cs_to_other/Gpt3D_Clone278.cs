#input 
[Test] public static void Main (string [] args) {
    var method = typeof (Program).GetMethod ("Main");
    var type = typeof (Program);
    SomeValue = 1;
    Console.WriteLine (method.GetCustomAttributes (false).OfType < TestAttribute > ().First ().SomeValue);
    SomeValue = 2;
    Console.WriteLine (method.GetCustomAttributes (false).OfType < TestAttribute > ().First ().SomeValue);
    SomeValue = 3;
    Console.WriteLine (type.GetCustomAttributes (false).OfType < TestAttribute > ().First ().SomeValue);
    SomeValue = 4;
    Console.WriteLine (type.GetCustomAttributes (false).OfType < TestAttribute > ().First ().SomeValue);
    Console.ReadLine ();
}


#====================
#gpt output=============

Python: 
[Test] 
def Main (args) :
  method = type (Program).GetMethod ("Main")
  type = type (Program)
  Program.SomeValue = 1
  print (method.GetCustomAttributes (false).OfType (TestAttribute).First ().SomeValue)
  Program.SomeValue = 2
  print (method.GetCustomAttributes (false).OfType (TestAttribute).First ().SomeValue)
  Program.SomeValue = 3
  print (type.GetCustomAttributes (false).OfType (TestAttribute).First ().SomeValue)
  Program.SomeValue = 4
  print (type.GetCustomAttributes (false).OfType (TestAttribute).First ().SomeValue)

C: 
[Test] 
void Main (char * args []) {
  Method * method = typeof Program.GetMethod ("Main");
  Type * type = typeof (Program);
  Program.SomeValue = 1;
  printf ("%d\n", method.GetCustomAttributes (false).OfType <TestAttribute> ().First ().SomeValue);
  Program.SomeValue = 2;
  printf ("%d\n", method.GetCustomAttributes (false).OfType <TestAttribute> ().First ().SomeValue);
  Program.SomeValue = 3;
  printf ("%d\n", type.GetCustomAttributes (false).OfType <TestAttribute> ().First ().SomeValue);
  Program.SomeValue = 4;
  printf ("%d\n", type.GetCustomAttributes (false).OfType <TestAttribute> ().First ().SomeValue);
  getchar ();
}

Java: 
@Test
public static void Main (String [] args) {
  Method method = typeof (Program).getMethod ("Main");
  Type type = typeof (Program);
  Program.SomeValue = 1;
  System.out.println (method.GetCustomAttributes (false).OfType <TestAttribute> ().First ().SomeValue);
  Program.SomeValue = 2;
  System.out.println (method.GetCustomAttributes (false).OfType <TestAttribute> ().First ().SomeValue);
  Program.SomeValue = 3;
  System.out.println (type.GetCustomAttributes (false).OfType <TestAttribute> ().First ().SomeValue);
  Program.SomeValue = 4;
  System.out.println (type.GetCustomAttributes (false).OfType <TestAttribute> ().First ().SomeValue);
  System.in.read ();
}

