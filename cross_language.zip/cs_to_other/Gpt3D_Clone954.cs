#input 
public static void DrawNormalizedAudio (ref float [] data, PictureBox pb, Color color) {
    Bitmap bmp;
    if (pb.Image == null) {
        bmp = new Bitmap (pb.Width, pb.Height);
    } else {
        bmp = (Bitmap) pb.Image;
    }
    int BORDER_WIDTH = 5;
    int width = bmp.Width - (2 * BORDER_WIDTH);
    int height = bmp.Height - (2 * BORDER_WIDTH);
    using (Graphics g = Graphics.FromImage (bmp))
    {
        g.Clear (Color.Black);
        Pen pen = new Pen (color);
        int size = data.Length;
        for (int iPixel = 0; iPixel < width; iPixel ++) {
            int start = (int) ((float) iPixel * ((float) size / (float) width));
            int end = (int) ((float) (iPixel + 1) * ((float) size / (float) width));
            float min = float.MaxValue;
            float max = float.MinValue;
            for (int i = start; i < end; i ++) {
                float val = data [i];
                min = val < min ? val : min;
                max = val > max ? val : max;
            }
            int yMax = BORDER_WIDTH + height - (int) ((max + 1) *.5 * height);
            int yMin = BORDER_WIDTH + height - (int) ((min + 1) *.5 * height);
            g.DrawLine (pen, iPixel + BORDER_WIDTH, yMax, iPixel + BORDER_WIDTH, yMin);
        }
    } pb.Image = bmp;
}


#====================
#gpt output=============

Python:
def draw_normalized_audio(data, pb, color):
    bmp = None
    if pb.image is None:
        bmp = Bitmap(pb.width, pb.height)
    else:
        bmp = pb.image

    BORDER_WIDTH = 5
    width = bmp.width - (2 * BORDER_WIDTH)
    height = bmp.height - (2 * BORDER_WIDTH)

    with graphics.Graphics.from_image(bmp) as g:
        g.clear(color.black)

        pen = graphics.Pen(color)
        size = len(data)

        for iPixel in range(width):
            start = int(iPixel * (size / width))
            end = int((iPixel + 1) * (size / width))

            min = float('inf')
            max = float('-inf')
            for i in range(start, end):
                val = data[i]
                min = min if min <= val else val
                max = max if max >= val else val

            yMax = BORDER_WIDTH + height - int(((max + 1) * 0.5) * height)
            yMin = BORDER_WIDTH + height - int(((min + 1) * 0.5) * height)

            g.draw_line(pen, iPixel + BORDER_WIDTH, yMax, iPixel + BORDER_WIDTH, yMin)

    pb.image = bmp

C: 
void DrawNormalizedAudio(const float* data, PictureBox* pb, Color color)
{
    Bitmap* bmp;

    if (pb->Image == NULL)
    {
        bmp = new Bitmap(pb->Width, pb->Height);
    }
    else
    {
        bmp = (Bitmap*)pb->Image;
    }

    const int BORDER_WIDTH = 5;
    const int width = bmp->Width - (2 * BORDER_WIDTH);
    const int height = bmp->Height - (2 * BORDER_WIDTH);

    Graphics* g = Graphics::FromImage(bmp);
    g->Clear(Color::Black);
    Pen pen = new Pen(color);
    const size_t size = data.Length;

    for (int iPixel = 0; iPixel < width; iPixel++)
    {
        int start = (int)((float)iPixel * ((float)size / (float)width));
        int end = (int)((float)(iPixel + 1) * ((float)size / (float)width));
        float min = FLT_MAX;
        float max = FLT_MIN;

        for (int i = start; i < end; i++)
        {
            float val = data[i];
            min = val < min ? val : min;
            max = val > max ? val : max;
        }

        int yMax = BORDER_WIDTH + height - (int)((max + 1) * 0.5 * height);
        int yMin = BORDER_WIDTH + height - (int)((min + 1) * 0.5 * height);
        g->DrawLine(pen, iPixel + BORDER_WIDTH, yMax, iPixel + BORDER_WIDTH, yMin);
    }

    pb->Image = bmp;
}

Java: 
public static void drawNormalizedAudio(float[] data, PictureBox pb, Color color) {
        BufferedImage bmp;
        if (pb.getImage() == null) {
            bmp = new BufferedImage(pb.getWidth(), pb.getHeight(), BufferedImage.TYPE_INT_ARGB);
        } else {
            bmp = (BufferedImage) pb.getImage();
        }
        final int BORDER_WIDTH = 5;
        final int width = bmp.getWidth() - (2 * BORDER_WIDTH);
        final int height = bmp.getHeight() - (2 * BORDER_WIDTH);
 
        Graphics2D g = (Graphics2D) bmp.getGraphics();
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, bmp.getWidth(), bmp.getHeight());
        g.setStroke(new BasicStroke(2f));
        g.setColor(color);
        final int size = data.length; 
        for (int iPixel = 0; iPixel < width; iPixel++) {
            int start = (int) (iPixel * (float) (size / width));
            int end = (int) ((iPixel + 1) * (float) (size / width));
            float min = Float.MIN_VALUE;
            float max = Float.MAX_VALUE;
            for (int i = start; i < end; i++) {
                float val = data[i];
                min = (val < min) ? val : min;
                max = (val > max) ? val : max;
            }
            int yMax = BORDER_WIDTH + height - (int) ((max + 1) * 0.5 * height);
            int yMin = BORDER_WIDTH + height - (int) ((min + 1) * 0.5 * height);
            g.drawLine(iPixel + BORDER_WIDTH, yMax, iPixel + BORDER_WIDTH, yMin);
        }
        pb.setImage(bmp);
    }

