#input 
public string IntToString (int a) {
    if (a == 0)
        return "0";
    if (a == int.MinValue)
        return "-2147483648";
    var isNegative = false;
    if (a < 0) {
        a = - a;
        isNegative = true;
    }
    var stack = new Stack < char > ();
    while (a != 0) {
        var c = a % 10 + '0';
        stack.Push ((char) c);
        a /= 10;
    }
    if (isNegative)
        stack.Push ('-');
    return new string (stack.ToArray ());
}


#====================
#gpt output=============

Python:
def IntToString (a):
    if a == 0:
        return "0"
    if a == int.min:
        return "-2147483648"
    isNegative = False
    if a < 0:
        a = -a
        isNegative = True
    stack = []
    while a != 0:
        c = a % 10 + '0'
        stack.append(c)
        a //= 10
    if isNegative:
        stack.append('-')
    return ''.join(stack)

C:
char* IntToString(int a) {
    if (a == 0) 
        return "0";
    if (a == INT_MIN) 
        return "-2147483648"; 
    int isNegative = 0; 
    char stack[50];
    int i = 0; 
    if (a < 0) { 
        isNegative = 1; 
        a = -a; 
    } 
    while (a != 0) { 
        stack[i++] = (a % 10) + '0'; 
        a = a / 10; 
    } 
    if (isNegative == 1) 
        stack[i++] = '-'; 
    stack[i] = '\0'; 
    char* result = (char*)malloc(.sizeof(char) * (strlen(stack) + 1)); 
    strcpy(result, stack);
    reverse(result, strlen(result)); 
    return result; 
} 

Java:
public static String IntToString (int a) {
    if (a == 0)
        return "0";
    if (a == Integer.MIN_VALUE)
        return "-2147483648";
    boolean isNegative = false;
    if (a < 0) {
        a = -a;
        isNegative = true;
    }
    Stack<Character> stack = new Stack<>();
    while (a != 0) {
        int c = a % 10 + '0';
        stack.push((char) c);
        a /= 10;
    }
    if (isNegative) 
        stack.push('-');
    StringBuilder sb = new StringBuilder();
    while (!stack.isEmpty()) {
        sb.append(stack.pop());
    }
    return sb.toString();
}

