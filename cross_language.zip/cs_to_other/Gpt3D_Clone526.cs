#input 
public bool Seq_Check (int [] elems, int k) {
    for (int i = elems.Length; i > 0; i --) {
        if (elems [i] == k) {
            int curr = k - 1;
            for (; i > 0 && curr > 0; i --) {
                if (elems [i] != curr) {
                    if (elems [i] == k) {
                        curr = k - 1;
                        continue;
                    }
                    break;
                }
                curr --;
            }
            if (curr == 0) {
                return true;
            }
        }
    }
    return false;
}


#====================
#gpt output=============



# Python
def Seq_Check(elems, k):
    for i in range(len(elems) - 1, -1, -1):
        if elems[i] == k:
            curr = k - 1
            while i >= 0 and curr >= 0:
                if elems[i] != curr:
                    if elems[i] == k:
                        curr = k - 1
                        continue
                    break
                curr -= 1
            if curr == 0:
                return True
    return False

# C
bool Seq_Check(int elems[], int k) {
    for (int i = sizeof(elems) / sizeof(elems[0]) - 1; i >= 0; i--) {
        if (elems[i] == k) {
            int curr = k - 1;
            for (; i >= 0 && curr >= 0; i--) {
                if (elems[i] != curr) {
                    if (elems[i] == k) {
                        curr = k - 1;
                        continue;
                    }
                    break;
                }
                curr--;
            }
            if (curr == 0) {
                return true;
            }
        }
    }
    return false;
}

# Java
public boolean Seq_Check(int[] elems, int k) {
    for (int i = elems.length - 1; i >= 0; i--) {
        if (elems[i] == k) {
            int curr = k - 1;
            while (i >= 0 && curr >= 0) {
                if (elems[i] != curr) {
                    if (elems[i] == k) {
                        curr = k - 1;
                        continue;
                    }
                    break;
                }
                curr--;
            }
            if (curr == 0) {
                return true;
            }
        }
    }
    return false;
}

