#input 
private static void parallelSpeedTest () {
    Console.ForegroundColor = ConsoleColor.Yellow;
    Console.WriteLine ("parallelSpeedTest");
    long totalObjectsCreated = 0;
    long totalElapsedTime = 0;
    var tasks = new List < Task > ();
    var processorCount = Environment.ProcessorCount;
    Console.WriteLine ("Running on {0} cores", processorCount);
    for (var t = 0; t < processorCount; t ++) {
        tasks.Add (Task.Factory.StartNew (() = > {
            const int reps = 1000000000;
            var sp = Stopwatch.StartNew ();
            for (var j = 0; j < reps; ++ j) {
                new object ();
            }
            sp.Stop ();
            Interlocked.Add (ref totalObjectsCreated, reps);
            Interlocked.Add (ref totalElapsedTime, sp.ElapsedMilliseconds);
        }));
    }
    Task.WaitAll (tasks.ToArray ());
    Console.WriteLine ("Created {0:N} objects in 1 sec\n", (totalObjectsCreated / (totalElapsedTime / processorCount)) * 1000);
}


#====================
#gpt output=============

Python:
def parallelSpeedTest():
    print("parallelSpeedTest")
    total_objects_created = 0
    total_elapsed_time = 0
    tasks = []
    processor_count = os.cpu_count()
    print("Running on {0} cores".format(processor_count))
    for t in range(processor_count):
        tasks.append(threading.Thread(target= lambda: 
        reps = 1000000000
        sp = time.time()
        for j in range(reps):
            object = Object()
        total_objects_created += reps
        total_elapsed_time += time.time() - sp
        ))
    for task in tasks:
        task.start()
    for task in tasks:
        task.join()
    print("Created {0:N} objects in 1 sec\n".format((total_objects_created/(total_elapsed_time/processor_count))*1000))

C: 
void parallelSpeedTest() {
    printf("parallelSpeedTest\n");
    long totalObjectsCreated = 0;
    long totalElapsedTime = 0;
    int processorCount = getProcessorCount();
    printf("Running on %d cores\n", processorCount);
    pthread_t* threads  = malloc(processorCount * sizeof(pthread_t));
    long* threadData = malloc(processorCount * sizeof(long));
    for (int t = 0; t < processorCount; t++) {
        threadData[t] = t;
        pthread_create(&threads[t], NULL, speedTestHelper, (void*) &threadData[t]);
    }
    for (int t = 0; t < processorCount; t++) {
        pthread_join(threads[t], NULL);
    }
    free(threads);
    free(threadData);
    printf("Created %lld objects in 1 sec\n", (totalObjectsCreated / (totalElapsedTime / processorCount)) * 1000);
}

void* speedTestHelper(void* arg) {
    int threadNumber = *(int*) arg;
    int reps = 1000000000;
    struct timespec start;
    clock_gettime(CLOCK_MONOTONIC, &start);
    for (int j = 0; j < reps; ++j) {
        void* obj = malloc(1);
        // Do something with obj
        free(obj);
    }
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    long elapsedTime = (now.tv_sec - start.tv_sec) * 1000 + (now.tv_nsec - start.tv_nsec) / 1000000;
    __sync_fetch_and_add(&totalObjectsCreated, reps);
    __sync_fetch_and_add(&totalElapsedTime, elapsedTime);
    return 0;
}

Java:
private static void parallelSpeedTest() {
    System.out.println("parallelSpeedTest");
    long totalObjectsCreated = 0;
    long totalElapsedTime = 0;
    int processorCount = Runtime.getRuntime().availableProcessors();
    System.out.println("Running on " + processorCount + " cores");
    ExecutorService service = Executors.newFixedThreadPool(processorCount);
    List<Future> tasks = new ArrayList<>();
    for (int t = 0; t < processorCount; t++) {
        tasks.add(service.submit(() -> {
            int reps = 1000000000;
            long start = System.currentTimeMillis();
            for (int j = 0; j < reps; ++j) {
                Object object = new Object();
            }
            totalObjectsCreated += reps;
            totalElapsedTime += System.currentTimeMillis() - start;
        }));
    }

    tasks.forEach(task -> {
        try {
            task.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    });
    service.shutdown();
    System.out.println("Created " + (totalObjectsCreated / (totalElapsedTime / processorCount)) * 1000 + " objects in 1 sec\n");
}

