#input 
public bool Equals (Shape s) {
    int count = 0;
    int [] temp1 = new int [this.coordinate.Length];
    foreach (int x in this.coordinate)
        temp1 [count ++] = x;
    count = 0;
    int [] temp2 = new int [s.coordinate.Length];
    foreach (int x in s.coordinate)
        temp2 [count ++] = x;
    return temp1.SequenceEqual (temp2);
}


#====================
#gpt output=============


//Python 
def Equals(self, s): 
  count = 0
  temp1 = [0]*len(self.coordinates)
  for x in self.coordinates: 
    temp1[count] = x 
    count += 1
  count = 0  
  temp2 = [0]*len(s.coordinates)
  for x in s.coordinates: 
    temp2[count] = x 
    count +=1 
  return temp1 == temp2 


//Java 
public boolean equals(Shape s) {
	int count = 0;
	int[] temp1 = new int[this.coordinate.Length];
	for(int x : this.coordinate) {
		temp1[count] = x;
		count++;
	}
	count = 0;
	int[] temp2 = new int[s.coordinate.Length];
	for(int x : s.coordinate) {
		temp2[count] = x;
		count++;
	}
	return Arrays.equals(temp1, temp2);
}


//C 
bool Equals(Shape *s) 
{ 
    int count = 0; 
    int temp1[this->coordinate.Length]; 
    for (int i = 0; i < this->coordinate.Length; i++){
        temp1[count++] = this->coordinate[i]; 
    }
    count = 0; 
    int temp2[s->coordinate.Length]; 
    for (int i = 0; i < s->coordinate.Length; i++){
        temp2[count++] = s->coordinate[i]; 
    } 
  
    int flag = 1; 
    for (int i = 0; i < this->coordinate.Length; i++)  
    { 
        if (temp1[i] != temp2[i]) 
        { 
            flag = 0; 
            break; 
        } 
    } 
  
    return flag; 
}

