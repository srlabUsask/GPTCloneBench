#input 
private static IEnumerable < int > Approximations (IEnumerable < int > values, int target) {
    int sum = 0;
    bool first = true;
    foreach (var item in values) {
        if (sum + item < target || first) {
            first = false;
            sum += item;
        } else {
            if (sum + item - target < target - sum) {
                yield return sum + item;
                sum = 0;
                first = true;
            } else {
                yield return sum;
                sum = item;
            }
        }
    }
    if (first)
        yield break;
    yield return sum;
}


#====================
#gpt output=============


Python: 
def approximations(values, target):
    summation = 0
    first = True
    for item in values:
        if summation + item < target or first:
            first = False
            summation += item
        else:
            if summation + item - target < target - summation:
                yield summation + item
                summation = 0
                first = True
            else:
                yield summation
                summation = item

    if first:
        yield break
    yield summation



C:
IEnumerable *Approximations(IEnumerable *values, int target) {
    int sum = 0;
    bool first = true;
    while (values->hasNext()) {
        int item = values->next();
        if (sum + item < target || first) {
            first = false;
            sum += item;
        } else {
            if (sum + item - target < target - sum) {
                yield sum + item;
                sum = 0;
                first = true;
            } else {
                yield sum;
                sum = item;
            }
        }
    }

    if (first) {
        yield break;
    } else {
        yield sum;
    }
}


Java:
public static List<Integer> approximations(List<Integer> values, int target) {
    int sum = 0;
    boolean first = true;
    List<Integer> result = new ArrayList<>();
    
    for (int item : values) {
        if (sum + item < target || first) {
            first = false;
            sum += item;
        } else {
            if (sum + item - target < target - sum) {
                result.add(sum + item);
                sum = 0;
                first = true;
            } else {
                result.add(sum);
                sum = item;
            }
        }
    }
    
    if (!first)
        result.add(sum);
    
    return result;
}

