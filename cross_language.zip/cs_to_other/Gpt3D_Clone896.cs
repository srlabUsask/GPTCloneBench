#input 
public void PrintRandom () {
    Random r = new Random ();
    int strLength = r.Next (1, 10);
    var sb = new StringBuilder ();
    for (int i = 0; i < strLength; i ++) {
        int whichType = r.Next (0, 3);
        switch (whichType) {
            case 0 :
                sb.Append ((char) (97 + r.Next (0, 26)));
                break;
            case 1 :
                sb.Append ((char) (65 + r.Next (0, 26)));
                break;
            case 2 :
                sb.Append ((char) (48 + r.Next (0, 10)));
                break;
        }
    }
    Console.WriteLine (sb.ToString ());
    Console.ReadLine ();
}


#====================
#gpt output=============

Python:
import random

def printRandom():
  randomLength = random.randint(1, 10)
  randomString = ""
  for i in range (randomLength):
    whichType = random.randint(0, 2)
    if(whichType == 0):
      randomString += chr(random.randint(97, 122))
    elif (whichType == 1):
      randomString += chr(random.randint(65, 90))
    else:
      randomString += chr(random.randint(48, 57))
  print(randomString)

printRandom()


C: 
#include <stdio.h> 
#include <time.h> 
#include <stdlib.h> 
  
void printRandom() 
{ 
    srand(time(NULL)); 
  
    // Generate random string 
    int randomLength = (rand() % 8) + 1; 
  
    char str[randomLength]; 
  
    int c; 
    for (c = 0; c < randomLength; c++) { 
        int whichType = random() % 3; 
        switch (whichType) { 
        case 0: 
            str[c] = (char) (97 + random() % 26); 
            break; 
        case 1: 
            str[c] = (char)(65 + random() % 26 ); 
            break; 
        case 2: 
            str[c] = (char)(48 + random() % 10); 
            break; 
        } 
    } 
  
    str[c] = '\0'; 
    printf("%s\n", str); 
} 
  
// Driver code 
int main() 
{ 
    printRandom(); 
    return 0; 
} 



Java:
public static void printRandom(){
    Random r = new Random();
    int strLength = r.nextInt(10) + 1;
    StringBuilder sb = new StringBuilder();
    for(int i = 0; i < strLength; i++){
        int whichType = r.nextInt(3);
        switch(whichType){
            case 0:
                sb.append((char)(97 + r.nextInt(26)));
                break;
            case 1:
                sb.append((char)(65 + r.nextInt(26)));
                break;
            case 2:
                sb.append((char)(48 + r.nextInt(10)));
                break;
        }
    }
    System.out.println(sb.toString());
    Scanner in = new Scanner(System.in);
    String read = in.nextLine();
}

