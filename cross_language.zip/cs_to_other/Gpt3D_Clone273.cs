#input 
private static void GetUserData (string userName, UserSession user) {
    using (Entities ctx = CommonSERT.GetContext ())
    {
        var result = (from ur in ctx.datUserRoles
            where ur.AccountName.Equals (userName, StringComparison.CurrentCultureIgnoreCase)
            select new {Active = ur.active, ID = ur.ID,}).FirstOrDefault ();
        if (result != null)
            user.UserActive = result.Active;
        user.UserID = result.ID;
    }}


#====================
#gpt output=============

Python: 
def GetUserData(userName, user):
    ctx = CommonSERT.GetContext()
    result = ctx.datUserRoles.filter(lambda ur: ur.AccountName.equals(userName, case_ignored=True)).first_or_default()
    if result:
        user.UserActive = result.Active
    user.UserID = result.ID
    

Java: 
private static void GetUserData(String userName, UserSession user) {
    try (Entities ctx = CommonSERT.GetContext()) {
        List<datUserRoles> results = ctx.datUserRoles
            .filter(ur -> ur.AccountName.equalsIgnoreCase(userName))
            .collect(Collectors.toList());
        if (!results.isEmpty()) {
            user.UserActive = results.get(0).active;
            user.UserID = results.get(0).ID;
        }
    }
} 

C: 
void GetUserData(char* userName, UserSession* user) {
    Entities* ctx = CommonSERT.GetContext();
    datUserRoles* result = NULL;
    datUserRoles* current;
    for (int n = 0; n < ctx->datUserRolesSize; n++) {
        current = ctx->datUserRoles + n;
        if (strcasecmp(current->AccountName, userName) == 0) {
            result = current;
            break;
        }
    }
    if (result) {
        user->UserActive = result->Active;
        user->UserID = result->ID;
    }
}

