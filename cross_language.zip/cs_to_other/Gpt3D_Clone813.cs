#input 
public static List < Point > ConvexHull (List < Point > points) {
    if (points.Count < 3) {
        throw new ArgumentException ("At least 3 points reqired", "points");
    }
    List < Point > hull = new List < Point > ();
    Point vPointOnHull = points.Where (p = > p.X == points.Min (min = > min.X)).First ();
    Point vEndpoint;
    do
        {
            hull.Add (vPointOnHull);
            vEndpoint = points [0];
            for (int i = 1; i < points.Count; i ++) {
                if ((vPointOnHull == vEndpoint) || (Orientation (vPointOnHull, vEndpoint, points [i]) == - 1)) {
                    vEndpoint = points [i];
                }
            }
            vPointOnHull = vEndpoint;
        } while (vEndpoint != hull [0]);
    return hull;
}


#====================
#gpt output=============

Python
def convex_hull(points):
    if len(points) < 3: 
        raise ValueError("At least 3 points reqired")

    hull = []
    v_point_on_hull = min(points, key = lambda x: x[0])

    v_endpoint = points[0]

    while True: 
        hull.append(v_point_on_hull)

        # find most anti-clockwise point 
        v_endpoint = points[0]
        for i in range(1, len(points)):
            if(v_point_on_hull == v_endpoint or 
            Orientation(v_point_on_hull, v_endpoint, points[i] == -1)):
                v_endpoint = points[i] 
        
        v_point_on_hull = v_endpoint 

        if v_point_on_hull == hull[0]:
            break

    return hull 

C 
List* ConvexHull(List* points) {
    if (points->Count < 3) {
        printf("At least 3 points required");
        exit(1);
    }

    List* hull = creat_list();
    Point* v_point_on_hull = points->min(points, cmp_x);
    Point* v_endpoint;

    do {
        list_add(hull, v_point_on_hull);

        v_endpoint = points->items[0];
        for(int i = 1; i < points->Count; i++) {
            if(v_point_on_hull == v_endpoint ||
               Orientation(v_point_on_hull, v_endpoint, points->items[i]) == -1) {
                v_endpoint = points->items[i];
            }
        }
        v_point_on_hull = v_endpoint;
    } while(v_endpoint != hull->items[0]);

    return hull;
}

Java
public static List < Point > ConvexHull (List < Point > points) {
    if (points.size () < 3) {
        throw new IllegalArgumentException ("At least 3 points reqired", "points");
    }

    List < Point > hull = new ArrayList < Point > ();
    Point vPointOnHull = points.stream().min(Comparator.comparing(Point::getX)).get();
    Point vEndpoint;

    do {
        hull.add (vPointOnHull);
        vEndpoint = points.get(0);
        for (int i = 1; i < points.size(); i ++) {
            if ((vPointOnHull == vEndpoint) 
                || (Orientation(vPointOnHull, vEndpoint, points.get(i)) == - 1)) {
                    vEndpoint = points.get(i);
            }
        }
        vPointOnHull = vEndpoint;
    } while (vEndpoint != hull.get(0));
    return hull;
}

