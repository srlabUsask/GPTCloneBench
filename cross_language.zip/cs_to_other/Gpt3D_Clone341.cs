#input 
public static Image Resize (this Image image, Single scale) {
    if (image == null)
        return null;
    scale = Math.Max (0.0F, scale);
    Int32 scaledWidth = Convert.ToInt32 (image.Width * scale);
    Int32 scaledHeight = Convert.ToInt32 (image.Height * scale);
    return image.Resize (new Size (scaledWidth, scaledHeight));
}


#====================
#gpt output=============

Python implementation:
def resize(image, scale):
    if image is None:
        return None
    scale = max(0.0, scale)
    scaled_width = int(image.width * scale)
    scaled_height = int(image.height * scale)
    return image.resize((scaled_width, scaled_height))

C implementation:
Image * resize (Image *image, float scale) {
    if (image == NULL)
        return NULL;
    scale = fmaxf (0.0f, scale);
    int scaledWidth = (int) (image->width * scale);
    int scaledHeight = (int) (image->height * scale);
    return imageResize (image, scaledWidth, scaledHeight);
}

Java implementation:
public static Image resize(Image image, float scale) {
    if (image == null)
        return null;
	scale = Math.max(0.0F, scale);
    int scaledWidth = (int) (image.width * scale);
    int scaledHeight = (int) (image.height * scale);
    return image.resize(scaledWidth, scaledHeight);
}

