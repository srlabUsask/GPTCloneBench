#input 
private BitmapSource BitmaptoBitmapsource (System.Drawing.Bitmap bitmap) {
    BitmapSource bms;
    IntPtr hBitmap = bitmap.GetHbitmap ();
    BitmapSizeOptions sizeOptions = BitmapSizeOptions.FromEmptyOptions ();
    try {
        bms = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap (hBitmap, IntPtr.Zero, Int32Rect.Empty, sizeOptions);
        bms.Freeze ();
    }
    finally {
        DeleteObject (hBitmap);
    }
    return bms;
}


#====================
#gpt output=============

Python: 
def BitmaptoBitmapsource(bitmap): 
    bms = None
    hBitmap = bitmap.GetHbitmap()
    sizeOptions = BitmapSizeOptions.FromEmptyOptions()
    try: 
        bms = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(hBitmap, IntPtr.Zero, Int32Rect.Empty, sizeOptions)
        bms.Freeze()
    finally: 
        DeleteObject(hBitmap)
    return bms

C: 
BitmapSource BitmaptoBitmapsource(System.Drawing.Bitmap bitmap){
    BitmapSource bms;
    IntPtr hBitmap = bitmap.GetHbitmap();
    BitmapSizeOptions sizeOptions = BitmapSizeOptions.FromEmptyOptions();
    try {
        bms = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(hBitmap, IntPtr.Zero, Int32Rect.Empty, sizeOptions);
        bms.Freeze();
    }
    finally {
        DeleteObject(hBitmap);
    }
    return bms;
}

Java: 
public BitmapSource BitmaptoBitmapsource(System.Drawing.Bitmap bitmap) {
    BitmapSource bms;
    IntPtr hBitmap = bitmap.getHbitmap();
    BitmapSizeOptions sizeOptions = BitmapSizeOptions.FromEmptyOptions();
    try {
        bms = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(hBitmap, IntPtr.Zero, Int32Rect.Empty, sizeOptions);
        bms.Freeze();
    }
    finally {
        DeleteObject(hBitmap);
    }
    return bms;
}

