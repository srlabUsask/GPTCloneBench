#input 
static public bool AddUserToGroup (string user, UserGroup group) {
    var name = new StringBuilder (512);
    var nameSize = (uint) name.Capacity;
    var refDomainName = new StringBuilder (512);
    var refDomainNameSize = (uint) refDomainName.Capacity;
    var sid = new IntPtr ();
    switch (group) {
        case UserGroup.PerformanceMonitorUsers :
            ConvertStringSidToSid ("S-1-5-32-558", out sid);
            break;
        case UserGroup.Administrators :
            ConvertStringSidToSid ("S-1-5-32-544", out sid);
            break;
    }
    SID_NAME_USE sidType;
    if (! LookupAccountSid (null, sid, name, ref nameSize, refDomainName, ref refDomainNameSize, out sidType))
        return false;
    LOCALGROUP_MEMBERS_INFO_3 info;
    info.Domain = user;
    var val = NetLocalGroupAddMembers (null, name.ToString (), 3, ref info, 1);
    return val.Equals (SUCCESS) || val.Equals (ERROR_MEMBER_IN_ALIAS);
}


#====================
#gpt output=============

// Python
import ctypes 
def AddUserToGroup (user, UserGroup): 
    name = ctypes.create_string_buffer(512) 
    nameSize = ctypes.c_uint(name.capacity) 
    refDomainName = ctypes.create_string_buffer(512) 
    refDomainNameSize = ctypes.c_uint(refDomainName.capacity) 
    sid = ctypes.pointer(ctypes.c_int(-1)) 
   
    if UserGroup == UserGroup.PerformanceMonitorUsers: 
        ctypes.windll.advapi32.ConvertStringSidToSidW('S-1-5-32-558', sid) 
    elif UserGroup == UserGroup.Administrators: 
        ctypes.windll.advapi32.ConvertStringSidToSidW('S-1-5-32-544', sid) 
   
    sidType = ctypes.wintypes.DWORD() 
    ctypes.windll.advapi32.LookupAccountSidW(None, sid.contents, name, ctypes.byref(nameSize), refDomainName, ctypes.byref(refDomainNameSize), ctypes.byref(sidType)) 

    info = ctypes.create_string_buffer(user.encode('utf-8')) 
    val = ctypes.windll.netapi32.NetLocalGroupAddMembers(None, name.value, 3, ctypes.byref(info), 1) 
   
    if val == 0: 
        return True 
    elif val == 2221: 
        return True 
    else: 
        return False 

// Java
import com.sun.jna.platform.win32.Advapi32Util;
import com.sun.jna.platform.win32.WinError;
import com.sun.jna.platform.win32.Netapi32;
import com.sun.jna.platform.win32.Sid;
 
public static boolean AddUserToGroup(String user, UserGroup group) {
    StringBuilder name = new StringBuilder(512);
    uint nameSize = (uint) name.capacity();
    StringBuilder refDomainName = new StringBuilder(512);
    uint refDoaminNameSize = (uint) refDomainName.capacity();
    Sid sid = new Sid();
 
    switch (group) {
        case UserGroup.PerformanceMonitorUsers :
            Advapi32Util.ConvertStringSidToSid("S-1-5-32-558", sid);
            break;
        case UserGroup.Administrators :
            Advapi32Util.ConvertStringSidToSid("S-1-5-32-544", sid);
            break;
    }
   Sid.SID_NAME_USE sidType = new Sid.SID_NAME_USE();
   
    if (!Advapi32Util.LookupAccountSid(null, sid, name, nameSize, refDomainName, refDoaminNameSize, sidType))
        return false;
   
    Netapi32.LOCALGROUP_MEMBERS_INFO_3 info = new Netapi32.LOCALGROUP_MEMBERS_INFO_3(user);
    int val = Netapi32.INSTANCE.NetLocalGroupAddMembers(null, name.toString(), 3, info, 1);
    return (val == WinError.ERROR_SUCCESS || val == WinError.ERROR_MEMBER_IN_ALIAS);
}

// C
#include <windows.h>
#include <stdio.h>
#include <lmaccess.h>

bool Winapi AddUserToGroup(char * user, UserGroup group)  
{
    char name[512]; 
    DWORD nameSize = sizeof(name); 
    char refDomainName[512]; 
    DWORD refDomainNameSize = sizeof(refDomainName); 
    PSID sid; 
    SID_NAME_USE sidType; 

    switch (group)  
    {
        case PerformanceMonitorUsers: 
            ConvertStringSidToSid("S-1-5-32-558", &sid); 
            break; 
        case Administrators: 
            ConvertStringSidToSid("S-1-5-32-544", &sid); 
            break; 
    }

    LookupAccountSid(NULL, sid, name, &nameSize, refDomainName, &refDomainNameSize, &sidType); 

    LOCALGROUP_MEMBERS_INFO_3 info; 
    info.Domain = user; 
    DWORD val = NetLocalGroupAddMembers(NULL, name, 3, &info, 1); 

    return (val == NETWORK_STATUS_SUCCESS || val == ERROR_MEMBER_IN_ALIAS); 
}

