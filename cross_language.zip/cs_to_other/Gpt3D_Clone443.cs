#input 
private static void Main (string [] args) {
    Thread t = new Thread (ReaderFunc);
    t.Start ();
    int index = 0;
    while (! StopWriting.WaitOne (Timeout.Infinite)) {
        ++ index;
        Console.WriteLine (index.ToString ());
    }
    t.Join ();
}


#====================
#gpt output=============

Python:
import threading
StopWriting = threading.Event()

def ReaderFunc():
    print("ReaderFunc")

def Main(args):
    t = threading.Thread(target=ReaderFunc)
    t.start()
    index = 0
    while not StopWriting.wait(timeout=None):
        index += 1
        print(str(index))
    t.join()

C:
#include <stdio.h>
#include <pthread.h>
pthread_cond_t StopWriting;

void* ReaderFunc(void* args) {
printf("ReaderFunc\n");
}

int Main(int argc, char** argv) {
pthread_t t;
pthread_create(&t, NULL, ReaderFunc, NULL);
int index = 0;
while(!pthread_cond_wait(&StopWriting, NULL)) {
index++;
printf("%d\n", index);
}
pthread_join(t, NULL);
return 0;
}

Java:
import java.util.concurrent.TimeUnit;

public class Main {
    private static Thread t;
    private static int index = 0;
    private static boolean StopWriting = false;

    private static void ReaderFunc() {
        System.out.println("ReaderFunc");
    }

    public static void main(String[] args) {
        t = new Thread(Main::ReaderFunc);
        t.start();
        while (!StopWriting) {
            index++;
            System.out.println(String.valueOf(index));
        }
        try {
            t.join(TimeUnit.SECONDS.toMillis(20));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            e.printStackTrace();
        }
    }
}

