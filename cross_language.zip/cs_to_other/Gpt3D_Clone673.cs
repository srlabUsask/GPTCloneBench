#input 
public static DateTime AddBusinessDays (this DateTime date, int days) {
    date = date.AddDays ((days / 5) * 7);
    int remainder = days % 5;
    switch (date.DayOfWeek) {
        case DayOfWeek.Tuesday :
            if (remainder > 3)
                date = date.AddDays (2);
            break;
        case DayOfWeek.Wednesday :
            if (remainder > 2)
                date = date.AddDays (2);
            break;
        case DayOfWeek.Thursday :
            if (remainder > 1)
                date = date.AddDays (2);
            break;
        case DayOfWeek.Friday :
            if (remainder > 0)
                date = date.AddDays (2);
            break;
        case DayOfWeek.Saturday :
            if (days > 0)
                date = date.AddDays ((remainder == 0) ? 2 : 1);
            break;
        case DayOfWeek.Sunday :
            if (days > 0)
                date = date.AddDays ((remainder == 0) ? 1 : 0);
            break;
        default :
            break;
    }
    return date.AddDays (remainder);
}


#====================
#gpt output=============

Python:
def add_business_days(date, days):
    date += (days // 5) * 7
    remainder = days % 5
    if date.weekday() == 1:
        if remainder > 3:
            date += 2
    elif date.weekday() == 2:
        if remainder > 2:
            date += 2
    elif date.weekday() == 3:
        if remainder > 1:
            date += 2
    elif date.weekday() == 4:
        if remainder > 0:
            date += 2
    elif date.weekday() == 5:
        if days > 0:
            date += (1 if remainder == 0 else 2)
    elif date.weekday() == 6:
        if days > 0:
            date += (2 if remainder == 0 else 1)

    return date + remainder

C:
DateTime add_business_days(DateTime date, int days) {
    date = date + ((days / 5) * 7);
    int remainder = days % 5;

    switch (date.dayOfWeek) {
        case DayOfWeek.tuesday: 
            if (remainder > 3)
                date = date + 2;
            break;
        case DayOfWeek.wednesday: 
            if (remainder > 2)
                date = date + 2;
            break;
        case DayOfWeek.thursday: 
            if (remainder > 1)
                date = date + 2;
            break;
        case DayOfWeek.friday: 
            if (remainder > 0)
                date = date + 2;
            break;
        case DayOfWeek.saturday: 
            if (days > 0)
                date = date + (1 * (remainder == 0)) + 2 * (remainder != 0);
            break;
        case DayOfWeek.sunday: 
            if (days > 0)
                date = date + (2 * (remainder == 0)) + 1 * (remainder != 0);
            break;
        default: //None of the above
            break;
    }
    return date + remainder;
}

Java:
public static DateTime addBusinessDays(DateTime date, int days) {
    date = date.addDays((days / 5) * 7);
    int remainder = days % 5;
    switch (date.dayOfWeek) {
        case DayOfWeek.TUESDAY:
            if (remainder > 3)
                date = date.addDays(2);
            break;
        case DayOfWeek.WEDNESDAY:
            if (remainder > 2)
                date = date.addDays(2);
            break;
        case DayOfWeek.THURSDAY:
            if (remainder > 1)
                date = date.addDays(2);
            break;
        case DayOfWeek.FRIDAY:
            if (remainder > 0)
                date = date.addDays(2);
            break;
        case DayOfWeek.SATURDAY:
            if (days > 0)
                date = date.addDays((remainder == 0) ? 2 : 1);
            break;
        case DayOfWeek.SUNDAY:
            if (days > 0)
                date = date.addDays((remainder == 0) ? 1 : 0);
            break;
        default:
            break;
    }
    return date.addDays(remainder);
}

