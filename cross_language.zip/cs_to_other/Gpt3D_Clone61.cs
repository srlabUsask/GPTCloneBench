#input 
static bool Check2DArray (int [,] data, int [,] find) {
    int dataLen = data.Length;
    int findLen = find.Length;
    for (int i = 0; i < dataLen; i ++) {
        int dataX = i % data.GetLength (0);
        int dataY = i / data.GetLength (0);
        bool okay = true;
        for (int j = 0; j < findLen && okay; j ++) {
            int findX = j % find.GetLength (1);
            int findY = j / find.GetLength (1);
            int checkedX = findX + dataX;
            int checkedY = findY + dataY;
            if (checkedX >= data.GetLength (0) || checkedY >= data.GetLength (1)) {
                okay = false;
                break;
            }
            okay = data [dataY + findY, dataX + findX] == find [findY, findX];
        }
        if (okay)
            return true;
    }
    return false;
}


#====================
#gpt output=============

Python:
def Check2DArray(data, find):
    data_len = len(data)
    find_len = len(find)
    for i in range(data_len):
        data_x = i % len(data[0])
        data_y = i // len(data[0])
        okay = True
        for j in range(find_len) and okay:
            find_x = j % len(find[0])
            find_y = j // len(find[0])
            checked_x = find_x + data_x
            checked_y = find_y + data_y
            if checked_x >= len(data[0]) or checked_y >= len(data):
                okay = False
                break
            okay = data[data_y + find_y][data_x + find_x] == find[find_y][find_x]
        if okay:
            return True
    return False


C: 
bool Check2DArray (int data[], int find[], int data_len, int find_len) {
    int data_x, data_y, find_x, find_y, checked_x, checked_y;
    bool okay = true;
    for (int i = 0; i < data_len; i ++) {
        data_x = i % (sizeof(data) / data_len);
        data_y = i / (sizeof(data) / data_len);
        for (int j = 0; j < find_len && okay; j ++) {
            find_x = j % (sizeof(find) / find_len);
            find_y = j / (sizeof(find) / find_len);
            checked_x = find_x + data_x;
            checked_y = find_y + data_y;
            if (checked_x >= (sizeof(data) / data_len) || checked_y >= (sizeof(data) / data_len)) {
                okay = false;
                break;
            }
            okay = data[(data_y + find_y) * (sizeof(data) / data_len) + data_x + find_x] == find[(find_y * (sizeof(find) / find_len) + find_x]
        }
        if (okay)
            return true;
    }
    return false;
}

Java:
public static boolean Check2DArray (int[][] data, int[][] find) {
    int dataLen = data.length;
    int findLen = find.length;
    for (int i = 0; i < dataLen; i ++) {
        int dataX = i % data.length;
        int dataY = i / data.length;
        boolean okay = true;
        for (int j = 0; j < findLen && okay; j ++) {
            int findX = j % find.length;
            int findY = j / find.length;
            int checkedX = findX + dataX;
            int checkedY = findY + dataY;
            if (checkedX >= data.length || checkedY >= data.length) {
                okay = false;
                break;
            }
            okay = data [dataY + findY][dataX + findX] == find [findY][findX];
        }
        if (okay)
            return true;
    }
    return false;
}

