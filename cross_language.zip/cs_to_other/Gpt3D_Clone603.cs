#input 
private void CheckIfPalindrome (string str) {
    char [] array = str.ToCharArray ();
    int length = array.Length - 1;
    Boolean palindrome = true;
    for (int i = 0; i <= length; i ++) {
        if (array [i] != array [length]) {
            MessageBox.Show ("not");
            palindrome = false;
            break;
        } else {
            length --;
        }
    }
    if (palindrome)
        MessageBox.Show ("Palindrome");
}


#====================
#gpt output=============

//PYTHON
def checkIfPalindrome(str): 
	array = list(str) 
	length = len(array) - 1
	isPalindrome = True
	for i in range(0, length + 1): 
		if array[i] != array[length]: 
			print("not")
			isPalindrome = False
			break
		else: 
			length -= 1
	if isPalindrome: 
		print('Palindrome') 
		
	
//C
void checkIfPalindrome(char str[]) { 
	int i, length; 

	length = strlen(str) - 1;  

	int isPalindrome = 1; 
	for (i = 0; i <= length; i++) { 
		if (str[i] != str[length]) {    
			printf("not"); 
			isPalindrome = 0; 
			break; 
		} 
		else 
			length--; 
	} 

	if (isPalindrome) 
		printf("Palindrome"); 
}

//JAVA
public void CheckIfPalindrome(String str) {
    char[] array = str.toCharArray();
    int length = array.length - 1;
    boolean palindrome = true;

    for (int i = 0; i <= length; i++) {
        if (array[i] != array[length]) {
            System.out.println("not");
            palindrome = false;
            break;
        } else {
            length--;
        }
    }

    if (palindrome)
        System.out.println("Palindrome");
}

