#input 
static void Main (string [] args) {
    unpack ();
    Process process = new Process ();
    process.StartInfo.FileName = "exe1.exe";
    process.Start ();
    process.WaitForExit ();
    process = new Process ();
    process.StartInfo.FileName = "exe2.exe";
    process.Start ();
    process.WaitForExit ();
    process = new Process ();
    process.StartInfo.FileName = @"C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe";
    process.StartInfo.Arguments = "ps1.ps1";
    process.Start ();
    process.WaitForExit ();
}


#====================
#gpt output=============

Python:
def unpack():
    pass

proc1 = subprocess.Popen("exe1.exe")
proc1.wait()

proc2 = subprocess.Popen("exe2.exe")
proc2.wait()

proc3 = subprocess.Popen([r'C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe', 'ps1.ps1'])
proc3.wait()


C:
void unpack (void) {}

int main (int argc, char *argv[]) {
    int retval;
    const char *exe1Path = "exe1.exe";
    char *args[] = {"exe1.exe", NULL};
    retval = fork();
    if (retval == 0) {
        execvp(exe1Path, args);
    }
    wait(NULL);
    
    const char *exe2Path = "exe2.exe";
    args[0] = "exe2.exe";
    retval = fork();
    if (retval == 0) {
        execvp(exe2Path, args);
    }
    wait(NULL);
    
    const char *psPath = "C:\\Windows\\SysWOW64\\WindowsPowerShell\\v1.0\\powershell.exe";
    args[0] = "C:\\Windows\\SysWOW64\\WindowsPowerShell\\v1.0\\powershell.exe";
    args[1] = "ps1.ps1";
    retval = fork();
    if (retval == 0) {
        execvp(psPath, args);
    }
    wait(NULL);
    
    return 0;
}


Java:
public static void unpack(){}

public static void main(String[] args){
    try {
        Process p1 = Runtime.getRuntime().exec("exe1.exe");
        p1.waitFor();

        Process p2 = Runtime.getRuntime().exec("exe2.exe");
        p2.waitFor();

        String psPath = "C:\\Windows\\SysWOW64\\WindowsPowerShell\\v1.0\\powershell.exe";
        String[] psArgs = {"ps1.ps1"};
        Process p3 = Runtime.getRuntime().exec(psPath, psArgs);
        p3.waitFor();
    }catch(Exception e){
        System.out.println(e.getMessage());
    }
}

