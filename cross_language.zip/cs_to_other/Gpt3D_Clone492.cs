#input 
static public void HideColumn (GridView gv, int columnIndex) {
    if (gv.HeaderRow != null)
        gv.HeaderRow.Cells [columnIndex].Style.Add ("display", "none");
    foreach (GridViewRow row in gv.Rows) {
        if (row.RowType == DataControlRowType.DataRow)
            row.Cells [columnIndex].Style.Add ("display", "none");
    }
}


#====================
#gpt output=============

// Python 
def HideColumn(gv, columnIndex): 
    if(gv.HeaderRow != None):
        gv.HeaderRow.Cells[columnIndex].Style.Add("display", "none")
    for row in gv.Rows: 
        if(row.RowType == DataControlRowType.DataRow):
            row.Cells[columnIndex].Style.Add("display", "none")

// Java 
public static void HideColumn(GridView gv, int columnIndex) { 
    if(gv.getHeaderRow() != null) 
        gv.getHeaderRow().getCells()[columnIndex].getStyle().add("display", "none");
    for (GridViewRow row : gv.getRows()) { 
        if(row.getRowType() == DataControlRowType.DataRow)
            row.getCells()[columnIndex].getStyle().add("display", "none");
    }
    
    
// C 
void HideColumn (GridView *gv, int columnIndex) {
    if ( gv->HeaderRow != NULL )
        gv->HeaderRow->Cells[columnIndex].Style.Add("display", "none");
    for (int i = 0; i < gv->Rows->length; i++) {
        GridViewRow row = gv->Rows[i];
        if ( row->RowType == DataControlRowType.DataRow)
            row->Cells[columnIndex].Style.Add("display", "none");
    }
}

