#input 
static void Main (string [] args) {
    Console.WriteLine ("Add First:");
    LinkedList myList1 = new LinkedList ();
    myList1.AddFirst ("Hello");
    myList1.AddFirst ("Magical");
    myList1.AddFirst ("World");
    myList1.printAllNodes ();
    Console.WriteLine ();
    Console.WriteLine ("Add Last:");
    LinkedList myList2 = new LinkedList ();
    myList2.AddLast ("Hello");
    myList2.AddLast ("Magical");
    myList2.AddLast ("World");
    myList2.printAllNodes ();
    Console.ReadLine ();
}


#====================
#gpt output=============

//Python
def main(args): 
    print("Add First:") 
    myList1 = LinkedList() 
    myList1.add_first("Hello") 
    myList1.add_first("Magical") 
    myList1.add_first("World") 
    myList1.print_all_nodes() 
    print() 
    print("Add Last:") 
    myList2 = LinkedList() 
    myList2.add_last("Hello") 
    myList2.add_last("Magical") 
    myList2.add_last("World") 
    myList2.print_all_nodes() 
    input() 
 
 
//C
void main (char *args[]){
	printf("Add First:");
	LinkedList myList1 = newLinkedList() ;
    addFirst(myList1, "Hello");
    addFirst(myList1, "Magical");
    addFirst(myList1, "World");
    printAllNodes(myList1);
    printf("\n");
    printf("Add Last:");
    LinkedList myList2 = newLinkedList() ;
    addLast(myList2, "Hello");
    addLast(myList2, "Magical");
    addLast(myList2, "World");
    printAllNodes(myList2);
    scanf("");
}
 
 
//Java
public static void main(String[] args) {
    System.out.println("Add First:");
    LinkedList myList1 = new LinkedList();
    myList1.addFirst("Hello");
    myList1.addFirst("Magical");
    myList1.addFirst("World");
    myList1.printAllNodes();
    System.out.println();
    System.out.println("Add Last:");
    LinkedList myList2 = new LinkedList();
    myList2.addLast("Hello");
    myList2.addLast("Magical");
    myList2.addLast("World");
    myList2.printAllNodes();
    Scanner sc = new Scanner(System.in);
    sc.nextLine();
}

