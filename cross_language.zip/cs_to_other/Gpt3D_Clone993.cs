#input 
public static IDictionary < string, object > ToDictionary (this JObject @object) {
    var result = @object.ToObject < Dictionary < string, object > > ();
    var JObjectKeys = (from r in result
        let key = r.Key
        let value = r.Value
        where value.GetType () == typeof (JObject)
        select key).ToList ();
    var JArrayKeys = (from r in result
        let key = r.Key
        let value = r.Value
        where value.GetType () == typeof (JArray)
        select key).ToList ();
    JArrayKeys.ForEach (key = > result [key] = ((JArray) result [key]).Values ().Select (x = > ((JValue) x).Value).ToArray ());
    JObjectKeys.ForEach (key = > result [key] = ToDictionary (result [key] as JObject));
    return result;
}


#====================
#gpt output=============

Python:
def ToDictionary(obj):
    result = dict(obj)
    JObjectKeys = [key for key, value in result.items() if type(value) == dict]
    JArrayKeys = [key for key, value in result.items() if type(value) == list]
    for key in JArrayKeys:
        result[key] = [v.value for v in result[key]]
    for key in JObjectKeys:
        result[key] = ToDictionary(result[key])
    return result

C:
IDictionary<string, object> ToDictionary(JObject* object) 
{
	Dictionary<string, object> result = (Dictionary<string, object>)object;
	List<string> JObjectKeys;
	List<string> JArrayKeys;

	foreach (var item in result) {
		string key = item.Key;
		object value = item.Value;
		if (value.getType() == typeof(JObject)) 
			JObjectKeys.add(key);
		if (value.getType() == typeof(JArray))
			JArrayKeys.add(key);
	}
	
	for (int i = 0; i < JArrayKeys.size(); ++i) 
	{
		List<object> values;
		JArray values_in_JArray = (JArray)result[JArrayKeys[i]];
		for (int j = 0; j < values.size(); ++j) 
			values.add(values_in_JArray[j].value);
		result[JArrayKeys[i]] = values;
	}

	for (int i = 0; i < JObjectKeys.size(); ++i) 
		result[JObjectKeys[i]] = ToDictionary((JObject)result[JObjectKeys[i]]);

	return result;
}

Java:
public static Map<String, Object> toDictionary(JObject object) 
{
    Map<String, Object> result = object.toObject(new HashMap<String, Object>());
    List<String> JObjectKeys = new ArrayList<String>();
    List<String> JArrayKeys = new ArrayList<String>();

    for (Map.Entry<String, Object> r : result.entrySet()) 
    {
        String key = r.getKey();
        Object value = r.getValue();
        if (value instanceof JObject)
            JObjectKeys.add(key);
        if (value instanceof JArray)
            JArrayKeys.add(key);
    }

    for (String key : JArrayKeys) 
    {
        JArray valuesInJArray = (JArray) result.get(key);
        Object[] values = new Object[valuesInJArray.size()];
        for (int i = 0; i < values.length; i++) 
            values[i] = ((JValue) valuesInJArray.get(i)).value;
        result.put(key, values);
    }

    for (String key : JObjectKeys) 
        result.put(key, toDictionary((JObject) result.get(key)));

    return result;
}

