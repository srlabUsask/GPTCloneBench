#input 
private Bitmap RotateImage (Bitmap bmp, float angle) {
    Bitmap rotatedImage = new Bitmap (bmp.Width, bmp.Height);
    using (Graphics g = Graphics.FromImage (rotatedImage))
    {
        g.TranslateTransform (bmp.Width / 2, bmp.Height / 2);
        g.RotateTransform (angle);
        g.TranslateTransform (- bmp.Width / 2, - bmp.Height / 2);
        g.DrawImage (bmp, new Point (0, 0));
    } return rotatedImage;
}


#====================
#gpt output=============

Python:
def rotate_image(bmp, angle):
    rotated_image = Image.new('RGB', (bmp.width, bmp.height))
    rotated_image.paste(bmp)
    rotated_image = rotated_image.rotate(angle)
    return rotated_image

C:
Bitmap* rotate_image(Bitmap* bmp, float angle) {
    if (!bmp) return NULL;

    Bitmap* rotatedImage = new Bitmap (bmp->width, bmp->height);
    if (!rotatedImage) return NULL;

    Graphics g (rotatedImage);
    g.TranslateTransform (bmp->width / 2, bmp->height / 2);
    g.RotateTransform (angle);
    g.TranslateTransform (- bmp->width / 2, - bmp->height / 2);
    g.DrawImage (bmp, 0, 0);
    return rotatedImage;
}

Java:
Bitmap rotateImage(Bitmap bmp, float angle) {
    Bitmap rotatedImage = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(rotatedImage);
    Matrix matrix = new Matrix();
    matrix.postTranslate(bmp.getWidth()/2, bmp.getHeight()/2);
    matrix.postRotate(angle);
    matrix.postTranslate(-bmp.getWidth()/2, -bmp.getHeight()/2);
    canvas.drawBitmap(bmp, matrix, null);
    return rotatedImage;
}

