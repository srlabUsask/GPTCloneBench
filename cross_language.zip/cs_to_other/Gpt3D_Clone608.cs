#input 
public static T Map < T > (Dictionary < string, string > dictionary) where T : class, new () {
    var obj = new T ();
    var properties = typeof (T).GetProperties ();
    foreach (var item in dictionary) {
        var prop = properties.FirstOrDefault (p = > p.Name.Equals (item.Key, StringComparison.InvariantCultureIgnoreCase));
        if (prop != null)
            prop.SetValue (obj, item.Value, null);
    }
    return obj;
}


#====================
#gpt output=============

Python: 
def map[T](dictionary: dict) -> T:
    obj = T()
    properties = obj.__class__.__dict__

    for item in dictionary:
        prop = properties.get(item.key, None)
        if prop is not None:
            setattr(obj, prop, item.value)
    return obj


C: 
T* map(Dictionary *dictionary) {
    T *obj = calloc(1, sizeof(T)); // Creates the object 
    Property **properties = typeof(T)->getProperties();

    for (size_t i = 0; i < dictionary->num_entries; i++) {
      Property *prop = NULL;

      for (size_t j = 0; j < properties->length && prop == NULL; j++) {
        // Compares ignoring case 
        if (strcasecmp(properties[j]->name, dictionary->entries[i]->key) == 0) {
          prop = properties[j];
        }
      }

      if (prop) { // If property is found 
        prop->setValue(obj, dictionary->entries[i]->value, 0); // Sets the value 
      }
  }

  return obj;
}


Java:
public static<T> T map(Dictionary<String, String> dictionary) throws Exception {
  T obj = (T) Class.forName(T.class.getName()).newInstance();
  PropertyDescriptor[] properties = Introspector.getBeanInfo(obj.getClass()).getPropertyDescriptors();

  for (Map.Entry<String, String> entry : dictionary.entrySet()) {
    for (PropertyDescriptor descriptor : properties) {
      if (descriptor.getName().equalsIgnoreCase(entry.getKey())) {
        descriptor.getWriteMethod().invoke(obj, entry.getValue());
      }
    }
  }

  return obj;
}

