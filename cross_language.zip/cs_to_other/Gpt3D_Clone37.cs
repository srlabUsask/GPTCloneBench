#input 
public static DateTime AddBusinessDays (this DateTime current, int days) {
    var sign = Math.Sign (days);
    var unsignedDays = Math.Abs (days);
    for (var i = 0; i < unsignedDays; i ++) {
        do
            {
                current = current.AddDays (sign);
            } while (current.DayOfWeek == DayOfWeek.Saturday || current.DayOfWeek == DayOfWeek.Sunday);
    }
    return current;
}


#====================
#gpt output=============

Python
def add_business_days(current, days):
    import datetime
    sign = int(days/abs(days))
    unsigned_days = abs(days)
    for i in range(unsigned_days):
        while (datetime.date(current).weekday() == 5 or
               datetime.date(current).weekday() == 6):
            current = (
                current.date() +
                datetime.timedelta(days=sign)
            )
    return current
    
C
DateTime add_business_days(this DateTime current, int days) {
  int sign = (days < 0) ? -1 : 1;
  int unsigned_days = abs(days);
  
  for(int i = 0; i < unsigned_days; ++i) {
    while(weekday(current) == 6 || weekday(current) == 0) 
      current = add_days(current, sign);
  }
  return current;
}

Java 
public static DateTime addBusinessDays(this DateTime current, int days) {
  int sign = Math.signum(days);
  int unsignedDays = Math.abs(days);

  for (int i = 0; i < unsignedDays; i++) {
    while (current.getDayOfWeek() == DayOfWeek.SATURDAY || current.getDayOfWeek() == DayOfWeek.SUNDAY) {
        current = current.plusDays(sign);
    }
  }
  return current;
}

