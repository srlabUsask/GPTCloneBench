#input 
static void Main (string [] args) {
    DataTable Matrix = new DataTable ();
    Matrix.TableName = "Matrix";
    Matrix.Columns.Add (new DataColumn (MakeStringBeutiful ("Name")));
    Matrix.Columns.Add (new DataColumn (MakeStringBeutiful ("1 England")));
    Matrix.Columns.Add (new DataColumn (MakeStringBeutiful ("2 Germany")));
    Matrix.Columns.Add (new DataColumn (MakeStringBeutiful ("3 France ")));
    Matrix.Rows.Add ("1 England", "    x    ", "         ", "         ");
    Matrix.Rows.Add ("2 Germany", "         ", "    x    ", "         ");
    Matrix.Rows.Add ("3 France ", "         ", "         ", "    x    ");
    PrintMatrix (Matrix);
    Console.WriteLine ("Enter column number:");
    string sx = Console.ReadLine ();
    int x = int.Parse (sx);
    Console.WriteLine ("Enter row number:");
    string sy = Console.ReadLine ();
    int y = int.Parse (sy);
    Console.WriteLine ("Enter value:");
    string v = Console.ReadLine ();
    SetValue (x, y, v, Matrix);
    PrintMatrix (Matrix);
    Console.ReadLine ();
}


#====================
#gpt output=============

Python
def main(args):
    matrix = []
    columnHeadings = ["Name", "1 England", "2 Germany", "3 France"]
    matrix.append(columnHeadings)
    matrix.append(["1 England", "    x    ", "         ", "         "])
    matrix.append(["2 Germany", "         ", "    x    ", "         "])
    matrix.append(["3 France ", "         ", "         ", "    x    "])
    print_matrix(matrix)

    x = int(input("Enter column number: "))
    y = int(input("Enter row number: "))
    v = input("Enter value: ")
    set_value(x, y, v, matrix)
	print_matrix(matrix)
	

def print_matrix(matrix):
    for row in matrix:
        print(" ".join(row))
	

def set_value(x, y, v, matrix):
    matrix[y][x] = v


C
void main(int argc, char **argv) { 
    DataTable* Matrix = createDataTable("Matrix"); 
    addDataColumn(Matrix, makeStringBeutiful("Name")); 
    addDataColumn(Matrix, makeStringBeutiful("1 England")); 
    addDataColumn(Matrix, makeStringBeutiful("2 Germany")); 
    addDataColumn(Matrix, makeStringBeutiful("3 France")); 
    addDataRow(Matrix, "1 England", "    x    ", "         ", "         "); 
    addDataRow(Matrix, "2 Germany", "         ", "    x    ", "         "); 
    addDataRow(Matrix, "3 France", "         ", "         ", "    x    "); 
    printMatrix(Matrix);    
    printf("Enter column number: "); 
    int x; 
    scanf("%d", &x); 
    printf("Enter row number: "); 
    int y; 
    scanf("%d", &y); 
    printf("Enter value: "); 
    int v; 
    scanf("%d", &v); 
    setValue(x, y, v, Matrix); 
    printMatrix(Matrix); 
    getchar(); 
} 



Java
public static void main(String[] args) { 
    DataTable matrix = new DataTable();
    matrix.setTableName("Matrix");
    matrix.addColumn(makeStringBeautiful("Name"))
    matrix.addColumn(makeStringBeautiful("1 England"))
    matrix.addColumn(makeStringBeautiful("2 Germany"))
    matrix.addColumn(makeStringBeautiful("3 France"))
    matrix.addRow("1 England", "    x    ", "         ", "         ");
    matrix.addRow("2 Germany", "         ", "    x    ", "         ");
    matrix.addRow("3 France", "         ", "         ", "    x    ");
    printMatrix(matrix);
    System.out.println("Enter column number:");
    int x = Integer.parseInt(System.console().readLine());
    System.out.println("Enter row number:");
    int y = Integer.parseInt(System.console().readLine());
    System.out.println("Enter value:");
    String v = System.console().readLine();
    setValue(x, y, v, matrix);
    printMatrix(matrix);
}

