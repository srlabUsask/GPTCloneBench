#input 
public string Insert () {
    string conStr = @"Data Source=ZARAK\SQLEXPRESS;Initial Catalog=ProjectDAL;integrated security=true";
    int queryResult = 0;
    try {
        string querySQL = "Insert INTO tbl_User(Name,Email,Password)VALUES(@name,@email,@password)";
        using (SqlConnection Conn = new SqlConnection (conStr))
        {
            using (SqlCommand cmd = new SqlCommand (querySQL, Conn))
            {
                cmd.Parameters.Add ("@name", SqlDbType.VarChar).Value = Name;
                cmd.Parameters.Add ("@email", SqlDbType.VarChar).Value = email;
                cmd.Parameters.Add ("@password", SqlDbType.VarChar).Value = password;
                queryResult = cmd.ExecuteNonQuery ();
            }} return queryResult + "Record/s Inserted successfully!";
    }
    catch (SqlException ex) {
        if (ex.Number == 2627) {
            return "Record Already Exists";
        }
        return "Some other error";
    }
}


#====================
#gpt output=============

Python implementation:
def Insert():
    conStr = 'Data Source=ZARAK\SQLEXPRESS;Initial Catalog=ProjectDAL;integrated security=true'
    queryResult = 0
    try:
        querySQL = 'Insert INTO tbl_User(Name,Email,Password)VALUES(%s,%s,%s)'
        
        Conn = sqlite3.connect('ProjectDAL')
        cursor = Conn.cursor()
        queryResult = cursor.execute(querySQL, (Name, email, password)).rowcount
        
        Conn.commit()
        return queryResult + 'Record/s Inserted successfully!'
    except sqlite3.IntegrityError as e:
        if e.args[0] == 'UNIQUE constraint failed':
            return 'Record Already Exists'
        return 'Some other error'

Java implementation:
public String Insert() {
    String conStr = "Data Source=ZARAK\\SQLEXPRESS;Initial Catalog=ProjectDAL;integrated security=true";
    int queryResult = 0;
    try {
        String querySQL = "Insert INTO tbl_User(Name,Email,Password)VALUES(?,?,?)";
        Class.forName("com.mysql.jdbc.Driver");
        
        Connection Conn = DriverManager.getConnection(conStr);
        PreparedStatement stmt = Conn.prepareStatement(querySQL);
        stmt.setString(1, Name);
        stmt.setString(2, email);
        stmt.setString(3, password);
        queryResult = stmt.executeUpdate();
        Conn.close();
        return queryResult + "Record/s Inserted successfully!";
    } catch (SQLException e) {
        if(e.getErrorCode() == 2627) {
             return "Record Already Exists";
        }
        return "Some other error";
    } catch (ClassNotFoundException e) {
        return "Class not Found Exception";
        }
} 

C implementation:
char *Insert()
{
    char *conStr = "Data Source=ZARAK\\SQLEXPRESS;Initial Catalog=ProjectDAL;integrated security=true";
    int queryResult = 0;
    try 
    {
        char *querySQL = "Insert INTO tbl_User(Name,Email,Password)VALUES(@name,@email,@password)";
        sqlite3 *db;
        int retCode = sqlite3_open_v2(conStr, &db, SQLITE_OPEN_READWRITE, NULL);
        if (retCode) 
        {
            //handling the correct error message
        } 
        else 
        {
            char *sql;
            int r = sqlite3_prepare_v2(db, querySQL, strlen(querySQL), &sql, NULL);
            if (r) 
            {
                //handling the correct error message
            } 
            else 
            {
                //Binding the parameters in sql query
                sqlite3_bind_text(sql, 1, Name, -1, SQLITE_TRANSIENT);
                sqlite3_bind_text(sql, 2, email, -1, SQLITE_TRANSIENT);
                sqlite3_bind_text(sql, 3, password, -1, SQLITE_TRANSIENT);
                queryResult = sqlite3_step(sql);
                sqlite3_finalize(sql);
                sqlite3_close(db);
            }
            return queryResult + "Record/s Inserted successfully!";
        }
    } 
    catch (SQLException e) 
    {
        if (e.getErrorCode() == 2627) 
        {
            return "Record Already Exists";
        }
        return "Some other error";
    }
}

