#input 
public static bool IsPowerOfTwo (ulong n) {
    if (n % 2 != 0)
        return false;
    double exp = Math.Log (n, 2);
    if (exp != Math.Floor (exp))
        return false;
    return Math.Pow (2, exp) == n;
}


#====================
#gpt output=============

Python:
def is_power_of_two(n):
  if n < 0 or n & (n - 1) != 0:
    return False
  return (2**(round(math.log(n, 2))) == n)

C:
int is_power_of_two (unsigned long n)
{
    // log2(n) must be an integer
    double exp = log2(n);
    double floor_exp = floor(exp);
    
     // bitwise operation to check the number is 2^n or not
    if (n&(n-1) || floor_exp != exp)
        return 0;
    return (pow(2, floor_exp) == n);
}

Java: 
public static boolean isPowerOfTwo (long n) {
    if (n % 2 != 0)
        return false;
        
    double exp = Math.log(n) / Math.log(2);
    double floorExp = Math.floor(exp);

    return Math.pow(2, floorExp) == n;
}

