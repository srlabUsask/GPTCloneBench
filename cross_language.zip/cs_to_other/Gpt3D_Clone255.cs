#input 
protected void Application_Error (object sender, EventArgs e) {
    Exception exception = Server.GetLastError () as Exception;
    if (exception != null) {
        Context.ClearError ();
        Context.Response.TrySkipIisCustomErrors = true;
        string path = (exception is HttpException && (exception as HttpException).GetHttpCode () == 404) ? "~/Error/NotFound?errorMessage=" + exception.Message : "~/Error/Index?errorMessage=" + exception.Message;
        Context.Server.TransferRequest (path, false);
    }
}


#====================
#gpt output=============

Python:
def application_Error(self, sender, e):
    exception = Server.getLastError() as Exception
    if exception is not None:
        Context.clearError()
        Context.response.TrySkipIISCustomErrors = True
        if isinstance(exception, HttpException) and exception.getHttpCode() == 404:
            path = "~/Error/NotFound?errorMessage=" + exception.message
        else:
            path = "~/Error/Index?errorMessage=" + exception.message
        Context.server.TransferRequest(path, False)
    
    
Java:
protected void applicationError(Object sender, EventArgs e) {
   Exception exception = Server.getLastError() instanceof Exception;
   if(exception != null) {
      Context.clearError();
      Context.response.SetSkipIISCustomErrors(true);
      String path;
      if(exception instance of HttpException &&
            ((HttpException)exception).getHttpCode() == 404) {
            path = "~/Error/NotFound?errorMessage=" + exception.getMessage();
      } else {
            path = "~/Error/Index?errorMessage=" + exception.getMessage(); 
      }
      Context.server.TransferRequest(path, false);
   }
}


C:
void applicationError(void *sender, void *e)
{
    Exception *exception = Server.getLastError() as Exception;
    if (exception) {
        Context.clearError();
        Context.response.TrySkipIISCustomErrors = true;
        char* path;
        if (exception is HttpException && ((HttpException*)exception).getHttpCode() == 404) {
            const unsigned int pathLength = strlen("~/Error/NotFound?errorMessage=") + strlen(exception.message) + 1;
            path = (char*)malloc(pathLength * sizeof(char));
            sprintf(path, "~/Error/NotFound?errorMessage=%s", exception.message);
        } else {
            const unsigned int pathLength = strlen("~/Error/Index?errorMessage=") + strlen(exception.message) + 1;
            path = (char*)malloc(pathLength * sizeof(char));
            sprintf(path, "~/Error/Index?errorMessage=%s", exception.message);
        }
        Context.server.TransferRequest(path, false);
        free(path);
    }
}

