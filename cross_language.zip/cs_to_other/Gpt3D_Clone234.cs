#input 
public static void Main (string [] args) {
    int ? first = null, second = null;
    int first_i = 0, second_i = 0;
    while (! first.HasValue) {
        Console.WriteLine ("enter first number");
        if (int.TryParse (Console.ReadLine (), out first_i)) {
            first = first_i;
        }
    }
    while (! second.HasValue) {
        Console.WriteLine ("enter second number");
        if (int.TryParse (Console.ReadLine (), out second_i)) {
            second = first_i;
        }
    }
    int product = computeProd1 (first_i, second_i);
    Console.WriteLine ("Their product is:\t" + product);
    Console.Read ();
}


#====================
#gpt output=============

//Python 
first = None
second = None
first_i = 0
second_i = 0
while not first:
    print("enter first number")
    try:
        first_i = int(input())
        first = first_i;
    except:
        pass
while not second:
    print("enter second number")
    try:
        second_i = int(input())
        second = second_i;
    except: 
        pass
product = computeProd1(first_i, second_i)
print("Their product is:\t" + str(product))


//C
int first = 0, second = 0;
int first_i = 0, second_i = 0;
while (!first) {
    printf("enter first number");
    if (scanf("%d", &first_i)) {
            first = first_i;
    }
} 
while (!second) {
    printf("enter second number");
    if (scanf("%d", &second_i)) {
            second = second_i;
    }
}
int product = computeProd1(first_i, second_i);
printf("Their product is:\t %d ", product);


//Java
int first = 0, second = 0;
int first_i = 0, second_i = 0;
while (first == 0) {
    System.out.println("enter first number");
    Scanner sc = new Scanner(System.in); 
    if (sc.hasNextInt()) { 
        first_i = sc.nextInt(); 
        first = first_i;
    } 
}
while (second == 0) {
    System.out.println("enter second number");
    Scanner sc = new Scanner(System.in); 
    if (sc.hasNextInt()) { 
        second_i = sc.nextInt(); 
        second = second_i;
    }
}
int product = computeProd1(first_i, second_i);
System.out.println("Their product is:\t" + product);

