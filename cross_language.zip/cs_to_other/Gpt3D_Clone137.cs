#input 
protected override void OnPaint (PaintEventArgs e) {
    float x = 10.0F;
    float y = 10.0F;
    string drawString = "123";
    using (SolidBrush brush = new SolidBrush (Color.Black))
    using (Font drawFont = new Font ("Arial", 16))
    {
        foreach (char c in drawString.ToCharArray ()) {
            PointF p = new PointF (x, y);
            e.Graphics.DrawString (c.ToString (), drawFont, brush, p);
            y += drawFont.Height;
        }
    } base.OnPaint (e);
}


#====================
#gpt output=============

Python:
def OnPaint (self, e):
    x = 10.0
    y = 10.0
    draw_string = '123'
    brush = pygame.Color(0, 0, 0)
    font = pygame.font.SysFont('Arial', 16)
    for char in draw_string:
        point = (x, y)
        e.screen.blit(font.render(char, True, brush), point)
        y += font.get_height()

C:
void OnPaint (PaintEventArgs e) {
    float x = 10.0F;
    float y = 10.0F;
    char* drawString = "123";
    int len = strlen(drawString);
    HBRUSH brush = CreateSolidBrush(0);
    HFONT font = CreateFontA(16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "Arial");
    for (int i = 0; i < len; ++i) {
        POINTF p = {x, y};
        DrawTextA(e->hdc, &drawString[i], 1, &p, DT_NOCLIP);
        y += font->Height;
    }
    DeleteObject(brush);
    DeleteObject(font);
}

Java: 
protected void onPaint(Graphics g) {
    float x = 10.0F;
    float y = 10.0F;
    String drawString = "123";
    Font font = new Font("Arial", Font.PLAIN, 16);
    for (char c : drawString.toCharArray()) {
        PointF p = new PointF(x, y);
        g.drawString(Character.toString(c), p.x, p.y);
        y += font.getSize();
    }
}

