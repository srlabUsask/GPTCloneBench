#input 
void btnApplica_Click_Scelta_Campi_Etichetta (object sender, EventArgs e) {
    Debug.Print ("btnApplica_Click_Scelta_Campi_Etichetta START");
    string id;
    if (sender.GetType () == typeof (ImageButton)) {
        ImageButton button = (ImageButton) sender;
        id = button.ID;
    }
    SPWeb contextWeb = SPContext.Current.Web;
    string url = contextWeb.Url;
    string link = url + "/ARXEIA WEBPART/Carica documento.aspx?mode=scelta_campi_facoltativi_etichetta&obj=" + obj;
    SPUtility.Redirect (link, SPRedirectFlags.Default, Context);
}


#====================
#gpt output=============

#Python
def btnApplica_Click_Scelta_Campi_Etichetta(sender, EventArgs):
    print("btnApplica_Click_Scelta_Campi_Etichetta START")
    id = ""
    if(type(sender) is ImageButton):
        button = sender
        id = button.ID
    contextWeb = SPContext.current.Web
    link = contextWeb.Url + "/ARXEIA WEBPART/Carica documento.aspx?mode=scelta_campi_facoltativi_etichetta&obj={0}".format(obj)
    SPUtility.redirect(link, SPRedirectFlags.Default, context)
    
#C
void btnApplica_Click_Scelta_Campi_Etichetta(object sender, EventArgs e) {
    printf("btnApplica_Click_Scelta_Campi_Etichetta START\n");
    char *id; 
    if (sender.GetType() == typeof(ImageButton)) {
        ImageButton *button = (ImageButton) sender;
        id = button->ID;
    }
    SPWeb *contextWeb = SPContext.Current.Web ;
    char *url = contextWeb->Url;
    char link[256];
    sprintf(link, "%s/ARXEIA WEBPART/Carica documento.aspx?mode=scelta_campi_facoltativi_etichetta&obj=%d", url, obj);
    SPUtility.Redirect(link, SPRedirectFlags.Default, Context);
}

#Java
public void btnApplica_Click_Scelta_Campi_Etichetta(object sender, EventArgs e) {
    System.out.println("btnApplica_Click_Scelta_Campi_Etichetta START");
    String id;
    if (sender.getClass() == ImageButton.class) {
        ImageButton button = (ImageButton) sender;
        id = button.getID();
    }
    SPWeb contextWeb = SPContext.current().getWeb();
    String url = contextWeb.getUrl();
    String link = url + "/ARXEIA WEBPART/Carica documento.aspx?mode=scelta_campi_facoltativi_etichetta&obj=" + obj;
    SPUtility.redirect(link, SPRedirectFlags.Default, Context);
}

