#input 
public static string GetFullPath (string fileName) {
    if (File.Exists (fileName))
        return Path.GetFullPath (fileName);
    var values = Environment.GetEnvironmentVariable ("PATH");
    foreach (var path in values.Split (';')) {
        var fullPath = Path.Combine (path, fileName);
        if (File.Exists (fullPath))
            return fullPath;
    }
    return null;
}


#====================
#gpt output=============

Python
def GetFullPath(fileName):
  if os.path.exists(fileName):
      return os.path.abspath(fileName)
  values = os.environ.get('PATH')
  for path in values.split(':'):
      fullPath = os.path.join(path, fileName)
      if os.path.exists(fullPath):
          return fullPath
  return None
  

C
char* GetFullPath(char* fileName) {
  if (fileExists(fileName))
     return pathGetFullPath(fileName);
  
  char *values = getEnv("PATH");
  char *str;
  char *token = strtok(values, ";");
  char fullPath[2048];
  while (token != NULL) {
    strcat(fullPath, token);
    strcat(fullPath, "/");
    strcat(fullPath, filename);
    if (fileExists(fullPath) == 1) {
        return fullPath;    
    }
    token = strtok(NULL, ";");
   }
   return NULL;
} 

Java 
public static String GetFullPath(String fileName) {
    if (Files.exists(Paths.get(fileName)))
        return Paths.get(fileName).toAbsolutePath().toString();
    String values = System.getenv("PATH");
    String[] paths = values.split(";");
    for (String path : paths) {
        String fullPath = Paths.get(path, fileName).toString();
        if (Files.exists(Paths.get(fullPath)))
            return Paths.get(fullPath).toAbsolutePath().toString();
    }
    return null;
}

