#input 
public static Image RotateImage (Image img, float rotationAngle) {
    int minx = int.MaxValue, maxx = int.MinValue, miny = int.MaxValue, maxy = int.MinValue;
    using (Bitmap bmp = new Bitmap (1, 1))
    {
        using (Graphics g = Graphics.FromImage (bmp))
        {
            g.TranslateTransform ((float) img.Width / 2, (float) img.Height / 2);
            g.RotateTransform (rotationAngle);
            g.TranslateTransform (- (float) img.Width / 2, - (float) img.Height / 2);
            Point [] pts = new Point [4];
            pts [0] = new Point (0, 0);
            pts [1] = new Point (img.Width, 0);
            pts [2] = new Point (img.Width, img.Height);
            pts [3] = new Point (0, img.Height);
            g.TransformPoints (CoordinateSpace.Device, CoordinateSpace.World, pts);
            foreach (Point pt in pts) {
                minx = Math.Min (minx, pt.X);
                maxx = Math.Max (maxx, pt.X);
                miny = Math.Min (miny, pt.Y);
                maxy = Math.Max (maxy, pt.Y);
            }
        }} Bitmap bmp2 = new Bitmap (maxx - minx, maxy - miny);
    using (Graphics g = Graphics.FromImage (bmp2))
    {
        g.TranslateTransform ((float) bmp2.Width / 2, (float) bmp2.Height / 2);
        g.RotateTransform (rotationAngle);
        g.TranslateTransform (- (float) bmp2.Width / 2, - (float) bmp2.Height / 2);
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.DrawImage (img, bmp2.Width / 2 - img.Width / 2, bmp2.Height / 2 - img.Height / 2);
    } return bmp2;
}


#====================
#gpt output=============

// Python
def RotateImage(img, rotationAngle): 
    minx, maxx, miny, maxy = float('inf'), -float('inf'), float('inf'), -float('inf') 
    with Image.open(img) as img: 
        with Image.new('RGB', img.size) as bmp: 
            with ImageDraw.Draw(bmp) as g: 
                g.translate(img.width//2, img.height//2) 
                g.rotate(rotationAngle)
                g.translate(-img.width//2, -img.height//2) 
                pts = [(0, 0), (img.width, 0), (img.width, img.height), (0, img.height)] 
                g.transform(pts) 
                for pt in pts: 
                    minx = min(minx, pt[0]) 
                    maxx = max(maxx, pt[0]) 
                    miny = min(miny, pt[1]) 
                    maxy = max(maxy, pt[1]) 

        bmp2 = Image.new('RGB', (maxx - minx, maxy - miny)) 
        with ImageDraw.Draw(bmp2) as g2: 
            g2.translate(bmp2.width//2, bmp2.height//2) 
            g2.rotate(rotationAngle)
            g2.translate(-bmp2.width//2, -bmp2.height//2)
            g2.interpolation('bicubic') 
            g2.image(img, bmp2.width//2 - img.width//2, bmp2.height//2 - img.height//2) 
    return bmp2 


// C
Image RotateImage (Image img, float rotationAngle) {
    int minx = INT_MAX, maxx = INT_MIN, miny = INT_MAX, maxy = INT_MIN;

    Bitmap *bmp = BitmapCreateWithSize(img.width, img.height);

    Graphics *g = GraphicsCreateFromBitmap(bmp);
    GraphicsTranslateTransform(g, (float)img.width/2, (float)img.height/2);
    GraphicsRotateTransform(g, rotationAngle);
    GraphicsTranslateTransform(g, -(float)img.width/2, -(float)img.height/2);

    Point pts[4];
    pts[0].x = 0;
    pts[0].y = 0;
    pts[1].x = img.width;
    pts[1].y = 0;
    pts[2].x = img.width;
    pts[2].y = img.height;
    pts[3].x = 0;
    pts[3].y = img.height;
    GraphicsTransformPoints(g, CoordinateSpaceDevice, CoordinateSpaceWorld, pts, 4);
    
    for (int i = 0; i < 4; i++) {
        minx = min(minx, pts[i].x);
        maxx = max(maxx, pts[i].x);
        miny = min(miny, pts[i].y);
        maxy = max(maxy, pts[i].y);
    }

    BitmapDestroy(bmp);

    Bitmap *bmp2 = BitmapCreateWithSize(maxx - minx, maxy - miny);
    g = GraphicsCreateFromBitmap(bmp2);
    GraphicsTranslateTransform(g, (float)bmp2.width / 2, (float)bmp2.height / 2);
    GraphicsRotateTransform(g, rotationAngle);
    GraphicsTranslateTransform(g, -(float)bmp2.width / 2, -(float)bmp2.height / 2);
    GraphicsSetInterpolationMode(g, InterpolationModeHighQualityBicubic);
    GraphicsDrawImage(g, img, bmp2.width / 2 - img.width / 2, bmp2.height / 2 - img.height / 2);
    GraphicsDestroy(g);

    return bmp2;
}


// Java
public static Image rotateImage (Image img, float rotationAngle) {
    int minx = Integer.MAX_VALUE, maxx = Integer.MIN_VALUE, miny = Integer.MAX_VALUE, maxy = Integer.MIN_VALUE;
    BufferedImage bmp = new BufferedImage (1, 1, BufferedImage.TYPE_3BYTE_BGR);
    
    Graphics2D g = bmp.createGraphics();
    g.translate((double) img.getWidth() / 2, (double) img.getHeight() / 2);
    g.rotate(Math.toRadians(rotationAngle));
    g.translate(- (double) img.getWidth() / 2, - (double) img.getHeight() / 2);

    Point [] pts = new Point [4];
    pts [0] = new Point(0, 0);
    pts [1] = new Point(img.getWidth(), 0);
    pts [2] = new Point(img.getWidth(), img.getHeight());
    pts [3] = new Point(0, img.getHeight());
    g.transform(pts);
    
    for(Point pt: pts) {
        minx = Math.min(minx, pt.x);
        maxx = Math.max(maxx, pt.x);
        miny = Math.min(miny, pt.y);
        maxy = Math.max(maxy, pt.y);
    }
    
    BufferedImage bmp2 = new BufferedImage(maxx - minx, maxy - miny, BufferedImage.TYPE_3BYTE_BGR);
    g = bmp2.createGraphics();
    g.translate(bmp2.getWidth() / 2.0, bmp2.getHeight() / 2.0);
    g.rotate(Math.toRadians(rotationAngle));
    g.translate(- bmp2.getWidth() / 2.0, - bmp2.getHeight() / 2.0);
    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
    g.drawImage(img, (bmp2.getWidth() - img.getWidth()) / 2, (bmp2.getHeight() - img.getHeight()) / 2, null);
    
    return bmp2;
}

