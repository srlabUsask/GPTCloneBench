#input 
private void DefineGeometry () {
    var points = PointCollection;
    _figure.Segments.Clear ();
    if (points.Any ()) {
        _figure.StartPoint = points [0];
        if (points.Count > 1) {
            for (int i = 1; i < (points.Count - 1); i ++) {
                var v1 = (Point) points [i] - points [i - 1];
                var v2 = (Point) points [i + 1] - points [i];
                var radius = (points [i].Radius ?? Radius) ?? 0;
                radius = Math.Min (Math.Min (v1.Length, v2.Length) / 2, radius);
                double len = v1.Length;
                v1.Normalize ();
                v1 *= (len - radius);
                var line = new LineSegment ((Point) points [i - 1] + v1, true);
                _figure.Segments.Add (line);
                v2.Normalize ();
                v2 *= radius;
                var direction = (Vector.AngleBetween (v1, v2) > 0) ? SweepDirection.Clockwise : SweepDirection.Counterclockwise;
                var arc = new ArcSegment ((Point) points [i] + v2, new Size (radius, radius), 0, false, direction, true);
                _figure.Segments.Add (arc);
            }
            _figure.Segments.Add (new LineSegment (points [points.Count - 1], true));
        }
    }
}


#====================
#gpt output=============

Python Implementation: 
def DefineGeometry():
	points = PointCollection 
	_figure.Segments.Clear()
	if points.any():
		_figure.StartPoint = points[0]
		if points.count() > 1: 
			for i in range(1, points.count() - 1): 
				v1 = points[i] - points[i-1]
				v2 = points[i+1] - points[i]
				radius = points[i].Radius or Radius or 0 
				radius = min(min(v1.length(), v2.length()) / 2, radius)
				len = v1.length()
				v1.normalize() 
				v1 *= len - radius
				line = LineSegment((points[i - 1] + v1), True)
				_figure.Segments.add(line)
				v2.normalize() 
				v2 *= radius
				direction = SweepDirection.Clockwise if Vector.AngleBetween(v1, v2) > 0 else SweepDirection.Counterclockwise
				arc = ArcSegment((points[i] + v2), Size(radius, radius), 0, False, direction, True)
				_figure.Segments.add(arc)
		_figure.Segments.add(new LineSegment(points[points.count() - 1], True))

JAVA Implementation:
private void defineGeometry() {
    PointCollection points = PointCollection;
    _figure.getSegments().clear();
 
    if (points.any()) {
        _figure.setStartPoint(points.get(0));
 
        if (points.getCount() > 1) {
            for (int i = 1; i < (points.getCount() - 1); i++) {
                Point v1 = points.get(i).subtract(points.get(i - 1));
                Point v2 = points.get(i + 1).subtract(points.get(i));
 
                Double radius = points.get(i).getRadius();
 
                if (radius == null) {
                    radius = Radius;
 
                    if (radius == null) {
                        radius = 0.0;
                    }
                }
 
                radius = Math.min(Math.min(v1.getLength(), v2.getLength()) / 2, radius);
                Double len = v1.getLength();
 
                v1.normalize();
                v1.setLength(len - radius);
                LineSegment line = new LineSegment(points.get(i - 1).add(v1), true);
                _figure.getSegments().add(line);
 
                v2.normalize();
                v2.setLength(radius);
 
                SweepDirection direction = ( Vector.angleBetween(v1, v2) > 0)
                    ? SweepDirection.CLOCKWISE
                    : SweepDirection.COUNTERCLOCKWISE;
 
                ArcSegment arc = new ArcSegment(points.get(i).add(v2),
                    new Size(radius, radius),
                    0,
                    false,
                    direction,
                    true);
 
                _figure.getSegments().add(arc);
            }
            _figure.getSegments().add(new LineSegment(points.get
            (points.getCount() - 1), true));
        }
    }
}

C Implementation:
void DefineGeometry(){
    PointCollection points = PointCollection;
    _figure.Segments->Clear();

    if(points.Any()){
        _figure.StartPoint = points[0];
        if(points.Count > 1){
            for(int i = 1; i < (points.Count - 1); i++){
                Point v1 = (Point)points[i] - points[i - 1];
                Point v2 = (Point)points[i+1] - points[i];
                double radius = (points[i].Radius ?? Radius) ?? 0;
                radius = min(min(v1.Length, v2.Length) / 2, radius);
                double len = v1.Length;
                v1.Normalize();
                v1 *= (len - radius);
                LineSegment* line = LineSegment_new((Point)(points[i - 1] + v1), true);
                _figure.Segments->Add(line);
                v2.Normalize();
                v2 *= radius;
                SweepDirection direction = (Vector.AngleBetween(v1, v2) > 0) ? SweepDirection.Clockwise : SweepDirection.Counterclockwise;
                ArcSegment* arc = ArcSegment_new((Point)(points[i] + v2), Size_new(radius, radius), 0.0, false, direction, true);
                _figure.Segments->Add(arc);
            }
            LineSegment* lastLine = LineSegment_new(points[points.Count - 1], true);
            _figure.Segments->Add(lastLine);
        }
    }
}

