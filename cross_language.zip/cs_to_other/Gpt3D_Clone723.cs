#input 
public static bool IsInPolygon (Point [] poly, Point p) {
    Point p1, p2;
    bool inside = false;
    if (poly.Length < 3) {
        return inside;
    }
    var oldPoint = new Point (poly [poly.Length - 1].X, poly [poly.Length - 1].Y);
    for (int i = 0; i < poly.Length; i ++) {
        var newPoint = new Point (poly [i].X, poly [i].Y);
        if (newPoint.X > oldPoint.X) {
            p1 = oldPoint;
            p2 = newPoint;
        } else {
            p1 = newPoint;
            p2 = oldPoint;
        }
        if ((newPoint.X < p.X) == (p.X <= oldPoint.X) && (p.Y - (long) p1.Y) * (p2.X - p1.X) < (p2.Y - (long) p1.Y) * (p.X - p1.X)) {
            inside = ! inside;
        }
        oldPoint = newPoint;
    }
    return inside;
}


#====================
#gpt output=============

Python:
def is_in_polygon(poly, p):
    p1 = None
    p2 = None
    inside = False
 
    if (len(poly) < 3):
        return inside
 
    oldPoint = Point(poly[len(poly) - 1].x, poly[len(poly) - 1].y)
    for i in range(len(poly)):
        newPoint = Point(poly[i].x, poly[i].y)
        if (newPoint.x > oldPoint.x):
            p1 = oldPoint
            p2 = newPoint
        else:
            p1 = newPoint
            p2 = oldPoint
 
        if ((newPoint.x < p.x) == (p.x <= oldPoint.x) and 
            (p.y - p1.y) * (p2.x - p1.x) < (p2.y - p1.y) * (p.x - p1.y)):
            inside = not inside
 
        oldPoint = newPoint
 
    return inside


C:
int is_in_polygon (struct Point *poly, struct Point p){
    struct Point p1, p2;
    int inside = 0; //false
    if (sizeof(poly) / sizeof(poly[0]) < 3){
        return inside;
    }
    struct Point old_point = {poly[sizeof(poly) / sizeof(poly[0]) - 1].x, poly[sizeof(poly) / sizeof(poly[0]) - 1].y};

    for(int i=0; i<sizeof(poly) / sizeof(poly[0]); i++){
        struct Point new_point = {poly[i].x, poly[i].y};
        if (new_point.x > old_point.x){
            p1 = old_point;
            p2 = new_point;
        } else {
            p1 = new_point;
            p2 = old_point;
        }
        if( (new_point.x < p.x) == (p.x <= old_point.x) && 
            (p.y - (long)p1.y) * (p2.x - p1.x) < (p2.y - (long)p1.y) * (p.x - p1.x) ){
            inside = !inside;
        }

        old_point = new_point;
    }

    return inside;
}

Java: 
public static boolean isInPolygon(Point[] poly, Point point) {
    Point p1, p2;
    boolean inside = false;
    if (poly.length < 3) {
        return inside;
    }
    Point oldPoint = new Point(poly[poly.length - 1].x, poly[poly.length - 1].y);
    for (int i = 0; i < poly.length; i++) {
        Point newPoint = new Point(poly[i].x, poly[i].y);
        if (newPoint.x > oldPoint.x) {
            p1 = oldPoint;
            p2 = newPoint;
        } else {
            p1 = newPoint;
            p2 = oldPoint;
        }
        if ((newPoint.x < point.x) == (point.x <= oldPoint.x)
            && (point.y - (long) p1.y) * (p2.x - p1.x) < (p2.y - (long) p1.y) * (point.x - p1.x)) {
            inside = !inside;
        }

        oldPoint = newPoint;
    }

    return inside;
}

