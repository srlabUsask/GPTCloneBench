#input 
static IEnumerable < string > GetFiles (string path) {
    Queue < string > queue = new Queue < string > ();
    queue.Enqueue (path);
    while (queue.Count > 0) {
        path = queue.Dequeue ();
        try {
            foreach (string subDir in Directory.GetDirectories (path)) {
                queue.Enqueue (subDir);
            }
        }
        catch (Exception ex) {
            Console.Error.WriteLine (ex);
        }
        string [] files = null;
        try {
            files = Directory.GetFiles (path);
        }
        catch (Exception ex) {
            Console.Error.WriteLine (ex);
        }
        if (files != null) {
            for (int i = 0; i < files.Length; i ++) {
                yield return files [i];
            }
        }
    }
}


#====================
#gpt output=============

//Python
def get_files(path):
    stack = [path]
    while stack:
        path = stack.pop()
        try:
            for sub_dir in os.listdir(path):
                stack.append(sub_dir)
        except Exception as e:
            print(e)
        try:
            files = os.listdir(path)
        except Exception as e:
            print(e)
        if files:
            for i in range(len(files)):
                yield files[i]

//C
IEnumerable* get_files(char* path) {
  Queue* queue = init_queue();
  enqueue_queue(queue, path);
  while (queue->length > 0) {
    path = dequeue_queue(queue);
    try {
      for (int i = 0; i < sizeof(Directory.GetDirectories(path)); i++) {
        enqueue_queue(queue, Directory.GetDirectories(path)[i]);
      }
    } catch (Exception ex) {
      printf("%s", ex);
    }
    char** files = NULL;
    try {
      files = Directory.GetFiles(path);
    } catch (Exception ex) {
      printf("%s", ex);
    }
    if (files != NULL) {
      for (int i = 0; i < sizeof(files); i++) {
        yield_enumerable(files[i]);
      }
    }
  }
}

//Java
public static List<String> getFiles(String path) {
    Queue<String> queue = new LinkedList<>();
    queue.add(path);
    while (!queue.isEmpty()) {
        path = queue.remove();
        try {
            List<String> subDirs = Arrays.asList(path.listFiles());
            queue.addAll(subDirs);
        } catch (Exception ex) {
            System.err.println(ex);
        }
        String[] files = null;
        try {
            files = path.list();
        } catch (Exception ex) {
            System.err.println(ex);
        }
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                yield return files[i];
            }
        }
    }
}

