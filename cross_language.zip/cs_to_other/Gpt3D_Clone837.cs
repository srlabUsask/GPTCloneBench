#input 
private string CreateSqlFilter (string fieldName, Control userInputControl, SqlCommand command, bool exactMatch) {
    string searchValue = null;
    if (userInputControl is TextBox)
        searchValue = ((TextBox) userInputControl).Text;
    if (userInputControl is ComboBox)
        searchValue = ((ComboBox) userInputControl).Text;
    if (String.IsNullOrWhiteSpace (searchValue))
        return null;
    if (exactMatch) {
        command.Parameters.Add (new SqlParameter ("@" + fieldName, searchValue));
        return fieldName + " = @" + fieldName;
    } else {
        command.Parameters.Add (new SqlParameter ("@" + fieldName, "%" + searchValue + "%"));
        return fieldName + " LIKE @" + fieldName;
    }
}


#====================
#gpt output=============

Python
def create_sql_filter(field_name, user_input_control, command, exact_match):
    search_value = None
    if isinstance(user_input_control, TextBox):
        search_value = user_input_control.get_text()
    elif isinstance(user_input_control, Combobox):
        search_value = user_input_control.get_text()
    if search_value == None or search_value.isspace():
        return None
    if exact_match:
        command.parameters.add(SqlParameter("@" + field_name, search_value))
        return field_name + "=@" + field_name
    else:
        command.parameters.add(SqlParameter("@" + field_name, "%" + search_value + "%"))
        return field_name + " LIKE @" + field_name

C
char* create_sql_filter(char* field_name, void* user_input_control, SqlCommand* command, bool exact_match) {
    char* search_value = NULL;
    if (type_of(user_input_control) == TextBox)
        search_value = ((TextBox*)user_input_control)->Text;
    if (type_of(user_input_control) == ComboBox)
        search_value = ((ComboBox*)user_input_control)->Text;
    if (strlen(search_value) == 0)
        return NULL;
    if (exact_match) {
        command->parameters[field_name] = search_value;
        char* res = malloc(strlen(field_name) + strlen("=@") + strlen(field_name) + 1);
        strcpy(res, field_name);
        strcat(res, "=@");
        strcat(res, field_name);
        return res;
    } else {
        char* search_value_with_wildcards = malloc(strlen(search_value) + 3);
        strcpy(search_value_with_wildcards, "%");
        strcat(search_value_with_wildcards, search_value);
        strcat(search_value_with_wildcards, "%");
        command->parameters[field_name] = search_value_with_wildcards;
        char* res = malloc(strlen(field_name) + strlen(" LIKE @") + strlen(field_name) + 1);
        strcpy(res, field_name);
        strcat(res, " LIKE @");
        strcat(res, field_name);
        return res;

    }
}

Java
public String createSqlFilter(String fieldName, Control userInputControl, SqlCommand command, boolean exactMatch) {
        String searchValue = null;
        if (userInputControl instanceof TextBox)
            searchValue = ((TextBox)userInputControl).getText();
        if (userInputControl instanceof ComboBox)
            searchValue = ((ComboBox)userInputControl).getText();
        if (searchValue == null || searchValue.trim().length() == 0)
            return null;
        if (exactMatch) {
            command.setParameter("@" + fieldName, searchValue);
            return fieldName + " = @" + fieldName;
        } else {
            command.setParameter("@" + fieldName, "%" + searchValue + "%");
            return fieldName + " LIKE @" + fieldName;
        }
    }

