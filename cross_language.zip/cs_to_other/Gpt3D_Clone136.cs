#input 
static void Main (string [] args) {
    authenticator auth = new authenticator ();
    string login = "hello";
    string pass = "12345";
    if (auth.CheckPassword (login, pass))
        Console.Write ("Access granted");
    else
        Console.Write ("Wrong login or password");
}


#====================
#gpt output=============

Python:
def Main(args):
    auth = authenticator()
    login = "hello"
    password = "12345"
    if auth.CheckPassword(login, password):
        print("Access granted")
    else:
        print("Wrong login or password")

C:
void Main (char *args[]) 
{
    authenticator auth = newAuthenticator();
    char *login = "hello";
    char *pass = "12345";
    if (auth->CheckPassword(login, pass)) 
        printf("Access granted");
    else
        printf("Wrong login or password");
}

Java:
public static void Main (String[] args) {
    Authenticator auth = new Authenticator();
    String login = "hello";
    String pass = "12345";
    if (auth.CheckPassword(login, pass))
        System.out.println("Access granted");
    else
        System.out.println("Wrong login or password");
}

