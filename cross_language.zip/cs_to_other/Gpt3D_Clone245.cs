#input 
public Point GetShot () {
    Point p = new Point ();
    if (attackVector.Count () > 0) {
        p = ExtendShot ();
        return p;
    }
    Board potential = new Board (size);
    for (p.Y = 0; p.Y < size.Height; ++ p.Y) {
        for (p.X = 0; p.X < size.Width; ++ p.X) {
            if (shotBoard.ShotAt (p)) {
                potential [p] = 0;
                continue;
            }
            foreach (HunterBoard b in targetBoards) {
                potential [p] += b.GetWeightAt (p);
            }
        }
    }
    Point shot;
    shot = potential.GetWeightedRandom (rand.NextDouble ());
    shotBoard [shot] = Shot.Unresolved;
    return shot;
}


#====================
#gpt output=============

Python: 
def get_shot():
    p = Point()
    if len(attack_vector) > 0:
        p = extend_shot()
    else:
        potential = Board(size)
        for y in range(0, size.height):
            for x in range(0, size.width):
                if shot_board.shot_at(p):
                    potential[p] = 0
                    continue
                for board in target_boards:
                    potential[p] += board.get_weight_at(p)
        shot = potential.get_weighted_random(rand.next_double())
        shot_board[shot] = Shot.unresolved
        return shot

C: 
Point get_shot() {
    Point p = {0};
    if (attack_vector->count > 0) {
        p = extend_shot();
        return p;
    }

    Board potential = {0};
    init_board(&potential, size);

    for (uint16_t y = 0; y < size.height; ++y) {
        for (uint16_t x = 0; x < size.width; ++x) {
            p.y = y;
            p.x = x;

            if (shot_at(&shot_board, p)) {
                set_weight(&potential, p, 0);
                continue;
            }

            for (uint32_t i = 0; i < target_boards->length; ++i) {
                increase_weight(&potential, p, 
                    get_weight_at(target_boards->boards[i], p));
            }
        }
    }

    Point shot;
    shot = get_weighted_random(&potential, rand_next_double());

    set_weight(&shot_board, shot, UNRESOLVED);
    return shot;
}

Java: 
public Point getShot() {
    Point p = new Point();
    if (attackVector.size() > 0) {
        p = extendShot();
        return p;
    }

    Board potential = new Board(size);
    for (int y = 0; y < size.height; ++y) {
        for (int x = 0; x < size.width; ++x) {
            p.y = y;
            p.x = x;
            if (shotBoard.shotAt(p)) {
                potential.setWeight(p, 0);
                continue;
            }
            for (HunterBoard board : targetBoards) {
                potential.increaseWeight(p, board.getWeightAt(p));
            }
        }
    }

    Point shot;
    shot = potential.getWeightedRandom(rand.nextDouble());
    shotBoard.setWeight(shot, Shot.UNRESOLVED);
    return shot;
}

