#input 
static void WritePropertyNames () {
    TestObject lTestObject = new TestObject ();
    PropertyInfo [] lProperty = typeof (TestObject).GetProperties ();
    List < Expression > lExpressions = new List < Expression > ();
    MethodInfo lMethodInfo = typeof (Console).GetMethod ("WriteLine", new Type [] {typeof (string)});
    lProperty.ForEach (x = > {
        ConstantExpression lConstant = Expression.Constant (x.Name);
        MethodCallExpression lMethodCall = Expression.Call (lMethodInfo, lConstant);
        lExpressions.Add (lMethodCall);
    });
    BlockExpression lBlock = Expression.Block (lExpressions);
    LambdaExpression lLambda = Expression.Lambda < Action > (lBlock, null);
    Action lWriteProperties = lLambda.Compile () as Action;
    lWriteProperties ();
}


#====================
#gpt output=============

Python:
from System import Console
from Reflection import PropertyInfo

def WritePropertyNames():
    lTestObject = TestObject()
    lProperty = type(lTestObject).GetProperties()
    
    lExpressions = []
    def lMethodHandler(x):
        lConstant = Expression.Constant(x.Name)
        lMethodCall = Expression.Call(lMethodInfo, lConstant)
        lExpressions.append(lMethodCall)
    
    lProperty.forEach(lMethodHandler)
 
    lBlock = Expression.Block(lExpressions)
    lLambda = Expression.Lambda(lBlock, None)
    lWriteProperties = Lambda.Compile()()
    lWriteProperties()

C:
#include <stdio.h>
#include <string.h>

struct TestObject {};
 
void WritePropertyNames() {
    struct TestObject lTestObject;
    
    PropertyInfo[] lProperty = typeof(TestObject).GetProperties();
    int property_length = (int) lProperty.length;
 
    List* lExpressions = List_new();
    MethodInfo* lMethodInfo = typeof(Console).GetMethod("WriteLine", new Type [] {typeof(string)});
    for (int i = 0; i < property_length; i++) {
        ConstantExpression lConstant = Expression_Constant(lProperty[i].Name);
        MethodCallExpression lMethodCall = Expression_Call(lMethodInfo, lConstant);
        List_add(lExpressions, lMethodCall);
    }
    
    BlockExpression lBlock = Expression_Block(lExpressions);
    LambdaExpression lLambda = Expression_Lambda(lBlock, NULL);
    Action lWriteProperties = (Action) LambdaExpression_Compile(lLambda);
    lWriteProperties();
    
    List_destroy(lExpressions);
}

Java:
import java.lang.reflect.Method;

public class TestObject {

    static void WritePropertyNames() {
        TestObject lTestObject = new TestObject();
        Method[] lProperties = TestObject.class.getMethods();
        List<Method> lExpressions = new ArrayList<Method>();
        Method lMethodinfo = Console.class.getMethod("WriteLine", new Type [] {String.class});
        for (Method property : lProperties) {
            ConstantExpression lConstant = new ConstantExpression(property.getName());
            MethodCallExpression lMethodCall = new MethodCallExpression(lMethodinfo, lConstant);
            lExpressions.add(lMethodCall);
        }
        BlockExpression lBlock = new BlockExpression(lExpressions);
        LambdaExpression lLambda = new LambdaExpression(lBlock);
        Action lWriteProperties = lLambda.compile() as Action;
        lWriteProperties();
    }
}

