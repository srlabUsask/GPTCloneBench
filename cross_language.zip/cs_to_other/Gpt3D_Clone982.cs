#input 
public static string GetWord (string input, int position) {
    char s = input [position];
    int sp1 = 0, sp2 = input.Length;
    for (int i = position; i > 0; i --) {
        char ch = input [i];
        if (ch == ' ' || ch == '\n') {
            sp1 = i;
            break;
        }
    }
    for (int i = position; i < input.Length; i ++) {
        char ch = input [i];
        if (ch == ' ' || ch == '\n') {
            sp2 = i;
            break;
        }
    }
    return input.Substring (sp1, sp2 - sp1).Replace ("\n", "");
}


#====================
#gpt output=============

//Python:
def GetWord(input, position):
    s = input[position]
    sp1 = 0
    sp2 = len(input)
    for i in range (position, 0, -1): 
        ch = input[i]
        if ch == ' ' or ch == '\n':
            sp1 = i
            break
    for i in range (position, len(input)-1): 
        ch = input[i]
        if ch == ' ' or ch == '\n':
            sp2 = i
            break
    return input[sp1:sp2].replace('\n', '')

//C:
char* GetWord(char* input, int position){
    char s = input[position];
    int sp1 = 0, sp2 = strlen(input);
    for(int i = position; i >= 0; i--){
        char ch = input[i];
        if(ch == ' ' || ch == '\n'){
            sp1 = i;
            break;
        }
    }
    for(int i = position; i < strlen(input); i++){
        char ch = input[i];
        if(ch == ' ' || ch == '\n'){
            sp2 = i;
            break;
        }
    }
    int len = sp2 - sp1;
    char* word = (char *)malloc((len + 1) * sizeof(char));
    if(word == NULL){
        exit(-1);
    }
    
    int k = 0;
    for(int i = sp1; i < sp2; i++){
        if(input[i] != '\n'){
            word[k] = input[i];
            k++;
        }
    }
    word[k] = '\0';
    
    return word;
}

//Java:
  public static String getWord(String input, int position) {
        char s = input.charAt(position);
        int sp1 = 0;
        int sp2 = input.length();
        for (int i = position; i > 0; i--){
            char ch = input.charAt(i);
            if (ch == ' ' || ch == '\n') {
                sp1 = i;
                break;
            }
        }
        for (int i = position; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (ch == ' ' || ch == '\n') {
                sp2 = i;
                break;
            }
        }
        return input.substring(sp1, sp2).replace("\n", "");
    }

