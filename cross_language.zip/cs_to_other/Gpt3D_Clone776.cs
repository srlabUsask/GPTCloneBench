#input 
public static ManagementObject GetWebServerSettingsByServerComment (string serverComment) {
    ManagementObject returnValue = null;
    ManagementScope iisScope = new ManagementScope (@"\\localhost\root\MicrosoftIISv2", new ConnectionOptions ());
    iisScope.Connect ();
    if (iisScope.IsConnected) {
        ObjectQuery settingQuery = new ObjectQuery (String.Format ("Select * from IIsWebServerSetting where ServerComment = '{0}'", serverComment));
        ManagementObjectSearcher searcher = new ManagementObjectSearcher (iisScope, settingQuery);
        ManagementObjectCollection results = searcher.Get ();
        if (results.Count > 0) {
            foreach (ManagementObject manObj in results) {
                returnValue = manObj;
                if (returnValue != null) {
                    break;
                }
            }
        }
    }
    return returnValue;
}


#====================
#gpt output=============


Python: 
def get_web_server_settings_by_server_comment(server_comment):
    return_value = None
    iis_scope = ManagementScope("\\localhost\root\MicrosoftIISv2", ConnectionOptions())
    iis_scope.connect()
    if iis_scope.is_connected():
        setting_query = ObjectQuery(f'Select * from IIsWebServerSetting where ServerComment = "{server_comment}"')
        searcher = ManagementObjectSearcher(iis_scope, setting_query)
        results = searcher.get()
        if len(results) > 0:
            for man_obj in results:
                return_value = man_obj
                if return_value is not None:
                    break
    return return_value


C: 
ManagementObject *get_web_server_settings_by_server_comment(const char *server_comment) {
    ManagementObject *return_value = NULL;
    ManagementScope iis_scope = ManagementScope("\\\\localhost\\root\\MicrosoftIISv2", ConnectionOptions());
    iis_scope.connect();
    if (iis_scope.is_connected()) {
        ObjectQuery setting_query = ObjectQuery(StringFormat("Select * from IIsWebServerSetting where ServerComment = '%s'", server_comment));
        ManagementObjectSearcher searcher = ManagementObjectSearcher(iis_scope, setting_query);
        ManagementObjectCollection results = searcher.get();
        if (results.count() > 0) {
            for (ManagementObject man_obj : results) {
                return_value = &man_obj;
                if (return_value != NULL) {
                    break;
                }
            }
        }
    }
    return return_value;
} 


Java: 
public static ManagementObject getWebServerSettingsByServerComment (String serverComment) {
    ManagementObject returnValue = null;
    ManagementScope iisScope = new ManagementScope("\\\\localhost\\root\\MicrosoftIISv2", new ConnectionOptions());
    iisScope.connect();
    if (iisScope.isConnected()) {
        ObjectQuery settingQuery = new ObjectQuery(String.format("Select * from IIsWebServerSetting where ServerComment = '%s'", serverComment));
        ManagementObjectSearcher searcher = new ManagementObjectSearcher(iisScope, settingQuery);
        ManagementObjectCollection results = searcher.get();
        if (results.count() > 0) {
            for (ManagementObject manObj : results) {
                returnValue = manObj;
                if (returnValue != null) {
                    break;
                }
            }
        }
    }
    return returnValue;
}

