#input 
public static String GetString (object value) {
    if (value is string) {
        return value as string;
    } else if (value is IDictionary) {
        return GetString (value as IDictionary);
    } else if (value is IEnumerable) {
        return GetString (value as IEnumerable);
    } else {
        return value.ToString ();
    }
}


#====================
#gpt output=============

Python: 
def GetString(value):
    if isinstance(value, str): 
        return value 
    elif isinstance(value, dict):
        return GetString(value)
    elif isinstance(value, list):
        return GetString(value)
    else:
        return str(value)

C: 
char* GetString(void* value) 
{ 
    if (strcmp((char*)value, "string")==0) 
        return (char*)value; 
    else if (strcmp((char*)value, "dictionary")==0) 
        return GetString((dictionary*)value); 
    else if (strcmp((char*)value, "enumerable")==0) 
        return GetString((enumerable*)value); 
    else  
        return (char*) value->ToString(); 
} 

Java:
public static String GetString(Object value) {
    if (value instanceof String) {
        return (String) value;
    } else if (value instanceof Map) {
        return GetString((Map) value);
    } else if (value instanceof Collection) {
        return GetString((Collection) value);
    } else {
        return value.toString();
    }
}

