#input 
public Image ResizeImage (Image source, RectangleF destinationBounds) {
    RectangleF sourceBounds = new RectangleF (0.0f, 0.0f, (float) source.Width, (float) source.Height);
    RectangleF scaleBounds = new RectangleF ();
    Image destinationImage = new Bitmap ((int) destinationBounds.Width, (int) destinationBounds.Height);
    Graphics graph = Graphics.FromImage (destinationImage);
    graph.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
    graph.FillRectangle (new SolidBrush (System.Drawing.Color.White), destinationBounds);
    float resizeRatio, sourceRatio;
    float scaleWidth, scaleHeight;
    sourceRatio = (float) source.Width / (float) source.Height;
    if (sourceRatio >= 1.0f) {
        resizeRatio = destinationBounds.Width / sourceBounds.Width;
        scaleWidth = destinationBounds.Width;
        scaleHeight = sourceBounds.Height * resizeRatio;
        float trimValue = destinationBounds.Height - scaleHeight;
        graph.DrawImage (source, 0, (trimValue / 2), destinationBounds.Width, scaleHeight);
    } else {
        resizeRatio = destinationBounds.Height / sourceBounds.Height;
        scaleWidth = sourceBounds.Width * resizeRatio;
        scaleHeight = destinationBounds.Height;
        float trimValue = destinationBounds.Width - scaleWidth;
        graph.DrawImage (source, (trimValue / 2), 0, scaleWidth, destinationBounds.Height);
    }
    return destinationImage;
}


#====================
#gpt output=============

Python:
def ResizeImage(source, destinationBounds):
    sourceBounds = RectangleF(0.0, 0.0, float(source.width), float(source.height))
    destinationImage = Bitmap(int(destinationBounds.width), int(destinationBounds.height))
    graph = Graphics.FromImage(destinationImage)
    graph.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic
    graph.FillRectangle(SolidBrush(System.Drawing.Color.White), destinationBounds)

    sourceRatio = float(source.width) / float(source.height)
    if sourceRatio >= 1.0:
       resizeRatio = destinationBounds.width / sourceBounds.width
       scaleWidth = destinationBounds.width
       scaleHeight = sourceBounds.height * resizeRatio
       trimValue = destinationBounds.height - scaleHeight
       graph.DrawImage(source, 0, (trimValue/2), destinationBounds.width, scaleHeight)
    else:
       resizeRatio = destinationBounds.height / sourceBounds.height
       scaleWidth = sourceBounds.width * resizeRatio
       scaleHeight = destinationBounds.height
       trimValue = destinationBounds.width - scaleWidth
       graph.DrawImage(source, (trimValue/2), 0, scaleWidth, destinationBounds.height)

    return destinationImage


C:
Image ResizeImage(Image *source, RectangleF destinationBounds){
    RectangleF sourceBounds = {0.0f, 0.0f, (float)source->Width, (float)source->Height };
    RectangleF scaleBounds = { 0 };
    Image *destinationImage = (Image *)malloc(sizeof(Image));
    destinationImage->Width = (int)destinationBounds.Width;
    destinationImage->Height = (int)destinationBounds.Height;
    Graphics *graph = Init_Graphics(destinationImage);
    graph->InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
    FillRectangle(graph->Context, System.Drawing.Color.White, destinationBounds);

    float resizeRatio, sourceRatio;
    float scaleWidth, scaleHeight;
    sourceRatio = (float)source->Width / (float)source->Height;
    if (sourceRatio >= 1.0f) {
       resizeRatio = destinationBounds.Width / sourceBounds.Width;
       scaleWidth = destinationBounds.Width;
       scaleHeight = sourceBounds.Height * resizeRatio;
       float trimValue = destinationBounds.Height - scaleHeight;
       DrawImage(graph->Context, source, 0, (trimValue/2), destinationBounds.Width, scaleHeight);
    } else {
       resizeRatio = destinationBounds.Height / sourceBounds.Height;
       scaleWidth = sourceBounds.Width * resizeRatio;
       scaleHeight = destinationBounds.Height;
       float trimValue = destinationBounds.Width - scaleWidth;
       DrawImage(graph->Context, source, (trimValue/2), 0, scaleWidth, destinationBounds.Height);
    }

    return destinationImage;
}


Java:
public static Image resizeImage(Image source, RectangleF destinationBounds) {
    RectangleF sourceBounds = new RectangleF(0.0F, 0.0F, (float)source.getWidth(), (float)source.getHeight());
    RectangleF scaleBounds = new RectangleF();
    Image destinationImage = new BufferedImage((int) destinationBounds.getWidth(), (int) destinationBounds.getHeight(),BufferedImage.TYPE_INT_ARGB);
    Graphics2D graph = (Graphics2D) destinationImage.getGraphics();
    graph.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
    graph.setColor(Color.white);
    graph.fill(destinationBounds);
    float resizeRatio, sourceRatio;
    float scaleWidth, scaleHeight;
    sourceRatio = (float) source.getWidth() / (float) source.getHeight();
    if (sourceRatio >= 1.0F) {
        resizeRatio = destinationBounds.getWidth() / sourceBounds.getWidth();
        scaleWidth = destinationBounds.getWidth();
        scaleHeight = sourceBounds.getHeight() * resizeRatio;
        float trimValue = destinationBounds.getHeight() - scaleHeight;
        graph.drawImage(source, 0, (trimValue / 2), destinationBounds.getWidth(), scaleHeight, null);
    } else {
        resizeRatio = destinationBounds.getHeight() / sourceBounds.getHeight();
        scaleWidth = sourceBounds.getWidth() * resizeRatio;
        scaleHeight = destinationBounds.getHeight();
        float trimValue = destinationBounds.getWidth() - scaleWidth;
        graph.drawImage(source, (trimValue / 2), 0, scaleWidth, destinationBounds.getHeight(), null);
    }
    return destinationImage;
}

