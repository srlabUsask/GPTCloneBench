#input 
static void Main () {
    var moCollection = new ManagementClass ("Win32_LogicalDisk").GetInstances ();
    foreach (var mo in moCollection) {
        if (mo ["DeviceID"] != null && mo ["DriveType"] != null && mo ["Size"] != null && mo ["FreeSpace"] != null) {
            if (Convert.ToInt32 (mo ["DriveType"]) == 3) {
                Console.WriteLine ("Drive {0}", mo ["DeviceID"]);
                Console.WriteLine ("Size {0} bytes", mo ["Size"]);
                Console.WriteLine ("Free {0} bytes", mo ["FreeSpace"]);
            }
        }
    }
}


#====================
#gpt output=============

Python implementation:

def Main():
    mocollection = ManagementClass("Win32_LogicalDisk").GetInstances()
    for mo in mocollection:
        if mo["DeviceID"] is not None and mo["DriveType"] is not None and mo["Size"] is not None and mo["FreeSpace"] is not None:
            if int(mo["DriveType"]) == 3:
                print("Drive {0}".format(mo["DeviceID"]))
                print("Size {0} bytes".format(mo["Size"]))
                print("Free {0} bytes".format(mo["FreeSpace"]))

C implementation:

void Main(void) 
{ 
    ManagementClass* moCollection = ManagementClass_GetInstances("Win32_LogicalDisk"); 
    ManagementClass_Iterator mo; 
    ManagementClass_ForEach (moCollection, mo) 
    { 
        if (ManagementClass_GetValue(mo, "DeviceID") && 
        ManagementClass_GetValue(mo, "DriveType") && 
        ManagementClass_GetValue(mo, "Size") && 
        ManagementClass_GetValue(mo, "FreeSpace")) 
        { 
            if (atoi(ManagementClass_GetValue(mo, "DriveType")) == 3) 
            { 
                printf("Drive %s\n", ManagementClass_GetValue(mo, "DeviceID")); 
                printf("Size %s bytes\n", ManagementClass_GetValue(mo, "Size")); 
                printf("Free %s bytes\n", ManagementClass_GetValue(mo, "FreeSpace")); 
            } 
        } 
    } 
}

Java implementation:

public static void main() {
    ManagementClass mocollection = new ManagementClass("Win32_LogicalDisk").getInstances();
    for (ManagementClass mo : mocollection) {
        if (mo.get("DeviceID") != null && mo.get("DriveType") != null && mo.get("Size") != null && mo.get("FreeSpace") != null) {
            if (Integer.parseInt(mo.get("DriveType")) == 3) {
                System.out.println("Drive " + mo.get("DeviceID"));
                System.out.println("Size " + mo.get("Size") + " bytes");
                System.out.println("Free " + mo.get("FreeSpace") + " bytes");
            }
        }
    }
}

