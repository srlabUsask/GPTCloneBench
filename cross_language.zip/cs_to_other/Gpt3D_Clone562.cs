#input 
protected override void WndProc (ref Message m) {
    if (m.Msg == 0x0203) {
        int start = SelectionStart;
        if (start < 1)
            start = 1;
        int left = - 1;
        int right = Text.Length;
        int pos;
        foreach (char c in delimiterList) {
            pos = Text.LastIndexOf (c, start - 1);
            if (pos > left)
                left = pos;
            pos = Text.IndexOf (c, start);
            if (pos < right && pos != - 1)
                right = pos;
        }
        SelectionStart = left + 1;
        SelectionLength = right - left - 1;
        return;
    }
    base.WndProc (ref m);
}


#====================
#gpt output=============


Python Implementation: 
def WndProc(self, m):
	if m.Msg == 0x0203:
		start = self.SelectionStart
		if start < 1:
			start = 1
		left = -1
		right = len(self.Text)
		for c in self.delimiterList:
			pos = self.Text.rfind(c, start-1)
			if pos > left:
				left = pos
			pos = self.Text.find(c, start)
			if pos < right and pos != -1:
				right = pos
		self.SelectionStart = left+1
		self.SelectionLength = right-left-1
		return
	super(WndProc, self).WndProc(m)

C Implementation: 
void WndProc(Message* m) 
{ 
    if (m->Msg == 0x0203) 
    { 
        // Save size of Message 
        int start = SelectionStart; 
  
        if (start < 1) 
            start = 1; 
  
        int left = -1; 
        int right = Text.length(); 
        int pos; 
  
        for (int i = 0; i < delimiterList.length(); i++) 
        { 
            pos = Text.lastIndexOf(delimiterList[i], start - 1); 
            if (pos > left) 
                left = pos; 
            pos = Text.indexOf(delimiterList[i], start); 
            if (pos < right && pos != -1) 
                right = pos; 
        } 
  
        SelectionStart = left + 1; 
        SelectionLength = right - left - 1; 
        return; 
    } 
  
    // Call base class WndProc 
    base::WndProc(m); 
} 

Java Implementation:
@Override
protected void WndProc(Message m) 
{ 
    if (m.getMsg() == 0x0203) 
    { 
        int start = SelectionStart; 
        if (start < 1) 
            start = 1; 
        int left = -1; 
        int right = Text.length; 
        int pos; 
        for (char c : delimiterList) 
        { 
            pos = Text.lastIndexOf(c, start - 1); 
            if (pos > left) 
                left = pos; 
            pos = Text.indexOf(c, start); 
            if (pos < right && pos != -1) 
                right = pos; 
        } 
        SelectionStart = left + 1; 
        SelectionLength = right - left - 1; 
        return; 
    } 
    super.WndProc(m); 
}

