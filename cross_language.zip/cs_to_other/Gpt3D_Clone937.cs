#input 
static List < Info > RecursiveScan2 (string directory) {
    IntPtr INVALID_HANDLE_VALUE = new IntPtr (- 1);
    WIN32_FIND_DATAW findData;
    IntPtr findHandle = INVALID_HANDLE_VALUE;
    var info = new List < Info > ();
    try {
        findHandle = FindFirstFileW (directory + @"\*", out findData);
        if (findHandle != INVALID_HANDLE_VALUE) {
            do
                {
                    if (findData.cFileName == "." || findData.cFileName == "..")
                        continue;
                    string fullpath = directory + (directory.EndsWith ("\\") ? "" : "\\") + findData.cFileName;
                    bool isDir = false;
                    if ((findData.dwFileAttributes & FileAttributes.Directory) != 0) {
                        isDir = true;
                        info.AddRange (RecursiveScan2 (fullpath));
                    }
                    info.Add (new Info () {CreatedDate = findData.ftCreationTime.ToDateTime (), ModifiedDate = findData.ftLastWriteTime.ToDateTime (), IsDirectory = isDir, Path = fullpath});
                } while (FindNextFile (findHandle, out findData));
        }
    }
    finally {
        if (findHandle != INVALID_HANDLE_VALUE)
            FindClose (findHandle);
    }
    return info;
}


#====================
#gpt output=============

Python Implementation:
def RecursiveScan2(directory):
    INVALID_HANDLE_VALUE = -1
    info_list = []
    findHandle = INVALID_HANDLE_VALUE
    try:
        findHandle = os.findfirstfile("%s/*" % directory)
        if findHandle != INVALID_HANDLE_VALUE:
            while True:
                findData = os.finddataex(findHandle)
                if findData.name not in (".", ".."):
                    fullpath = directory + ("\\" if not directory.endswith("\\") else "") + findData.name
                    isDir = False
                    if findData.attributes & os.attribute_directory:
                        isDir = True
                        info_list += RecursiveScan2(fullpath)
                    info_list.append(Info(created_date=findData.created.timetuple(), modified_date=findData.modified.timetuple(), is_dir=isDir, path=fullpath))
                if not os.findnextfile(findHandle):
                    break
    finally:
        if findHandle != INVALID_HANDLE_VALUE:
            os.findclose(findHandle)
    return info_list


C Implementation:
List *RecursiveScan2(char *directory) {
    IntPtr INVALID_HANDLE_VALUE = -1;
    WIN32_FIND_DATAW findData;
    IntPtr findHandle = INVALID_HANDLE_VALUE;
    List *info_list = list_create();
    try {
        findHandle = FindFirstFileW(directory + "\\*", &findData);
        if (findHandle != INVALID_HANDLE_VALUE) {
            do
            {
                if (strcmp(findData.cFileName, ".") == 0 || strcmp(findData.cFileName, "..") == 0)
                    continue;
                char *fullpath = malloc(strlen(directory) + strlen(findData.cFileName) + 2);
                sprintf(fullpath, "%s\\%s", directory, findData.cFileName);
                bool isDir = false;
                if ((findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0) {
                    isDir = true;
                    list_append_all(info_list, RecursiveScan2(fullpath));
                }
                Info *info = info_create(findData.ftCreationTime.ToDateTime(), findData.ftLastWriteTime.ToDateTime(), isDir, fullpath);
                list_add(info_list, info);
                free(fullpath);
            } while (FindNextFile(findHandle, &findData));
        }
    }
    finally {
        if (findHandle != INVALID_HANDLE_VALUE)
            FindClose(findHandle);
    }
    return info_list;
}


Java Implementation:
public static List<Info> RecursiveScan2(String directory) {
    IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1); 
    WIN32_FIND_DATAW findData;
    IntPtr findHandle = INVALID_HANDLE_VALUE;
    List<Info> info = new ArrayList<Info>();
    try {
        findHandle = FindFirstFileW(directory + File.separator + "*", findData);
        if (findHandle != INVALID_HANDLE_VALUE) {
            do
                {
                    if (findData.cFileName.equals(".") || findData.cFileName.equals(".."))
                        continue;
                    String fullpath = directory + ((directory.endsWith(File.separator) ? "" : File.separator) + findData.cFileName);
                    boolean isDir = false;
                    if ((findData.dwFileAttributes & FileAttribute.DIRECTORY.getMask()) != 0) {
                        isDir = true;
                        info.addAll(RecursiveScan2(fullpath));
                    }
                    info.add(new Info(findData.ftCreationTime.ToDateTime(), findData.ftLastWriteTime.ToDateTime(), isDir, fullpath));
                } while (FindNextFile(findHandle, findData));
        }
    }
    finally {
        if (findHandle != INVALID_HANDLE_VALUE)
            FindClose(findHandle);
    }
    return info;
}

