#input 
static void Main (string [] args) {
    Stopwatch sw = new Stopwatch ();
    sw.Start ();
    int count = 0;
    for (uint i = 0; i < 1000000000; ++ i) {
        var isMultipleOf16 = i % 16 == 0;
        count += isMultipleOf16 ? 1 : 0;
    }
    sw.Stop ();
    Console.WriteLine (string.Format ("Ellapsed {0}, count {1}", sw.Elapsed, count));
    Console.ReadKey ();
}


#====================
#gpt output=============

Python: 
import time

def main():
    sw = time.time()
    count = 0

    for i in range(0, 1000000000):
        is_multiple_of_16 = i % 16 == 0
        count += 1 if is_multiple_of_16 else 0

    elapsed_time = time.time() - sw
    print("Ellapsed {0}, count {1}".format(elapsed_time, count))

if __name__ == '__main__':
    main()


C:
#include <stdio.h>
#include <time.h>

int main(void) {
    clock_t sw = clock();
    int count = 0;

    for (uint i = 0; i < 1000000000; ++i) {
        int is_multiple_of_16 = i % 16 == 0;
        count += is_multiple_of_16 ? 1 : 0;
    }

    clock_t elapsed_time = clock() - sw;
    printf("Ellapsed %f, count %d\n", (float) elapsed_time / CLOCKS_PER_SEC, count);

    return 0;
}


Java: 
public class Main {
    public static void main(String[] args) {
        Stopwatch sw = new Stopwatch();
        sw.start();
        int count = 0;
        
        for (int i = 0; i < 1000000000; ++i) {
            boolean isMultipleOf16 = i % 16 == 0;
            count += isMultipleOf16 ? 1 : 0;
        }
        
        sw.stop();
        System.out.println("Ellapsed " + sw.elapsedTime + ", count " + count);
    }
}

