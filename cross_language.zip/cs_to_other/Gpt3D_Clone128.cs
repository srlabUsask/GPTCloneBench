#input 
public void Queue (Action action, bool urgent, int delay) {
    if (delay > 0) {
        Timer t = null;
        t = new Timer (_ = > {
            Queue (action, urgent, 0);
            t.Dispose ();
        }, null, delay, Timeout.Infinite);
        return;
    }
    lock (threads)
    {
        if (maxThreads > threads.Count) {
            Thread t = new Thread (new ThreadStart (ThreadProc));
            t.IsBackground = true;
            t.Priority = ThreadPriority.Lowest;
            t.Name = "Worker thread for " + name;
            t.Start ();
            threads.Add (t);
        }
    } lock (actions)
    {
        if (urgent) {
            actions.Insert (0, action);
        } else {
            actions.Add (action);
        }
        Monitor.Pulse (actions);
    }}


#====================
#gpt output=============

Python:
def Queue(action, urgent, delay):
    if delay > 0:
        t = threading.Timer(delay, Queue, args=[action, urgent, 0])
        t.start()
        return
    with threading.Lock():
        if maxThreads > threads:
            t = threading.Thread(target=ThreadProc)
            t.daemon = True
            t.priority = threading.ThreadPriority.lowest
            t.start()
            threads.append(t)
    with threading.Lock():
        if urgent:
            actions.insert(0,action)
        else:
            actions.append(action)
        threading.Condition().notify()

C:
void Queue(void *action, bool urgent, int delay) {
    if (delay > 0) {
        Timer *t = new Timer(Queue, action, urgent, 0, delay);
        return;
    }
    pthread_mutex_lock(&threads);
    if (maxThreads > threads.size) {
        pthread_t t;
        pthread_create(&t, NULL, ThreadProc, NULL);
        pthread_attr_setdetachstate(&t, PTHREAD_CREATE_DETACHED);
        pthread_attr_setschedpolicy(&t, SCHED_LOWEST);
        threads.push_back(t);
    }
    pthread_mutex_unlock(&threads);
    pthread_mutex_lock(&actions);
    if (urgent) {
        actions.insert(action, 0);
    } else {
        actions.push_back(action);
    }
    pthread_cond_signal(&actions);
    pthread_mutex_unlock(&actions);
}

Java:
public void Queue(Action action, boolean urgent, int delay) {
    if (delay > 0) {
        Timer t = null;
        t = new Timer(() -> {
            Queue(action, urgent, 0);
            t.cancel();
        }, delay, Timeout.INFINITE);
        return;
    }
    synchronized(threads) {
        if (maxThreads > threads.size()) {
            Thread t = new Thread(this::ThreadProc);
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            t.setName("Worker thread for " + name);
            t.start();
            threads.add(t);
        }
    }
    synchronized(actions) {
        if (urgent) {
            actions.add(0, action);
        } else {
            actions.add(action);
        }
        actions.notify();
    }
}

