#input 
void Main () {
    var a = new StateRandom (123);
    a.Next (100);
    a.Next (100);
    a.Next (100);
    var state = a.NumberOfInvokes;
    Console.WriteLine (a.Next (100));
    Console.WriteLine (a.Next (100));
    Console.WriteLine (a.Next (100));
    var b = new StateRandom (123, state);
    Console.WriteLine (b.Next (100));
    Console.WriteLine (b.Next (100));
    Console.WriteLine (b.Next (100));
}


#====================
#gpt output=============

//PYTHON
import random
a = random.Random(123) 
a.randint(0,99) 
a.randint(0,99) 
a.randint(0,99) 
state = a.state 
print(a.randint(0,99)) 
print(a.randint(0,99)) 
print(a.randint(0,99)) 
b = random.Random(123, state) 
print(b.randint(0,99)) 
print(b.randint(0,99)) 
print(b.randint(0,99))


//C
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

srand(123); 
rand()%100; 
rand()%100; 
rand()%100; 
int state = srand(123); 
printf("%d",rand()%100); 
printf("%d",rand()%100); 
printf("%d",rand()%100); 
srand(123, state);
printf("%d",rand()%100); 
printf("%d",rand()%100); 
printf("%d",rand()%100); 


//JAVA
import java.util.Random;

Random a = new Random(123); 
a.nextInt(100); 
a.nextInt(100); 
a.nextInt(100); 
int state = a.state; 
System.out.println(a.nextInt(100)); 
System.out.println(a.nextInt(100)); 
System.out.println(a.nextInt(100)); 
Random b = new Random(123, state); 
System.out.println(b.nextInt(100)); 
System.out.println(b.nextInt(100)); 
System.out.println(b.nextInt(100));

