#input 
public static void Main (string [] args) {
    int result = 1;
    int numToCheck = 141234;
    boolean found = false;
    for (int i = 0; i < 15; i ++) {
        if (numToCheck == result) {
            found = true;
            break;
        }
        result *= 2;
    }
    if (found)
        Console.WriteLine ("Awesome");
}


#====================
#gpt output=============

Python:
result = 1
numToCheck = 141234
found = False
for i in range(15):
    if numToCheck == result:
        found = True
        break
    result *= 2
if found:
    print("Awesome")


C:
#include <stdio.h>
int main () {
    int result = 1;
    int numToCheck = 141234;
    _Bool found = 0;
    for (int i = 0; i < 15; i ++) {
        if (numToCheck == result) {
            found = 1;
            break;
        }
        result *= 2;
    }
    if (found)
        printf("Awesome");
    return 0;
}

Java:
public class Main {
    public static void main(String[] args) {
        int result = 1;
        int numToCheck = 141234;
        boolean found = false;
        for (int i = 0; i < 15; i ++) {
            if (numToCheck == result) {
                found = true;
                break;
            }
            result *= 2;
        }
        if (found)
            System.out.println("Awesome");
    }
}

