#input 
protected void GridView1_RowUpdating (object sender, GridViewUpdateEventArgs e) {
    GridViewRow row = (GridViewRow) GridView1.Rows [e.RowIndex];
    int id = Int32.Parse (GridView1.DataKeys [e.RowIndex].Value.ToString ());
    TextBox tname = (TextBox) row.FindControl ("nam");
    TextBox tques = (TextBox) row.FindControl ("que");
    MySqlCommand cmd = new MySqlCommand ("update exam set name1=@name,ques=@ques where id = @id", con);
    cmd.Parameters.Add ("@id", MySqlDbType.Int16).Value = id;
    cmd.Parameters.Add ("@name", MySqlDbType.VarChar, 30).Value = tname.Text.Trim ();
    cmd.Parameters.Add ("@ques", MySqlDbType.VarChar, 40).Value = tques.Text.Trim ();
    con.Open ();
    cmd.ExecuteNonQuery ();
    GridView1.EditIndex = - 1;
    bind ();
}


#====================
#gpt output=============


Python: 
def GridView1_RowUpdating(sender, e):
    row = GridView1.Rows[e.RowIndex]
    id = int(GridView1.DataKeys[e.RowIndex].value)
    tname = row.FindControl("nam")
    tques = row.FindControl("que")
    cmd = connection.cursor()
    cmd.execute("update exam set name1=@name,ques=@ques where id = @id", con)
    cmd.execute("SET @id = %s", (id,))
    cmd.execute("SET @name= %s", (tname.Text.trim(),))
    cmd.execute("SET @ques= %s", (tques.Text.trim(),))
    con.open()
    cmd.execute()
    GridView1.EditIndex = -1
    bind()

C: 
void GridView1_RowUpdating(Object sender, GridViewUpdateEventArgs e) { 
    GridViewRow row = (GridViewRow) GridView1.Rows[e.RowIndex] 
    int id = Int32.Parse(GridView1.DataKeys[e.RowIndex].Value.ToString());
    TextBox tname = (TextBox) row.FindControl("nam");
    TextBox tques = (TextBox) row.FindControl("que");
    char query[256];
    sprintf(query, "update exam set name1=@name,ques=@ques where id = %d", id);
    MySqlCommand cmd = new MySqlCommand (query, con);
    cmd.Parameters.Add("@name", MySqlDbType.VarChar, 30).Value = tname.Text.Trim();
    cmd.Parameters.Add("@ques", MySqlDbType.VarChar, 40).Value = tques.Text.Trim();
    con.Open();
    cmd.ExecuteNonQuery();
    GridView1.EditIndex = -1;
    bind();
}

Java: 
protected void GridView1_RowUpdating(Object sender, GridViewUpdateEventArgs e){
    GridViewRow row = (GridViewRow) GridView1.Rows[e.RowIndex];
    int id = Integer.parseInt(GridView1.DataKeys[e.RowIndex].value.toString());
    TextBox tname = (TextBox) row.FindControl("nam");
    TextBox tques = (TextBox) row.FindControl("que");
    String query = "update exam set name1=@name,ques=@ques where id = ?";
    PreparedStatement cmd = new PreparedStatement (query, con);
    cmd.setInt(1, id);
    cmd.setString(2, tname.getText().trim());
    cmd.setString(3, tques.getText().trim());
    con.open()
    cmd.executeUpdate();
    GridView1.EditIndex = -1;
    bind();
}

