#input 
private static void Main (string [] args) {
    var connection = new HubConnection ("http://127.0.0.1:8088/");
    var myHub = connection.CreateHubProxy ("MyHub");
    Console.WriteLine ("Enter your name");
    string name = Console.ReadLine ();
    connection.Start ().ContinueWith (task = > {
        if (task.IsFaulted) {
            Console.WriteLine ("There was an error opening the connection:{0}", task.Exception.GetBaseException ());
        } else {
            Console.WriteLine ("Connected");
            myHub.On < string, string > ("addMessage", (s1, s2) = > {
                Console.WriteLine (s1 + ": " + s2);
            });
            while (true) {
                string message = Console.ReadLine ();
                if (string.IsNullOrEmpty (message)) {
                    break;
                }
                myHub.Invoke < string > ("Send", name, message).ContinueWith (task1 = > {
                    if (task1.IsFaulted) {
                        Console.WriteLine ("There was an error calling send: {0}", task1.Exception.GetBaseException ());
                    } else {
                        Console.WriteLine (task1.Result);
                    }
                });
            }
        }
    }).Wait ();
    Console.Read ();
    connection.Stop ();
}


#====================
#gpt output=============

Python Implementation: 
def main (args): 
    connection = HubConnection ("http://127.0.0.1:8088/")
    my_hub = connection.create_hub_proxy ("MyHub")
    print ("Enter your name")
    name = input ()
    connection.start ().continue_with (task = > {
        if (task.is_faulted):
            print ("There was an error opening the connection:{0}", task.exception.get_base_exception ())
        else:
            print ("Connected")
            my_hub.on < string, string > ("addMessage", (s1, s2) = > {
                print (s1 + ": " + s2)
            })
            while (True):
                message = input ()
                if (string.is_null_or_empty (message)):
                    break
                my_hub.invoke < string > ("Send", name, message).continue_with (task1 = > {
                    if (task1.is_faulted):
                        print ("There was an error calling send: {0}", task1.exception.get_base_exception ())
                    else:
                        print (task1.result)
                })
    }).wait ()
    input ()
    connection.stop ()

C Implementation: 
void main (string *args) 
{ 
    HubConnection *connection = new HubConnection ("http://127.0.0.1:8088/"); 
    HubProxy *myHub = connection->CreateHubProxy ("MyHub"); 
    printf ("Enter your name\n"); 
    char name[64]; 
    scanf ("%s", name); 
    connection->Start ().ContinueWith (task = > { 
        if (task->IsFaulted) 
        { 
            printf ("There was an error opening the connection: %s", task->Exception->GetBaseException ()); 
        } 
        else 
        { 
            printf ("Connected\n"); 
            myHub->On < string, string > ("addMessage", (s1, s2) = > { 
                printf ("%s: %s\n", s1, s2); 
            }); 
            while (true) 
            { 
                char message[64]; 
                scanf ("%s", message); 
                if (string_is_null_or_empty (message)) 
                { 
                    break; 
                } 
                myHub->Invoke < string > ("Send", name, message).ContinueWith (task1 = > { 
                    if (task1->IsFaulted) 
                    { 
                        printf ("There was an error calling send: %s", task1->Exception->GetBaseException ()); 
                    } 
                    else 
                    { 
                        printf ("%s", task1->Result); 
                    } 
                }); 
            } 
        } 
    }).Wait (); 
    getchar (); 
    connection->Stop (); 
    delete connection;
} 

Java Implementation: 
public static void main (String [] args) {
    HubConnection connection = new HubConnection ("http://127.0.0.1:8088/");
    HubProxy myHub = connection.createHubProxy ("MyHub");
    System.out.println ("Enter your name");
    String name = System.console ().readLine ();
    connection.start ().continueWith (task = > {
        if (task.isFaulted ()) {
            System.out.println ("There was an error opening the connection:" + task.getException ().getbaseException ());
        } else {
            System.out.println ("Connected");
            myHub.on < String, String > ("addMessage", (s1, s2) = > {
                System.out.println (s1 + ": " + s2);
            });
            while (true) {
                String message = System.console ().readLine ();
                if (String.isNullOrEmpty (message)) {
                    break;
                }
                myHub.invoke <String> ("Send", name, message).continueWith (task1 = > {
                    if (task1.isFaulted()) {
                        System.out.println ("There was an error calling send: " + task1.getException ().getBaseException ());
                    } else {
                        System.out.println (task1.getResult ());
                    }
                });
            }
        }
    }).wait ();
    System.console ().readLine ();
    connection.stop ();
}

