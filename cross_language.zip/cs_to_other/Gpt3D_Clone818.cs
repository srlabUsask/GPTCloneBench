#input 
private static IEnumerable < Type > GetTypeArguments (Type t, IEnumerable < Type > values) {
    if (t.IsGenericType)
        foreach (var arg in t.GetGenericArguments ())
            values = values.Union (GetTypeArguments (arg, values));
    else
        values = values.Union (new [] {t});
    return values;
}


#====================
#gpt output=============

Python:

def get_type_arguments(t, values):
    if hasattr(t, "IsGenericType"):
        for arg in t.GetGenericArguments():
            values = values.union(get_type_arguments(arg, values))
    else:
        values = values.union([t])
    return values


C:

static IEnumerable *GetTypeArguments(Type t, IEnumerable *values)
{
    if (t->is_generic_type)
    {
        int i;
        for (i = 0; i < t->num_generic_arguments; i++)
            values = union_sets(GetTypeArguments(t->generic_arguments[i], values), values);
    }
    else
    {
        int size = 1;
        values = union_sets(construct_set(t, &size), values);
    }
 
    return values;
}


Java:

private static IEnumerable<Type> getTypeArguments(Type t, IEnumerable<Type> values) {
    if (t.isGenericType()) {
        for (Type arg : t.getGenericArguments()) {
            values = union(getTypeArguments(arg, values), values);
        }
    } else {
        int size = 1;
        values = union(constructSet(t, size), values);
    }
 
    return values;
}

