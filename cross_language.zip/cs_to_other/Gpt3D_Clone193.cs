#input 
private Update BuildMetaData (MetaData [] nvPairs) {
    Update update = new Update ();
    var ip = new List < InputProperty > ();
    foreach (var nvPair in nvPairs) {
        if (nvPair == null)
            break;
        var inputProp = new InputProperty {Name = "udf:" + nvPair.Name, Val = nvPair.Value};
        ip.Add (inputProp);
    }
    update.Items = ip.ToArray ();
    return update;
}


#====================
#gpt output=============

Python Implementation:

def BuildMetaData(nvPairs): 
  update = Update() 
  ip = list() 
  for nvPair in nvPairs: 
    if nvPair == null:
      break
    inputProp = InputProperty() 
    inputProp.Name = "udf:" + nvPair.Name
    inputProp.Val = nvPair.Value 
    ip.append(inputProp) 
  update.Items = ip.to_array() 
  return update 


C Implementaiton:

Update BuildMetaData(MetaData nvPairs[]){
  Update update;
  List<InputProperty> ip; 
  for(int i = 0; i < nvPairs.length; i++){
    if(nvPairs[i] == NULL){
      break; 
    }
    InputProperty inputProp; 
    inputProp.Name = "udf:" + nvPairs[i].Name; 
    inputProp.Val = nvPairs[i].Value;
    ip.add(inputProp); 
  }
  update.Items = ip.to_array(); 
  return update; 
}


Java Implementation: 

private Update BuildMetaData (MetaData[] nvPairs) {
    Update update = new Update ();
    ArrayList<InputProperty> ip = new ArrayList<InputProperty>();
    for (MetaData nvPair : nvPairs) {
        if (nvPair == null) {
            break;
        }
        InputProperty inputProp = new InputProperty();
        inputProp.Name = "udf:" + nvPair.Name;
        inputProp.Val = nvPair.Value;
        ip.add(inputProp);
    }
    update.Items = ip.toArray(new InputProperty[ip.size()]);
    return update;
}

