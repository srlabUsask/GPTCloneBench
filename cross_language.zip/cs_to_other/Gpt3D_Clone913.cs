#input 
private static Func < TArg, TRes > Memoize < TArg, TRes > (Func < TArg, TRes > func) {
    var cache = new Dictionary < TArg, TRes > ();
    return arg = > {
        TRes res;
        if (! cache.TryGetValue (arg, out res)) {
            Console.WriteLine ("Calculating " + arg.ToString ());
            res = func (arg);
            cache.Add (arg, res);
        } else {
            Console.WriteLine ("Getting from cache " + arg.ToString ());
        }
        return res;
    };
}


#====================
#gpt output=============

Python: 
def memoize(func):
    cache = dict()
    def wrapper(arg):
        if arg not in cache:
            print("Calculating " + str(arg))
            cache[arg] = func(arg)
        else:
            print("Getting from cache " + str(arg))
        return cache[arg]
    return wrapper

C:
Func* memoize(Func* func) {
    map<TypeArg, TypeRes> cache;
    return (TypeArg arg) {
        TypeRes res;
        if (cache.find(arg) != cache.end()) {
            printf("Calculating %d\n", arg);
            res = func(arg);
            cache.add(arg, res);
        } else {
            printf("Getting from cache %d\n", arg);
        }
        return res;
    };
}

Java: 
public static <TArg, TRes> Func<TArg, TRes> memoize(Func<TArg, TRes> func) {
    Map<TArg, TRes> cache = new HashMap<>();
    return arg -> {
        TRes res;
        if (cache.containsKey(arg)) {
            System.out.println("Calculating " + arg.toString());
            res = func.apply(arg);
            cache.put(arg, res);
        } else {
            System.out.println("Getting from cache " + arg.toString());
        }
        return res;
    };
}

