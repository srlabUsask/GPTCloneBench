#input 
protected override void WndProc (ref Message m) {
    const UInt32 WM_NCHITTEST = 0x0084;
    const UInt32 WM_MOUSEMOVE = 0x0200;
    const UInt32 HTBOTTOMRIGHT = 17;
    const int RESIZE_HANDLE_SIZE = 10;
    bool handled = false;
    if (m.Msg == WM_NCHITTEST || m.Msg == WM_MOUSEMOVE) {
        Size formSize = this.Size;
        Point screenPoint = new Point (m.LParam.ToInt32 ());
        Point clientPoint = this.PointToClient (screenPoint);
        Rectangle hitBox = new Rectangle (formSize.Width - RESIZE_HANDLE_SIZE, formSize.Height - RESIZE_HANDLE_SIZE, RESIZE_HANDLE_SIZE, RESIZE_HANDLE_SIZE);
        if (hitBox.Contains (clientPoint)) {
            m.Result = (IntPtr) HTBOTTOMRIGHT;
            handled = true;
        }
    }
    if (! handled)
        base.WndProc (ref m);
}


#====================
#gpt output=============

Python:
def WndProc(self, message):
    WM_NCHITTEST = 0x0084
    WM_MOUSEMOVE = 0x0200
    HTBOTTOMRIGHT = 17
    RESIZE_HANDLE_SIZE = 10
    handled = False
    if message.Msg == WM_NCHITTIST or message.Msg == WM_MOUSEMOVE:
        form_size = self.size
        screen_point = (message.LParam.ToInt32())
        client_point = self.PointToClient(screen_point)
        hitbox = Rectangle(form_size.Width - RESIZE_HANDLE_SIZE, form_size.Height - RESIZE_HANDLE_SIZE, RESIZE_HANDLE_SIZE, RESIZE_HANDLE_SIZE)
        if hitbox.Contains(client_point):
            message.Result = (IntPtr)HTBOTTOMRIGHT
            handled = True
    if not handled:
        super().WndProc(message)


C: 
void WndProc (Message *m) {
    const UInt32 WM_NCHITTEST = 0x0084;
    const UInt32 WM_MOUSEMOVE = 0x0200;
    const UInt32 HTBOTTOMRIGHT = 17;
    const int RESIZE_HANDLE_SIZE = 10;
    bool handled = false;
    if (m->Msg == WM_NCHITTEST || m->Msg == WM_MOUSEMOVE) {
        Size formSize = this->Size;
        Point screenPoint; 
        screenPoint.x = m->LParam & 0x0000FFFF;
        screenPoint.y = m->LParam >> 16;
        Point clientPoint = this->PointToClient (screenPoint);
        Rectangle hitBox;
        hitBox.init(formSize.Width - RESIZE_HANDLE_SIZE, formSize.Height - RESIZE_HANDLE_SIZE, RESIZE_HANDLE_SIZE, RESIZE_HANDLE_SIZE);
        if (hitBox.inside(clientPoint)) {
            m->Result = (IntPtr)HTBOTTOMRIGHT;
            handled = true;
        }
    }
    if (! handled)
        WndProc (m);
}

Java: 
protected void WndProc (Message m) {
    final UInt32 WM_NCHITTEST = 0x0084;
    final UInt32 WM_MOUSEMOVE = 0x0200;
    final UInt32 HTBOTTOMRIGHT = 17;
    final int RESIZE_HANDLE_SIZE = 10;
    boolean handled = false;
    if (m.Msg == WM_NCHITTEST || m.Msg == WM_MOUSEMOVE) {
        Size formSize = this.Size;
        Point screenPoint = new Point (m.LParam.ToInt32 ());
        Point clientPoint = this.PointToClient (screenPoint);
        Rectangle hitBox = new Rectangle (formSize.Width - RESIZE_HANDLE_SIZE, formSize.Height - RESIZE_HANDLE_SIZE, RESIZE_HANDLE_SIZE, RESIZE_HANDLE_SIZE);
        if (hitBox.Contains (clientPoint)) {
            m.Result = (IntPtr) HTBOTTOMRIGHT;
            handled = true;
        }
    }
    if (! handled)
        super.WndProc (m);
}

