#input 
private void txt_miktar_TextChanged (object sender, TextChangedEventArgs e) {
    if ((sender as TextBox).Text.Length < 1) {
        return;
    }
    try {
        int adet = Convert.ToInt32 ((sender as TextBox).Text);
    }
    catch {
        string s = "";
        s = (sender as TextBox).Text;
        s = s.Substring (0, s.Length - 1);
        (sender as TextBox).Text = s;
        (sender as TextBox).Select (s.Length, s.Length);
    }
}


#====================
#gpt output=============

Python:
def txt_miktar_TextChanged (sender, e):
    if len((sender as TextBox).Text) < 1:
        return

    try:
        adet = int((sender as TextBox).Text)
    except:
        s = ""
        s = (sender as TextBox).Text
        s = s[0:len(s)-1]
        (sender as TextBox).Text = s
        (sender as TextBox).Select(len(s), len(s))

C:
void txt_miktar_TextChanged(object* sender, TextChangedEventArgs* e) {
    if (strlen(((TextBox*)sender)->Text) < 1) {
        return;
    }
    try {
        int adet = (int)strtol(((TextBox*)sender)->Text, NULL, 10);
    }
    catch {
        char* s = "";
        s = strcpy(((TextBox*)sender)->Text);
        s = substring(s, 0, strlen(s) - 1);
        ((TextBox*)sender)->Text = s;
        ((TextBox*)sender)->Select(strlen(s), strlen(s));
    }
}

Java:
private void txt_miktar_TextChanged (Object sender, TextChangedEventArgs e) {
    if (((TextBox)sender).getText().length() < 1) {
        return;
    }
    try {
        int adet = Integer.parseInt(((TextBox)sender).getText());
    }
    catch (NumberFormatException ex) {
        String s = "";
        s = ((TextBox)sender).getText();
        s = s.substring(0, s.length() - 1);
        ((TextBox)sender).setText(s);
        ((TextBox)sender).select(s.length(), s.length());
    }
}

