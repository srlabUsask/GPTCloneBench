#input 
public void EnableControls (ControlCollection ctrl, bool isEnable) {
    foreach (Control item in ctrl) {
        if (item.HasControls ())
            EnableControls (item.Controls, isEnable);
        else if (item is WebControl)
            ((WebControl) item).Enabled = isEnable;
        else if (item is HtmlControl)
            ((HtmlControl) item).Disabled = ! isEnable;
    }
}


#====================
#gpt output=============


#PYTHON
def EnableControls(ctrl, isEnable):
    for item in ctrl:
        if item.HasControls():
            EnableControls(item.Controls, isEnable)
        elif isinstance(item, WebControl):
            item.Enabled = isEnable
        elif isinstance(item, HtmlControl):
            item.Disabled = not isEnable
            

#C
void EnableControls(ControlCollection ctrl, int isEnable) {
    Control *item;
    for (item in ctrl) {
        if (item->HasControls())
            EnableControls(item->Controls, isEnable);
        else if (item is WebControl)
            ((WebControl) item)->Enabled = isEnable;
        else if (item is HtmlControl)
            ((HtmlControl) item)->Disabled = !isEnable;
    }
}

#JAVA
public void EnableControls(ControlCollection ctrl, boolean isEnable) {
    for (Control item : ctrl) {
        if (item.HasControls())
            EnableControls(item.Controls, isEnable);
        else if (item instanceof WebControl)
            ((WebControl) item).setEnabled(isEnable);
        else if (item instanceof HtmlControl)
            ((HtmlControl) item).setDisabled(!isEnable);
    }
}

