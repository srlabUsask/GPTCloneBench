#input 
private static void ExpandItemWithInitialExpandedAttribute (PropertyGrid propertyGrid, GridItem gridItem) {
    if (gridItem != null) {
        if (gridItem.GridItemType == GridItemType.Property && gridItem.Expandable) {
            object [] objs = gridItem.Value.GetType ().GetCustomAttributes (typeof (PropertyGridInitialExpandedAttribute), false);
            if (objs.Length > 0) {
                if (((PropertyGridInitialExpandedAttribute) objs [0]).InitialExpanded) {
                    gridItem.Expanded = true;
                }
            }
        }
        foreach (GridItem childItem in gridItem.GridItems) {
            ExpandItemWithInitialExpandedAttribute (propertyGrid, childItem);
        }
    }
}


#====================
#gpt output=============

Python
def ExpandItemWithInitialExpandedAttribute (propertyGrid, gridItem):
    if (gridItem is not None):
        if (gridItem.GridItemType == GridItemType.Property and gridItem.Expandable):
            objs = gridItem.value.GetType().GetCustomAttributes(typeof (PropertyGridInitialExpandedAttribute), false)
            if (len(objs) > 0):
                if (objs[0].InitialExpanded):
                    gridItem.Expanded = True
        for childItem in gridItem.GridItems:
            ExpandItemWithInitialExpandedAttribute(propertyGrid, childItem)

C
void ExpandItemWithInitialExpandedAttribute(PropertyGrid propertyGrid, GridItem gridItem) {
	if (gridItem != NULL) {
		if (gridItem.GridItemType == GridItemType.Property && gridItem.Expandable) {
			Object objs[];
			objs = gridItem.value.GetType().GetCustomAttributes(typeof (PropertyGridInitialExpandedAttribute), false);
			if (len(objs) > 0) {
				if (objs[0].InitialExpanded) {
					gridItem.Expanded = true;
				}
			}
		}
		for (int i = 0; i < gridItem.GridItems.length;i++) {
			ExpandItemWithInitialExpandedAttribute(propertyGrid, gridItem.GridItems[i]);
		}
	}
}

Java
private static void ExpandItemWithInitialExpandedAttribute(PropertyGrid propertyGrid, GridItem gridItem) {
    if (gridItem != null) {
        if (gridItem.getGridItemType() == GridItemType.PROPERTY && gridItem.isExpandable()) {
            Object[] objs = gridItem.getValue().getClass().getCustomAttributes(PropertyGridInitialExpandedAttribute.class, false);
            if (objs.length > 0) {
                if (objs[0].getInitialExpanded()) {
                    gridItem.setExpanded(true);
                }
            }
        }
        for (GridItem childItem : gridItem.getGridItems()) {
            ExpandItemWithInitialExpandedAttribute(propertyGrid, childItem);
        }
    }
 }

