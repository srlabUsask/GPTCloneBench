#input 
static void Main (string [] args) {
    string processName = "OUTLOOK";
    Console.WriteLine ("Press the any key to stop...\n");
    while (! Console.KeyAvailable) {
        Process [] pp = Process.GetProcessesByName (processName);
        if (pp.Length == 0) {
            Console.WriteLine (processName + " does not exist");
        } else {
            Process p = pp [0];
            if (lastTime == null || lastTime == new DateTime ()) {
                lastTime = DateTime.Now;
                lastTotalProcessorTime = p.TotalProcessorTime;
            } else {
                curTime = DateTime.Now;
                curTotalProcessorTime = p.TotalProcessorTime;
                double CPUUsage = (curTotalProcessorTime.TotalMilliseconds - lastTotalProcessorTime.TotalMilliseconds) / curTime.Subtract (lastTime).TotalMilliseconds / Convert.ToDouble (Environment.ProcessorCount);
                Console.WriteLine ("{0} CPU: {1:0.0}%", processName, CPUUsage * 100);
                lastTime = curTime;
                lastTotalProcessorTime = curTotalProcessorTime;
            }
        }
        Thread.Sleep (250);
    }
}


#====================
#gpt output=============

Python:

process_name = "OUTLOOK"
print("Press any key to stop...")

while True:
    pp = list(map(lambda process: process.name == process_name, psutil.process_iter()))

    if not pp:
        print(f"{process_name} does not exist")
    else:
        p = pp[0]
        last_time = last_time if last_time else datetime.now()
        last_total_processor_time = last_total_processor_time if last_total_processor_time else p.cpu_times().user
        cur_time = datetime.now()
        cur_total_processor_time = p.cpu_times().user
        cpu_usage = (cur_total_processor_time - last_total_processor_time) / cur_time.subtract(last_time).total_seconds()/ psutil.cpu_count()
        print(f"{process_name} CPU: {cpu_usage * 100:0.0f}%")
        last_time = cur_time
        last_total_processor_time = cur_total_processor_time

    time.sleep(250)

C:

char *processName = "OUTLOOK";
printf ("Press the any key to stop...\n");

while (1) {
    size_t n = 0;
    struct process **pp = getProcessByName(processName, &n);
    if (n == 0) {
        printf ("%s does not exist\n", processName);
    } else {
        struct process *p = pp[0];
        if (lastTime == 0 || lastTime ==  currentTime()) {
            lastTime = currentTime();
            lastTotalProcessorTime = getTotalProcessorTime(p);
        } else {
            curTime = currentTime();
            curTotalProcessorTime = getTotalProcessorTime(p);
            double CPUUsage = (curTotalProcessorTime - lastTotalProcessorTime) / (curTime - lastTime)  / getProcessorCount();
            printf ("%s CPU: %.0f%%\n", processName, CPUUsage * 100);
            lastTime = curTime;
            lastTotalProcessorTime = curTotalProcessorTime;
        }
    }
    sleep(250);
}
Java:

String processName = "OUTLOOK";
System.out.println("Press any key to stop...");

while (true) {
    List<ProcessHandle> pp = ProcessHandle.allProcesses()
        .filter(ph -> ph.info().command().orElse("").contains(processName)).collect(Collectors.toList());
    if (pp.size() == 0) {
        System.out.println(processName + " does not exist");
    } else {
        ProcessHandle p = pp.get(0);
        if (lastTime == null || lastTime == 0) {
            lastTime = System.nanoTime();
            lastTotalProcessorTime = p.info().totalCpuDuration().orElse(0L);
        } else {
            curTime = System.nanoTime();
            curTotalProcessorTime = p.info().totalCpuDuration().orElse(0L);
            double CPUUsage = (curTotalProcessorTime - lastTotalProcessorTime) / (curTime - lastTime)  / Runtime.getRuntime().availableProcessors();
            System.out.println(processName + " CPU: " + CPUUsage * 100 + "%");
            lastTime = curTime;
            lastTotalProcessorTime = curTotalProcessorTime;
        }
    }
    Thread.sleep(250);
 }

