#input 
private void SetTableDescriptions (Type tableType) {
    string fullTableName = context.GetTableName (tableType);
    Regex regex = new Regex (@"(\[\w+\]\.)?\[(?<table>.*)\]");
    Match match = regex.Match (fullTableName);
    string tableName;
    if (match.Success)
        tableName = match.Groups ["table"].Value;
    else
        tableName = fullTableName;
    var tableAttrs = tableType.GetCustomAttributes (typeof (TableAttribute), false);
    if (tableAttrs.Length > 0)
        tableName = ((TableAttribute) tableAttrs [0]).Name;
    foreach (var prop in tableType.GetProperties (System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance)) {
        if (prop.PropertyType.IsClass && prop.PropertyType != typeof (string))
            continue;
        var attrs = prop.GetCustomAttributes (typeof (DisplayAttribute), false);
        if (attrs.Length > 0)
            SetColumnDescription (tableName, prop.Name, ((DisplayAttribute) attrs [0]).Name);
    }
}


#====================
#gpt output=============

Python: 
def set_table_descriptions(table_type):
    full_table_name = context.get_table_name(table_type)
    regex = re.compile(r'(\[\w+\]\.)?\[(?P<table>.*)\]')
    match = regex.match(full_table_name)
    if match:
        table_name = match.group('table')
    else:
        table_name = full_table_name
    table_attrs = table_type.get_attr_data(type(TableAttribute), False)
    if len(table_attrs) > 0:
        table_name = table_attrs[0].name
    for prop in table_type.get_prop_data(
        System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance):
        if prop.prop_type.is_class and not prop.prop_type is type(str):
            continue
        attrs = prop.get_attr_data(type(DisplayAttribute), False)
        if attrs:
            set_column_description(table_name, prop.name, attrs[0].name)

C:
void SetTableDescriptions(Type tableType) {
    char *fullTableName = context.GetTableName(tableType);
    Regex *regex = new Regex(\\.(\\w+)\\.\\.(\\(\\?&lt;table\\>.*)\\]);
    Match *match = regex->Match(fullTableName);
    char *tableName;
    if (match->Success) {
        tableName = match->Groups["table"].Value;
   } else {
        tableName = fullTableName; 
   }
   CustomAttributes *tableAttrs = tableType->GetCustomAttributes(
       typeof(TableAttribute), false);
   if (tableAttrs->Length > 0) {
       tableName = ((TableAttribute *) tableAttrs[0])->Name;
   }
   
   for (int i = 0; i < tableType->GetProperties(
       System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance)->length; i++) {
       Property *prop = tableType->GetProperties(
           System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance)[i];
       if (prop->PropertyType.IsClass && !prop->PropertyType == typeof(string)) {
           continue; 
       }
       CustomAttributes *attrs = prop->GetCustomAttributes(typeof(DisplayAttribute), false);
       if (attrs->Length > 0) {
           SetColumnDescription(tableName, prop->Name, ((DisplayAttribute *) attrs[0])->Name);
       }
   }
}

Java: 
private void setTableDescriptions(Type tableType) {
    String fullTableName = context.getTableName(tableType);
    Pattern regex = Pattern.compile("(\\[\\w+\\]\\.)?\\[(?<table>.*)\\]");
    Matcher match = regex.matcher(fullTableName);
    String tableName;
    if (match.find()) {
        tableName = match.group("table");
    }
    else {
        tableName = fullTableName;
    }
    TableAttribute[] tableAttrs = tableType.getAnnotationsByType(TableAttribute.class);
    if (tableAttrs.length > 0) {
        tableName = tableAttrs[0].name();
    }
    for (Field prop : tableType.getDeclaredFields()) {
        if (prop.getType().isAnnotation()) {
            continue;
        }
        DisplayAttribute attrs = prop.getAnnotation(DisplayAttribute.class);
        if (attrs != null) {
            setColumnDescription(tableName,prop.getName(),attrs.name());
        }
    }
}

