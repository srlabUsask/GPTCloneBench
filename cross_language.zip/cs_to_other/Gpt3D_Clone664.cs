#input 
private void DrawGroupBox (GroupBox box, Graphics g, Color textColor, Color borderColor) {
    if (box != null) {
        Brush textBrush = new SolidBrush (textColor);
        Brush borderBrush = new SolidBrush (borderColor);
        Pen borderPen = new Pen (borderBrush);
        SizeF strSize = g.MeasureString (box.Text, box.Font);
        Rectangle rect = new Rectangle (box.ClientRectangle.X, box.ClientRectangle.Y + (int) (strSize.Height / 2), box.ClientRectangle.Width - 1, box.ClientRectangle.Height - (int) (strSize.Height / 2) - 1);
        g.Clear (this.BackColor);
        g.DrawString (box.Text, box.Font, textBrush, box.Padding.Left, 0);
        g.DrawLine (borderPen, rect.Location, new Point (rect.X, rect.Y + rect.Height));
        g.DrawLine (borderPen, new Point (rect.X + rect.Width, rect.Y), new Point (rect.X + rect.Width, rect.Y + rect.Height));
        g.DrawLine (borderPen, new Point (rect.X, rect.Y + rect.Height), new Point (rect.X + rect.Width, rect.Y + rect.Height));
        g.DrawLine (borderPen, new Point (rect.X, rect.Y), new Point (rect.X + box.Padding.Left, rect.Y));
        g.DrawLine (borderPen, new Point (rect.X + box.Padding.Left + (int) (strSize.Width), rect.Y), new Point (rect.X + rect.Width, rect.Y));
    }
}


#====================
#gpt output=============

Python:
def drawGroupBox(box, graphics, text_color, border_color):
    if box is not None:
        text_brush = graphics.SolidBrush(text_color)
        border_brush = graphics.SolidBrush(border_color)
        border_pen = graphics.Pen(border_brush)
        string_size = graphics.MeasureString(box.Text, box.Font)
        rect = graphics.Rectangle(box.ClientRectangle.X, box.ClientRectangle.Y + (string_size.Height/2), box.ClientRectangle.Width - 1, box.ClientRectangle.Height - (string_size.Height/2) - 1)
        graphics.Clear(BackColor)
        graphics.DrawString(box.Text, box.Font, text_brush, box.Padding.Left, 0)
        graphics.DrawLine(border_pen, rect.Location, (rect.X, rect.Y + rect.Height))
        graphics.DrawLine(border_pen, (rect.X + rect.Width, rect.Y), (rect.X + rect.Width, rect.Y + rect.Height))
        graphics.DrawLine(border_pen, (rect.X, rect.Y + rect.Height), (rect.X + rect.Width, rect.Y + rect.Height))
        graphics.DrawLine(border_pen, (rect.X, rect.Y), (rect.X + box.Padding.Left, rect.Y))
        graphics.DrawLine(border_pen, (rect.X + box.Padding.Left + (string_size.Width), rect.Y), (rect.X + rect.Width, rect.Y))

C:
void DrawGroupBox(GroupBox *box, Graphics *g, Color textColor, Color borderColor)
{
    if (box != NULL)
    {
        Brush *textBrush = new SolidBrush(textColor);
        Brush *borderBrush = new SolidBrush(borderColor);
        Pen *borderPen = new Pen(borderBrush);
        SizeF strSize = g->MeasureString(box->Text, box->Font);
        Rectangle rect = new Rectangle(box->ClientRectangle.X, box->ClientRectangle.Y + (int) (strSize.Height / 2), 
        box->ClientRectangle.Width - 1, box->ClientRectangle.Height - (int) (strSize.Height / 2) - 1);
        g->Clear(this->BackColor);
        g->DrawString(box->Text, box->Font, textBrush, box->Padding.Left, 0);
        g->DrawLine(borderPen, rect.Location, Point(rect.X, rect.Y + rect.Height));
        g->DrawLine(borderPen, Point(rect.X + rect.Width, rect.Y), Point(rect.X + rect.Width, rect.Y + rect.Height));
        g->DrawLine(borderPen, Point(rect.X, rect.Y + rect.Height), Point(rect.X + rect.Width, rect.Y + rect.Height));
        g->DrawLine(borderPen, Point(rect.X, rect.Y), Point(rect.X + box->Padding.Left, rect.Y));
        g->DrawLine(borderPen, Point(rect.X + box->Padding.Left + (int) (strSize.Width), rect.Y), Point(rect.X + rect.Width, rect.Y));
    }
}

Java:
public void drawGroupBox(GroupBox box, Graphics g, Color textColor, Color borderColor){
	if(box != null){
		Brush textBrush = new SolidBrush(textColor);
		Brush borderBrush = new SolidBrush(borderColor);
		Pen borderPen = new Pen(borderBrush);
		SizeF strSize = g.MeasureString(box.Text, box.Font);
		Rectangle rect = new Rectangle(box.ClientRectangle.X, box.ClientRectangle.Y + (int)(strSize.Height/2), box.ClientRectangle.Width - 1, box.ClientRectangle.Height - (int)(strSize.Height/2) - 1);
		g.Clear(this.BackColor);
		g.DrawString(box.Text, box.Font, textBrush, box.Padding.Left, 0);
		g.DrawLine(borderPen, rect.Location, new Point(rect.X, rect.Y + rect.Height));
		g.DrawLine(borderPen, new Point(rect.X + rect.Width, rect.Y), new Point(rect.X + rect.Width, rect.Y + rect.Height));
		g.DrawLine(borderPen, new Point(rect.X, rect.Y + rect.Height), new Point(rect.X + rect.Width, rect.Y + rect.Height));
		g.DrawLine(borderPen, new Point(rect.X, rect.Y), new Point(rect.X + box.Padding.Left, rect.Y));
		g.DrawLine(borderPen, new Point(rect.X + box.Padding.Left + (int)(strSize.Width), rect.Y), new Point(rect.X + rect.Width, rect.Y)); 
	}
}

