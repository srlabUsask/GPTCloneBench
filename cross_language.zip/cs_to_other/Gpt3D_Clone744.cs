#input 
private static string GetPropertyName < TPropertySource > (Expression < Func < TPropertySource, object > > expression) {
    var lambda = expression as LambdaExpression;
    MemberExpression memberExpression;
    if (lambda.Body is UnaryExpression) {
        var unaryExpression = lambda.Body as UnaryExpression;
        memberExpression = unaryExpression.Operand as MemberExpression;
    } else {
        memberExpression = lambda.Body as MemberExpression;
    }
    Debug.Assert (memberExpression != null, "Please provide a lambda expression like 'n => n.PropertyName'");
    if (memberExpression != null) {
        var propertyInfo = memberExpression.Member as PropertyInfo;
        return propertyInfo.Name;
    }
    return null;
}


#====================
#gpt output=============

Python implementation:
def get_property_name(expression):
    lambda_expression = expression
    member_expression = None 
    if isinstance(lambda_expression.body, UnaryExpression):
        unary_expression = lambda_expression.body
        member_expression = unary_expression.operand
    else :
        member_expression = lambda_expression.body 
    assert member_expression is not None, "Please provide a lambda expression like 'n => n.PropertyName'" 
    if member_expression is not None:
        property_info = member_expression.member 
        return property_info.name 
    return None 

C implementation:
char * get_property_name(expression_t expression) {
    lambda_expression_t lambda = expression;
    member_expression_t member_expression;
    if (lambda->body->type == unary_expression_type) {
        unary_expression_t unary_expression = lambda->body;
        member_expression = unary_expression->operand;
    } else {
        member_expression = lambda->body;
    }
    assert(member_expression != NULL, "Please provide a lambda expression like 'n => n.PropertyName'");
    if (member_expression != NULL) {
        property_info_t property_info = member_expression->member;
        return property_info->name;
    }
    return NULL;
}

Java implementation:
public static String getPropertyName(Function<Object, String> expression) {
    // Create lambda expression
    LambdaExpression lambda = expression;
    MemberExpression memberExpression;

    // Check if expression is unary expression
    if (lambda.getBody() instanceof UnaryExpression) {
        UnaryExpression unaryExpression = (UnaryExpression) lambda.getBody();
        memberExpression = unaryExpression.getOperand();
    } else {
        memberExpression = lambda.getBody();
    }

    assert(memberExpression != null, "Please provide a lambda expression like 'n -> n.PropertyName'");

    if (memberExpression != null) {
        // Get property info from member expression
        PropertyInfo propertyInfo = memberExpression.getMember();
        return propertyInfo.getName();
    }
    return null;
}

