#input 
public static void DisplayIPAddresses () {
    StringBuilder sb = new StringBuilder ();
    NetworkInterface [] networkInterfaces = NetworkInterface.GetAllNetworkInterfaces ();
    foreach (NetworkInterface network in networkInterfaces) {
        IPInterfaceProperties properties = network.GetIPProperties ();
        foreach (IPAddressInformation address in properties.UnicastAddresses) {
            if (address.Address.AddressFamily != AddressFamily.InterNetwork)
                continue;
            if (IPAddress.IsLoopback (address.Address))
                continue;
            sb.AppendLine (address.Address.ToString () + " (" + network.Name + ")");
        }
    }
    MessageBox.Show (sb.ToString ());
}


#====================
#gpt output=============

Python:
def display_ip_addresses():
    sb = []
    networks = get_all_network_interfaces()
    for network in networks:
        properties = network.get_ip_properties()
        for address in properties.unicast_addresses:
            if address.family != socket.AF_INET:
                continue
            if ipaddress.ip_address(address.ip).is_loopback:
                continue
            sb.append(address.ip + " (" + network.name + ")")
    print(sb)

C:
void display_ip_addresses() {
  char sb[1000], temp[100];
  int n = get_all_network_interfaces();
 
  for (int i = 0; i < n; i++) {
    NetworkInterface network = get_network_interface(i);
    IPProperties properties = network.get_ip_properties();
 
    for (int j = 0; j < properties.unicast_addresses_count; j++) {
      IPAddressInformation address = properties.unicast_addresses[j];
      if (address.family != AF_INET) {
        continue;
      }
 
      if (IPAddress_IsLoopback(address.ip)) {
        continue;
      }
 
      sprintf(temp, "%s (%s)", address.ip, network.name);
      strcat(sb, temp);
    }
  }
 
  printf("%s", sb);
}

Java:
public static void displayIPAddresses() {
    StringBuilder sb = new StringBuilder();
    Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();

    while (networkInterfaces.hasMoreElements()) {
        NetworkInterface network = networkInterfaces.nextElement();
        Enumeration<InetAddress> addresses = network.getInetAddresses();

        while (addresses.hasMoreElements()) {
            InetAddress address = addresses.nextElement();
            if (address instanceof Inet4Address && !address.isLoopbackAddress()) {
                sb.append(address + " (" + network.getName() + ")" + "\n");
            }
        }
    }
    System.out.println(sb);
}

