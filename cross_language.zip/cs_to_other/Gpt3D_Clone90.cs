#input 
static void Main (string [] args) {
    var l = new List < List < double > > () {new List < Double > () {0, 16.0000, 15.0000, 0, 2.7217, 3.7217}, new List < Double > () {0, 0, 15.0000, 15.0000, 5.6904, 5.6904}};
    int i = 1;
    var result = from sublist in l
        select new {min = sublist.Min (), max = sublist.Max (), index = i ++};
    foreach (var r in result)
        Console.WriteLine (String.Format ("Index: {0} Min: {1} Max: {2}", r.index, r.min, r.max));
    Console.ReadKey ();
}


#====================
#gpt output=============

Python: 
def Main(args): 
    l = [[0, 16.0000, 15.0000, 0, 2.7217, 3.7217], [0, 0, 15.0000, 15.0000, 5.6904, 5.6904]] 
    i = 1
    result = [ {'min': sublist.min(), 'max': sublist.max(), 'index': i} for sublist in l ]
    for r in result: 
        print("Index: {index} Min: {min} Max: {max}".format(**r))
        
C:
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char* argv[]) {
    double l[2][6] = {{0, 16.0000, 15.0000, 0, 2.7217, 3.7217}, {0, 0, 15.0000, 15.0000, 5.6904, 5.6904}};
    int i = 1; 
    struct {
        double min; 
        double max; 
        int index; 
    } *result = malloc(sizeof(struct)); 
    for (int j = 0; j < 2; j++) {
        result[j].min = getMin(l[j], 6);
        result[j].max = getMax(l[j], 6); 
        result[j].index = i++;
    }
    
    for(int k = 0; k < 2; k++) {
        printf("Index: %d Min: %lf Max: %lf\n", result[k].index, result[k].min, result[k].max);
    }
    return 0; 
}

double getMin(double arr[], int n) { 
    double min = arr[0];
    for(int i = 1; i < n; i++) {
        if (arr[i] < min) {
            min = arr[i];
        }
    }
    return min; 
}

double getMax(double arr[], int n) { 
    double max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max; 
}

Java: 
public static void main (String[] args) {
    List<List<Double>> l = new ArrayList<List<Double>>() {{
        add(Arrays.asList(0.0, 16.0000, 15.0000, 0.0, 2.7217, 3.7217)); 
        add(Arrays.asList(0.0, 0.0, 15.0000, 15.0000, 5.6904, 5.6904)); 
    }}; 
    int i = 1;
    List<Map<String, Double>> result = new ArrayList<>(); 
    for (List<Double> sublist : l) {
        Map<String, Double> minmax = new HashMap<>();
        minmax.put("min", Collections.min(sublist)); 
        minmax.put("max", Collections.max(sublist)); 
        minmax.put("index", (double) i++); 
        result.add(minmax); 
    }

    for (Map<String, Double> r : result) {
        System.out.println(String.format("Index: %.0f Min: %f Max: %f", r.get("index"), r.get("min"), r.get("max"))); 
    }
    System.in.read(); 
}

