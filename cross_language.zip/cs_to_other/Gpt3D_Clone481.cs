#input 
private static void note () {
    int [] i = new int [1];
    do
        {
            Console.WriteLine ("Please enter test result");
            bool result = int.TryParse (Console.ReadLine (), out i [0]);
            if (! result) {
                Console.WriteLine ("Please enter a number");
                continue;
            }
            if (i [0] == 999) {
                Console.WriteLine ("You entered 999 to stop");
                break;
            } else if (i [0] < 0 || i [0] > 100) {
                Console.WriteLine ("Enter a value between 0 and 100");
            } else if (i [0] >= 90) {
                Console.WriteLine ("note is A");
            } else if (i [0] >= 80) {
                Console.WriteLine ("note is B");
            } else if (i [0] >= 70) {
                Console.WriteLine ("note is C");
            } else if (i [0] >= 60) {
                Console.WriteLine ("note is D");
            } else if (i [0] < 60) {
                Console.WriteLine ("Failure");
            }
            Console.WriteLine ("Your result is:" + i [0]);
        } while (true);
}


#====================
#gpt output=============

Python Implementation:
def note():
    i = [0]
    while True:
        print("Please enter test result")
        result = True
        try:
            i[0] = int(input())
        except ValueError:
            print("Please enter a number")
            result = False
        if result:
            if i[0] == 999:
                print("You entered 999 to stop")
                break
            elif 0 <= i[0] <= 100:
                if 90 <= i[0]:
                    print("note is A")
                elif 80 <= i[0]:
                    print("note is B")
                elif 70 <= i[0]:
                    print("note is C")
                elif 60 <= i[0]:
                    print("note is D")
                else:
                    print("Failure")
            else:
                print("Enter a value between 0 and 100")
            print("Your result is:" + str(i[0]))

Java Implementation:
 private static void note() {
 	int[] i = new int[1];
 	do {
 		System.out.println("Please enter test result");
 		boolean result = parseInt(i);
 		if (!result) {
 			System.out.println("Please enter a number");
 			continue;
 		}
 		if (i[0] == 999) {
 			System.out.println("You entered 999 to stop");
 			break;
 		} else if (i[0] < 0 || i[0] > 100) {
 			System.out.println("Enter a value between 0 and 100");
 		} else if (i[0] >= 90) {
 			System.out.println("note is A");
 		} else if (i[0] >= 80) {
 			System.out.println("note is B");
 		} else if (i[0] >= 70) {
 			System.out.println("note is C");
 		} else if (i[0] >= 60) {
 			System.out.println("note is D");
 		} else if (i[0] < 60) {
 			System.out.println("Failure");
 		}
 		System.out.println("Your result is:" + i[0]);
 	} while (true);
 }
 
 private static boolean parseInt(int[] array) {
 	String num = System.console().readLine();
 	try {
 		array[0] = Integer.parseInt(num);
 		return true;
 	} catch (NumberFormatException ex) {
 		return false;
 	}
 }

C Implementation:
void note()
{
    int i[1];
 
    do
    {
        printf("Please enter test result\n");
        bool result = read_int(&i[0]);
 
        if (!result)
        {
            printf("Please enter a number\n");
            continue;
        }
        if (i[0] == 999){
            printf("You entered 999 to stop\n");
            break;
        }
        else if (i[0] > 100 || i[0] < 0)
        {
            printf("Enter a value between 0 and 100\n");
        }
        else if (i[0] >= 90)
        {
            printf("note is A\n");
        }
        else if (i[0] >= 80)
        {
            printf("note is B\n");
        }
        else if (i[0] >= 70)
        {
            printf("note is C\n");
        }
        else if (i[0] >= 60)
        {
            printf("note is D\n");
        }
        else if (i[0] < 60)
        {
            printf("Failure\n");
        }        
 
        printf("Your result is: %d\n", i[0]);
    }
    while (1);
}
 
bool read_int(int* i)
{
    char str[100];
    fgets(str, sizeof(str), stdin);
    char* eptr;
    *i = strtol(str, &eptr, 10);
 
    return (strlen(str) > 0 && (size_t)(eptr - str) == strlen(str));
}

