#input 
private static void Test (Action toTest) {
    for (int i = 0; i < 100; i ++) {
        var sw = Stopwatch.StartNew ();
        toTest ();
        sw.Stop ();
        Console.WriteLine ("costs {0}", sw.ElapsedMilliseconds);
        sw.Reset ();
    }
}


#====================
#gpt output=============

Python:
def test(toTest):
    for i in range(100):
        sw = time.time()
        toTest()
        sw = time.time() - sw
        print("costs {}".format(sw * 1000))

C:
void Test (void (*toTest)()) {
    for (int i = 0; i < 100; i ++) {
        clock_t sw = clock();
        toTest();
        sw = clock() - sw;
        printf("costs %.2f", (float)sw / CLOCKS_PER_SEC * 1000);
    }
}

Java:
private static void Test (Runnable toTest) {
    for (int i = 0; i < 100; i ++) {
        Long sw = System.currentTimeMillis();
        toTest.run();
        sw = System.currentTimeMillis() - sw;
        System.out.println("costs " + sw);
    }
}

