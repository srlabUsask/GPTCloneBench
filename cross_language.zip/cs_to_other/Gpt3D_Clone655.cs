#input 
public static object GetPropertyValue (object srcobj, string propertyName) {
    if (srcobj == null)
        return null;
    object obj = srcobj;
    string [] propertyNameParts = propertyName.Split ('.');
    foreach (string propertyNamePart in propertyNameParts) {
        if (obj == null)
            return null;
        if (! propertyNamePart.Contains ("[")) {
            PropertyInfo pi = obj.GetType ().GetProperty (propertyNamePart);
            if (pi == null)
                return null;
            obj = pi.GetValue (obj, null);
        } else {
            int indexStart = propertyNamePart.IndexOf ("[") + 1;
            string collectionPropertyName = propertyNamePart.Substring (0, indexStart - 1);
            int collectionElementIndex = Int32.Parse (propertyNamePart.Substring (indexStart, propertyNamePart.Length - indexStart - 1));
            PropertyInfo pi = obj.GetType ().GetProperty (collectionPropertyName);
            if (pi == null)
                return null;
            object unknownCollection = pi.GetValue (obj, null);
            if (unknownCollection.GetType ().IsArray) {
                object [] collectionAsArray = unknownCollection as Array [];
                obj = collectionAsArray [collectionElementIndex];
            } else {
                System.Collections.IList collectionAsList = unknownCollection as System.Collections.IList;
                if (collectionAsList != null) {
                    obj = collectionAsList [collectionElementIndex];
                } else {
                }
            }
        }
    }
    return obj;
}


#====================
#gpt output=============

Python Implementation:
def get_property_value(srcobj, property_name):
    if srcobj is None:
        return None
    obj = srcobj
    property_name_parts = property_name.split('.')
    for property_name_part in property_name_parts:
        if obj is None:
            return None
        if not "[" in property_name_part:
            pi = getattr(obj, property_name_part)
            obj = pi()
        else:
            index_start = property_name_part.index('[') + 1
            collection_property_name = property_name_part[0:index_start-1]
            collection_element_index = int(property_name_part[index_start:-1])
            pi = getattr(obj, collection_property_name)
            unknown_collection = pi()
            if isinstance(unknown_collection, list):
                obj = unknown_collection[collection_element_index]
            elif isinstance(unknown_collection, dict):
                obj = unknown_collection[property_name_part[index_start:-1]]
            else: 
               raise TypeError

    return obj


C Implementation:
#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <stdbool.h> 

typedef struct {
    char* propertyName; 
    char* value; 
} PropertyValue; 

PropertyValue* getPropertyValue( PropertyValue* srcobj, char* propertyName ) 
{ 
    if ( srcobj == NULL ) 
        return NULL; 

    PropertyValue* obj = srcobj; 
    char *propertyNameParts[100]; 
    int i = 0; 
    char *part = strtok (propertyName, "."); 

    while (part != NULL) 
    { 
        propertyNameParts[i] = part; 
        part = strtok (NULL, "."); 
        i++; 
    } 

    int splitSize = i;
 
    for (i = 0; i < splitSize; i++) { 
        if (obj == NULL) 
            return NULL;
  
        if (strstr(propertyNameParts[i], "[") == NULL) { 
            PropertyValue* pi = NULL; 

            while(obj->propertyName != NULL)
            {
                if(!strcmp(obj->propertyName, propertyNameParts[i]))
                    pi = obj;

                obj++;
            } 

            if (pi == NULL) 
                return NULL;
            
            return pi;  
        }
        else { 
            int indexStart = 0; 
            while(propertyNameParts[i][indexStart] != '[') 
                indexStart++;
            
            int collectionPropertyNameLen = indexStart; 
            char collectionPropertyName[collectionPropertyNameLen + 1]; 
            strncpy(collectionPropertyName, propertyNameParts[i], collectionPropertyNameLen); 
            collectionPropertyName[collectionPropertyNameLen] = '\0'; 
  
            int collectionElementIndex = atoi (strstr(propertyNameParts[i], "[") + 1); 

            PropertyValue* pi = NULL; 

            while(obj->propertyName != NULL)
            {
                if(!strcmp(obj->propertyName, collectionPropertyName))
                    pi = obj;

                obj++;
            } 

            if (pi == NULL) 
                return NULL;

            obj = pi; 
            obj += collectionElementIndex;
        } 
    } 

    return obj; 
} 


Java Implementation:
public static Object getPropertyValue(Object srcObj, String propertyName) {
    if(srcObj == null)
        return null;
    Object obj = srcObj;
    String[] propertyNameParts = propertyName.split("\\.");
    
    for(String propertyNamePart : propertyNameParts) {
        if(obj == null)
            return null;
        if(!propertyNamePart.contains("[")) {
            try {
                java.lang.reflect.Method method = obj.getClass().getMethod(propertyNamePart);
                obj = method.invoke(obj);
            } catch (Exception e) {
                return null;
            }
        } else {
            int indexStart = propertyNamePart.indexOf("[") + 1;
            String collectionPropertyName = propertyNamePart.substring(0, indexStart - 1);
            int collectionElementIndex = Integer.parseInt(propertyNamePart.substring(indexStart, propertyNamePart.length() - indexStart - 1));
            try {
                java.lang.reflect.Method method = obj.getClass().getMethod(collectionPropertyName);
                Object unknownCollection = method.invoke(obj);
                if(unknownCollection instanceof Object[]) {
                    Object[] collectionAsArray = (Object[]) unknownCollection;
                    obj = collectionAsArray[collectionElementIndex];
                } else if(unknownCollection instanceof List) {
                    List collectionAsList = (List) unknownCollection;
                    obj = collectionAsList.get(collectionElementIndex);
                }
            } catch(Exception e) {
                return null;
            }
        }
    }

    return obj;
}

