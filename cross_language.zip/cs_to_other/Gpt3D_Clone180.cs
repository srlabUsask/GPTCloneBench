#input 
protected void Button1_Click (object sender, EventArgs e) {
    try {
        using (var conn = new SqlConnection (ConfigurationManager.ConnectionStrings ["RegistrationConnectionString"].ConnectionString))
        {
            using (var cmd = new SqlCommand ("spCheckUsernameForAnswer", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add (new SqlParameter ("@username", TextBoxUN.Text));
                conn.Open ();
                var returnCode = Convert.ToInt32 (cmd.ExecuteScalar ());
                if (returnCode == 1) {
                    Label1.Text = "Username found";
                } else {
                    Label1.Text = "not found";
                    Register ();
                }
            }}}
    catch (Exception ex) {
        Response.Write ("Error:" + ex.ToString ());
    }
}


#====================
#gpt output=============

Python:

def button1_click(sender, event_args):
    try:
        conn = sqlite3.connect(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString)
        cur = conn.cursor()
        cur.execute("spCheckUsernameForAnswer", (TextBoxUN.Text, ))
        return_code = cur.fetchone()[0]
        if return_code == 1:
            Label1.Text = "Username found"
        else:
            Label1.Text = "not found"
            Register()
    except Exception as ex:
        response.write("Error:" + ex.ToString())

C:

void Button1_Click(Object sender, EventArgs e)
{
    sqlite3 *conn;
    sqlite3_stmt * stmt;
    int rc;

    rc = sqlite3_open_v2(ConfigurationManager.ConnectionStrings["RegistrationConnectionString"].ConnectionString, &conn, SQLITE_OPEN_READONLY, NULL);
    if( rc ) {
        fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
    }

    rc = sqlite3_prepare_v2(conn, "spCheckUsernameForAnswer", -1, & stmt, NULL);
    if(rc != SQLITE_OK) {
        fprintf(stderr, "Preparation failed: %s\n", sqlite3_errmsg(conn));
        sqlite3_close(conn);
    }

    sqlite3_bind_text(stmt, 1, TextBoxUN.Text, -1, SQLITE_STATIC);
    rc = sqlite3_step( stmt );
    if(rc == SQLITE_ROW && sqlite3_column_int(stmt, 0) == 1) {
        Label1.Text = "Username found";
    }
    else {
        Label1.Text = "not found";
        Register();
    }
    sqlite3_finalize(stmt);
    sqlite3_close(conn);

Java:

protected void Button1_Click (Object sender, EventArgs e) {
    try {
        Connection conn = DriverManager.getConnection(ConfigurationManager.ConnectionStrings ["RegistrationConnectionString"].ConnectionString);

        String query = "spCheckUsernameForAnswer";
        PreparedStatement pstmt = conn.prepareStatement(query);

        pstmt.setString(1, TextBoxUN.Text); // Set String parameter 1
        ResultSet rs = pstmt.executeQuery();

        if (rs.next() && rs.getInt(1) == 1) {
            Label1.Text = "Username found";
        } else {
            Label1.Text = "not found";
            Register();
        }

    } catch (Exception ex) {
        Response.Write("Error:" + ex.ToString());
    }
}

