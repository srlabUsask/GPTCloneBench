#input 
public override void OnException (ExceptionContext filterContext) {
    filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;
    filterContext.ExceptionHandled = true;
    filterContext.HttpContext.Response.ClearContent ();
    var controllerName = (string) filterContext.RouteData.Values ["controller"];
    var actionName = (string) filterContext.RouteData.Values ["action"];
    var model = new HandleErrorInfo (filterContext.Exception, controllerName, actionName);
    filterContext.Result = new ViewResult {ViewName = View, MasterName = Master, ViewData = new ViewDataDictionary < HandleErrorInfo > (model), TempData = filterContext.Controller.TempData};
    filterContext.Exception = null;
}


#====================
#gpt output=============

Python:
def OnException (filterContext): 
    filterContext.HttpContext.Response.TrySkipIisCustomErrors = True
    filterContext.ExceptionHandled = True
    filterContext.HttpContext.Response.ClearContent ()
    controllerName = filterContext.RouteData.Values["controller"]
    actionName = filterContext.RouteData.Values["action"]
    model = HandleErrorInfo (filterContext.Exception, controllerName, actionName)
    filterContext.Result = ViewResult (View, Master, ViewData (model), TempData = filterContext.Controller.TempData)
    filterContext.Exception = None
    
C:
void OnException (ExceptionContext* filterContext) {
    filterContext->HttpContext->Response->TrySkipIisCustomErrors = true;
    filterContext->ExceptionHandled = true;
    filterContext->HttpContext->Response->ClearContent ();
    char * controllerName = (char *) filterContext->RouteData->Values["controller"];
    char * actionName = (char *) filterContext->RouteData->Values["action"];
    HandleErrorInfo * model = HandleErrorInfo_Create (filterContext->Exception, controllerName, actionName);
    filterContext->Result = ViewResult_Create (View, Master, ViewData_Create (model), TempData = filterContext->Controller->TempData);
    filterContext->Exception = NULL;
}

Java:
public void OnException(ExceptionContext filterContext) {
    filterContext.getHttpContext().getResponse().setTrySkipIisCustomErrors(true);
    filterContext.setExceptionHandled(true);
    filterContext.getHttpContext().getResponse().clearContent();
    String controllerName = (String) filterContext.getRouteData().getValues().get("controller");
    String actionName = (String) filterContext.getRouteData().getValues().get("action");
    HandleErrorInfo model = new HandleErrorInfo(filterContext.getException(), controllerName, actionName);
    filterContext.setResult(new ViewResult(View, Master, new ViewDataDictionary<HandleErrorInfo>(model), filterContext.getController().getTempData()));
    filterContext.setException(null);
}

