#input 
public static string SummarizeMethodCall (MethodBase method, params object [] values) {
    var output = new StringBuilder (method.Name + " invoked: ");
    ParameterInfo [] parameters = method.GetParameters ();
    for (int i = 0; i < parameters.Length; i ++) {
        output.AppendFormat ("{0} = {1}", parameters [i].Name, i >= values.Length ? "<empty>" : values [i]);
        if (i < parameters.Length - 1)
            output.Append (", ");
    }
    return output.ToString ();
}


#====================
#gpt output=============

Python implementation:
def SummarizeMethodCall(method, *values):
    output = f'{method.Name} invoked: '
    parameters = method.GetParameters()
    for i in range(len(parameters)):
        output += f'{parameters[i].Name} = {"" if i >= len(values) else values[i]}'
        if i < len(parameters) - 1:
            output += ', '
    return output

C implementation:

char* SummarizeMethodCall(methodbase *method, const void **values)
{
    int numParameters = method->getParameters();
    char *output = (char*) malloc((numParameters * 2 * sizeof(char)) + strlen(method->name) + 13);
    strcpy(output, method->name);
    strcat(output, " invoked: ");
    int i;
    for (i = 0; i < numParameters; i++)
    {
        char paramName[strlen(parameters[i]->name) + 1];
        strcpy(paramName, parameters[i]->name);
        if (i < sizeof(values) / sizeof(values[0]))
        {
            char buffer[strlen(paramName) + sizeof(values[i]) + 4];
            sprintf(buffer, "%s = %s, ", paramName, values[i]);
            strcat(output, buffer);
        }
        else
        {
            char buffer[strlen(paramName) + 10];
            sprintf(buffer, "%s = <empty>, ", paramName);
            strcat(output, buffer);
        }
    }
    output[strlen(output)-2] = 0;
    return output;
}

Java implementation: 
public static String SummarizeMethodCall(MethodBase method, Object... values) {
    StringBuilder output = new StringBuilder(method.getName() + " invoked: ");
    Parameter[] parameters = method.getParameters();
    for(int i = 0; i < parameters.length; i++) {
        output.append(parameters[i].getName() + " = " +
                (i >= values.length ? "<empty>" : values[i]));
        if(i < parameters.length - 1) 
            output.append(", ");
    }
    return output.toString();
}

