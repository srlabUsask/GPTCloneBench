#input 
public void Run () {
    System.Diagnostics.ProcessStartInfo ps = new System.Diagnostics.ProcessStartInfo ();
    ps.FileName = "netstat";
    ps.ErrorDialog = false;
    ps.Arguments = "-e 5";
    ps.CreateNoWindow = true;
    ps.UseShellExecute = false;
    ps.RedirectStandardOutput = true;
    ps.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
    using (System.Diagnostics.Process proc = new System.Diagnostics.Process ())
    {
        proc.StartInfo = ps;
        proc.EnableRaisingEvents = true;
        proc.Exited += new EventHandler (proc_Exited);
        proc.OutputDataReceived += new System.Diagnostics.DataReceivedEventHandler (proc_OutputDataReceived);
        proc.Start ();
        proc.BeginOutputReadLine ();
        proc.WaitForExit ();
    }}


#====================
#gpt output=============

Python:
import subprocess
def Run():
    ps = subprocess.Popen(["netstat", "-e 5"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    out, err = ps.communicate()
    output_data = out.decode('utf-8')
    print(output_data)

C:
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void Run(){
    char command[100];
    strncpy(command, "netstat -e 5", sizeof(command));
    command[sizeof(command) - 1] = 0;
    FILE *fp;

    fp = popen(command, "r"); 
    if (fp == NULL) {
        
        printf("Failed to run command\n" );
        exit(1);
    }

    char output_data[1024];
    while (fgets(output_data, sizeof(output_data)-1, fp) != NULL) {
        printf("%s", output_data);
    }
    pclose(fp);
}

Java: 
public void Run() throws IOException{
    Runtime runtime = Runtime.getRuntime();
    Process p = runtime.exec("netstat -e 5");
    BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
    String output_data;
    while ((output_data = stdInput.readLine()) != null) {
        System.out.println(output_data);
    }
}

