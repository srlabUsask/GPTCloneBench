#input 
public static byte [] CreateGridImage (int maxXCells, int maxYCells, int cellXPosition, int cellYPosition, int boxSize) {
    using (var bmp = new System.Drawing.Bitmap (maxXCells * boxSize + 1, maxYCells * boxSize + 1))
    {
        using (Graphics g = Graphics.FromImage (bmp))
        {
            g.Clear (Color.Yellow);
            Pen pen = new Pen (Color.Black);
            pen.Width = 1;
            Rectangle rect = new Rectangle (boxSize * (cellXPosition - 1), boxSize * (cellYPosition - 1), boxSize, boxSize);
            g.FillRectangle (new SolidBrush (Color.Red), rect);
            g.DrawLine (pen, boxSize * (cellXPosition - 1), boxSize * (cellYPosition - 1), boxSize * cellXPosition, boxSize * cellYPosition);
            g.DrawLine (pen, boxSize * (cellXPosition - 1), boxSize * cellYPosition, boxSize * cellXPosition, boxSize * (cellYPosition - 1));
            for (int i = 0; i <= maxXCells; i ++) {
                g.DrawLine (pen, (i * boxSize), 0, i * boxSize, boxSize * maxYCells);
            }
            for (int i = 0; i <= maxYCells; i ++) {
                g.DrawLine (pen, 0, (i * boxSize), boxSize * maxXCells, i * boxSize);
            }
        } var memStream = new MemoryStream ();
        bmp.Save (memStream, ImageFormat.Jpeg);
        return memStream.ToArray ();
    }}


#====================
#gpt output=============

Python Implementation:

def createGridImage(maxXCells, maxYCells, cellXPosition, cellYPosition, boxSize):
    image = Image.new('RGBA', (maxXCells * boxSize + 1, maxYCells * boxSize + 1), 'yellow')
    draw = ImageDraw.Draw(image)
    pen = ImageDraw.ImageDraw.Draw.Pen(image, 'black', width=1)
    rect = (boxSize * (cellXPosition - 1), boxSize * (cellYPosition - 1), boxSize, boxSize)
    draw.rectangle(rect, fill='red')
    draw.line([boxSize * (cellXPosition-1), boxSize * (cellYPosition-1), boxSize * cellXPosition, boxSize * cellYPosition], pen)
    draw.line([boxSize * (cellXPosition-1), boxSize * cellYPosition, boxSize * cellXPosition, boxSize * (cellYPosition-1)], pen)
    for i in range(0, maxXCells+1):
        draw.line((i * boxSize, 0, i * boxSize, boxSize * maxYCells), pen)
    for i in range(0, maxYCells+1):
        draw.line((0, i * boxSize, boxSize * maxXCells, i * boxSize), pen)
    stream = BytesIO()
    image.save(stream, format='JPEG')
    stream.seek(0)
    return stream.read()


C Implementation:
    
    #include <stdio.h>
    #include <stdlib.h>
    #include <graphics.h>

byte* createGridImage(int maxXCells, int maxYCells, int cellXPosition, int cellYPosition, int boxSize) {
        int bytesPerPixel = 3;
        int width = maxXCells * boxSize + 1;
        int height = maxYCells * boxSize + 1;
        int totalBytes = bytesPerPixel * width * height;
        byte *bitmap = malloc(totalBytes);

        int i, x, y;
        for (x = 0; x < width; x++) {
            for (y = 0; y < height; y++) {
                // Set yellow
                i = x * bytesPerPixel + y * width * bytesPerPixel;
                bitmap[i + 0] = 0xFF;
                bitmap[i + 1] = 0xFF;
                bitmap[i + 2] = 0x00;

                // Fill the current position
                if (boxSize * (cellXPosition - 1) == x 
                    && boxSize * (cellYPosition - 1) == y) {
                    bitmap[i + 0] = 0xFF;
                    bitmap[i + 1] = 0x00;
                    bitmap[i + 2] = 0x00;
                }

                // Draw the left and top sides of the current position
                if ((boxSize * (cellXPosition - 1) == x 
                    && boxSize * cellYPosition == y) 
                    || (boxSize * cellXPosition == x
                    && boxSize * (cellYPosition - 1) == y)) {
                    bitmap[i + 0] = 0x00;
                    bitmap[i + 1] = 0x00;
                    bitmap[i + 2] = 0x00;
                }
            }
        }
        // Draw vertical and horizontal lines
        for (x = 0; x <= maxXCells; x++) {
            for (y = 0; y < height; y++) {
                i = x * bytesPerPixel + (y * width * bytesPerPixel);
                bitmap[i + 0] = 0x00;
                bitmap[i + 1] = 0x00;
                bitmap[i + 2] = 0x00;
            }
        }
        for (y = 0; y <= maxYCells; y++) {
            for (x = 0; x < width; x++) {
                i = x * bytesPerPixel +  (y * width * bytesPerPixel);
                bitmap[i + 0] = 0x00;
                bitmap[i + 1] = 0x00;
                bitmap[i + 2] = 0x00;
            }
        }
        return bitmap;
    }


Java Implementation:

public static byte[] createGridImage(int maxXCells, int maxYCells, int cellXPosition, int cellYPosition, int boxSize) {
        BufferedImage bmp = new BufferedImage(maxXCells * boxSize + 1, maxYCells * boxSize + 1, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = bmp.createGraphics();

        g.setColor(Color.YELLOW);
        g.fillRect(0, 0, maxXCells * boxSize + 1, maxYCells * boxSize + 1);
        g.setColor(Color.BLACK);

        //draw red box
        Rectangle rect = new Rectangle(boxSize * (cellXPosition - 1), boxSize * (cellYPosition - 1), boxSize, boxSize);
        g.setColor(Color.RED);
        g.fill(rect);
        g.setColor(Color.BLACK);

        //draw lines
        g.drawLine(boxSize * (cellXPosition - 1), boxSize * (cellYPosition - 1), boxSize * cellXPosition, boxSize * cellYPosition);
        g.drawLine(boxSize * (cellXPosition - 1), boxSize * cellYPosition, boxSize * cellXPosition, boxSize * (cellYPosition - 1));
        for (int i = 0; i <= maxXCells; i++) {
            g.drawLine((i * boxSize), 0, i * boxSize, boxSize * maxYCells);
        }
        for (int i = 0; i <= maxYCells; i++) {
            g.drawLine(0, (i * boxSize), boxSize * maxXCells, i * boxSize);
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            ImageIO.write(bmp, "jpg", out);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return out.toByteArray();
    }

