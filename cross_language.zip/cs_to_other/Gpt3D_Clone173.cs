#input 
internal static string GetIPAddress (HttpRequestBase request) {
    string forwarded = request.Headers ["Forwarded"];
    if (! String.IsNullOrEmpty (forwarded)) {
        foreach (string segment in forwarded.Split (',') [0].Split (';')) {
            string [] pair = segment.Trim ().Split ('=');
            if (pair.Length == 2 && pair [0].Equals ("for", StringComparison.OrdinalIgnoreCase)) {
                string ip = pair [1].Trim ('"');
                int left = ip.IndexOf ('['), right = ip.IndexOf (']');
                if (left == 0 && right > 0) {
                    return ip.Substring (1, right - 1);
                }
                int colon = ip.IndexOf (':');
                if (colon != - 1) {
                    return ip.Substring (0, colon);
                }
                return ip;
            }
        }
    }
    string xForwardedFor = request.Headers ["X-Forwarded-For"];
    if (! String.IsNullOrEmpty (xForwardedFor)) {
        return xForwardedFor.Split (',') [0];
    }
    return request.UserHostAddress;
}


#====================
#gpt output=============



Python

def GetIPAddress(request):
    forwarded = request.headers.get('Forwarded')
    if forwarded is not None: 
        for segment in forwarded.split(',')[0].split(';'):
            pair = segment.strip().split('=')
            if len(pair) == 2 and pair[0].lower() == 'for':
                ip = pair[1].strip('"')
                left = ip.find('[')
                right = ip.find(']')
                if left == 0 and right > 0:
                    return ip[1:right]
                colon = ip.find(':')
                if colon != -1:
                    return ip[0:colon]
                return ip

    xForwardedFor = request.headers.get('X-Forwarded-For')
    if xForwardedFor:
        return xForwardedFor.split(',')[0]

    return request.user_host_address

C

char* get_IP_Address(http_request_base_t* request)
{
    char* forwarded = request->header("Forwarded");
    if (strlen(forwarded) > 0)
    {
        size_t count;
        char** segs = str_slice(forwarded, ";", &count);
        if (count > 0)
        {
            for (size_t i = 0; i < count; i++)
            {
                char** pair = str_slice(segs[i], "=", NULL);
                
                if (pair == NULL) continue;
                if (strlen(pair[0]) == 0 || strlen(pair[1]) == 0)
                {
                    free(pair);
                    continue;
                }
                
                
                if (str_equals_ignore_case(pair[0], "for"))
                {
                    char* ip = str_slice_primitive(pair[1], "\"", NULL);
                    
                    char* result = (char*)calloc(INET6_ADDRSTRLEN, 1);
                    size_t left = str_index_of(ip, "[");
                    size_t right = str_index_of(ip, "]");
                    size_t colon = str_index_of(ip, ":");
                    
                    if (left == 0 && right > 0)
                    {
                        memcpy(result, ip + 1, right - 1);
                    }
                    else if (colon > 0)
                    {
                        memcpy(result, ip, colon);
                    }
                    else
                    {
                        strcpy(result, ip);
                    }
                    
                    free(ip);
                    free(pair);
                    free(segs);
                    return result;
                }
                
                free(pair);
            }
        }
        
        free(segs);
    }
    
    char* xForwardedFor = request->header("X-Forwarded-For");
    if (strlen(xForwardedFor) > 0)
    {
        char** segs = str_slice(xForwardedFor, ",", NULL);
        char* result = (char*)calloc(strlen(segs[0]) + 1, 1);
        strcpy(result, segs[0]);
        free(segs);
        return result;
    }
    
    char* result = (char*)calloc(strlen(request->user_host_address) + 1, 1);
    strcpy(result, request->user_host_address);
    return result;
}



Java 

public static String getIPAddress(HttpRequestBase request) {
    String forwarded = request.getHeaders("Forwarded");
    if (StringUtils.isNotEmpty(forwarded)) {
        String[] segments = forwarded.split(",")[0].split(";");

        for (String segment : segments) {
            String[] pair = segment.trim().split("=");
            if (pair.length == 2 && pair[0].equalsIgnoreCase("for")) {
                String ip = pair[1].trim("\"");
                int left = ip.indexOf('[');
                int right = ip.indexOf(']');
                if (left == 0 && right > 0) {
                    return ip.substring(1, right - 1);
                }
                int colon = ip.indexOf(':');
                if(colon != - 1) {
                    return ip.substring(0, colon);
                }
                return ip;
            }
        }
    }

    String xForwardedFor = request.getHeaders("X-Forwarded-For");
    if (StringUtils.isNotEmpty(xForwardedFor)) {
        return xForwardedFor.split(",")[0];
    }

    return request.getUserHostAddress();
}


