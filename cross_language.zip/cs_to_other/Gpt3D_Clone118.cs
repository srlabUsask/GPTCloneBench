#input 
static void Main (string [] args) {
    Vector3 vector = new Vector3 ();
    vector.x = 1;
    vector.y = 2;
    vector.z = 3;
    MemoryStream memoryStream = new MemoryStream ();
    BinaryFormatter binaryFormatter = new BinaryFormatter ();
    binaryFormatter.Serialize (memoryStream, vector);
    string str = System.Convert.ToBase64String (memoryStream.ToArray ());
}


#====================
#gpt output=============

Python:

from struct import *
from io import BytesIO
import base64

vector = (1, 2, 3)

memoryStream = BytesIO()
memoryStream.write(pack('3f', *vector))
str = base64.b64encode(memoryStream.read())

C:

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <base64.h>

typedef struct vector3_s {
    float x;
    float y;
    float z;
} vector3_t;

int main(int argc, char* argv[]) {
    vector3_t vector = {1.0f, 2.0f, 3.0f};
    
    char * memoryStream = malloc(sizeof(vector3_t));
    memcpy(memoryStream, (char*)&vector, sizeof(vector3_t));
    char * str = b64_encode(memoryStream, sizeof(vector3_t));
    
    free(memoryStream);
    
    return 0;
}

Java:

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.util.Base64;

public static void Main(String[] args) {
    Vector3 vector = new Vector3();
    vector.x = 1;
    vector.y = 2;
    vector.z = 3;

    try {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      ObjectOutputStream oos = new ObjectOutputStream(baos);
      oos.writeObject(vector);
      oos.close();
      String str = Base64.getEncoder().encodeToString(baos.toByteArray());
    } catch(IOException e) {
      e.printStackTrace();
    }
}

