#input 
static void Main () {
    Bitmap mask = new Bitmap (@"mask.bmp");
    Bitmap bmp = new Bitmap (@"test.jpg");
    int width = bmp.Width;
    int height = bmp.Height;
    for (int x = 0; x < width; x ++)
        for (int y = 0; y < height; y ++)
            if (mask.GetPixel (x, y).R < 250)
                bmp.SetPixel (x, y, mask.GetPixel (x, y));
    bmp.Save (@"test3.jpg");
}


#====================
#gpt output=============


Python:
from PIL import Image

mask = Image.open('mask.bmp')
bmp = Image.open('test.jpg')
width, height = bmp.size

for x in range(width):
    for y in range(height):
        if mask.getpixel((x, y)).get(0) < 250:
            bmp.putpixel((x, y), mask.getpixel((x, y)))

bmp.save('test3.jpg')



C:
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <math.h>

#define BMP_HEADER_SIZE 54

int main()
{
    int width, height, bpp;
    int x, y;

    // create structures for bmp headers
    uint8_t mask_header[BMP_HEADER_SIZE];
    uint8_t bmp_header[BMP_HEADER_SIZE];

    // open the mask and bmp files
    FILE *mask = fopen("mask.bmp", "rb");
    FILE *bmp = fopen("test.jpg", "rb");

    // read the corresponding headers
    fread(mask_header, BMP_HEADER_SIZE, 1, mask);
    fread(bmp_header, BMP_HEADER_SIZE, 1, bmp);

    // compute the width, height and bits per pixel
    width = mask_header[0x12] + (mask_header[0x13] << 8) + (mask_header[0x14] << 16) + (mask_header[0x15] << 24);
    height = mask_header[0x16] + (mask_header[0x17] << 8) + (mask_header[0x18] << 16) + (mask_header[0x19] << 24);
    bpp = mask_header[0x1C] + (mask_header[0x1D] << 8);

    // loop through each pixel in the image
    for (x = 0; x < width; x ++)
        for (y = 0; y < height; y ++)
        {
            // read the mask pixel
            uint8_t mask_pixel[3];
            fread(mask_pixel, 3, 1, mask);

            // check if the red channel is 255
            if (mask_pixel[2] < 250)
            {
                // write the bmp pixel
                fwrite(mask_pixel, 3, 1, bmp);
            }
        }

    // save to new file
    fclose(bmp);
    bmp = fopen("test3.jpg", "wb");
    fwrite(bmp_header, BMP_HEADER_SIZE, 1, bmp);
    rewind(mask);
    for (int i = 0; i < width * height; i++)
    {
        uint8_t pixel[3];
        fread(pixel, 3, 1, mask);
        fwrite(pixel, 3, 1, bmp);
    }

    // close the files
    fclose(bmp);
    fclose(mask);

    return 0;
}



Java:
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ReplacePixels {
    static void main() {
        BufferedImage mask;
        BufferedImage bmp;
        int width;
        int height;

        try {
            mask = ImageIO.read(new File("mask.bmp"));
            width = mask.getWidth();
            height = mask.getHeight();
            bmp = ImageIO.read(new File("test.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        for (int x = 0; x < width; x ++) {
            for (int y = 0; y < height; y ?) {
                int maskRed = mask.getRGB(x,y) >> 16 & 0xFF;
                if (maskRed < 250) {
                    int maskRgb = mask.getRGB(x,y);
                    bmp.setRGB(x,y,maskRgb);
                }
            }
        }
        try {
            ImageIO.write(bmp,"jpg",new File("test3.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

