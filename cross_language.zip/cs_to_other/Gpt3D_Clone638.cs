#input 
public static void FindGoodFont (Graphics Graf, string sStringToFit, Size TextRoomAvail, ref Font FontToUse, GraphicsUnit FontUnit) {
    SizeF RealSize = Graf.MeasureString (sStringToFit, FontToUse);
    Debug.WriteLine ("big string is {0}, orig size = {1},{2}", sStringToFit, RealSize.Width, RealSize.Height);
    if ((RealSize.Width <= TextRoomAvail.Width) && (RealSize.Height <= TextRoomAvail.Height)) {
        Debug.WriteLine ("The space is big enough already");
        return;
    }
    float HeightScaleRatio = TextRoomAvail.Height / RealSize.Height;
    float WidthScaleRatio = TextRoomAvail.Width / RealSize.Width;
    float ScaleRatio = (HeightScaleRatio < WidthScaleRatio) ? ScaleRatio = HeightScaleRatio : ScaleRatio = WidthScaleRatio;
    float ScaleFontSize = FontToUse.Size * ScaleRatio;
    Debug.WriteLine ("Resizing with scales {0},{1} chose {2}", HeightScaleRatio, WidthScaleRatio, ScaleRatio);
    Debug.WriteLine ("Old font size was {0}, new={1} ", FontToUse.Size, ScaleFontSize);
    FontStyle OldFontStyle = FontToUse.Style;
    FontToUse.Dispose ();
    FontToUse = new Font (FontToUse.FontFamily, ScaleFontSize, OldFontStyle, FontUnit);
}


#====================
#gpt output=============

Python
def FindGoodFont(Graf, sStringToFit, TextRoomAvail, FontToUse, FontUnit):
    RealSize = Graf.MeasureString(sStringToFit, FontToUse)
    print "big string is {0}, orig size = {1},{2}".format(sStringToFit, RealSize.Width, RealSize.Height)
    if (RealSize.Width <= TextRoomAvail.Width) and (RealSize.Height <= TextRoomAvail.Height):
        print "The space is big enough already"
        return
    HeightScaleRatio = TextRoomAvail.Height / RealSize.Height
    WidthScaleRatio = TextRoomAvail.Width / RealSize.Width
    ScaleRatio = None
    if HeightScaleRatio < WidthScaleRatio:
        ScaleRatio = HeightScaleRatio
    else:
        ScaleRatio = WidthScaleRatio
    ScaleFontSize = FontToUse.Size * ScaleRatio
    print "Resizing with scales {0},{1} chose {2}".format(HeightScaleRatio, WidthScaleRatio, ScaleRatio)
    print "Old font size was {0}, new={1}".format(FontToUse.Size, ScaleFontSize)
    OldFontStyle = FontToUse.Style
    FontToUse.Dispose()
    FontToUse = new Font(FontToUse.FontFamily, ScaleFontSize, OldFontStyle, FontUnit)


C
void FindGoodFont (Graphics Graf, char * sStringToFit, Size TextRoomAvail, Font * FontToUse, GraphicsUnit FontUnit) {
    SizeF RealSize = Graf.MeasureString (sStringToFit, FontToUse);
    printf("big string is %s, orig size = %d,%d\n", sStringToFit, RealSize.Width, RealSize.Height);
    if ((RealSize.Width <= TextRoomAvail.Width) && (RealSize.Height <= TextRoomAvail.Height)) {
        printf("The space is big enough already\n");
        return;
    }
    float HeightScaleRatio = TextRoomAvail.Height / RealSize.Height;
    float WidthScaleRatio = TextRoomAvail.Width / RealSize.Width;
    float ScaleRatio = (HeightScaleRatio < WidthScaleRatio) ? ScaleRatio = HeightScaleRatio : ScaleRatio = WidthScaleRatio;
    float ScaleFontSize = FontToUse->Size * ScaleRatio;
    printf("Resizing with scales %f,%f chose %f\n", HeightScaleRatio, WidthScaleRatio, ScaleRatio);
    printf("Old font size was %d, new=%f \n", FontToUse->Size, ScaleFontSize);
    FontStyle OldFontStyle = FontToUse->Style;
    FontToUse->Dispose ();
    FontToUse = new Font (FontToUse->FontFamily, ScaleFontSize, OldFontStyle, FontUnit);
}

Java
public static void FindGoodFont (Graphics Graf, String sStringToFit, Size TextRoomAvail, Font FontToUse, GraphicsUnit FontUnit) {
    SizeF RealSize = Graf.MeasureString (sStringToFit, FontToUse);
    System.out.println("big string is " + sStringToFit + ", orig size = " + RealSize.Width + ", " + RealSize.Height);
    if ((RealSize.Width <= TextRoomAvail.Width) && (RealSize.Height <= TextRoomAvail.Height)) {
        System.out.println("The space is big enough already");
        return;
    }
    float HeightScaleRatio = TextRoomAvail.Height / RealSize.Height;
    float WidthScaleRatio = TextRoomAvail.Width / RealSize.Width;
    float ScaleRatio;
    if (HeightScaleRatio < WidthScaleRatio) {
        ScaleRatio = HeightScaleRatio;
    }
    else {
        ScaleRatio = WidthScaleRatio;
    }
    float ScaleFontSize = FontToUse.Size * ScaleRatio;
    System.out.println("Resizing with scales " + HeightScaleRatio + ", " + WidthScaleRatio + " chose " + ScaleRatio);
    System.out.println("Old font size was " + FontToUse.Size + ", new= " + ScaleFontSize);
    FontStyle OldFontStyle = FontToUse.Style;
    FontToUse.dispose();
    FontToUse = new Font (FontToUse.FontFamily, ScaleFontSize, OldFontStyle, FontUnit);
}

