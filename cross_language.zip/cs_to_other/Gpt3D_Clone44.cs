#input 
static void Main (string [] args) {
    double d = double.NaN;
    for (int test = 0; test < 10; ++ test) {
        var sw1 = Stopwatch.StartNew ();
        bool result1 = false;
        for (int ix = 0; ix < 1000 * 1000; ++ ix) {
            result1 |= double.IsNaN (d);
        }
        sw1.Stop ();
        var sw2 = Stopwatch.StartNew ();
        bool result2 = false;
        for (int ix = 0; ix < 1000 * 1000; ++ ix) {
            result2 |= IsNaN (d);
        }
        sw2.Stop ();
        Console.WriteLine ("{0} - {1} x {2}%", sw1.Elapsed, sw2.Elapsed, 100 * sw2.ElapsedTicks / sw1.ElapsedTicks, result1, result2);
    }
    Console.ReadLine ();
}


#====================
#gpt output=============

Python Implementation:
def main(args):
    d = float('nan')
    for test in range(10):
        sw1_start = time.time()
        result1 = False
        for ix in range(1000 * 1000):
            result1 = result1 or math.isnan(d)
        sw1_stop = time.time()
        sw2_start = time.time()
        result2 = False
        for ix in range(1000 * 1000):
            result2 = result2 or is_nan(d)
        sw2_stop = time.time()
        print('{} - {} x {} %, {} {}'.format(sw1_stop - sw1_start, sw2_stop - sw2_start, (100 * (sw2_stop - sw2_start)) / (sw1_stop - sw1_start)), result1, result2)
    input('Press any key to exit\n')

C Implementation:
int main(int argc, char *argv[])
{
    double d = NAN;
    for (int test = 0; test < 10; ++test) {
        clock_t sw1_start = clock();
        int result1 = 0;
        for (int ix = 0; ix < 1000 * 1000; ++ix) {
            result1 |= isnan(d);
        }
        clock_t sw1_stop = clock();
        clock_t sw2_start = clock();
        int result2 = 0;
        for (int ix = 0; ix < 1000 * 1000; ++ix) {
            result2 |= IsNaN(d);
        }
        clock_t sw2_stop = clock();
        printf("%f - %f x %f%, %d %d\n", (double)(sw1_stop - sw1_start) / CLOCKS_PER_SEC, 
               (double)(sw2_stop - sw2_start) / CLOCKS_PER_SEC, 
               100 * ((double)(sw2_stop - sw2_stop) / (double)(sw1_stop - sw1_start)), 
               result1, result2);
    }
    getchar();
    return 0;
}

Java Implementation:
public class Main {  
  public static void main(String[] args) {  
    double d = Double.NaN;  
    for (int test = 0; test < 10; ++test) {  
      long sw1_start = System.nanoTime();  
      boolean result1 = false;  
      for (int ix = 0; ix < 1000 * 1000; ++ix) {  
        result1 |= Double.isNaN(d);  
      }  
      long sw1_stop = System.nanoTime();  
      long sw2_start = System.nanoTime();  
      boolean result2 = false;  
      for (int ix = 0; ix < 1000 * 1000; ++ix) {  
        result2 |= IsNaN(d);  
      }  
      long sw2_stop = System.nanoTime();  
      System.out.printf("%d - %d x %f%, %s %s\n", (sw1_stop - sw1_start),
                        (sw2_stop - sw2_start),  
                        (100 * ((double)sw2_stop - sw2_start) / (double)sw1_stop - sw1_start), 
                        result1, result2);  
    }  
    System.out.println("Press ENTER to exit");  
    Scanner sc = new Scanner(System.in);  
    sc.nextLine();  
    sc.close();  
  }  
   
  public static boolean IsNaN(double d) {  
    return d != d;  
  }  
}

