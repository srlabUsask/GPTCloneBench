#input 
public bool PreFilterMessage (ref Message m) {
    if (m.Msg == 0x20a) {
        Point pos = new Point (m.LParam.ToInt32 () & 0xffff, m.LParam.ToInt32 () > > 16);
        IntPtr hWnd = WindowFromPoint (pos);
        if (hWnd != IntPtr.Zero && hWnd != m.HWnd && Control.FromHandle (hWnd) != null) {
            SendMessage (hWnd, m.Msg, m.WParam, m.LParam);
            return true;
        }
    }
    return false;
}


#====================
#gpt output=============


Python:
def PreFilterMessage (m):
    if (m.Msg == 0x20a):
        pos = [m.LParam & 0xffff, m.LParam >> 16]
        hWnd = WindowFromPoint (pos)
        if (hWnd != None and hWnd != m.HWnd and Control.FromHandle (hWnd) != None):
            SendMessage (hWnd, m.Msg, m.WParam, m.LParam)
            return True
    return False


C:
bool PreFilterMessage(Message *m)
{
    if (m->Msg == 0x20a)
    {
        Point pos;
        pos.x = m->LParam & 0xffff;
        pos.y = m->LParam >> 16;
        IntPtr hWnd = WindowFromPoint(pos);
        if (hWnd != NULL && hWnd != m->HWnd && Control.FromHandle (hWnd) != NULL)
        {
            SendMessage(hWnd, m->Msg, m->WParam, m->LParam);
            return true;
        }
    }
    return false;
}


Java:
public boolean PreFilterMessage (Message m) {
    if (m.Msg == 0x20a) {
        Point pos = new Point (m.LParam & 0xffff, m.LParam >>> 16);
        IntPtr hWnd = WindowFromPoint (pos);
        if (hWnd != IntPtr.Zero && hWnd != m.HWnd && Control.FromHandle (hWnd) != null) {
            SendMessage (hWnd, m.Msg, m.WParam, m.LParam);
            return true;
        }
    }
    return false;
}

