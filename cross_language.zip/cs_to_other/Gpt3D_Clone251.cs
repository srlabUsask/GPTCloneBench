#input 
protected override void WndProc (ref Message message) {
    base.WndProc (ref message);
    if (message.Msg == 0x84) {
        var cursor = this.PointToClient (Cursor.Position);
        if (TopLeft.Contains (cursor))
            message.Result = (IntPtr) HTTOPLEFT;
        else if (TopRight.Contains (cursor))
            message.Result = (IntPtr) HTTOPRIGHT;
        else if (BottomLeft.Contains (cursor))
            message.Result = (IntPtr) HTBOTTOMLEFT;
        else if (BottomRight.Contains (cursor))
            message.Result = (IntPtr) HTBOTTOMRIGHT;
        else if (Top.Contains (cursor))
            message.Result = (IntPtr) HTTOP;
        else if (Left.Contains (cursor))
            message.Result = (IntPtr) HTLEFT;
        else if (Right.Contains (cursor))
            message.Result = (IntPtr) HTRIGHT;
        else if (Bottom.Contains (cursor))
            message.Result = (IntPtr) HTBOTTOM;
    }
}


#====================
#gpt output=============

Python:
def WndProc(self, message):
    super().WndProc(message)
    if message.Msg == 0x84:
        cursor = self.PointToClient(cursor.Position)
        if TopLeft.contains(cursor):
            message.Result = (ctypes.wintypes.HANDLE) HTTOPLEFT
        elif TopRight.contains(cursor):
            message.Result = (ctypes.wintypes.HANDLE) HTTOPRIGHT
        elif BottomLeft.contains(cursor):
            message.Result = (ctypes.wintypes.HANDLE) HTBOTTOMLEFT
        elif BottomRight.contains(cursor):
            message.Result = (ctypes.wintypes.HANDLE) HTBOTTOMRIGHT
        elif Top.contains(cursor):
            message.Result = (ctypes.wintypes.HANDLE) HTTOP
        elif Left.contains(cursor):
            message.Result = (ctypes.wintypes.HANDLE) HTLEFT
        elif Right.contains(cursor):
            message.Result = (ctypes.wintypes.HANDLE) HTRIGHT
        elif Bottom.contains(cursor):
            message.Result = (ctypes.wintypes.HANDLE) HTBOTTOM

C:
void WndProc(Message *message) {
    base.WndProc(message);
    if (message->Msg == 0x84) {
        Point cursor = this->PointToClient(Cursor->Position);
        if (TopLeft.Contains(cursor)) {
            message->Result = (WindowHandle) HTTOPLEFT;
        } else if (TopRight.Contains(cursor)) {
            message->Result = (WindowHandle) HTTOPRIGHT;
        } else if (BottomLeft.Contains(cursor)) {
            message->Result = (WindowHandle) HTBOTTOMLEFT;
        } else if (BottomRight.Contains(cursor)) {
            message->Result = (WindowHandle) HTBOTTOMRIGHT;
        } else if (Top.Contains(cursor)) {
            message->Result = (WindowHandle) HTTOP;
        } else if (Left.Contains(cursor)) {
            message->Result = (WindowHandle) HTLEFT;
        } else if (Right.Contains(cursor)) {
            message->Result = (WindowHandle) HTRIGHT;
        } else if (Bottom.Contains(cursor)) {
            message->Result = (WindowHandle) HTBOTTOM;
        }
    }
} 

Java:
protected void WndProc(Message message){
    super.WndProc(message);
    if (message.getMsg() == 0x84){
        Point cursor = this.PointToClient(Cursor.getPosition());
        if (TopLeft.contains(cursor))
            message.setResult((Integer) HTTOPLEFT);
        else if (TopRight.contains(cursor))
            message.setResult((Integer) HTTOPRIGHT);
        else if (BottomLeft.contains(cursor))
            message.setResult((Integer) HTBOTTOMLEFT);
        else if (BottomRight.contains(cursor))
            message.setResult((Integer) HTBOTTOMRIGHT);
        else if (Top.contains(cursor))
            message.setResult((Integer) HTTOP);
        else if (Left.contains(cursor))
            message.setResult((Integer) HTLEFT);
        else if (Right.contains(cursor))
            message.setResult((Integer) HTRIGHT);
        else if (Bottom.contains(cursor))
            message.setResult((Integer) HTBOTTOM);
    }
}

