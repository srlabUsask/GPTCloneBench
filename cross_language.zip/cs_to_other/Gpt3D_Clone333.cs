#input 
protected void btnAdd_Click (object sender, EventArgs e) {
    for (Int32 i = lstAvailableColors.Items.Count; i >= 0; i --) {
        ListItem item = lstAvailableColors.Items [i];
        if (item.Selected) {
            lstSelectedColors.Items.Add (item);
            lstAvailableColors.Items.Remove (item);
        }
    }
}


#====================
#gpt output=============

#Python 
def btnAdd_Click (self, sender, e): 
    length = len(lstAvailableColors.Items)
    for position in range(length -1, -1, -1):
        item = lstAvailableColors.Items[position]
        if item.Selected:
            lstSelectedColors.Items.Add(item)
            lstAvailableColors.Items.Remove (item)

#C
void btnAdd_Click (object sender, EventArgs e) {
    for (Int32 i = lstAvailableColors.Items.Count; i >= 0; i--) {
        ListItem item = lstAvailableColors.Items[i]
        if (item.Selected) {
            lstSelectedColors.Items.push_back(item)
            lstAvailableColors.Items.erase(item)
        }
    }
}

#Java 
protected void btnAdd_Click (object sender, EventArgs e) {
    for (Int32 i = lstAvailableColors.Items.size() - 1; i >= 0; i--) {
        ListItem item = lstAvailableColors.Items.get(i);
        if (item.Selected) {
            lstSelectedColors.Items.add(item);
            lstAvailableColors.Items.remove(item);
        }
    }
}

