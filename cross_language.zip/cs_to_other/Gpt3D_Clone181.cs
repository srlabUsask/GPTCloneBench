#input 
static void Main (string [] args) {
    var fsm = new FiniteStateMachine ();
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.PlugIn);
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.TurnOn);
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.TurnOff);
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.TurnOn);
    Console.WriteLine (fsm.State);
    fsm.ProcessEvent (FiniteStateMachine.Events.RemovePower);
    Console.WriteLine (fsm.State);
    Console.ReadKey ();
}


#====================
#gpt output=============

Python:
def main(args): 
    fsm = FiniteStateMachine()
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.PlugIn)
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.TurnOn)
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.TurnOff)
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.TurnOn)
    print(fsm.state)
    fsm.process_event(FiniteStateMachine.Events.RemovePower)
    print(fsm.state)
    
    
C: 
#include <stdio.h>
#include "finite_state_machine.h"

int main (int argc, char **argv) {
    FiniteStateMachine fsm;
    printf("%s\n", fsm.state);
    fsm.processEvent(FiniteStateMachine_Events_PlugIn);
    printf("%s\n", fsm.state);
    fsm.processEvent(FiniteStateMachine_Events_TurnOn);
    printf("%s\n", fsm.state);
    fsm.processEvent(FiniteStateMachine_Events_TurnOff);
    printf("%s\n", fsm.state);
    fsm.processEvent(FiniteStateMachine_Events_TurnOn);
    printf("%s\n", fsm.state);
    fsm.processEvent(FiniteStateMachine_Events_RemovePower);
    printf("%s\n", fsm.state);
    getchar();
}


Java:
public static void main(String[] args) {
    FiniteStateMachine fsm = new FiniteStateMachine();
    System.out.println(fsm.getState());
    fsm.processEvent(FiniteStateMachine.Events.PlugIn);
    System.out.println(fsm.getState());
    fsm.processEvent(FiniteStateMachine.Events.TurnOn);
    System.out.println(fsm.getState());
    fsm.processEvent(FiniteStateMachine.Events.TurnOff);
    System.out.println(fsm.getState());
    fsm.processEvent(FiniteStateMachine.Events.TurnOn);
    System.out.println(fsm.getState());
    fsm.processEvent(FiniteStateMachine.Events.RemovePower);
    System.out.println(fsm.getState());
    System.in.read();
}

