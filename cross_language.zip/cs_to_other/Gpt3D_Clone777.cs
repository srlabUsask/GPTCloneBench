#input 
public static LinkedList < T > SwapPairwise < T > (this LinkedList < T > source) {
    if (source == null)
        throw new ArgumentNullException ("source");
    var current = source.First;
    if (current == null)
        return source;
    while (current.Next != null) {
        current.SwapWith (current.Next);
        current = current.Next;
        if (current != null)
            current = current.Next;
    }
    return source;
}


#====================
#gpt output=============


Python: 
def swap_pairwise(source):
    if source is None:
        raise ValueError("Source cannot be null")
    current = source.head
    if current is None:
        return source
    while current.next is not None:
        current.swap_with(current.next)
        current = current.next
        if current is not None:
            current = current.next
    return source

    
C: 
LinkedList* SwapPairwise(LinkedList* source) {
    if (!source) {
        throw(ArgumentNullException);
    }

    Node* current = source->head;
    if (!current) {
        return source;
    }

    while (current->next) {
        current->swap_with(current->next);
        current = current->next;
        if (current) {
            current = current->next;
        }
    }

    return source;
}


Java: 
public static <T> LinkedList<T> swapPairwise(LinkedList<T> source) throws ArgumentNullException {
    if (source == null) {
        throw new ArgumentNullException("source");
    }
    LinkedList.Node current = source.head;
    if (current == null) {
        return source;
    }
    while (current.next != null) {
        current.swapWith(current.next);
        current = current.next;
        if (current != null) {
            current = current.next;
        } 
    }
    return source;
}

