#input 
[STAThread] static void Main (string [] args) {
    fileDialog.ShowDialog ();
    string fileName = fileDialog.FileName;
    if (string.IsNullOrEmpty (fileName) == false) {
        AppDomain.CurrentDomain.AssemblyResolve += CurrentDomain_AssemblyResolve;
        if (Directory.Exists (@"c:\Provisioning\") == false)
            Directory.CreateDirectory (@"c:\Provisioning\");
        assemblyDirectory = Path.GetDirectoryName (fileName);
        Assembly loadedAssembly = Assembly.LoadFile (fileName);
        List < Type > assemblyTypes = loadedAssembly.GetTypes ().ToList < Type > ();
        foreach (var type in assemblyTypes) {
            if (type.IsInterface == false) {
                StreamWriter jsonFile = File.CreateText (string.Format (@"c:\Provisioning\{0}.json", type.Name));
                JavaScriptSerializer serializer = new JavaScriptSerializer ();
                jsonFile.WriteLine (serializer.Serialize (Activator.CreateInstance (type)));
                jsonFile.Close ();
            }
        }
    }
}


#====================
#gpt output=============

# Python
import os
from os import listdir
from os.path import isfile, join
import subprocess
from array import *

def show_dialog():
    file_Dialog.ShowDialog()
    file_name = file_Dialog.FileName()
    if not file_name:
        return
    
    if not os.path.exists("C:\\Provisioning\\"):
        os.mkdir("C:\\Provisioning\\")

    file_dir = os.path.dirname(file_name)
    json_path = os.path.join(file_dir, file_name)

    export_file = open(os.path.join("C:\\Provisioning\\", file_name) + ".json",'w')
    assembly_types = array.array()
    try:
        assembly_types = os.listdir(json_path)
    except:
        pass
    
    for assembly_type in assembly_types:
        if not assembly_type.isInterface():
            serializer = JavaScriptSerializer()
            export_file.write(serializer.serialize(Activator.CreateInstance(assembly_type)))
            export_file.close()

show_dialog()

# C
#include <stdio.h>
#include <string.h>
#include <windows.h>

void main(int args, char *argv[])
{
    FileDialog fileDialog = new FileDialog();
    if(fileDialog.ShowDialog() == true) {
        char* fileName = fileDialog.FileName;
        if(strlen(fileName) > 0) {
            AppDomain.CurrentDomain.AssemblyResolve += CurrentDomain_AssemblyResolve;
            if(!Directory.Exists("c:\\Provisioning\\")) {
                CreateDirectory("c:\\Provisioning\\", NULL);
            }
            
            char* assemblyDir = Path.GetDirectoryName(fileName);
            char* assemblyName = Path.GetFileName(fileName);
            Assembly loadedAssembly = Assembly.LoadFile(fileName);
            List<Type> assemblyTypes = loadedAssembly.GetTypes().ToList<Type>();
            for(int i = 0; i < assemblyTypes.Count; i++) {
                
                Type type = assemblyTypes[i];
                StreamWriter jsonFile;
                jsonFile = new StreamWriter(String.Format("c:\\Provisioning\\{0}.json", type.Name));
                
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                jsonFile.WriteLine(serializer.Serialize(Activator.CreateInstance(type)));
                jsonFile.Close();
            }
         }
    }
}

# Java
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        FileDialog fileDialog = new FileDialog();
        fileDialog.showDialog();
        String fileName = fileDialog.getFileName();
        if(!fileName.isEmpty()) {
            AppDomain.CurrentDomain.addAssemblyResolveListener(CurrentDomain_AssemblyResolve);
            if(!Directory.exists("c:\\Provisioning\\")) {
                Directory.createDirectory("c:\\Provisioning\\");
            }

            String assemblyDirectory = Path.getDirectoryName(fileName);
            Assembly loadedAssembly = Assembly.loadFile(fileName);
            List<Type> assemblyTypes = new ArrayList<>(loadedAssembly.getTypes());
            for(Type type : assemblyTypes) {
                if(type.isInterface() == false) {
                    StreamWriter jsonFile = File.createText(String.format("c:\\Provisioning\\{0}.json", type.getName()));
                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    jsonFile.println(serializer.serialize(Activator.createInstance(type)));
                    jsonFile.close();
                }
            }
        }
    }
}

