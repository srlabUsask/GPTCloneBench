#input 
static void Main (string [] args) {
    Database.SetInitializer < MyContext > (new DropCreateDatabaseAlways < MyContext > ());
    using (var ctx = new MyContext ())
    {
        ctx.Database.Initialize (false);
        var parent = new MyEntity {Name = "Parent", Children = new List < MyEntity > ()};
        parent.Children.Add (new MyEntity {Name = "Child 1"});
        parent.Children.Add (new MyEntity {Name = "Child 2"});
        ctx.MyEntities.Add (parent);
        ctx.SaveChanges ();
    } using (var ctx = new MyContext ())
    {
        var parent = ctx.MyEntities.Include (e = > e.Children).FirstOrDefault ();
        foreach (var child in parent.Children.ToList ())
            ctx.MyEntities.Remove (child);
        ctx.MyEntities.Remove (parent);
        ctx.SaveChanges ();
    }}


#====================
#gpt output=============

// Python
import MySQLdb
db = MySQLdb.Connection ()
db.set_initializer (DropCreateDatabaseAlways ())
with db.transaction () as ctx:
    parent = MyEntity (name="Parent", Children=[])
    parent.Children.append (MyEntity (name="Child 1"))
    parent.Children.append (MyEntity (name="Child 2"))
    ctx.add (parent)

with db.transaction () as ctx:
    parent = ctx.query (MyEntity).include (e => e.Children).first ()
    for child in parent.Children.to_list ():
        ctx.remove (child)
    ctx.remove (parent)

// C
#include <stdio.h>
#include <mysql.h>

void
main (int args, char *argv[])
{
    MYSQL *db;

    db = mysql_init (NULL);
    mysql_set_initializer (DropCreateDatabaseAlways ());
    mysql_transaction_start (db);
    {
        MyEntity *parent = myentity_create ("Parent", NULL);
        MyEntity *child1 = myentity_create ("Child 1", NULL);
        MyEntity *child2 = myentity_create ("Child 2", NULL);
    
        myentity_add_children (parent, child1);
        myentity_add_children (parent, child2);

        mysql_add (db, parent);
        mysql_add (db, child1);
        mysql_add (db, child2);
    }
    mysql_transaction_end (db);
    mysql_transaction_start (db);
    {
        MyEntity *parent = mysql_query_include_children (db, NULL);
        int size = myentity_children_size (parent);
        for (int i = 0; i < size; i++)
        {
            MyEntity *child = myentity_children_at (parent, i);
            mysql_remove (db, child);
        }
        mysql_remove (db, parent);
    }
    mysql_transaction_end (db);
}

// Java
public static void main (String [] args) {
    Database.setInitializer (new DropCreateDatabaseAlways < MyContext > ());
    try (MyContext ctx = new MyContext ()) {
        ctx.setDatabase ().initialize (false);
        MyEntity parent = new MyEntity ("Parent", new ArrayList < MyEntity > ());
        parent.getChildren ().add (new MyEntity ("Child 1"));
        parent.getChildren ().add (new MyEntity ("Child 2"));
        ctx.getMyEntities().add (parent);
        ctx.saveChanges ();
    } try (MyContext ctx = new MyContext ()) {
        MyEntity parent = ctx.getMyEntities ().include (e -> e.getChildren ()).firstOrDefault ();
        for (MyEntity child : parent.getChildren ())
            ctx.getMyEntities ().remove (child);
        ctx.getMyEntities ().remove (parent);
        ctx.saveChanges ();
    }
}

