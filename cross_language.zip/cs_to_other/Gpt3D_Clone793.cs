#input 
public string SplitLongWords (string text, int maxWordLength) {
    var result = new StringBuilder ();
    int currentWordLength = 0;
    foreach (char c in text) {
        if (char.IsWhiteSpace (c)) {
            currentWordLength = 0;
        } else if (currentWordLength == maxWordLength) {
            currentWordLength = 1;
            result.Append (' ');
        } else {
            ++ currentWordLength;
        }
        result.Append (c);
    }
    return result.ToString ().TrimEnd ();
}


#====================
#gpt output=============

Python:
def split_long_words(text, max_word_length):
    result = []
    current_word_length = 0
    for c in text:
        if c.isspace():
            current_word_length = 0
        elif current_word_length == max_word_length:
            current_word_length = 1
            result.append(' ')
        else:
            current_word_length += 1
        result.append(c)
    return ''.join(result).rstrip()
 
 
C:
char* split_long_words(char* text, int max_word_length) {
    char* result = (char*) malloc(strlen(text) + 1);
    int current_word_length = 0;
    int result_index = 0;
    for (int i = 0; i < strlen(text); i++) {
        if (text[i] == ' ') {
            current_word_length = 0;
        } else if (current_word_length == max_word_length) {
            current_word_length = 1;
            result[result_index++] = ' ';
        } else {
            ++ current_word_length;
        }
        result[result_index++] = text[i];
    }
    result[result_index++] = '\0';
    return result;
}


Java:
public static String splitLongWords(String text, int maxWordLength) {
    StringBuilder result = new StringBuilder();
    int currentWordLength = 0;

    for (int i = 0; i < text.length(); i++) {
        char c = text.charAt(i);
        if (Character.isWhitespace(c)) {
            currentWordLength = 0;
        } else if (currentWordLength == maxWordLength) {
            currentWordLength = 1;
            result.append(' ');
        } else {
            ++currentWordLength;
        }
        result.append(c);
    }
    return result.toString().trim();
}

