#input 
private void button6_Click (object sender, EventArgs e) {
    string select = (listView1.SelectedItems.Count > 0) ? (listView1.SelectedItems [0].Text) : null;
    if (! string.IsNullOrWhiteSpace (select)) {
        listView1.BeginUpdate ();
        pths.Remove (select);
        rec.Remove (select);
        listView1.EndUpdate ();
        string s = String.Join ("; ", pths.ToArray ());
        string r = String.Join ("; ", rec.ToArray ());
    }
    Disp ();
}


#====================
#gpt output=============

//Python

def button6_Click(self, sender, e):
    select = (len(listView1.selectedItems() > 0))) ? (listView1.selectedItems()[0].text) : None
    if select is not None and select.strip() != '':
        listView1.beginUpdate()
        pths.remove(select)
        rec.remove(select)
        listView1.endUpdate()
        s = '; '.join(pths)
        r = '; '.join(rec)
    Disp()

//C

void button6_Click(object sender, EventArgs e) {
    char* select;
    if (listView1->selectedItems->Count > 0)
        select = listView1->selectedItems[0]->Text;
    else
        select = NULL;
    
    if (select && strlen(select) > 0) {
        listView1->beginUpdate();
        list_remove(&pths, select);
        list_remove(&rec, select);
        listView1->endUpdate();
        char *s = list_join(&pths, "; ");
        char *r = list_join(&rec, "; ");    
    }
    Disp();
}

//Java

private void button6_Click (Object sender, EventArgs e) {
    String select;
    if (listView1.getSelectedItems().size() > 0) {
        select = listView1.getSelectedItems().get(0).getText();
    } else {
        select = null;
    }

    if (select != null && !select.trim().isEmpty()) {
        listView1.beginUpdate();
        pths.remove(select);
        rec.remove(select);
        listView1.endUpdate();
        String s = String.join("; ", pths);
        String r = String.join("; ", rec);
    }
    Disp();
}

