#input 
public void ShotHit (Point shot, bool sunk) {
    shotBoard [shot] = Shot.Hit;
    if (! sunk) {
        if (attackVector.Count == 0) {
            attackVector.Push (new Attack (this, shot));
        } else {
            attackVector.Peek ().AddHit (shot);
        }
    }
    if (sunk) {
        if (attackVector.Count > 0) {
            attackVector.Pop ();
        }
    }
}


#====================
#gpt output=============

Python:
def ShotHit(shot, sunk): 
    shotBoard[shot] = Shot.Hit 
    if not sunk: 
        if len(attackVector) == 0: 
            attackVector.append(Attack(self, shot)) 
        else: 
            attackVector[-1].AddHit(shot) 
    if sunk: 
        if len(attackVector) > 0: 
            attackVector.pop()


C: 
void ShotHit(Point shot, bool sunk) {
    shotBoard[shot] = Shot.Hit;
    if (!sunk) {
        if (attackVector.length == 0) {
            Attack_Push(&attackVector, Attack(this, shot));
        } else {
            Attack_AddHit(attackVector.items[attackVector.length - 1], shot);
        }
    }
    if (sunk) {
        if (attackVector.length > 0) {
            Attack_Pop(&attackVector);
        }
    }
}

Java: 
public void ShotHit(Point shot, boolean sunk) {
    shotBoard.put(shot, Shot.Hit);
    if (!sunk) {
        if (attackVector.size() == 0) {
            attackVector.push(new Attack(this, shot));
        } else {
            attackVector.peek().AddHit(shot);
        }
    }
    if (sunk) {
        if (attackVector.size() > 0) {
            attackVector.pop();
        }
    }
}

