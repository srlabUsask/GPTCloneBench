#input 
public static void WriteLog (string strLog) {
    StreamWriter log;
    FileStream fileStream = null;
    DirectoryInfo logDirInfo = null;
    FileInfo logFileInfo;
    string logFilePath = "C:\\Logs\\";
    logFilePath = logFilePath + "Log-" + System.DateTime.Today.ToString ("MM-dd-yyyy") + "." + "txt";
    logFileInfo = new FileInfo (logFilePath);
    logDirInfo = new DirectoryInfo (logFileInfo.DirectoryName);
    if (! logDirInfo.Exists)
        logDirInfo.Create ();
    if (! logFileInfo.Exists) {
        fileStream = logFileInfo.Create ();
    } else {
        fileStream = new FileStream (logFilePath, FileMode.Append);
    }
    log = new StreamWriter (fileStream);
    log.WriteLine (strLog);
    log.Close ();
}


#====================
#gpt output=============

// Python Implementation
def write_log(str_log):  
    log_file_path = "C:\\Logs\\"
    log_file_path = log_file_path + "Log-" + datetime.today().strftime('%m-%d-%Y') + ".txt"
    log_file_info = Path(log_file_path)
        
    if not log_file_info.exists():
        log_file_info.parent.mkdir(parents=True, exist_ok=True)
        with open(log_file_path, 'w') as logFile:
            logFile.write(str_log) 
            logFile.close()
    else:
        with open(log_file_path, 'a') as logFile:
            logFile.write(str_log)
            logFile.close()

// C Implementation
void WriteLog (char *strLog)  
{  
    FileStream *fileStream;
    DirectoryInfo *logDirInfo;
    FileInfo *logFileInfo;
    char logFilePath[100] = "C:\\Logs\\";
    char logFileAppend[100]; 
    strcat(logFilePath, "Log-");
    strcat(logFilePath, getCurrentDate());
    strcat(logFilePath, ".txt");
    logFileInfo = (FileInfo *)malloc(sizeof(FileInfo));
    fileStream = (FileStream *)malloc(sizeof(FileStream));
    logDirInfo = (DIrectoryInfo *)malloc(sizeof(DirectoryInfo));
    logFileAppend = (char *)malloc(strlen(strLog));
    strcpy(logFileAppend, logFilePath);

    if (!logDirInfo->Exists)
    {
        logDirInfo->Create();
    }
    
    if (!logFileInfo->Exists) 
    {
        fileStream = logFileInfo->Create();
    } 
    else 
    {
        fileStream = new FileStream(logFileAppend, FileMode.Append);
    }

    strcat(fileStream->WriteLine, " \n");
    strcat(fileStream->WriteLine, strLog);  
    free(logDirInfo);
    free(logFileInfo);
    free(fileStream);
    free(logFileAppend);
}

// Java Implementation
public static void writeLog(String strLog) {
        PrintWriter log;
        FileOutputStream fileStream = null;
        File logFile;
        String logFilePath = "C:\\Logs\\";
        logFilePath = logFilePath + "Log-" + Calendar.getInstance().get(Calendar.MONTH) + "-" + Calendar.getInstance().get(Calendar.DATE) + "-" + Calendar.getInstance().get(Calendar.YEAR) + ".txt";
        logFile = new File(logFilePath);
        if (! logFile.getParentFile().exists())
            logFile.getParentFile().mkdirs();
        if (! logFile.exists()) {
            fileStream = new FileOutputStream(logFile);
        } else {
            fileStream = new FileOutputStream(logFilePath, true);
        }
        log = new PrintWriter(fileStream);
        log.println(strLog);
        log.close();
}

