#input 
private static string FormatNumber (long num) {
    long i = (long) Math.Pow (10, (int) Math.Max (0, Math.Log10 (num) - 2));
    num = num / i * i;
    if (num >= 1000000000)
        return (num / 1000000000D).ToString ("0.##") + "B";
    if (num >= 1000000)
        return (num / 1000000D).ToString ("0.##") + "M";
    if (num >= 1000)
        return (num / 1000D).ToString ("0.##") + "K";
    return num.ToString ("#,0");
}


#====================
#gpt output=============

Python: 
def format_number(num): 
    i = int(pow(10, max(0, math.log10(num) - 2)))
    num = int(num / i) * i
    if num >= 1000000000: 
        return '{:.2f}B'.format(num/1000000000)
    elif num >= 1000000: 
        return '{:.2f}M'.format(num/1000000)
    elif num >= 1000: 
        return '{:.2f}K'.format(num/1000)
    else:
        return '{:,d}'.format(num)

C: 
char* format_number(long num) {
    long  i = (long)pow(10, (int) fmax(0, log10(num) - 2));
    num = num / i * i;
    char *str;
    if (num >= 1000000000) {
        sprintf(str, "%.2fB", num/1000000000);
    }
    else if (num >= 1000000) {
        sprintf(str, "%.2fM", num/1000000);
    }
    else if (num >= 1000) {
        sprintf(str, "%.2fK", num/1000);
    }
    else {
        sprintf(str, "%ld", num);
    }
    return str;
}

Java: 
static String formatNumber (long num) {
    long  i = (long)Math.pow(10, (int)Math.max(0, Math.log10(num) - 2));
    num = num / i * i;
    if (num >= 1000000000)
        return String.format("%.2fB", num / 1000000000D);
    if (num >= 1000000)
        return String.format("%.2fM", num / 1000000D);
    if (num >= 1000)
        return String.format("%.2fK", num /1000D);
    return String.valueOf(num).replaceAll("^(-?)(0+)", "$1");
}

