#input 
public static void AssignValueToProperty (this ObjectAccessor accessor, string propertyName, object value) {
    var index = propertyName.IndexOf ('.');
    if (index == - 1) {
        accessor [propertyName] = value;
    } else {
        accessor = ObjectAccessor.Create (accessor [propertyName.Substring (0, index)]);
        AssignValueToProperty (accessor, propertyName.Substring (index + 1), value);
    }
}


#====================
#gpt output=============

Python: 
def AssignValueToProperty (this, accessor, propertyName, value):
    index = propertyName.find('.')
    if (index == -1):
        accessor[propertyName] = value
    else:
        accessor = ObjectAccessor.Create (accessor[propertyName[:index]])
        AssignValueToProperty (this, accessor, propertyName[index+1:], value)

C:
void AssignValueToProperty (struct ObjectAccessor *accessor, const char *propertyName, void *value) {
    int index = strIndexOf(propertyName, '.');
    if (index == -1) {
        accessor[propertyName] = value;
    } else {
        accessor = (struct ObjectAccessor*) ObjectAccessor_Create (accessor[propertyName[0:index]];
        AssignValueToProperty (accessor, propertyName[index+1:], value);
    }
}

Java: 
public static void AssignValueToProperty (ObjectAccessor accessor, String propertyName, Object value) {
    int index = propertyName.indexOf('.');
    if (index == -1) {
        accessor.put(propertyName, value);
    } else {
        accessor = ObjectAccessor.create(accessor.get(propertyName.substring(0, index)));
        AssignValueToProperty (accessor, propertyName.substring(index + 1), value);
    }
}

