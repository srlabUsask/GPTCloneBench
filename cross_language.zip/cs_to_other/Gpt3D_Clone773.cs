#input 
private void btnAddDriver_Click (object sender, RoutedEventArgs e) {
    decimal policy = 500M;
    decimal Chauffeur = 0.10M;
    decimal Accountant = 0.10M;
    decimal age2125 = 0.20M;
    decimal age2675 = 0.10M;
    if (cmbOccupation.SelectedItem.ToString () == Occumpation.Chauffeur.ToString ()) {
        policy += policy * Chauffeur;
    } else if (cmbOccupation.SelectedItem.ToString () == Occumpation.Accountant.ToString ()) {
        policy -= policy * Accountant;
    }
    DateTime ? birthDate = dpkDOB.SelectedDate;
    if (birthDate != null) {
        if (birthDate.Age ().Years () > 21 && birthDate.Age ().Years () < 26) {
            policy += policy * age2125;
        } else if (birthDate.Age ().Years () > 26 && birthDate.Age ().Years () < 76) {
            policy -= policy * age2675;
        }
    }
    txtPolicy.Text = policy.ToString ();
}


#====================
#gpt output=============

# Python 
def btnAddDriver_Click(self, sender, e):
    policy = 500M
    Chauffeur = 0.10M
    Accountant = 0.10M
    age2125 = 0.20M
    age2675 = 0.10M
    if cmbOccupation.SelectedItem.ToString == "Occuapation.Chauffeur.ToString":
        policy += policy * Chauffeur
    elif cmbOccupation.SelectedItem.ToString == "Occuapation.Accountant.ToString":
        policy -= policy * Accountant
    birthDate = dpkDOB.SelectedDate
    if birthDate is not None:
        if birthDate.Age().Years > 21 and birthDate.Age().Years < 26:
            policy += policy * age2125
        elif birthDate.Age().Years > 26 and birthDate.Age().Years < 76:
            policy -= policy * age2675
    txtPolicy.Text = str(policy)


# Java
private void btnAddDriver_Click(Object sender, RoutedEventArgs e) {
    BigDecimal policy = new BigDecimal("500M");
    BigDecimal chauffeur = new BigDecimal("0.10M");
    BigDecimal accountant = new BigDecimal("0.10M");
    BigDecimal age2125 = new BigDecimal("0.20M");
    BigDecimal age2675 = new BigDecimal("0.10M");
    if (cmbOccupation.SelectedItem.ToString() == "Occupation.Chauffer.ToString()") {
        policy = policy.add(policy.multiply(chauffeur));
    } else if (cmbOccupation.SelectedItem.ToString() == "Occupation.Accountant.ToString()") {
        policy = policy.subtract(policy.multiply(accountant));
    }
    LocalDateTime birthDate = dpkDOB.SelectedDate;
    if (birthDate != null) {
        if (birthDate.minusYears(21).getYears() > 0 && birthDate.minusYears(26).getYears() < 0) {
            policy = policy.add(policy.multiply(age2125));
        } else if (birthDate.minusYears(26).getYears() > 0 && birthDate.minusYears(76).getYears() < 0) {
            policy = policy.subtract(policy.multiply(age2675));
        }
    }
    txtPolicy.Text = policy.toString();
}

# C
void btnAddDriver_Click (object sender, RoutedEventArgs e) {
    decimal policy = 500M;
    decimal chauffeur = 0.10M;
    decimal accountant = 0.10M;
    decimal age2125 = 0.20M;
    decimal age2675 = 0.10M;
    if (strcmp (cmbOccupation.SelectedItem.ToString (), Occumpation.Chauffeur.ToString ())) {
        policy += policy * chauffeur;
    } else if (strcmp (cmbOccupation.SelectedItem.ToString (), Occumpation.Accountant.ToString ())) {
        policy -= policy * accountant;
    }
    DateTime birthDate = dpkDOB.SelectedDate;
    if (birthDate != NULL) {
        if (birthDate.Age().Years() > 21 && birthDate.Age().Years() < 26) {
            policy += policy * age2125;
        } else if (birthDate.Age().Years() > 26 && birthDate.Age().Years() < 76) {
            policy -= policy * age2675;
        }
    }
    txtPolicy.Text = policy.ToString ();
}

