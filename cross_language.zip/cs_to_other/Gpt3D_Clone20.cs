#input 
static void Main (string [] args) {
    Console.WriteLine ("Enter number(s): ");
    double [] values = new double [3];
    for (int i = 0; i < values.Length; i ++) {
        values [i] = Convert.ToDouble (Console.ReadLine ());
    }
    average (values);
    Console.ReadKey ();
}


#====================
#gpt output=============



//Python
def Main(args): 
    print("Enter number(s):") 
    values = [0] * 3
    for i in range(len(values)): 
        values[i] = float(input()) 
    average(values)
    input() 

//C
void Main (char * args[]) 
{
    printf("Enter number(s):");
    double values[3];
    for (int i=0; i<3; i++)
    {
    	scanf("%lf", &values[i]);
    }
    average(values); 
    getch(); 
}

//Java
public static void Main (String [] args) {
    System.out.println("Enter number(s): ");
    double [] values = new double [3];
    for (int i = 0; i < values.length; i ++) {
        values [i] = Double.parseDouble(System.console().readLine());
    }
    average (values);
    System.console().readLine();
}

