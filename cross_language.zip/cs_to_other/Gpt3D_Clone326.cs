#input 
public static void MultiplyDigitArrays (int [] lhs, int [] rhs, int [] result) {
    var n1 = BigInteger.Parse (string.Join ("", lhs));
    var n2 = BigInteger.Parse (string.Join ("", rhs));
    var resultBi = BigInteger.Multiply (n1, n2);
    Array.Clear (result, 0, result.Length);
    var stResult = resultBi.ToString ().PadLeft (result.Length, '0');
    for (int i = 0; i < stResult.Length; i ++) {
        result [(stResult.Length - 1) - i] = int.Parse (stResult [i].ToString ());
    }
}


#====================
#gpt output=============

// Python 
def MultiplyDigitArrays(lhs, rhs, result): 
    n1 = int(''.join(str(x) for x in lhs))
    n2 = int(''.join(str(x) for x in rhs))
    resultBi = n1 * n2
    result[:] = [0] * len(result)
    stResult = str(resultBi).zfill(len(result))
    for i in range(len(stResult)):
        result[(len(stResult) - 1) - i] = int(stResult[i])
                                                                                

// C 
void MultiplyDigitArrays (int lhs[], int rhs[], int result[], int size) { 
    int residue = 0;
    char n1[size], n2[size];
    long resultBi = 0;
    
    // convert int array to string array
    for (int i = 0; i < size; i++) { 
        n1[i] = lhs[i] + '0'; 
        n2[i] = rhs[i] + '0';
    }

    // Multiply digits by digits 
    for (int i = size - 1; i >= 0; i--) { 
        for (int j = size - 1; j >= 0; j--) { 
            resultBi += (n1[i] - '0') * (n2[j] - '0') + residue; 
            residue = resultBi / 10; 
            resultBi /= 10; 
        } 
    }
    
    // fill result array with the result
    for (int i = 0; i < size; i++) { 
        result[i] = resultBi % 10; 
        resultBi /= 10; 
    } 
} 


// Java
public static void MultiplyDigitArrays(int[] lhs, int[] rhs, int[] result) { 
    BigInteger n1 = new BigInteger(Arrays.stream(lhs).mapToObj(String::valueOf).collect(Collectors.joining("")));
    BigInteger n2 = new BigInteger(Arrays.stream(rhs).mapToObj(String::valueOf).collect(Collectors.joining("")));
    BigInteger resultBi = n1.multiply(n2);
    Arrays.fill(result, 0);
    String stResult = resultBi.toString().padStart(result.length, '0');
    for (int i = 0; i < stResult.length(); i++) {
        result[stResult.length() - 1 - i] = Integer.parseInt(stResult.substring(i, i + 1));
    } 
}

