#input 
private bool IsAnagramFast (string a, string b) {
    if (a.Length != b.Length) {
        return false;
    }
    var aFrequency = CalculateFrequency (a);
    var bFrequency = CalculateFrequency (b);
    foreach (var key in aFrequency.Keys) {
        if (! bFrequency.ContainsKey (key))
            return false;
        if (aFrequency [key] != bFrequency [key])
            return false;
    }
    return true;
}


#====================
#gpt output=============

Python Implementation:
def is_anagram_fast(a, b):
  if len(a) != len(b):
    return False
  a_frequency = calculate_frequency(a)
  b_frequency = calculate_frequency(b)
  for key in a_frequency.keys():
    if b_frequency.get(key) == None:
     return False
    if a_frequency[key] != b_frequency[key]:
     return False
  return True

C Implementation:
int is_anagram_fast(char *a, char *b) {
    int a_length = strlen(a); 
    int b_length = strlen(b); 
    if (a_length != b_length) {
        return 0;
    }
    int *a_frequency = calculate_frequency(a);
    int *b_frequency = calculate_frequency(b);
    for (int i = 0; i < a_length; i++){
        if (b_frequency[i] == 0) {
            return 0;
        }
        if (a_frequency[i] != b_frequency[i]) {
            return 0;
        }
    }
    return 1;
}

Java Implementation:
public static boolean isAnagramFast(String a, String b){
    int a_length = a.length();
    int b_length = b.length();
    if (a_length != b_length) {
        return false;
    }
    int[] a_frequency = calculateFrequency(a);
    int[] b_frequency = calculateFrequency(b);
    for (int i = 0; i < a_length; i++){
        if (b_frequency[i] == 0) {
            return false;
        }
        if (a_frequency[i] != b_frequency[i]) {
            return false;
        }
    }
    return true;
}

