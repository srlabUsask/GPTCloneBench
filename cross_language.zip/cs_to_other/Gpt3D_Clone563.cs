#input 
static void Main (string [] args) {
    Func < string > a = (() = > "a");
    Func < string > b = (() = > "b");
    Foo foo = new Foo ();
    foo.Del = a;
    WriteFoo (foo);
    Foo bar = ReadFoo ();
    Console.WriteLine (bar.Del ());
    Console.ReadKey ();
}


#====================
#gpt output=============

#Python
def Main(args): 
  def a():
    return "a"
  def b():
    return "b"
  
  foo = Foo() 
  foo.del = a
  WriteFoo(foo) 
  bar = ReadFoo() 
  print(bar.del())
  
#C
void Main(char *args[]) {
  Func a = { return "a" }; 
  Func b = { return "b" }; 
  
  Foo *foo; 
  foo = malloc(sizeof(Foo)); 
  foo->del = &a;
  WriteFoo(foo); 
  
  Foo *bar; 
  bar = ReadFoo(); 
  printf("%s\n", bar->del());
  
  free(foo); 
  free(bar); 
  
}

#Java
public static void main(String[] args){
  Func<String> a = () -> "a";
  Func<String> b = () -> "b";
  Foo foo = new Foo();
  foo.setDel(a);
  writeFoo(foo);
  Foo bar = readFoo();
  System.out.println(bar.getDel());
 }

