#input 
private bool IsValidImage (string filename) {
    Stream imageStream = null;
    try {
        imageStream = new FileStream (filename, FileMode.Open);
        if (imageStream.Length > 0) {
            byte [] header = new byte [30];
            string [] imageHeaders = new [] {"BM", "GIF", Encoding.ASCII.GetString (new byte [] {137, 80, 78, 71}), "MM\x00\x2a", "II\x2a\x00"};
            imageStream.Read (header, 0, header.Length);
            bool isImageHeader = imageHeaders.Count (str = > Encoding.ASCII.GetString (header).StartsWith (str)) > 0;
            if (imageStream != null) {
                imageStream.Close ();
                imageStream.Dispose ();
                imageStream = null;
            }
            if (isImageHeader == false) {
                using (BinaryReader br = new BinaryReader (File.Open (filename, FileMode.Open)))
                {
                    UInt16 soi = br.ReadUInt16 ();
                    UInt16 jfif = br.ReadUInt16 ();
                    return soi == 0xd8ff && (jfif == 0xe0ff || jfif == 57855);
                }}
            return isImageHeader;
        }
        return false;
    }
    catch {
        return false;
    }
    finally {
        if (imageStream != null) {
            imageStream.Close ();
            imageStream.Dispose ();
        }
    }
}


#====================
#gpt output=============

Python:
def IsValidImage(filename):
    imageStream = None
    try:
        imageStream = open(filename, 'rb')
        if os.path.getsize(filename) > 0:
            header = imageStream.read(30)
            imageHeaders = ['BM', 'GIF', b'\x89PNG', b'MM\x00*', b'II*\x00']
            isImageHeader = 0
            for i in range(len(imageHeaders)):
                if str(header).startswith(imageHeaders[i]):
                    isImageHeader+=1 
            if not isImageHeader:
                with open(filename, 'rb') as reader:
                    soi = reader.read(2)
                    jfif = reader.read(2)
                    return soi == b'\xff\xd8' and (jfif == b'\xff\xe0' or jfif == b'\xee\x00')
            return isImageHeader > 0
        return False
    except:
        return False
    finally:
        imageStream.close()



C: 
bool IsValidImage (const char *filename) {
    FILE* imageStream = NULL;
    try {
        imageStream = fopen(filename, "rb");
        if (imageStream) {
            int sz = 0;
            fseek(imageStream, 0L, SEEK_END);
            sz = ftell(imageStream);
            fseek(imageStream, 0L, SEEK_SET); 
            if (sz > 0) {
                char header[30];
                const char *imageHeaders[] = {"BM", "GIF", "\x89PNG", "MM\x00\x2a", "II\x2a\x00"};
                size_t num_headers = sizeof(imageHeaders) / sizeof(imageHeaders[0]); 
                size_t bytes_read = fread(header, 1, sizeof(header), imageStream); 
                int index = 0;
                bool isImageHeader = false;
                for (; index < num_headers; index++){
                    if (memcmp(header, imageHeaders[index], bytes_read) == 0){
                        isImageHeader = true;
                        break;
                    }
                }
                if (!isImageHeader) {
                    unsigned char buff[4];
                    FILE * reader = fopen(filename, "rb");
                    fread(buff, 1, 4, reader);
                    UInt16 soi = (buff[0] << 8) | buff[1];
                    UInt16 jfif = (buff[2] << 8) | buff[3];
                    fclose(reader);
                    return (soi == 0xd8ff && (jfif == 0xe0ff || jfif == 57855));
                }
                return isImageHeader;
            }
            return false;
        }
        return false;
    } catch(...) {
        return false;   
    } finally {
        if (imageStream) {
            fclose(imageStream);
        }
    }
}


Java:
public static Boolean isValidImage(String filename) {
    FileInputStream imageStream = null;
    try {
        imageStream = new FileInputStream(filename);
        if (imageStream.available() > 0) {
            byte[] header = new byte[30];
            String[] imageHeaders = new String[]{"BM", "GIF", new String(new byte[]{(byte) 0x89, (byte) 0x50, (byte) 0x4E, (byte) 0x47}), "MM\u0000\u002A", "II\u002A\u0000"};
            imageStream.read(header);
            boolean isImageHeader = false;
            for (String str : imageHeaders) {
                isImageHeader = str.equals(new String(header));
                if (isImageHeader) {
                    break;
                }
            }
            if (!isImageHeader) {
                BufferedInputStream reader = new BufferedInputStream(new FileInputStream(filename));
                int soi = reader.read();
                int jfif = reader.read();
                reader.close();
                return soi == 0xFF && (jfif == 0xE0FF || jfif == 0xED00);
            }
            return isImageHeader;
        }
        return false;
    } catch (IOException e) {
        return false;
    } finally {
        if (imageStream != null) {
            try {
                imageStream.close();
            } catch (IOException e) {
            }
        }
    }
}

