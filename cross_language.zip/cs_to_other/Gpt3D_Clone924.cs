#input 
public static IEnumerable < IList < T > > ChunkOn < T > (this IEnumerable < T > source, Func < T, bool > startChunk) {
    List < T > list = new List < T > ();
    foreach (var item in source) {
        if (startChunk (item) && list.Count > 0) {
            yield return list;
            list = new List < T > ();
        }
        list.Add (item);
    }
    if (list.Count > 0) {
        yield return list;
    }
}


#====================
#gpt output=============

// Python
def chunkOn(source, startChunk):
    list = []
    for item in source:
        if startChunk(item) and len(list) > 0:
            yield list
            list = []
        list.append(item)
    if len(list) > 0:
        yield list

// C
IEnumerable<IList<T>>* ChunkOn<T>(IEnumerable<T>* source, Func<T, bool> startChunk) {
    IList<T>* list = new List<T>();
    for (T item : source) {
        if (startChunk(item) && list->Count > 0) {
            yield list;
            list = new List<T>();
        }
        list->Add(item);
    }
    if (list->Count > 0) {
        yield list;
    }
}

// Java
public static <T> Iterable<List<T>> chunkOn(Iterable<T> source, Function<T, Boolean> startChunk) {
    List<T> list = new ArrayList<>();
    for (T item : source) {
        if (startChunk.apply(item) && !list.isEmpty()) {
            yield list;
            list = new ArrayList<>();
        }
        list.add(item);
    }
    if (!list.isEmpty()) {
        yield list;
    }
}

