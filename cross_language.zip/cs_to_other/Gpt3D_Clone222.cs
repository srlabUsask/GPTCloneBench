#input 
private void SendToPrinter () {
    ProcessStartInfo info = new ProcessStartInfo ();
    info.Verb = "print";
    info.FileName = @"c:\output.pdf";
    info.CreateNoWindow = true;
    info.WindowStyle = ProcessWindowStyle.Hidden;
    Process p = new Process ();
    p.StartInfo = info;
    p.Start ();
    long ticks = - 1;
    while (ticks != p.TotalProcessorTime.Ticks) {
        ticks = p.TotalProcessorTime.Ticks;
        Thread.Sleep (1000);
    }
    if (false == p.CloseMainWindow ())
        p.Kill ();
}


#====================
#gpt output=============

Python:
def SendToPrinter():
    info = subprocess.Popen('lp -d printer_name output.pdf') 
    ticks = - 1
    while ticks != info.TotalProcessorTime.Ticks:
        ticks = info.TotalProcessorTime.Ticks
        time.sleep(1000)
    if (false == p.CloseMainWindow()):
        p.Kill()

C: 
void SendToPrinter(){ 
    PROCESS_INFORMATION pi;
    STARTUPINFO si;
    ZeroMemory(&pi, sizeof(pi));
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
 
    CreateProcess("c:\\output.pdf", NULL, NULL, NULL, 0, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
 
    long ticks = -1;
    while (ticks != pi.TotalProcessorTime.Ticks){
        ticks = pi.TotalProcessorTime.Ticks;
        Sleep(1000);
    }
    TerminateProcess(pi.Process, 0);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
}

Java: 
private void SendToPrinter() {
    ProcessBuilder pb = new ProcessBuilder("print", "c:\\output.pdf");
    pb.inheritIO();
 
    long ticks = -1;
    try {
        Process process = pb.start();
        while (ticks != process.TotalProcessorTime.Ticks) {
            ticks = process.TotalProcessorTime.Ticks;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
 
        if (false == process.isAlive()) {
            process.destroyForcibly();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}

