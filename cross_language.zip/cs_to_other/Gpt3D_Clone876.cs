#input 
static void Main (string [] args) {
    var input = @"
              { ""store"": {
                    ""book"": [ 
                      { ""category"": ""reference"",
                            ""author"": ""Nigel Rees"",
                            ""title"": ""Sayings of the Century"",
                            ""price"": 8.95
                      },
                      { ""category"": ""fiction"",
                            ""author"": ""Evelyn Waugh"",
                            ""title"": ""Sword of Honour"",
                            ""price"": 12.99
                      },
                      { ""category"": ""fiction"",
                            ""author"": ""Herman Melville"",
                            ""title"": ""Moby Dick"",
                            ""isbn"": ""0-553-21311-3"",
                            ""price"": 8.99
                      },
                      { ""category"": ""fiction"",
                            ""author"": ""J. R. R. Tolkien"",
                            ""title"": ""The Lord of the Rings"",
                            ""isbn"": ""0-395-19395-8"",
                            ""price"": 22.99
                      }
                    ],
                    ""bicycle"": {
                      ""color"": ""red"",
                      ""price"": 19.95
                    }
              }
            }
        ";
    var json = JObject.Parse (input);
    var context = new JsonPathContext {ValueSystem = new JsonNetValueSystem ()};
    var values = context.SelectNodes (json, "$.store.book[*].author").Select (node = > node.Value);
    Console.WriteLine (JsonConvert.SerializeObject (values));
    Console.ReadKey ();
}


#====================
#gpt output=============

//Python
import json
data = json.loads("""input""")

result = [book['author'] for book in data['store']['book']]

print(json.dumps(result))


//C
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){
   const char* input = "{"store": {
                    "book": [ 
                      { "category": "reference",
                            "author": "Nigel Rees",
                            "title": "Sayings of the Century",
                            "price": 8.95
                      },
                      { "category": "fiction",
                            "author": "Evelyn Waugh",
                            "title": "Sword of Honour",
                            "price": 12.99
                      },
                      { "category": "fiction",
                            "author": "Herman Melville",
                            "title": "Moby Dick",
                            "isbn": "0-553-21311-3",
                            "price": 8.99
                      },
                      { "category": "fiction",
                            "author": "J. R. R. Tolkien",
                            "title": "The Lord of the Rings",
                            "isbn": "0-395-19395-8",
                            "price": 22.99
                      }
                    ],
                    "bicycle": {
                      "color": "red",
                      "price": 19.95
                    }
              }}";
    
    int i = 0;
    char* value = strstr(input, "\"author\": \"") + 10;
    char* authors[4];
    int len_authors = 0;
    while (value){
        authors[i] = malloc(sizeof(char) * strlen(value));
        strcpy(authors[i], value);
        value = strstr(value, "\"author\": \"") + 1; 
	len_authors++;
        i++;       
    }
    
    printf("[");
    for (i = 0; i < len_authors; i++){
        printf("\"%s\", ", authors[i]);
    }
    printf("]\n");
    return 0;
}


// Java
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

public class Main {
    
    public static void main(String[] args) {
        String input = 
                "{"store": {
                    "book": [ 
                      { "category": "reference",
                            "author": "Nigel Rees",
                            "title": "Sayings of the Century",
                            "price": 8.95
                      },
                      { "category": "fiction",
                            "author": "Evelyn Waugh",
                            "title": "Sword of Honour",
                            "price": 12.99
                      },
                      { "category": "fiction",
                            "author": "Herman Melville",
                            "title": "Moby Dick",
                            "isbn": "0-553-21311-3",
                            "price": 8.99
                      },
                      { "category": "fiction",
                            "author": "J. R. R. Tolkien",
                            "title": "The Lord of the Rings",
                            "isbn": "0-395-19395-8",
                            "price": 22.99
                      }
                    ],
                    "bicycle": {
                      "color": "red",
                      "price": 19.95
                    }
              }
            }";
        
        List<String> authors = new ArrayList<String>();
        try (JsonReader reader = Json.createReader(new StringReader(input))) {
            JsonObject jsonObject = reader.readObject();
            JsonArray bookArray = jsonObject.getJsonObject("store").getJsonArray("book");
            for (int i = 0; i < bookArray.size(); i++) {
                JsonObject bookObj = bookArray.getJsonObject(i);
                String authorName = bookObj.getString("author");
                authors.add(authorName);
            }
        }
        System.out.println(authors);          
    }
}

