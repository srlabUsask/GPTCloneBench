#input 
static void Main (string [] args) {
    Console.ForegroundColor = ConsoleColor.Green;
    StringBuilder sbOutFile = new StringBuilder ();
    Console.WriteLine ("DisplayName;IdentifyingNumber");
    sbOutFile.AppendLine ("Machine;DisplayName;Version");
    string [] lines = File.ReadAllLines (@"File_In/collectionMachines.txt");
    foreach (var machine in lines) {
        var registry_key = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";
        using (Microsoft.Win32.RegistryKey key = RegistryKey.OpenRemoteBaseKey (RegistryHive.LocalMachine, machine).OpenSubKey (registry_key))
        {
            foreach (string subkey_name in key.GetSubKeyNames ()) {
                using (RegistryKey subkey = key.OpenSubKey (subkey_name))
                {
                    if (subkey.GetValue ("DisplayName") != null) {
                        Console.WriteLine (string.Format ("{0};{1};{2}", machine, subkey.GetValue ("DisplayName"), subkey.GetValue ("Version")));
                        sbOutFile.AppendLine (string.Format ("{0};{1};{2}", machine, subkey.GetValue ("DisplayName"), subkey.GetValue ("Version")));
                    }
                }}
        }}
    var fileOutName = string.Format (@"File_Out\{0}_{1}.csv", "Software_Inventory", DateTime.Now.ToString ("yyyy_MM_dd_HH_mmssfff"));
    using (var file = new System.IO.StreamWriter (fileOutName))
    {
        file.WriteLine (sbOutFile.ToString ());
    } Console.WriteLine ("Press enter to continue !");
    Console.ReadLine ();
}


#====================
#gpt output=============

Python:

def main(args):
    print('DisplayName;IdentifyingNumber')
    sbOutFile = ''
    with open('File_In/collectionMachines.txt', 'r') as f:
        lines = f.readlines()
        for machine in lines:
            registry_key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall' 
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, machine + '\\' + registry_key, 
            0, winreg.KEY_ALL_ACCESS)
            for i in range(winreg.QueryInfoKey(key)[1]):
                line = ''
                subkey_name = winreg.EnumKey(key, i)
                subkey = winreg.OpenKey(key, subkey_name)
                try:
                    displayname = winreg.QueryValueEx(subkey, 'DisplayName')[0]
                    version = winreg.QueryValueEx(subkey, 'Version')[0]
                    print('{};{};{}'.format(machine,displayname,version))
                    line = '{};{};{}\n'.format(machine, displayname, version)
                except WindowsError:
                    pass
                sbOutFile += line

    fileOutName = 'File_Out/Software_Inventory_{}.csv'.format(datetime.now().strftime('%Y_%m_%d_%H_%M_%S%f'))
    with open(fileOutName, 'w') as f:
        f.write(sbOutFile)
    print('Press enter to continue !')
    input()

C:
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include <time.h>

int main(int argc, char *argv[]) {
    char line[256], buffer[1024];
    FILE* input = fopen("File_In\\collectionMachines.txt", "r");
    FILE* output = NULL;

    printf("DisplayName;IdentifyingNumber\n");
    sprintf(buffer, "File_Out\\Software_Inventory_%d_%d_%d_%d_%d_%d.csv", time(NULL));
    output = fopen(buffer, "w");

    fprintf(output, "Machine;DisplayName;Version\n");
    while (fgets(line, sizeof(line), input)) {
        int len = strlen(line);
        if (line[len - 1] == '\n') line[len - 1] = '\0';
        if (line[len - 2] == '\r') line[len - 2] = '\0';
        char *subKeyName = NULL;
        HKEY key, subkey;
        DWORD size;
        char displayname[256], version[256];
        LONG result = RegOpenKeyEx(HKEY_LOCAL_MACHINE, line, 0, KEY_ALL_ACCESS, &key);
        if (result == ERROR_SUCCESS) {
            int index = 0;
            while (RegEnumKeyEx(key, index, subKeyName, &size, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
                RegOpenKeyEx(key, subKeyName, 0, KEY_QUERY_VALUE | KEY_WOW64_64KEY, &subkey);
                char *dn = NULL, *vn = NULL, buffer[1024];
                DWORD sizeDN = 0, sizeVN = 0;
                RegQueryValueEx(subkey, "DisplayName", NULL, NULL, (LPBYTE)buffer, &sizeDN);
                dn = buffer;
                RegQueryValueEx(subkey, "Version", NULL, NULL, (LPBYTE)buffer, &sizeVN);
                vn = buffer;
                if (dn && vn) {
                    printf("%s;%s;%s\n", line, dn, vn);
                    fprintf(output, "%s;%s;%s\n", line, dn, vn);
                }
 
                index++;
            }
            RegCloseKey(key);
        }
    }

    fclose(input);
    fclose(output);
    printf("Press enter to continue !");
    getch();
    
    return 0;
}

Java:
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.Scanner;
import java.text.SimpleDateFormat;

import java.util.Base64;
import java.util.LinkedList;
import java.util.List;
import java.util.*;
import java.util.regex.Pattern;

import java.lang.StringBuilder;
import java.net.InetAddress;

import java.nio.file.Files;
import java.nio.file.Paths;

import java.util.prefs.Preferences;

import java.util.function.Predicate;

public class Main {
  
    public static void main(String[] args) throws IOException {
        System.out.println("DisplayName;IdentifyingNumber");
        StringBuilder sbOutFile = new StringBuilder();
        sbOutFile.append("Machine;DisplayName;Version\n");
        File file = new File("File_In/collectionMachines.txt"); 
            
        Scanner scanner = new Scanner(file); 
        while (scanner.hasNext()) { 
            String machine = scanner.nextLine(); 
            String registry_key = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall";
            Preferences prefs = Preferences.systemRoot().node(machine).node(registry_key);

            try {
                String[] childrenNames = prefs.childrenNames();
                for (int i = 0; i < childrenNames.length; i++) {
                    Preferences childPrefs = prefs.node(childrenNames[i]);
                    if (childPrefs.get("DisplayName", null) != null) {
                        System.out.println(String.format("%s;%s;%s", machine, childPrefs.get("DisplayName", null), childPrefs.get("Version", null)));
                        sbOutFile.append(String.format("%s;%s;%s\n", machine, childPrefs.get("DisplayName", null), childPrefs.get("Version", null)));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mmssfff");
        Date date = new Date();
                    
        FileWriter out = new FileWriter("File_Out/Software_Inventory_" +  formatter.format(date) + ".csv"); 
        out.write(sbOutFile.toString());
        out.close(); 
        System.out.println("Press enter to continue !");
        scanner.close(); 
    } 
}

