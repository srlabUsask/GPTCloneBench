#input 
static void Main (string [] args) {
    List < string > selected = new List < string > {"A", "B", "B.1", "B.11", "C"};
    List < string > required = new List < string > {"B", "C"};
    var matching = from s in selected
        where required.Any (r = > s.StartsWith (r))
        select s;
    foreach (string m in matching) {
        Console.WriteLine (m);
    }
}


#====================
#gpt output=============


Python:
selected = ["A", "B", "B.1", "B.11", "C"]
required = ["B", "C"]
matching = [s for s in selected if any(r for r in required if s.startswith(r))]
for m in matching:
  print(m)
  
  
C:
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void Main (int argc, char** argv) {
    char *selected[] = {"A", "B", "B.1", "B.11", "C"};
    char *required[] = {"B", "C"};
    char *matching[5];
    int cnt = 0;
    int i, j;
    for (i=0;i<5;i++) {
        for (j=0;j<2;j++) {
            if (strstr(selected[i], required[j]) != NULL) {
                matching[cnt] = selected[i];
                cnt++;
                break;
            }
        }
    }
    for (i=0;i<cnt;i++) {
        printf("%s\n", matching[i]);
    }
    return;
}


Java:
public class Main {
    public static void main (String[] args) {
        List<String> selected = new ArrayList<String> (Arrays.asList ("A", "B", "B.1", "B.11", "C"));
        List<String> required = new ArrayList<String> (Arrays.asList ("B", "C"));
        List<String> matching = new ArrayList<String> ();
        for (String s : selected) {
            for (String r : required) {
                if (s.startsWith (r)) {
                    matching.add (s);
                    break;
                }
            }
        }
        for (String m : matching) {
            System.out.println (m);
        }
    }
}

