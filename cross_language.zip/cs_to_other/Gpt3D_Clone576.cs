#input 
static void Main (string [] args) {
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine ("Split Analyser starts");
    Console.ForegroundColor = ConsoleColor.Red;
    Console.WriteLine ("Press Esc to quit.....");
    Thread MainThread = new Thread (new ThreadStart (startProcess));
    Thread ConsoleKeyListener = new Thread (new ThreadStart (ListerKeyBoardEvent));
    MainThread.Name = "Processor";
    ConsoleKeyListener.Name = "KeyListener";
    MainThread.Start ();
    ConsoleKeyListener.Start ();
    while (true) {
        if (Terminate) {
            Console.WriteLine ("Terminating Process...");
            MainThread.Abort ();
            ConsoleKeyListener.Abort ();
            Thread.Sleep (2000);
            Thread.CurrentThread.Abort ();
            return;
        }
        if (stopProcessor) {
            Console.WriteLine ("Ending Process...");
            MainThread.Abort ();
            ConsoleKeyListener.Abort ();
            Thread.Sleep (2000);
            Thread.CurrentThread.Abort ();
            return;
        }
    }
}


#====================
#gpt output=============

// Python
def Main(args):
   print('Split Analyser starts')
   print('Press Esc to quit.....')

   MainThread = Thread(target=startProcess)
   MainThread.name = "Processor"
   MainThread.start()

   ConsoleKeyListener = Thread(target=ListerKeyboardEvent)
   ConsoleKeyListener.name = "KeyListener"
   ConsoleKeyListener.start()

   while True:
      if Terminate:
         print('Terminating Process...')
         MainThread.abort()
         ConsoleKeyListener.abort()
         time.sleep(2)
         return
      if stopProcessor:
         print('Ending Process...')
         MainThread.abort()
         ConsoleKeyListener.abort()
         time.sleep(2)
         return

// C
void Main (char * args[]) {
    printf ("Split Analyser starts\n");
    printf ("Press Esc to quit.....\n");
    pthread_t MainThread;
    pthread_t ConsoleKeyListener;
    pthread_create(&MainThread, NULL, startProcess, NULL);
    pthread_create(&ConsoleKeyListener, NULL, ListenerKeyboardEvent, NULL);
    while (1) {
        if (Terminate) {
            printf ("Terminating Process...\n");
            pthread_cancel(MainThread);
            pthread_cancel(ConsoleKeyListener);
            sleep (2);
            return;
        }
        if (stopProcessor) {
            printf ("Ending Process...\n");
            pthread_cancel(MainThread);
            pthread_cancel(ConsoleKeyListener);
            sleep (2);
            return;
        }
    }
}

// Java
public static void Main (String [] args) {
    System.out.println ("Split Analyser starts");
    System.out.println ("Press Esc to quit.....");
    Thread MainThread = new Thread (() -> startProcess ());
    MainThread.setName ("Processor");
    MainThread.start ();
    Thread ConsoleKeyListener = new Thread (() -> ListenerKeyboardEvent ());
    ConsoleKeyListener.setName ("KeyListener");
    ConsoleKeyListener.start ();
    while (true) {
        if (Terminate) {
            System.out.println ("Terminating Process...");
            MainThread.interrupt ();
            ConsoleKeyListener.interrupt ();
            try {
                Thread.sleep (2000);
            } catch (InterruptedException e) {
                e.printStackTrace ();
            }
            Thread.currentThread ().interrupt ();
            return;
        }
        if (stopProcessor) {
            System.out.println ("Ending Process...");
            MainThread.interrupt ();
            ConsoleKeyListener.interrupt ();
            try {
                Thread.sleep (2000);
            } catch (InterruptedException e) {
                e.printStackTrace ();
            }
            Thread.currentThread ().interrupt ();
            return;
        }
    }
}

