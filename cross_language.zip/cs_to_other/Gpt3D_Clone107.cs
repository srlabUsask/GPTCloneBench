#input 
private void dataGridView1_CellContentClick (object sender, DataGridViewCellEventArgs e) {
    if (e.ColumnIndex == dataGridView1.Columns ["Your Column Name"].Index) {
        dataGridView1.EndEdit ();
        if ((bool) dataGridView1.Rows [e.RowIndex].Cells ["Your Column Name"].Value) {
            int colIndex = e.ColumnIndex;
            int rowIndex = e.RowIndex;
            dataGridView1.Rows [colIndex].Cells [rowIndex].ReadOnly = true;
        }
    }
}


#====================
#gpt output=============

Python:
def dataGridView1_CellContentClick (sender, e): 
  if e.ColumnIndex == dataGridView1.Columns ["Your Column Name"].Index: 
    dataGridView1.EndEdit ()
    if (bool) dataGridView1.Rows [e.RowIndex].Cells ["Your Column Name"].Value:
      colIndex = e.ColumnIndex
      rowIndex = e.RowIndex
      dataGridView1.Rows [colIndex].Cells [rowIndex].ReadOnly = True

C:
void dataGridView1_CellContentClick (void *sender, DataGridViewCellEventArgs e) 
{ 
	if (e.columnIndex == dataGridView1.columns ["Your Column Name"].index) {
		dataGridView1.EndEdit (); 
		if ((bool) dataGridView1.Rows[e.rowIndex].Cells ["Your Column Name"].value) { 
			int colIndex = e.columnIndex; 
			int rowIndex = e.rowIndex; 
			dataGridView1.Rows[colIndex].Cells[rowIndex].ReadOnly = true; 
		} 
	}
}

Java:
public void dataGridView1_CellContentClick (Object sender, DataGridViewCellEventArgs e) 
{ 
	if (e.ColumnIndex == dataGridView1.Columns ["Your Column Name"].index) 
	{
		dataGridView1.EndEdit (); 
		if ((boolean) dataGridView1.Rows[e.RowIndex].Cells ["Your Column Name"].Value)
		{ 
			int colIndex = e.ColumnIndex; 
			int rowIndex = e.RowIndex; 
			dataGridView1.Rows[colIndex].Cells[rowIndex].ReadOnly = true; 
		} 
	}
}

