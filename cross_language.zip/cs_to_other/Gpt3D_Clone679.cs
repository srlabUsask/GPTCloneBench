#input 
protected override void WndProc (ref Message m) {
    base.WndProc (ref m);
    if (m.Msg == WM_PAINT) {
        using (Graphics g = Graphics.FromHwnd (m.HWnd))
        {
            if (tabControl.Parent != null) {
                g.SetClip (new Rectangle (0, 0, tabControl.Width - 2, tabControl.Height - 1), CombineMode.Exclude);
                using (SolidBrush sb = new SolidBrush (tabControl.Parent.BackColor))
                g.FillRectangle (sb, new Rectangle (0, tabControl.ItemSize.Height + 2, tabControl.Width, tabControl.Height - (tabControl.ItemSize.Height + 2)));
            }
            if (tabControl.SelectedTab != null) {
                g.ResetClip ();
                Rectangle r = tabControl.SelectedTab.Bounds;
                g.SetClip (r, CombineMode.Exclude);
                using (SolidBrush sb = new SolidBrush (tabControl.SelectedTab.BackColor))
                g.FillRectangle (sb, new Rectangle (r.Left - 3, r.Top - 1, r.Width + 4, r.Height + 3));
            }
        }}
}


#====================
#gpt output=============

Python: 
def WndProc(self, m): 
    super().WndProc(m)
    if (m.Msg == WM_PAINT): 
        g = Graphics.HandleFromHwnd(m.Hwnd) 
        if (tabControl.Parent != null): 
            g.SetClip(newRectangle(0,0, tabControl.Width -2, tabControl.Height - 1), CombineMode.Exclude) 
            sb = SolidBrush(tabControl.Parent.BackColor)
            g.FillRectangle(sb, new Rectangle(0, tabControl.ItemSize.Height + 2, tabControl.Width, tabControl.Height - (tabControl.ItemSize.Height + 2))) 
        if (tabControl.SelectedTab != null): 
            g.ResetClip() 
            r = tabControl.SelectedTab.Bounds 
            g.SetClip(r, CombineMode.Exclude) 
            sb = SolidBrush(tabControl.SelectedTab.BackColor)
            g.FillRectangle(sb, new Rectangle(r.Left - 3, r.Top - 1, r.Width + 4, r.Height + 3)) 

C:
void WndProc(MESSAGE * m){
    base.WndProc(m);
    if (m->Msg == WM_PAINT){
        GRAPHIC * g = Graphics.HandleFromHwnd(m->Hwnd);
        if(tabControl.Parent != NULL){
            g->SetClip(new Rectangle(0, 0, tabControl.Width -2, tabControl.Height - 1), CombineMode.Exclude);
            SOLID_BRUSH * sb = SolidBrush(tabControl.Parent.BackColor);
            g->FillRectangle(sb, new Rectangle(0, tabControl.ItemSize.Height + 2, tabControl.Width, tabControl.Height - (tabControl.ItemSize.Height + 2)));
        }
        if(tabControl.SelectedTab != NULL){
            g->ResetClip();
            RECTANGLE r = tabControl.SelectedTab.Bounds;
            g->SetClip(r, CombineMode.Exclude);
            SOLID_BRUSH * sb = SolidBrush(tabControl.SelectedTab.BackColor);
            g->FillRectangle(sb, new Rectangle(r.Left - 3, r.Top - 1, r.Width + 4, r.Height + 3));
         }
    }
}

Java:
protected void WndProc ( Message m ) {
    super.WndProc(m);
    if (m.Msg == WM_PAINT) {
        Graphics g = Graphics.FromHwnd(m.HWnd);
        if (tabControl.Parent != null) {
            g.SetClip(new Rectangle(0, 0, tabControl.Width - 2, tabControl.Height - 1), CombineMode.Exclude);
            SolidBrush sb = new SolidBrush(tabControl.Parent.BackColor);
            g.FillRectangle(sb, new Rectangle(0, tabControl.ItemSize.Height + 2, tabControl.Width, tabControl.Height - (tabControl.ItemSize.Height + 2))); 
        if (tabControl.SelectedTab != null) {
            g.ResetClip();
            Rectangle r = tabControl.SelectedTab.Bounds;
            g.SetClip(r, CombineMode.Exclude);
            SolidBrush sb = new SolidBrush(tabControl.SelectedTab.BackColor);
            g.FillRectangle(sb, new Rectangle(r.Left - 3, r.Top - 1, r.Width + 4, r.Height + 3));
        }     
    }
}

