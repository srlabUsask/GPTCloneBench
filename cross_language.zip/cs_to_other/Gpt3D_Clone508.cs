#input 
public override void PreBuildUp (IBuilderContext context) {
    if (context.BuildKey.Type != typeof (Logger)) {
        var loggerPolicy = context.Policies.Get < ILoggerPolicy > (LoggerExtension.LoggerBuildKey);
        if (loggerPolicy == null) {
            loggerPolicy = new LoggerPolicy ();
            context.Policies.Set < ILoggerPolicy > (loggerPolicy, LoggerExtension.LoggerBuildKey);
        }
        loggerPolicy.Push (context.BuildKey.Type);
    }
}


#====================
#gpt output=============


Python:
def PreBuildUp(self, context):
    if context.BuildKey.Type != type(Logger):
        loggerPolicy = context.Policies.get(LoggerExtension.LoggerBuildKey)
        if loggerPolicy is None:
            loggerPolicy = LoggerPolicy()
            context.Policies.set(loggerPolicy, LoggerExtension.LoggerBuildKey)
        loggerPolicy.Push(context.BuildKey.Type)

C:
void PreBuildUp(IBuilderContext* context) {
    if (context->BuildKey->Type != typeof(Logger)) {
        ILoggerPolicy* loggerPolicy = context->Policies->Get(LoggerExtension->LoggerBuildKey);
        if (loggerPolicy == NULL) {
            loggerPolicy = new LoggerPolicy();
            context->Policies->Set(loggerPolicy, LoggerExtension->LoggerBuildKey);
        }
        loggerPolicy->Push(context->BuildKey->Type);
    }
}

Java:
public void preBuildUp(IBuilderContext context) {
    if (context.getBuildKey().getType() != Logger.class) {
        ILoggerPolicy loggerPolicy = context.getPolicies().get(LoggerExtension.LoggerBuildKey);
        if (loggerPolicy == null) {
            loggerPolicy = new LoggerPolicy();
            context.getPolicies().set(loggerPolicy, LoggerExtension.LoggerBuildKey);
        }
        loggerPolicy.push(context.getBuildKey().getType());
    }
}

