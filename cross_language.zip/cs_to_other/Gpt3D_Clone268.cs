#input 
static void Main () {
    HiResTimer timer = new HiResTimer ();
    Int64 counterAtStart = timer.Value;
    for (int count = 0; count < 10000; count ++) {
        count ++;
        count --;
    }
    Int64 counterAtEnd = timer.Value;
    Int64 timeElapsedInTicks = counterAtEnd - counterAtStart;
    Int64 timeElapseInTenthsOfMilliseconds = (timeElapsedInTicks * 10000) / timer.Frequency;
    MessageBox.Show ("Time Spent in operation (tenths of ms) " + timeElapseInTenthsOfMilliseconds + "\nCounter Value At Start: " + counterAtStart + "\nCounter Value At End : " + counterAtEnd + "\nCounter Frequency : " + timer.Frequency);
}


#====================
#gpt output=============

Python: 
import time

timer = time.perf_counter()
counterAtStart = timer
for count in range(10000):
    count += 1
    count -= 1
counterAtEnd = time.perf_counter()
timeElapsedInTicks = counterAtEnd - counterAtStart
timeElapseInTenthsOfMilliseconds = (timeElapsedInTicks * 10000) / timer.Frequency

print("Time Spent in operation (tenths of ms): ", timeElapseInTenthsOfMilliseconds,
      "\nCounter Value At Start: ", counterAtStart,
      "\nCounter Value At End : ", counterAtEnd, 
      "\nCounter Frequency : ", timer.Frequency)


C: 
#include <time.h>
#include <stdio.h>

int main(void) {
    HiResTimer timer;
    Int64 counterAtStart = timer.Value;
    for (int count = 0; count < 10000; count ++) {
        count ++;
        count --;
    }
    Int64 counterAtEnd = timer.Value;
    Int64 timeElapsedInTicks = counterAtEnd - counterAtStart;
    Int64 timeElapseInTenthsOfMilliseconds = (timeElapsedInTicks * 10000) / timer.Frequency;
    printf("Time Spent in operation (tenths of ms): %d\nCounter Value At Start: %d\n Counter Value At End: %d\nCounter Frequency: %d\n",
            timeElapseInTenthsOfMilliseconds, counterAtStart, counterAtEnd, timer.Frequency);
    return 0;
}



Java: 
public class TimerTest {
    public static void main(String[] args) {
    		HiResTimer timer = new HiResTimer();
		Int64 counterAtStart = timer.Value;
		for (int count = 0; count < 10000; count ++) {
			count ++;
			count --;
		}
		Int64 counterAtEnd = timer.Value;
		Int64 timeElapsedInTicks = counterAtEnd - counterAtStart;
		Int64 timeElapseInTenthsOfMilliseconds = (timeElapsedInTicks * 10000) / timer.Frequency;
		System.out.println("Time Spent in operation (tenths of ms): " + timeElapseInTenthsOfMilliseconds + "\nCounter Value At Start: " + counterAtStart + "\nCounter Value At End : " + counterAtEnd + "\nCounter Frequency : " + timer.Frequency);
    }
}

