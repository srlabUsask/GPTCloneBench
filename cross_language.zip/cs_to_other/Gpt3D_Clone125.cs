#input 
static void Main () {
    int i, n;
    Console.WriteLine ("Enter the number of highest elements you want to extract from the array:");
    while (! int.TryParse (Console.ReadLine (), out n)) {
        Console.WriteLine ("Enter the number of highest elements you want to extract from the array:");
    }
    double [] arr = {12.1, 5.9, 2.9, 6.8, 20.5};
    if (n > arr.Length)
        n = arr.Length;
    double [] result = new double [n];
    double max = 0;
    int k;
    for (int j = 0; j < n; j ++) {
        max = arr [0];
        k = 0;
        for (i = 1; i < arr.Length; i ++) {
            if (max < arr [i]) {
                max = arr [i];
                k = i;
            }
        }
        result [j] = max;
        arr [k] = Double.MinValue;
        Console.WriteLine ("Highest numbers: {0}", result [j]);
    }
    Console.ReadKey ();
}


#====================
#gpt output=============


Python:
def main():
    n = int(input("Enter the number of highest elements you want to extract from the array:"))
    arr = [12.1, 5.9, 2.9, 6.8, 20.5]
    if n > len(arr):
        n = len(arr)
    result = [0] * n
    max = 0
    k = 0
    for j in range(n):
        max = arr[0]
        k = 0
        for i in range(1, len(arr)):
            if max < arr[i]:
                max = arr[i]
                k = i
        result[j] = max
        arr[k] = float('-inf')
        print(f"Highest numbers: {result[j]}")
        

C: 
int main () {
    int i, n;
    printf ("Enter the number of highest elements you want to extract from the array:");
    if (! scanf ("%d", & n)) {
        printf ("Enter the number of highest elements you want to extract from the array:");
    }
    double arr [5] = {12.1, 5.9, 2.9, 6.8, 20.5};
    if (n > 5)
        n = 5;
    double result [n];
    double max = 0;
    int k;
    for (int j = 0; j < n; j ++) {
        max = arr [0];
        k = 0;
        for (i = 1; i < 5; i ++) {
            if (max < arr [i]) {
                max = arr [i];
                k = i;
            }
        }
        result [j] = max;
        arr [k] = - DBL_MAX;
        printf ("Highest numbers: %g ", result [j]);
    }
    return 0;
}


Java: 
public class Main {
    public static void main(String[] args) {
        System.out.println("Enter the number of highest elements you want to extract from the array:");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        double[] arr = {12.1, 5.9, 2.9, 6.8, 20.5};
        if (n > arr.length)
            n = arr.length;
        double[] result = new double[n];
        double max = 0;
        int k;
        for (int j = 0; j < n; j++) {
            max = arr[0];
            k = 0;
            for (int i = 1; i < arr.length; i++) {
                if (max < arr[i]) {
                    max = arr[i];
                    k = i;
                }
            }
            result[j] = max;
            arr[k] = Double.MIN_VALUE;
            System.out.printf("Highest numbers: %.2f\n", result[j]);
        }
    }
}

