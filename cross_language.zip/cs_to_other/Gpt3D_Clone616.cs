#input 
public static Task < TResult > OnPropertyChanged < T, TResult > (this T target, Expression < Func < T, TResult > > propertyExpression) where T : INotifyPropertyChanged {
    var tcs = new TaskCompletionSource < TResult > ();
    PropertyChangedEventHandler handler = null;
    var member = propertyExpression.GetMemberInfo ();
    var propertyName = member.Name;
    if (member.MemberType != MemberTypes.Property)
        throw new ArgumentException (string.Format ("{0} is an invalid property expression", propertyName));
    handler = (sender, args) = > {
        if (string.Equals (args.PropertyName, propertyName, StringComparison.InvariantCultureIgnoreCase)) {
            target.PropertyChanged -= handler;
            var value = propertyExpression.Compile () (target);
            tcs.SetResult (value);
        }
    };
    target.PropertyChanged += handler;
    return tcs.Task;
}


#====================
#gpt output=============

Python: 
def on_property_changed(target, propertyExpression):
    tcs = TaskCompletionSource()
    member = propertyExpression.get_member_info()
    propertyName = member.name
    if member.member_type != MemberTypes.Property:
        raise ArgumentError(f"{propertyName} is an invalid property expression")
    
    def handler(sender, args):
        if string.equals(args.propertyName, propertyName, StringComparison.InvariantCultureIgnoreCase):
            target.property_changed -= handler
            value = propertyExpression.compile()(target)
            tcs.set_result(value)
    
    target.property_changed += handler
    return tcs.task


C: 
Task <TResult> on_property_changed(T target, Expression <Func<T, TResult>> propertyExpression)
{
    TaskCompletionSource <TResult> tcs;
    PropertyChangedEventHandler handler = NULL;

    MemberInfo * member = propertyExpression.get_member_info();
    const char * propertyName = member->name;

    if (member->MemberType != MemberTypes_Property) {
        char * error_message;
        sprintf(error_message, "%s is an invalid property expression", propertyName);
        throw ArgumentException(strdup(error_message));
    }

    handler = ^(id sender, PropertyChangedEventArgs args) {
        if (strcmp(args.propertyName, propertyName, StringComparison_InvariantCultureIgnoreCase) == 0) {
            target.PropertyChanged -= handler;
            TResult value = propertyExpression.compile()(target);
            tcs.SetResult(value);
        }
    }
    target.PropertyChanged += handler;
    return tcs.Task;
}

Java: 
public static <T, TResult> Task <TResult> onPropertyChanged (T target, Expression<Func<T, TResult>> propertyExpression) {
    TaskCompletionSource <TResult> tcs = new TaskCompletionSource<>();
    PropertyChangeEventHandler handler = null;

    MemberInfo member = propertyExpression.getMemberInfo();
    String propertyName = member.name;

    if (member.MemberType != MemberTypes.PROPERTY) {
        throw new ArgumentException(String.format("%s is an invalid property expression", propertyName));
    }

    handler = (sender, args) -> {
        if (String.equalsIgnoreCase(args.propertyName, propertyName)) {
            target.removePropertyChangeListener(handler);
            TResult value = propertyExpression.compile().apply(target);
            tcs.setResult(value);
        }
    };
    target.addPropertyChangeListener(handler);
    return tcs.task;
}

