#input 
private static void SanitizeNode (HtmlNode node) {
    if (node.NodeType == HtmlNodeType.Element) {
        if (! Whitelist.ContainsKey (node.Name)) {
            if (! DeletableNodesXpath.Contains (node.Name)) {
                node.Name = "removeableNode";
                DeletableNodesXpath.Add (node.Name);
            }
            if (node.HasChildNodes) {
                SanitizeChildren (node);
            }
            return;
        }
        if (node.HasAttributes) {
            for (int i = node.Attributes.Count - 1; i >= 0; i --) {
                HtmlAttribute currentAttribute = node.Attributes [i];
                string [] allowedAttributes = Whitelist [node.Name];
                if (allowedAttributes != null) {
                    if (! allowedAttributes.Contains (currentAttribute.Name)) {
                        node.Attributes.Remove (currentAttribute);
                    }
                } else {
                    node.Attributes.Remove (currentAttribute);
                }
            }
        }
    }
    if (node.HasChildNodes) {
        SanitizeChildren (node);
    }
}


#====================
#gpt output=============

Python Implementation:
def SanitizeNode(node):
    if (node.NodeType == HtmlNodeType.Element):
        if (not Whitelist.containsKey(node.Name)):
            if (not DeletableNodesXpath.contains(node.Name)):
                node.Name = "removeableNode"
                DeletableNodesXpath.add(node.Name)
            if (node.HasChildNodes):
                SanitizeChildren(node)
            return

        if (node.HasAttributes):
            for i in range (node.Attributes.count - 1, -1, -1):
                currentAttribute = node.Attributes[i]
                allowedAttributes = Whitelist[node.Name]
                if (allowedAttributes is not None):
                    if (not allowedAttributes.contains(currentAttribute.Name)):
                        node.Attributes.Remove(currentAttribute)
                else:
                    node.Attributes.Remove(currentAttribute)
        if (node.HasChildNodes):
            SanitizeChildren(node)

C Implementation: 
void SanitizeNode(HtmlNode *node) {
    if (node->NodeType == HtmlNodeType.Element) {
        if (! Whitelist.ContainsKey (node->Name)) {
            if (! DeletableNodesXpath.Contains (node->Name)) {
                strcpy(node->Name, "removeableNode");
                DeletableNodesXpath.Add (node->Name);
            }
            if (node->HasChildNodes) {
                SanitizeChildren(node);
            }
            return;
        }
        if (node->HasAttributes) {
            for (int i = node->Attributes.Count - 1; i >= 0; i --) {
                HtmlAttribute *currentAttribute = node->Attributes[i];
                String *allowedAttributes = Whitelist[node->Name];
                if (allowedAttributes != NULL) {
                    if (! allowedAttributes->Contains (currentAttribute->Name)) {
                        node->Attributes.Remove (currentAttribute);
                    }
                } else {
                    node->Attributes.Remove (currentAttribute);
                }
            }
        }
    }
    if (node->HasChildNodes) {
        SanitizeChildren(node);
    }
}

Java Implementation: 
private static void SanitizeNode(HtmlNode node) {
    if (node.getNodeType() == HtmlNodeType.Element) {
        if (! Whitelist.containsKey(node.getName())) {
            if (! DeletableNodesXpath.contains(node.getName())) {
                node.setName("removeableNode");
                DeletableNodesXpath.add(node.getName());
            }
            if (node.hasChildNodes()) {
                SanitizeChildren(node);
            }
            return;
        }
        if (node.hasAttributes()) {
            for (int i = node.getAttributes().size() - 1; i >= 0; i--) {
                HtmlAttribute currentAttribute = node.getAttributes().get(i);
                String[] allowedAttributes = Whitelist.get(node.getName());
                if (allowedAttributes != null) {
                    if (! Arrays.asList(allowedAttributes).contains(currentAttribute.getName())) {
                        node.getAttributes().remove(currentAttribute);
                    }
                } else {
                    node.getAttributes().remove(currentAttribute);
                }
            }
        }
    }
    if (node.hasChildNodes()) {
        SanitizeChildren(node);
    }
}

