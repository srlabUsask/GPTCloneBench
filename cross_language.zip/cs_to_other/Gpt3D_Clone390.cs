#input 
            return "void";
        }
    } else {
        return objMethod.Type.Name;
    }
}

string ReturnType (Method m) {
    if (m.Type.Name == "IActionResult") {
        foreach (var a in m.Attributes) {
            if (a.name == "returnType") {
                string type = string.Empty;
                bool isArray = a.Value.Contains ("<");
                string formattedType = a.Value.Replace ("<", "").Replace ("><![CDATA[", "").Replace ("typeof(", "").Replace (")", "");
                string [] ar;
                ar = formattedType.Split ('.');
                type = ar [ar.Length - 1];
                if (isArray) {
                    type += "[]";
                }
                if (type == "bool") {
                    type = "boolean";
                }
                return type;
            }
        }

#====================
#gpt output=============
        return "void";
    } else {
        return m.Type.Name;
    }
}

//Python
def ReturnType(m): 
    if m.Type.Name == "IActionResult": 
        for a in m.Attributes: 
            if a.name == "returnType": 
                type = '' 
                isArray = '<' in a.Value 
                formattedType = a.Value.replace('<', '').replace('><![CDATA[', '').replace('typeof(', '').replace(')', '') 
                ar = formattedType.split('.') 
                type = ar[len(ar) - 1]
                if isArray: 
                    type += "[]" 
                if type == "bool": 
                    type = "boolean" 
                return type 
    return "void"

//C
char* ReturnType(struct Method m)
{
    if (strcmp(m.Type.Name, "IActionResult") == 0)
    {
        int numAttributes = sizeof(m.Attributes)/sizeof(m.Attributes[0]);
        
        for (int i = 0; i < numAttributes; i++)
        {
            if (strcmp(m.Attributes[i].name, "returnType") == 0)
            {
                char* type = "";
                int isArray = strstr(m.Attributes[i].Value, "<") != NULL;
                char* formattedType = strtok(m.Attributes[i].Value, "<>![CDATA[typeof()");
                char* ar[50];
                
                char* target = strtok(formattedType, ".");
                int j = 0;
                while (target != NULL)
                {
                    ar[j] = target;
                    j++;
                    target = strtok(NULL, ".");
                }
                type = ar[j - 1];
                if (isArray)
                {
                    strcat(type, "[]");
                }
                if (strcmp(type, "bool") == 0)
                {
                    strcpy(type, "boolean");
                }
                return type;
            }
        }
    }
    return "void";
}

//Java
public String ReturnType (Method m) {
    if (m.Type.Name.equals ("IActionResult")) {
        for (String a : m.Attributes) {
            if (a.name.equals ("returnType")) {
                String type = ""; 
                boolean isArray = false;
                String formattedType = a.Value.replace("<", "")
                                               .replace("><![CDATA[", "")
                                               .replace("typeof(", "")
                                               .replace(")", "");
                String[] ar = formattedType.split("\\.");
                type = ar[ar.length - 1];
                if (a.Value.contains("<")) {
                    isArray = true;
                }
                if (isArray) {
                    type += "[]";
                }
                if (type.equals("bool")) {
                    type = "boolean";
                }
                return type;
            } 
        } 
        return "void";
    } else {
        return m.Type.Name;
    } 
}

