#input 
public static void MoveFilesTo (this Folder folder, string folderUrl) {
    var ctx = (ClientContext) folder.Context;
    if (! ctx.Web.IsPropertyAvailable ("ServerRelativeUrl")) {
        ctx.Load (ctx.Web, w = > w.ServerRelativeUrl);
    }
    ctx.Load (folder, f = > f.Files, f = > f.ServerRelativeUrl, f = > f.Folders);
    ctx.ExecuteQuery ();
    EnsureFolder (ctx.Web.RootFolder, folderUrl.Replace (ctx.Web.ServerRelativeUrl, string.Empty));
    foreach (var file in folder.Files) {
        var targetFileUrl = file.ServerRelativeUrl.Replace (folder.ServerRelativeUrl, folderUrl);
        file.MoveTo (targetFileUrl, MoveOperations.Overwrite);
    }
    ctx.ExecuteQuery ();
    foreach (var subFolder in folder.Folders) {
        var targetFolderUrl = subFolder.ServerRelativeUrl.Replace (folder.ServerRelativeUrl, folderUrl);
        subFolder.MoveFilesTo (targetFolderUrl);
    }
}


#====================
#gpt output=============

Python: 
def MoveFilesTo(folder, folderUrl): 
    ctx = folder.context 
    if not ctx.web.is_property_available("ServerRelativeUrl"): 
        ctx.load(ctx.web, w = > w.ServerRelativeUrl) 

    ctx.load(folder, f = > f.Files, f = > f.ServerRelativeUrl, f = > f.Folders) 
    ctx.ExecuteQuery() 

    EnsureFolder(ctx.web.RootFolder, folderUrl.Replace(ctx.web.ServerRelativeUrl, "")) 
    for file in folder.Files: 
        targetFileUrl = file.ServerRelativeUrl.Replace(folder.ServerRelativeUrl, folderUrl) 
        file.MoveTo(targetFileUrl, MoveOperations.Overwrite) 

    ctx.ExecuteQuery() 
    for subFolder in folder.Folders: 
        targetFolderUrl = subFolder.ServerRelativeUrl.Replace(folder.ServerRelativeUrl, folderUrl) 
        subFolder.MoveFilesTo(targetFolderUrl) 

C: 
void MoveFilesTo(ClientContext ctx, Folder folder, char* folderUrl) 
{ 
    if(!ctx.Web.IsPropertyAvailable("ServerRelativeUrl")) 
    { 
        ctx.Load(ctx.Web, w = > w.ServerRelativeUrl); 
    } 
    ctx.Load(folder, f = > f.Files, f = > f.ServerRelativeUrl, f = > f.Folders); 
    ctx.ExecuteQuery(); 
    EnsureFolder(ctx.Web.RootFolder, Replace(folderUrl, ctx.Web.ServerRelativeUrl, "")); 

    for (int i = 0; i < folder.Files.Count; i ++) 
    { 
        File file = folder.Files[i]; 
        char* targetFileUrl = Replace(file.ServerRelativeUrl, folder.ServerRelativeUrl, folderUrl); 
        file.MoveTo(targetFileUrl, MoveOperations.Overwrite); 
    } 
    ctx.ExecuteQuery(); 

    for (int i = 0; i < folder.Folders.Count; i ++) 
    { 
        Folder subFolder = folder.Folders[i]; 
        char* targetFolderUrl = Replace(subFolder.ServerRelativeUrl, folder.ServerRelativeUrl, folderUrl); 
        subFolder.MoveFilesTo(targetFolderUrl); 
    } 
} 

Java: 
public static void moveFilesTo(Folder folder, String folderUrl) { 
    ClientContext ctx = (ClientContext) folder.getContext() 
    if (!ctx.getWeb().isPropertyAvailable("ServerRelativeUrl")) { 
        ctx.load(ctx.getWeb(), w -> w.getServerRelativeUrl()); 
    } 
    ctx.load(folder, f -> f.getFiles(), f -> f.getServerRelativeUrl(), f -> f.getFolders()); 
    ctx.executeQuery(); 
    ensureFolder(ctx.getWeb().getRootFolder(), folderUrl.replace(ctx.getWeb().getServerRelativeUrl(), "")); 
    for (File file : folder.getFiles()) { 
        String targetFileUrl = file.getServerRelativeUrl().replace(folder.getServerRelativeUrl(), folderUrl); 
        file.moveTo(targetFileUrl, MoveOperations.OVERWRITE); 
    } 
    ctx.executeQuery(); 
    for (Folder subFolder : folder.getFolders()) { 
        String targetFolderUrl = subFolder.getServerRelativeUrl().replace(folder.getServerRelativeUrl(), folderUrl); 
        subFolder.moveFilesTo(targetFolderUrl); 
    } 
}

