#input 
public static string GetAllMessages (this Exception ex) {
    if (ex == null)
        throw new ArgumentNullException ("ex");
    StringBuilder sb = new StringBuilder ();
    while (ex != null) {
        if (! string.IsNullOrEmpty (ex.Message)) {
            if (sb.Length > 0)
                sb.Append (" ");
            sb.Append (ex.Message);
        }
        ex = ex.InnerException;
    }
    return sb.ToString ();
}


#====================
#gpt output=============

Python Implementation:
def get_all_messages(ex):
    if(ex is None):
        raise Exception("Exception is null")
    message_string = ""
    while (ex is not None):
        if not ex.Message is None or len(ex.Message)>0:
            if (len(message_string)>0):
                message_string += " "
            message_string += ex.Message
        ex = ex.InnerException
    return message_string

C Implementation:
char* get_all_messages(Exception* ex)
{
    if (ex == NULL)
        throw new ArgumentNullException("ex");

    char* msg_str;
    int len = 0;
    while (ex != NULL)
    {
        if (ex->Message != NULL && strlen(ex->Message) > 0)
        {
            if (len > 0)
            {
                msg_str = (char*)realloc(msg_str, sizeof(char) * (len + 1));
                strcat(msg_str, " ");
             }
            else
            {
                msg_str = (char*)calloc(ex->Message, sizeof(char));
            }
            strcat(msg_str, ex->Message);
            len += strlen(ex->Message);
        }
        ex = ex->InnerException;
    }
    return msg_str;
}

Java Implementation:
public static String getAllMessages(Exception ex) {
        if (ex == null) {
            throw new ArgumentNullException("ex");
        }

        StringBuilder sb = new StringBuilder();
        while (ex !=null) {
            if (ex.getMessage() != null && !ex.getMessage().isEmpty()) {
                if (sb.length() > 0) {
                    sb.append(" ");
                }
                sb.append(ex.getMessage());
            }
            ex = ex.getInnerException();
        }

        return sb.toString();
    }

