#input 
public static void Main () {
    var raiser = new EventRaiser ();
    var handler = new Handler ();
    string eventName = "SomethingHappened";
    var eventinfo = raiser.GetType ().GetEvent (eventName);
    eventinfo.AddEventHandler (raiser, EventProxy.Create (eventinfo, handler.HandleEvent));
    string eventName2 = "SomethingHappenedWithArg";
    var eventInfo2 = raiser.GetType ().GetEvent (eventName2);
    eventInfo2.AddEventHandler (raiser, EventProxy.Create < int > (eventInfo2, handler.HandleEventWithArg));
    eventinfo.AddEventHandler (raiser, EventProxy.Create (eventinfo, () = > Console.WriteLine ("!")));
    eventInfo2.AddEventHandler (raiser, EventProxy.Create < int > (eventInfo2, i = > Console.WriteLine (i + "!")));
    raiser.RaiseEvents ();
}


#====================
#gpt output=============

// Python implementation
class EventRaiser:
    def __init__(self):
        self.events = []
 
    def GetType(self):
        return self
 
    def GetEvent(self, event_name):
        if event_name not in self.events:
            self.events.append(event_name)
        return event_name
    
    def RaiseEvents(self):
        for event_name in self.events:
            getattr(self, event_name)()
 
    def HandleEvent(self):
        print("!")
 
    def HandleEventWithArg(self, arg):
        print(arg, "!")
 
    def SomethingHappened(self):
        pass
 
    def SomethingHappenedWithArg(self, arg):
        pass
    
class EventProxy:
    @staticmethod
    def Create(event_info, handle_func):
        return (event_info, handle_func)
 
    @staticmethod
    def CreateWithArg(event_info, handle_func):
        return (event_info, handle_func)
 
def main():
    raiser = EventRaiser()
    handler = EventRaiser()
 
    event_name = "SomethingHappened"
    event_info = raiser.GetType().GetEvent(event_name)
    event_info.AddEventHandler(raiser, EventProxy.Create(event_info, handler.HandleEvent))
 
    event_name2 = "SomethingHappenedWithArg"
    event_info2 = raiser.GetType().GetEvent(event_name2)
    event_info2.AddEventHandler(raiser, EventProxy.CreateWithArg(event_info2, handler.HandleEventWithArg))
    event_info.AddEventHandler(raiser, EventProxy.Create(event_info, lambda: print("!")))
    event_info2.AddEventHandler(raiser, EventProxy.CreateWithArg(event_info2, lambda i: print(i, "!")))
 
    raiser.RaiseEvents()

if __name__ == "__main__":
    main()

    
// C implementation
#include<stdio.h>
#include<string.h>

typedef struct EventRaiser {
    int events[100];
    int num_events;
} EventRaiser;
 
void HandleEvent(EventRaiser* er) {
    printf("!");
}
 
void HandleEvent2(EventRaiser* er, int arg) {
    printf("%d!", arg);
}
 
void EventProxyCreate(EventRaiser* er, void(*handle_func)(EventRaiser*)) {
    if (er->num_events >= 100) {
        return;
    }
    er->events[er->num_events++] = (int)handle_func;
}
 
void EventProxyCreate2(EventRaiser* er, void(*handle_func2)(EventRaiser*, int)) {
    if (er->num_events >= 100) {
        return;
    }
    er->events[er->num_events++] = (int)handle_func2;
}
 
void SomethingHappened(EventRaiser* er) {
 
}
 
void SomethingHappenedWithArgs(EventRaiser* er, int arg) {
 
}
 
void EventRaiserRaiseEvents(EventRaiser* er) {
    for(int i = 0; i < er->num_events; i++) {
        int handle_func = er->events[i];
        void(*handle_func_ptr)(EventRaiser*) = (void(*)(EventRaiser*))handle_func;
        if (handle_func_ptr != NULL) {
            handle_func_ptr(er);
        }
    }
}

int main()
{
    EventRaiser er;
    er.num_events = 0;
    EventProxyCreate(&er, HandleEvent);
    EventProxyCreate2(&er, HandleEvent2);
    EventProxyCreate(&er, (void(*)(EventRaiser*))printf("!"));
    EventProxyCreate2(&er, (void(*)(EventRaiser*, int))printf);
    EventRaiserRaiseEvents(&er);
    return 0;
}


// Java implementation
public class Events {
    public static class EventRaiser {
        private List<Event<?>> events;
 
        public EventRaiser() {
            this.events = new ArrayList<>();
        }
 
        public Class<?> getType() {
            return this.getClass();
        }
 
        public Event<?> getEvent(String eventName) {
            Event<?> event = new Event<>(eventName);
            this.events.add(event);
            return event;
        }
 
        public void raiseEvents() {
            for (Event<?> event : this.events) {
                event.raise();
            }
        }
         
        public void somethingHappened() {
        }
         
        public void somethingHappenedWithArg(int arg) {
        }
    }
 
    public static class Handler {
        public void handleEvent() {
            System.out.println("!");
        } 
 
        public void handleEventWithArg(int arg) {
            System.out.println(arg + "!");
        }
    }
 
    public static class EventProxy {
        public static <T> void create(Event<?> eventInfo, Consumer<T> handleFunc) {
            handleFunc.accept((T)eventInfo);
        }
    }
    
    public static class Event<T> {
        private String eventName;
     
        public Event(String eventName) {
            this.eventName = eventName;
        }
         
        public void addEventHandler(EventRaiser raiser, Consumer<Event<?>> proxy) {
            proxy.accept(this);
        }
         
        public void raise() {
            switch (this.eventName) {
                case "SomethingHappened":
                    EventRaiser.somethingHappened();
                    break;
                case "SomethingHappenedWithArg":
                    EventRaiser.somethingHappenedWithArg(1);
                    break;
            }
        }
    }
}
 
public class Main {
    public static void main(String[] args) {
        Events.EventRaiser raiser = new Events.EventRaiser();
        Events.Handler handler = new Events.Handler();
        String eventName = "SomethingHappened";
        Events.Event<?> eventinfo = raiser.getEvent(eventName);
        eventinfo.addEventHandler(raiser, EventProxy.create(eventinfo, handler::handleEvent));
        String eventName2 = "SomethingHappenedWithArg";
        Events.Event<?> eventInfo2 = raiser.getEvent(eventName2);
        eventInfo2.addEventHandler(raiser, EventProxy.create(eventInfo2, handler::handleEventWithArg));
        eventinfo.addEventHandler(raiser, EventProxy.create(eventinfo, () -> System.out.println("!")));
        eventInfo2.addEventHandler(raiser, EventProxy.create(eventInfo2, i -> System.out.println(i + "!")));
        raiser.raiseEvents();
    }
}

