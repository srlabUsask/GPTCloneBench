#input 
static void Main (string [] args) {
    Stopwatch sw = new Stopwatch ();
    const int NUM_ITEMS = 10000;
    const int NUM_LOOPS2 = 1000000000;
    List < int > lst = new List < int > (NUM_ITEMS);
    IList < int > ilst = lst;
    for (int i = 0; i < NUM_ITEMS; i ++) {
        lst.Add (i);
    }
    int count = 0;
    sw.Reset ();
    sw.Start ();
    for (int i = 0; i < NUM_LOOPS2; i ++) {
        count = lst.Count;
    }
    sw.Stop ();
    Console.Out.WriteLine ("Took " + (sw.ElapsedMilliseconds) + "ms - 1.");
    sw.Reset ();
    sw.Start ();
    for (int i = 0; i < NUM_LOOPS2; i ++) {
        count = ilst.Count;
    }
    sw.Stop ();
    Console.Out.WriteLine ("Took " + (sw.ElapsedMilliseconds) + "ms - 2.");
}


#====================
#gpt output=============

Python:
import time

NUM_ITEMS = 10000
NUM_LOOPS2 = 1000000000

lst = [i for i in range(NUM_ITEMS)]
ilst = lst

start1 = time.perf_counter()
for i in range(NUM_LOOPS2):
    count = len(lst)

end1 = time.perf_counter()
print(f"Took {start1-end1}s - 1.")

start2 = time.perf_counter()
for i in range(NUM_LOOPS2):
    count = len(ilst)

end2 = time.perf_counter()
print(f"Took {start2-end2}s - 2.")


Java:
public class Stopwatch {
    private long start;

    public Stopwatch() {
        start = System.currentTimeMillis();
    }

    public void start() {
        start = System.currentTimeMillis();
    }

    public long elapsedMilliseconds() {
        return System.currentTimeMillis() - start;
    }
  }
  
public static void main (String[] args) {
    Stopwatch sw = new Stopwatch ();
    final int NUM_ITEMS = 10000;
    final int NUM_LOOPS2 = 1000000000;
    List<Integer> lst = new ArrayList<>(NUM_ITEMS);
    List<Integer> ilst = lst;
    for (int i = 0; i < NUM_ITEMS; i++) {
        lst.add(i);
    }
    int count = 0;
    sw.start();
    for (int i = 0; i < NUM_LOOPS2; i++) {
        count = lst.size();
    }
    System.out.println("Took " + (sw.elapsedMilliseconds()) + "ms - 1.");
    sw.start();
    for (int i = 0; i < NUM_LOOPS2; i++) {
        count = ilst.size();
    }
    System.out.println("Took " + (sw.elapsedMilliseconds()) + "ms - 2.");
  }

C : 
#include <stdio.h>
#include <time.h>

#define NUM_ITEMS 10000
#define NUM_LOOPS2 1000000000

int main (int argc, char *argv[]) {
    time_t start1, start2, end1, end2;
    int lst[NUM_ITEMS], ilst[NUM_ITEMS], count;

    for (int i=0; i<NUM_ITEMS; ++i) {
        lst[i] = i;
        ilst[i] = i;
    }

    start1 = time(0);
    for (int i=0; i<NUM_LOOPS2; ++i) {
        count = sizeof(lst) / sizeof(lst[0]);
    }
    end1 = time(0);
    printf("Took %.fms - 1.", difftime(end1, start1));

    start2 = time(0);
    for (int i=0; i<NUM_LOOPS2; ++i) {
        count = sizeof(ilst) / sizeof(ilst[0]);
    }
    end2 = time(0);
    printf("Took %.fms - 2.", difftime(end2, start2));

    return 0;
}

