#input 
private void next_item () {
    if (scrip_index < script_list.Count () - 1) {
        scrip_index ++;
        switch (script_list [scrip_index].action) {
            case "Load" :
                mediaElement1.LoadedBehavior = System.Windows.Controls.MediaState.Manual;
                mediaElement1.UnloadedBehavior = System.Windows.Controls.MediaState.Manual;
                if (mediaElement1.Source != new Uri (script_list [scrip_index].filename))
                    mediaElement1.Source = new Uri (script_list [scrip_index].filename);
                mediaElement1.ScrubbingEnabled = true;
                playing = false;
                next_item ();
                break;
            case "Play" :
                mediaElement1.Play ();
                playing = true;
                if (! test_position.IsBusy)
                    test_position.RunWorkerAsync ();
                break;
            case "Pause" :
                mediaElement1.Pause ();
                playing = false;
                break;
            case "Seek" :
                mediaElement1.Position = script_list [scrip_index].start_time;
                playing = true;
                break;
            case "Stop" :
                mediaElement1.Stop ();
                playing = false;
                break;
        }
    }
}


#====================
#gpt output=============

Python:

def next_item():
    if scrip_index < len(script_list) - 1:
        scrip_index += 1
        if script_list[scrip_index]['action'] == 'Load':
            mediaElement1.LoadedBehavior = 'System.Windows.Controls.MediaState.Manual'
            mediaElement1.UnloadedBehavior = 'System.Windows.Controls.MediaState.Manual'
            if mediaElement1.Source != script_list[scrip_index]['filename']:
                mediaElement1.Source = script_list[scrip_index]['filename']
            mediaElement1.ScrubbingEnabled = True
            playing = False
            next_item()
        elif script_list[scrip_index]['action'] == 'Play':
            mediaElement1.Play()
            playing = True
            if 'test_position' not in locals():
                test_position.run()
        elif script_list[scrip_index]['action'] == 'Pause':
            mediaElement1.Pause()
            playing = False
        elif script_list[scrip_index]['action'] == 'Seek':
            mediaElement1.Position = script_list[scrip_index]['start_time']
            playing = True
        elif script_list[scrip_index]['action'] == 'Stop':
            mediaElement1.Stop()
            playing = False

C:

void next_item() {
  if (scrip_index < script_list.size - 1) {
    scrip_index ++;
    char* action = script_list[scrip_index].action;
    if (strcmp(action, "Load") == 0) {
        mediaElement1.LoadedBehavior = SYSTEM_WINDOWS_CONTROLS_MEDIASTATE_MANUAL;
        mediaElement1.UnloadedBehavior = SYSTEM_WINDOWS_CONTROLS_MEDIASTATE_MANUAL;
        if (mediaElement1.Source != script_list[scrip_index].filename)
            mediaElement1.Source = script_list[scrip_index].filename;
        mediaElement1.ScrubbingEnabled = true;
        playing = false;
        next_item();
    } else if (strcmp(action, "Play") == 0 ) {
        mediaElement1.Play();
        playing = true;
        if (!test_position.IsBusy) 
            test_position.RunWorkerAsync();
    } else if (strcmp(action, "Pause") == 0) {
        mediaElement1.Pause();
        playing = false;
    } else if (strcmp(action, "Seek") == 0) {
        mediaElement1.Position = script_list[scrip_index].start_time;
        playing = true;
    } else if (strcmp(action, "Stop") == 0) {
        mediaElement1.Stop();
        playing = false;
    }
  }
}

Java:

private void next_item() {
    if (scrip_index < script_list.size() - 1) {
        scrip_index ++;
        String action = script_list.get(scrip_index).action;
        switch (action) {
            case "Load":
                mediaElement1.setLoadedBehavior(System.Windows.Controls.MediaState.Manual);
                mediaElement1.setUnloadedBehavior(System.Windows.Controls.MediaState.Manual);
                if (!mediaElement1.getSource().equals(script_list.get(scrip_index).filename))
                    mediaElement1.setSource(script_list.get(scrip_index).filename);
                mediaElement1.setScrubbingEnabled(true);
                playing = false;
                next_item();
                break;
            case "Play":
                mediaElement1.play();
                playing = true;
                if (!test_position.IsBusy()) 
                    test_position.runWorkerAsync();
                break;
            case "Pause":
                mediaElement1.pause();
                playing = false;
                break;
            case "Seek":
                mediaElement1.setPosition(script_list.get(scrip_index).start_time);
                playing = true;
                break;
            case "Stop":
                mediaElement1.stop();
                playing = false;
                break;
        }
    }
}

