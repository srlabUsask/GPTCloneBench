#input 
public static string GetAbsoluteUrl (string relativeUrl) {
    if (String.IsNullOrEmpty (relativeUrl))
        return String.Empty;
    if (relativeUrl.StartsWith ("http://", StringComparison.OrdinalIgnoreCase) || relativeUrl.StartsWith ("https://", StringComparison.OrdinalIgnoreCase))
        return relativeUrl;
    if (HttpContext.Current == null)
        return relativeUrl;
    HttpContext context = HttpContext.Current;
    if (relativeUrl.StartsWith ("/"))
        relativeUrl = relativeUrl.Insert (0, "~");
    Page page = context.Handler as Page;
    if (page != null) {
        relativeUrl = page.ResolveUrl (relativeUrl);
    } else {
        if (! relativeUrl.StartsWith ("~/"))
            relativeUrl = relativeUrl.Insert (0, "~/");
        relativeUrl = VirtualPathUtility.ToAbsolute (relativeUrl);
    }
    var url = context.Request.Url;
    var port = url.Port != 80 ? (":" + url.Port) : String.Empty;
    return String.Format ("{0}://{1}{2}{3}", url.Scheme, url.Host, port, relativeUrl);
}


#====================
#gpt output=============

Python: 
def get_absolute_url(relative_url): 
    if not relative_url or relative_url.startswith('http://') or relative_url.startswith('https://'): 
        return relative_url 
    if not 'HttpContext' in locals(): 
        return relative_url 
    from HttpContext import HttpContext 
    context = HttpContext.Current 
    if relative_url.startswith('/'): 
        relative_url = '~' + relative_url 
    if 'page' in locals(): 
        relative_url = page.ResolveUrl(relative_url) 
    elif not relative_url.startswith('~/'): 
        relative_url = '~/' + relative_url 
        relative_url = VirtualPathUtility.ToAbsolute(relative_url) 
    from HttpContext.Request import HttpRequest 
    request = HttpRequest.Current 
    port = ':' + request.Url.Port if request.Url.Port != 80 else '' 
    return '{0}://{1}{2}{3}'.format(request.Url.Scheme, request.Url.Host, port, relative_url)



C: 
char* get_absolute_url(char* relativeUrl) {
    if (strlen(relativeUrl) == 0) {
        return "";
    }

    if (strstr(relativeUrl, "http://") || strstr(relativeUrl, "https://")) {
        return relativeUrl;
    }

    if (HttpContext.Current == NULL) {
        return relativeUrl;
    }

    HttpContext* context = HttpContext.Current;
    if (relativeUrl == '/') {
        int len = strlen("~") + strlen(relativeUrl) + 1;
        char* res = malloc(len * sizeof(char));
        memcpy(res, "~", strlen("~"));
        strcat(res, relativeUrl);
        relativeUrl = res;
    }

    Page* page = context->Handler as Page;
    if (page != NULL) {
        relativeUrl = page->ResolveUrl(relativeUrl);
    }
    else {
        if (!strstr(relativeUrl, "~/")) {
            int len = strlen("~/") + strlen(relativeUrl) + 1;
            char* res = malloc(len * sizeof(char));
            memcpy(res, "~/", strlen("~/"));
            strcat(res, relativeUrl);
            relativeUrl = VirtualPathUtility.ToAbsolute(relativeUrl);
        }
    }

    char* port = HttpContext.Current->Request->Url->Port != 80 ? : (":" + HttpContext.Current->Request->Url->Port);
    char* url = malloc(strlen(HttpContext.Current->Request->Url->Scheme) +
        strlen(HttpContext.Current->Request->Url->Host) +
        strlen(port) +
        strlen(relativeUrl) + 1);
    strcat(url, HttpContext.Current->Request->Url->Scheme);
    strcat(url, HttpContext.Current->Request->Url->Host);
    strcat(url, port);
    strcat(url, relativeUrl);

    return url;
}



Java: 
public static String getAbsoluteUrl(String relativeUrl) {
        if (relativeUrl == null || relativeUrl.equals("")) {
            return "";
        }

        if (relativeUrl.startsWith("http://") || relativeUrl.startsWith("https://")) {
            return relativeUrl;
        }

        if (HttpContext.getCurrent() == null) {
            return relativeUrl;
        }

        HttpContext context = HttpContext.getCurrent();
        if (relativeUrl.startsWith("/")) {
            relativeUrl = "~" + relativeUrl;
        }

        if (context.getHandler() instanceof Page) {
            relativeUrl = ((Page) context.getHandler()).resolveUrl(relativeUrl);
        } else {
            if (!relativeUrl.startsWith("~/")) {
                relativeUrl = "~/" + relativeUrl;
            }
            relativeUrl = VirtualPathUtility.toAbsolute(relativeUrl);
        }

        int port = context.getRequest().getUrl().getPort() != 80 ? (":" + context.getRequest().getUrl().getPort()) : "";
        return String.format("%s://%s%s%s", context.getRequest().getUrl().getScheme(),
                context.getRequest().getUrl().getHost(), port, relativeUrl);
    }

