#input 
public static void Main (string [] args) {
    Test.checkInt (1);
    Test.checkMax (1);
    Test.checkMin (1);
    Test.checkInt (10);
    Test.checkMax (10);
    Test.checkMin (10);
    Test.checkInt (20);
    Test.checkMax (20);
    Test.checkMin (20);
    Test.checkInt (30);
    Test.checkMax (30);
    Test.checkMin (30);
    Test.checkInt (254);
    Test.checkMax (254);
    Test.checkMin (254);
    Test.checkInt (255);
    Test.checkMax (255);
    Test.checkMin (255);
    Test.checkInt (256);
    Test.checkMax (256);
    Test.checkMin (256);
}


#====================
#gpt output=============

//Python

def main(args):
    Test.checkInt(1)
    Test.checkMax(1)
    Test.checkMin(1)
    Test.checkInt(10)
    Test.checkMax(10)
    Test.checkMin(10)
    Test.checkInt(20)
    Test.checkMax(20)
    Test.checkMin(20)
    Test.checkInt(30)
    Test.checkMax(30)
    Test.checkMin(30)
    Test.checkInt(254)
    Test.checkMax(254)
    Test.checkMin(254)
    Test.checkInt(255)
    Test.checkMax(255)
    Test.checkMin(255)
    Test.checkInt(256)
    Test.checkMax(256)
    Test.checkMin(256)

#C

int main(int argc, char *argv[]) 
{ 
    Test_checkInt(1); 
    Test_checkMax(1); 
    Test_checkMin(1); 
    Test_checkInt(10); 
    Test_checkMax(10); 
    Test_checkMin(10); 
    Test_checkInt(20); 
    Test_checkMax(20); 
    Test_checkMin(20); 
    Test_checkInt(30); 
    Test_checkMax(30); 
    Test_checkMin(30); 
    Test_checkInt(254); 
    Test_checkMax(254); 
    Test_checkMin(254); 
    Test_checkInt(255); 
    Test_checkMax(255); 
    Test_checkMin(255); 
    Test_checkInt(256); 
    Test_checkMax(256); 
    Test_checkMin(256); 
   
    return 0; 
} 

//Java

public static void main(String[] args) {
    Test.checkInt(1);
    Test.checkMax(1);
    Test.checkMin(1);
    Test.checkInt(10);
    Test.checkMax(10);
    Test.checkMin(10);
    Test.checkInt(20);
    Test.checkMax(20);
    Test.checkMin(20);
    Test.checkInt(30);
    Test.checkMax(30);
    Test.checkMin(30);
    Test.checkInt(254);
    Test.checkMax(254);
    Test.checkMin(254);
    Test.checkInt(255);
    Test.checkMax(255);
    Test.checkMin(255);
    Test.checkInt(256);
    Test.checkMax(256);
    Test.checkMin(256);
}

