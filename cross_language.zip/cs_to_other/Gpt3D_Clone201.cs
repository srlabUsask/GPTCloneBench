#input 
public bool Equality (byte [] a1, byte [] b1) {
    if (a1.Length != b1.Length) {
        return false;
    }
    if (object.ReferenceEquals (a1, b1)) {
        return true;
    }
    for (int i = 0; i < a1.Length; i ++) {
        if (a1 [i] != b1 [i]) {
            return false;
        }
    }
    return true;
}


#====================
#gpt output=============


//Python
def Equality (a1, b1): 
    if len(a1) != len(b1): 
        return False
    if a1 is b1: 
        return True
    for i in range(len(a1)): 
        if a1[i] != b1[i]: 
            return False
    return True


//C
bool Equality (byte a1[], byte b1[]) {
    if (sizeof(a1) != sizeof(b1)) {
        return false;
    }
    if (&a1 == &b1) {
        return true;
    }
    for (int i = 0; i < sizeof(a1); i++) {
        if (a1[i] != b1[i]) {
            return false;
        }
    }
    return true;
}


//Java
public boolean Equality (byte[] a1, byte[] b1) {
    if (a1.length != b1.length) {
        return false;
    }
    if (Objects.equals(a1, b1)) {
        return true;
    }
    for (int i = 0; i < a1.length; i++) {
        if (a1[i] != b1[i]) {
            return false;
        }
    }
    return true;
}

