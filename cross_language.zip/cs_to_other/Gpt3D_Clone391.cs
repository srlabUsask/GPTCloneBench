#input 
static void Main () {
    List < string > keys = new List < string > {"REPORTMONTH", "CONTRACT", "DATE", "AMOUNT", "CONTRACT", "DATE", "AMOUNT"};
    List < string > values = new List < string > {"01", "ABC123", "01022014", "300.00", "DEF345", "03042014", "400.00"};
    var combined = Enumerable.Zip (keys, values, (key, value) = > new {Key = key, Value = value}).ToLookup (entry = > entry.Key);
    var dicts = new [] {new Dictionary < string, string > (), new Dictionary < string, string > ()};
    foreach (var items in combined) {
        int count = 0;
        string lastKey = null;
        foreach (var item in items.Take (2)) {
            dicts [count ++] [item.Key] = item.Value;
            lastKey = item.Key;
        }
        if (count == 1)
            dicts [1] [lastKey] = dicts [0] [lastKey];
    }
    dump ("1st dictionary", dicts [0]);
    dump ("2nd dictionary", dicts [1]);
}


#====================
#gpt output=============

Python: 
def main(): 
    keys = ["REPORTMONTH", "CONTRACT", "DATE", "AMOUNT", "CONTRACT", "DATE", "AMOUNT"] 
    values = ["01", "ABC123", "01022014", "300.00", "DEF345", "03042014", "400.00"] 
    combined = zip(keys, values) 
    dicts = [{}, {}] 
    last_key = None 

    for pair in combined: 
        count = 0 
        key, value = pair[0], pair[1] 
        dicts[count][key] = value 
        count += 1 
        last_key = key 
    
    if count == 1: 
        dicts[1][last_key] = dicts[0][last_key] 

    dump("1st dictionary", dicts[0]) 
    dump("2nd dictionary", dicts[1]) 

C:
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_LEN 200

struct kv_pair {
    char *key;
    char *value;
};

void dump(char *title, struct kv_pair *dict) {
    printf("\n%s: \n", title);
    int len = 0;
    while (dict[len].key[0] != '\0') {
        printf("Key: %s  Value: %s\n", dict[len].key, dict[len].value);
        len++;
    }
}

int main() {
    char keys[6][MAX_LEN] = {"REPORTMONTH", "CONTRACT", "DATE", "AMOUNT", "CONTRACT", "DATE", "AMOUNT"};
    char values[7][MAX_LEN] = {"01", "ABC123", "01022014", "300.00", "DEF345", "03042014", "400.00"};
    int len = 0;
    int klen = sizeof(keys) / MAX_LEN;
    int vlen = sizeof(values) / MAX_LEN;
    
    int i;
    for (i = 0; i < vlen - 1; i += 2) {
        len++;
    }

    struct kv_pair *dict[2];
    for (i = 0; i < 2; ++i) {
        dict[i] = (struct kv_pair*)malloc(len*sizeof(struct kv_pair));
    }

    int j = 0;
    int k = 0;
    for (i = 0; i < len; ++i) {
      strcpy(dict[0][i].key, keys[j]);
      strcpy(dict[1][i].key, keys[j + 1]);

      strcpy(dict[0][i].value, values[k]);
      strcpy(dict[1][i].value, values[k + 1]);

      j += 2;
      k += 2;
    }

    dict[1][len - 1].key[0] = '\0'; 

    dump("1st dictionary", dict[0]);
    dump("2nd dictionary", dict[1]);

    free(dict[0]); 
    free(dict[1]); 
    return 0;
}

Java:
public static void main() {
		List<String> keys = Arrays.asList("REPORTMONTH", "CONTRACT", "DATE", "AMOUNT", "CONTRACT", "DATE", "AMOUNT");
		List<String> values = Arrays.asList("01", "ABC123", "01022014", "300.00", "DEF345", "03042014", "400.00");

		Map<String, String>[] dicts = new HashMap[2];
		dicts[0] = new HashMap<>();
		dicts[1] = new HashMap<>();

		for (int i = 0; i < keys.size() - 1; i += 2) {
			dicts[0].put(keys.get(i), values.get(i));
			dicts[1].put(keys.get(i), values.get(i));
			
			dicts[0].put(keys.get(i + 1), values.get(i + 1));	
			dicts[1].put(keys.get(i + 1), values.get(i + 1));
		}
		
		dump("1st dictionary", dicts[0]);
		dump("2nd dictionary", dicts[1]);
	}
	
	public static void dump(String title, Map<String, String> dict) {
		System.out.println(title + ":");
		
		for (Map.Entry<String, String> entry : dict.entrySet()) {
			System.out.println("Key: " + entry.getKey() + "  Value: " + entry.getValue());
		}
	}

