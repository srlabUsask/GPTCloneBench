#input 
internal static void RunScriptFile (SqlConnection conn, string fileName) {
    long fileSize = 0;
    using (FileStream stream = File.OpenRead (fileName))
    {
        fileSize = stream.Length;
        using (StreamReader reader = new StreamReader (stream))
        {
            StringBuilder sb = new StringBuilder ();
            string line = string.Empty;
            while (! reader.EndOfStream) {
                line = reader.ReadLine ();
                if (string.Compare (line.Trim (), "GO", StringComparison.InvariantCultureIgnoreCase) == 0) {
                    RunCommand (conn, sb.ToString ());
                    sb.Length = 0;
                } else {
                    sb.AppendLine (line);
                }
            }
        }}}


#====================
#gpt output=============

Python implementation:

def run_script_file(conn, file_name): 
    file_size = 0
    with open(file_name, 'r') as stream: 
        file_size = len(stream.read())
        with open(file_name, 'r') as reader:
            script = ""
            line = ""
            while not reader.closed: 
                line = reader.readline()
                if line.strip().upper() == 'GO': 
                    run_command(conn, script)
                    script = ""
                else: 
                    script += line

C implementation: 

void RunScriptFile(SqlConnection conn, char *fileName)
{
    long fileSize = 0; 
    FILE *stream = fopen(fileName, "r");
    if (stream) 
    {
        fseek(stream, 0, SEEK_END);
        fileSize = ftell(stream); 
        rewind(stream); 

        char *line = malloc(fileSize * sizeof(char));
        char *script = calloc(1, sizeof(char));

        while (fgets(line, fileSize, stream)) 
        {
            char *cmd = strtok(line, "\n");  
           
            if (strcmp(cmd, "GO") == 0 || strcmp(cmd, "go") == 0) 
            {
                RunCommand(conn, script);
                script[0] = '\0';
            } 
            else 
            {
                script = strcat(script, line);
            }
        }

        free(script);
        free(line);
    }
    fclose(stream);
}

Java implementation:

public static void runScriptFile(SqlConnection conn, String fileName) 
{
    long fileSize = 0;
    try (FileInputStream stream = new FileInputStream(fileName)) {
        fileSize = stream.getChannel().size();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream))) {
            StringBuilder sb = new StringBuilder();
            String line = "";
            while((line = reader.readLine()) != null) {
                if(line.trim().equalsIgnoreCase("GO")) {
                    runCommand(conn, sb.toString());
                    sb = new StringBuilder();
                } else {
                    sb.append(line);
                    sb.append("\n");
                }
            }
        } catch(IOException e) {
            e.printStackTrace();
        }
    } catch(IOException e) {
        e.printStackTrace();
    }
}

