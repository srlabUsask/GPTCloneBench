#input 
public static void WriteMessage (string message) {
    var path = @"../../sth.txt";
    if (File.Exists (path)) {
        string [] lines = File.ReadAllLines (path);
        using (var writer = new StreamWriter (path, true))
        {
            if (lines.Length > 0) {
                writer.WriteLine ("Another Line Added - " + message);
            } else {
                writer.WriteLine (message);
            }
            writer.Flush ();
        }} else {
        using (StreamWriter writer = new StreamWriter (path))
        {
            writer.WriteLine (message);
            writer.Flush ();
        }}
}


#====================
#gpt output=============

//Python
def write_message(message):
    path = '../../sth.txt'
    if os.path.isfile(path):
        with open(path, 'r+') as f:
            lines = f.readlines()
            if len(lines) > 0:
                f.write("Another Line Added - " + message + '\n')
            else:
                f.write(message + '\n')
    else:
        with open(path, 'w+') as f:
            f.write(message + '\n')

//C
void WriteMessage (const char * message) {
    char path[] = "../../sth.txt";
    if (access(path, F_OK) != -1 ) {
        FILE *fp;
        char line[100];
        int i;

        fp = fopen(path, "r+");
        for(i=0;;i++) {
            if (fgets(line, sizeof(line), fp) != NULL) {
                if (i > 0) {
                    fputs("Another Line Added - ",fp);
                    fputs(message, fp);
                    fputs("\n", fp);
                    break;
                }
            }
            else {
                fputs(message, fp);
                fputs("\n", fp);
                break;
            }
        }
        fclose(fp);
    } else {
        FILE *fp;

        fp = fopen(path, "w+");
        fputs(message, fp);
        fputs("\n", fp);
        fclose(fp);
    }
}

//Java
public static void writeMessage(String message) {
    String path = "../../sth.txt";
    try {
        BufferedWriter writer = new BufferedWriter(new FileWriter(path, true));
        if (Files.readAllLines(Paths.get(path)).size() > 0) {
            writer.write("Another Line Added - " + message);
            writer.newLine();
        } else {
            writer.write(message);
            writer.newLine();
        }
        writer.flush();
        writer.close();
    } catch (IOException e) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(path, false));
            writer.write(message);
            writer.newLine();
            writer.flush();
            writer.close();
        }  catch (IOException e1) {
            e1.printStackTrace();
        }
    }
}

