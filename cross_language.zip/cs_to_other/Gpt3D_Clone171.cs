#input 
private void btnAdd_Click (object sender, RoutedEventArgs e) {
    string customer = btnEditCustomer1.Text;
    string piece = btnPiece.Text;
    string material = txtMaterial.Text;
    int quantity = Convert.ToInt32 (txtQuantity.Text);
    float weight = float.Parse (txtWeight.Text);
    if (customer != null && piece != null && material != null) {
        var item = new Liste {Customer = customer, Piece = piece, Material = material, Quantity = quantity, Weight = weight};
        AllItems.Add (item);
    }
}


#====================
#gpt output=============

Python: 
def btnAdd_Click(self, sender, e):
    customer = self.btnEditCustomer1.Text
    piece = self.btnPiece.Text
    material = self.txtMaterial.Text
    quantity = int(self.txtQuantity.Text)
    weight = float(self.txtWeight.Text)
    if customer != '' and piece != '' and material != '':
        item = Liste(customer, piece, material, quantity, weight)
        AllItems.append(item)

C: 
void btnAdd_Click(void* sender, RoutedEventArgs e){
    char* customer = btnEditCustomer1.Text;
    char* piece = btnPiece.Text;
    char* material = txtMaterial.Text;
    int quantity = atoi(txtQuantity.Text);
    float weight = strtof(txtWeight.Text, NULL);
    if(strcmp(customer, "") != 0 && strcmp(piece, "") != 0 && strcmp(material, "") != 0){
        Liste item;
        item.customer = customer;
        item.piece = piece;
        item.material = material;
        item.quantity = quantity;
        item.weight = weight;
        AllItems.add(item);
    }
}

Java: 
public void btnAddClick(Object sender, RoutedEventArgs e) {
    String customer = btnEditCustomer1.getText(); 
    String piece = btnPiece.getText(); 
    String material = txtMaterial.getText(); 
    int quantity = Integer.parseInt(txtQuantity.getText()); 
    float weight = Float.parseFloat(txtWeight.getText()); 
    if (customer != null && !customer.equals("") 
            && piece != null && !piece.equals("") 
            && material != null && !material.equals("")) { 
        Liste item = new Liste(customer, piece, material, quantity, weight); 
        AllItems.add(item); 
    }

}

