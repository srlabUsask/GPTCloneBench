#input 
protected void btnExport_Click (object sender, EventArgs e) {
    try {
        DataTable dt = new DataTable ("GridView_Data");
        foreach (TableCell cell in GridView1.HeaderRow.Cells) {
            dt.Columns.Add (cell.Text);
        }
        foreach (GridViewRow row in GridView1.Rows) {
            TextBox txtNameRow = (TextBox) row.FindControl ("txtName");
            Label lblCountryRow = (Label) row.FindControl ("lblCountry");
            DataRow drow = dt.NewRow ();
            for (int i = 0; i < GridView1.Columns.Count; i ++) {
                drow [i] = row.Cells [i].Text;
            }
            drow ["Name"] = txtNameRow.Text;
            drow ["Country"] = lblCountryRow.Text;
            dt.Rows.Add (drow);
        }
        using (XLWorkbook wb = new XLWorkbook ())
        {
            wb.Worksheets.Add (dt);
            Response.Clear ();
            Response.Buffer = true;
            Response.Charset = "";
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.AddHeader ("content-disposition", "attachment;filename=GV.xlsx");
            using (MemoryStream MyMemoryStream = new MemoryStream ())
            {
                wb.SaveAs (MyMemoryStream);
                MyMemoryStream.WriteTo (Response.OutputStream);
                Response.Flush ();
                Response.End ();
            }}}
    catch (Exception ex) {
        throw;
    }
}


#====================
#gpt output=============

Python:
def btnExport_Click(sender, e):
  try:
    dt = pandas.DataFrame('GridView_Data')

    for cell in GridView1.HeaderRow.Cells:
      dt.columns.add(cell.Text)

    for row in GridView1.Rows:
      txtNameRow = row.FindControl('txtName')
      lblCountryRow = row.FindControl('lblCountry')
      drow = dt.new_row()

      for i in range(0, GridView1.Columns.Count):
        drow[i] = row.Cells[i].Text

      drow['Name'] = txtNameRow.Text
      drow['Country'] = lblCountryRow.Text
      dt.Rows.Add(drow)

    export_xlsx = dt.to_excel (r'GV.xlsx', index=None, header=True)

except Exception as ex:
  print('exception is: ',ex)


C:
void btnExport_Click (object sender, EventArgs e) 
{ 
	try 
	{ 
		DataTable dt = new DataTable ("GridView_Data"); 
		foreach (TableCell cell in GridView1.HeaderRow.Cells) 
		{	 
			dt.Columns.Add (cell.Text); 
		} 
		foreach (GridViewRow row in GridView1.Rows) 
		{ 
			TextBox txtNameRow = (TextBox)row.FindControl ("txtName"); 
			Label lblCountryRow = (Label)row.FindControl ("lblCountry"); 
			DataRow drow = dt.NewRow (); 
			for (int i = 0; i < GridView1.Columns.Count; i++) 
			{ 
				drow[i] = row.Cells[i].Text; 
			} 
			drow["Name"] = txtNameRow.Text; 
			drow["Country"] = lblCountryRow.Text; 
			dt.Rows.Add (drow); 
		} 

		//Write to Excel 
		string filename = "GV.xlsx"; 
		string path = Server.MapPath ("~/Excel/" + filename); 
		if (File.Exists(path)) 
			File.Delete (path); 
		using (XLWorkbook wb = new XLWorkbook()) 
		{ 
			wb.Worksheets.Add (dt); 
			wb.SaveAs (path); 
			Response.Clear (); 
			Response.Buffer = true; 
			Response.Charset = ""; 
			Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; 
			Response.AddHeader ("content-disposition", "attachment;filename=" + filename); 
			Response.WriteFile (Server.MapPath ("~/Excel/" + filename)); 
			Response.Flush (); 
			Response.Close (); 
			Response.End (); 
		} 
	} 
	catch(Exception ex) 
	{ 
		throw; 
	} 
}

Java: 
protected void btnExport_Click (object sender, EventArgs e) {
    try {
        DataTable dt = new DataTable("GridView_Data");
        for (TableCell cell : GridView1.HeaderRow.Cells) {
            dt.Columns.add(cell.Text);
        }
        for (GridViewRow row : GridView1.Rows) {
            TextBox txtNameRow = (TextBox)row.FindControl("txtName");
            Label lblCountryRow = (Label)row.FindControl("lblCountry");  
            DataRow drow = dt.NewRow();
            for (int i = 0; i < GridView1.Columns.Count; i++) {
                drow[i] = row.Cells[i].Text;
            }
            drow["Name"] = txtNameRow.Text;
            drow["Country"] = lblCountryRow.Text;
            dt.Rows.add(drow);
        }
        try {
            HSSFWorkbook workbook = new HSSFWorkbook();
            HSSFSheet sheet = workbook.createSheet("GridView_Data");

            sheet.autoSizeColumn(0);
            sheet.autoSizeColumn(1);
            sheet.autoSizeColumn(2);
            sheet.autoSizeColumn(3);

            // Iterate over data and write to sheet
            Set < Integer > keyid = dt.keySet();
            int rowid = 0;

            for (Integer key : keyid) {
                Row row = sheet.createRow(rowid++);
                Object [] objArr = dt.get(key);
                int cellid = 0;
                for (Object obj : objArr) {
                    Cell cell = row.createCell(cellid++);
                    if (obj instanceof String)
                        cell.setCellValue((String) obj);
                    else if (obj instanceof Integer)
                        cell.setCellValue((Integer) obj);
                }
            }
            //Write the workbook in file system
            FileOutputStream out = new FileOutputStream(new File("GV.xlsx"));
            workbook.write(out);
            out.close();
            System.out.println("export.xlsx written successfully on disk.");
        } 
        catch (Exception ee) {
            ee.printStackTrace();
        }
    } 
    catch (Exception ex) {
        throw;
    }
}

