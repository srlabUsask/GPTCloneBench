#input 
static void Main (string [] args) {
    String a = "Hello ";
    String b = " World! ";
    int it = 20000;
    char [] result = new char [a.Length + it * b.Length];
    a.ToCharArray ().CopyTo (result, 0);
    for (int i = 0; i < it; i ++)
        b.ToCharArray ().CopyTo (result, a.Length + i * b.Length);
    Console.WriteLine (result);
}


#====================
#gpt output=============

Python: 
a = "Hello "
b = "World! "
it = 20000
result = [None] * (len(a) + it * len(b))

for i in range(len(a)):
    result[i] = a[i]

offset = 0
for j in range(it):
    for k in range(offset, len(b) + offset):
        result[k] = b[k - offset]
    offset += len(b)

print(''.join(result))

C: 
#include <stdio.h>
#include <string.h>
 
int main ()
{
   char a[100] = "Hello ";
   char b[100] = "World! ";
   int it = 20000;
   char result[100];
 
   int aLen = strlen(a);
   int bLen = strlen(b);
 
   for (int i = 0; i < aLen; i++)
   {
      result[i] = a[i];
   }
 
   for (int i = 0; i < it; i++)
   {
      int temp = 0;
      for (int j = 0; j < bLen; j++)
      {
         result[aLen + (bLen * i) + temp] = b[j];
         temp++;
      }
   }
   printf("%s", result);
 
   return 0;
}

Java: 
public class Main {

    public static void main(String[] args) {

        String a = "Hello ";
        String b = " World! ";
        int it = 20000;
        char[] result = new char[a.length() + it * b.length()];
        a.getChars(0, a.length(), result, 0);

        for (int i = 0; i < it; i++)
            b.getChars(0, b.length(), result, a.length() + i * b.length());

        System.out.println(result);
    }
}

