#input 
static void Main (string [] args) {
    HttpWebRequest request;
    HttpWebResponse response = null;
    StreamReader reader;
    StringBuilder sbSource;
    string uri = "https://yoursubdomain.harvestapp.com/projects";
    string username = "youremail@somewhere.com";
    string password = "yourharvestpassword";
    string usernamePassword = username + ":" + password;
    ServicePointManager.ServerCertificateValidationCallback = Validator;
    try {
        request = WebRequest.Create (uri) as HttpWebRequest;
        request.MaximumAutomaticRedirections = 1;
        request.AllowAutoRedirect = true;
        request.Accept = "application/xml";
        request.ContentType = "application/xml";
        request.UserAgent = "harvest_api_sample.cs";
        request.Headers.Add ("Authorization", "Basic " + Convert.ToBase64String (new ASCIIEncoding ().GetBytes (usernamePassword)));
        using (response = request.GetResponse () as HttpWebResponse)
        {
            if (request.HaveResponse == true && response != null) {
                reader = new StreamReader (response.GetResponseStream (), Encoding.UTF8);
                sbSource = new StringBuilder (reader.ReadToEnd ());
                Console.WriteLine (sbSource.ToString ());
            }
        }}
    catch (WebException wex) {
        if (wex.Response != null) {
            using (HttpWebResponse errorResponse = (HttpWebResponse) wex.Response)
            {
                Console.WriteLine ("The server returned '{0}' with the status code {1} ({2:d}).", errorResponse.StatusDescription, errorResponse.StatusCode, errorResponse.StatusCode);
            }} else {
            Console.WriteLine (wex);
        }
    }
    finally {
        if (response != null) {
            response.Close ();
        }
    }
}


#====================
#gpt output=============


Python: 
def main(args):
    request = None
    response = None
    reader = None
    sb_source = None
    uri = "https://yoursubdomain.harvestapp.com/projects"
    username = "youremail@somewhere.com"
    password = "yourharvestpassword"
    username_password = username + ":" + password 

    def validator(conn, cert, err, depth, certs_ok):
        return True

    try:
        request = urllib.request.Request(uri)
        request.maximum_automatics_redirects = 1
        request.allow_redirect = True
        request.accept = "application/xml"
        request.content_type = "application/xml" 
        request.user_agent = "harvest_api_sample.cs"
        request.add_header("Authorization", 'Basic ' + str.encode(username_password).hex())
        response = urllib.request.urlopen(request, context = ssl.SSLContext(ssl.PROTOCOL_TLSv1))
        reader = response.read().decode('utf-8')
        sb_source = str(reader)
        print(sb_source)
    except Exception as e:
        if response is not None: 
            print("The server returned {0} with the status code {1} ({2}).".format(response.status, response.status_code, response.status_code))
        else:
            print(e)
    finally:
        if response is not None:
            response.close() 


C: 
static void Main (char** args) {
    HttpWebRequest* request;
    HttpWebResponse* response = NULL;
    StreamReader* reader;
    StringBuilder* sbSource;
    char* uri = "https://yoursubdomain.harvestapp.com/projects";
    char* username = "youremail@somewhere.com";
    char* password = "yourharvestpassword";
    char* usernamePassword;
    ServicePointManager_ServerCertificateValidationCallback = Validator;
    int usernamePasswordLen = 0;
    int uriLen = 0;

    /* Calculate the lengths of our strings for safe malloc */
    usernamePasswordLen = strlen(username) + 1 + strlen(password) + 1;
    uriLen = strlen(uri);

    /* Setup a buffer to store username:password */
    usernamePassword = (char*)malloc(usernamePasswordLen);

    /* Concatenate username and password */
    strcpy(usernamePassword, username);
    strcat(usernamePassword, ":");
    strcat(usernamePassword, password);

    /* Create our request */
    request = WebRequest_Create(uri, uriLen) as HttpWebRequest;
    request->MaximumAutomaticRedirections = 1;
    request->AllowAutoRedirect = 1;
    request->Accept = "application/xml";
    request->ContentType = "application/xml";
    request->UserAgent = "harvest_api_sample.cs";
    request->Headers.Add ("Authorization", "Basic " + Convert_ToBase64String (usernamePassword, usernamePasswordLen));

    /* Send our request and check for valid responses */
    response = WebRequest_GetResponse(request) as HttpWebResponse;
    if(request->HaveResponse && response != NULL) {
        reader = StreamReader_Create(response->GetResponseStream(), Encoding_UTF8);
        sbSource = StringBuilder_Create(reader->ReadToEnd());

        /* Print our our string builder */
        printf("%s", sbSource);
    } else {
        /* We are here because either we didn't get a response
         * or we got an error
         */
        if(wex.Response != NULL) {
            HttpWebResponse* errorResponse = (HttpWebResponse*)wex->Response;
            printf("The server returned '%s' with the status code %d (%d).", errorResponse->StatusDescription,
                                                                            errorResponse->StatusCode,
                                                                            errorResponse->StatusCode);
        } else  {
            /* Print out the error message */
            printf("%s\n", wex);
        }
    }

    if(response != NULL) {
        HttpWebResponse_Close(response);
    }
    
    /* Free our usernamePassword buffer */
    free(usernamePassword);
}

Java: 
public static void main(String[] args){
    HttpWebRequest request;
    HttpWebResponse response = null;
    BufferedReader reader;
    StringBuilder sbSource;
    String uri = "https://yoursubdomain.harvestapp.com/projects";
    String username = "youremail@somewhere.com";
    String password = "yourharvestpassword";
    String usernamePassword = username + ":" + password;

    try {
        request = WebRequest.Create (uri) as HttpWebRequest;
        request.MaximumAutomaticRedirections = 1;
        request.AllowAutoRedirect = true;
        request.Accept = "application/xml";
        request.ContentType = "application/xml";
        request.UserAgent = "harvest_api_sample.java";
        request.Headers.Add ("Authorization", "Basic " + Base64.getEncoder().encodeToString(usernamePassword.getBytes(StandardCharsets.UTF_8)));
        response = (HttpWebResponse) request.getResponse();
        if (request.HaveResponse == true && response != null) {
            reader = new BufferedReader(new InputStreamReader(response.getInputStream(), StandardCharsets.UTF_8));
            sbSource = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sbSource.append(line);
            }
            System.out.println(sbSource.toString());
        }
    } catch (Exception e) {
        if (response != null) {
            System.out.println("The server returned "+ response.getStatus()+" with the status code "+response.getStatusCode()+".");
        } else {
            System.out.println(e.getMessage());
        }
    } finally {
        if (response != null) {
            response.close();
        }
    }
}

