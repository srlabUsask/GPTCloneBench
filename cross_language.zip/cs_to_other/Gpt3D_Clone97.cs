#input 
private ArrayList GetSameOf2AL (ArrayList first, ArrayList second) {
    ArrayList same = new ArrayList ();
    var one = from int i in first
        select i;
    var two = from int i in second
        select i;
    same.AddRange (one.Intersect (two).ToArray < int > ());
    return same;
}


#====================
#gpt output=============

Python:
def get_same_of_2al(first, second):
    same = []
    one = [i for i in first]
    two = [i for i in second]
    same.extend([i for i in set(one).intersection(two)])
    return same

C: 
ArrayList * get_same_of_2AL(ArrayList * first, ArrayList * second) {
    ArrayList * same = new_arraylist();
    int * one = malloc(sizeof(first->size));
    int * two = malloc(sizeof(second->size));

    for(int i = 0; i < first->size; i++) {
        one[i] = first->data[i];
    }
    for(int j = 0; j < second->size; j++) {
        two[j] = second->data[j];
    }

    for(int k = 0; k < first->size; k++){
        for(int l = 0; l < second->size; l++) {
            if(one[k] == two[l]) {
                arraylist_add(same, one[k]);
            }
        }
    }
    return same;
}

Java: 
public static ArrayList<Integer> getSameOf2AL(ArrayList<Integer> first, ArrayList<Integer> second) {
	ArrayList<Integer> same = new ArrayList<Integer>();
	List<Integer> one = first.stream().distinct().collect(Collectors.toList());
	List<Integer> two = second.stream().distinct().collect(Collectors.toList());
	same.addAll(one.stream().filter(two::contains).collect(Collectors.toList()));
	return same;
}

