#input 
static void Main (string [] args) {
    var ns = new List < int > ();
    for (int i = 0; i < 1000; i ++)
        ns.Add (1);
    var s1 = Stopwatch.StartNew ();
    bool result = SubsetSum (ns, 1000);
    s1.Stop ();
    Console.WriteLine (result);
    Console.WriteLine (s1.Elapsed);
    Console.Read ();
}


#====================
#gpt output=============

Python: 
def Main(args):
    ns = []
    for i in range(0, 1000):
        ns.append(1)
    s1 = time.time()
    result = SubsetSum(ns, 1000)
    s1 = time.time() - s1
    print(result)
    print(s1)
    input()

C:
int main(int argc, char *argv[]){
    int ns[1000];
    for (int i = 0; i < 1000; i ++){
        ns[i] = 1;
    }
    clock_t s1 = clock();
    int result = SubsetSum(ns, 1000);
    s1 = clock() - s1;
    printf("%d\n", result);
    printf("%f\n", (float)s1 / CLOCKS_PER_SEC);
    scanf("%d");
    return 0;
}

Java:
public static void Main (String [] args){
    List<Integer> ns = new ArrayList<Integer>();
    for (int i = 0; i < 1000; i ++)
        ns.add(1);
    long s1 = System.nanoTime();
    boolean result = SubsetSum (ns, 1000);
    s1 = System.nanoTime() - s1;
    System.out.println (result);
    System.out.println (s1);
    Scanner sc = new Scanner(System.in);
    sc.nextLine();
}

