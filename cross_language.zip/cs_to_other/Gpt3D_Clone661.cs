#input 
public static void Main () {
    var dico = new Dictionary < long, uint > ();
    for (long i = 0; i < 7500000; i ++) {
        dico.Add (i, (uint) i);
    }
    using (var stream = File.OpenWrite ("data.dat"))
    using (var writer = new BinaryWriter (stream))
    {
        foreach (var key in dico.Keys) {
            writer.Write (key);
            writer.Write (dico [key]);
        }
    } dico.Clear ();
    using (var stream = File.OpenRead ("data.dat"))
    using (var reader = new BinaryReader (stream))
    {
        while (stream.Position < stream.Length) {
            var key = reader.ReadInt64 ();
            var value = reader.ReadUInt32 ();
            dico.Add (key, value);
        }
    }}


#====================
#gpt output=============

Python: 
dico = {}
for i in range(7500000):
    dico[i] = i

with open("data.dat", "wb") as f:
    for key in dico.keys():
        f.write(key)
        f.write(dico[key])

dico.clear()

with open("data.dat", "rb") as f:
    while f.tell() < os.stat("data.dat").st_size:
        key = f.readInt64()
        value = f.readUInt32()
        dico[key] = value

C: 
#include<stdio.h>
#include<stdlib.h>

int main() 
{ 
    FILE* stream;
    stream = fopen("data.dat", "wb"); 
  
    long i;
    uint dico[7500000];
    for (i = 0; i < 7500000; i++)
    {
        dico[i] = i;
    }
  
    fwrite(&dico, sizeof(uint), 7500000, stream); 

    fclose(stream);

    stream = fopen("data.dat", "rb"); 

    long key; 
    uint value; 
    while (ftell(stream) < sizeof(uint)*7500000) { 

        fread(&key, sizeof(long), 1, stream); 
        fread(&value, sizeof(uint), 1, stream); 

        dico[key] = value; 
    } 
  
    fclose(stream); 
    return 0; 
} 

Java: 
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        HashMap<Long, Integer> dico = new HashMap<Long, Integer>();

        for (long i = 0; i < 7500000; i++) {
            dico.put(i, (int)i);
        }

        try {
            FileOutputStream stream = new FileOutputStream("data.dat");
            DataOutputStream writer = new DataOutputStream(stream);
            for (Long key : dico.keySet()) {
                writer.writeLong(key);
                writer.writeInt(dico.get(key));
            }
            dico.clear();
            FileInputStream stream2 = new FileInputStream("data.dat");
            DataInputStream reader = new DataInputStream(stream2);
            while (reader.available() > 0) {
                Long key = reader.readLong();
                Integer value = reader.readInt();
                dico.put(key, value);
            }
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}

