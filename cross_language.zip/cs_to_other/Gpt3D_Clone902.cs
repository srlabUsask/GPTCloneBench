#input 
private void PaintGradientBars (Graphics g, Rectangle r, Color startColor, Color endColor, int numBars) {
    int rMin = startColor.R;
    int gMin = startColor.G;
    int bMin = startColor.B;
    int rMax = endColor.R;
    int gMax = endColor.G;
    int bMax = endColor.B;
    int left = 0;
    for (int i = 0; i < numBars; i ++) {
        int rAvg = rMin + (int) ((rMax - rMin) * i / numBars);
        int gAvg = gMin + (int) ((gMax - gMin) * i / numBars);
        int bAvg = bMin + (int) ((bMax - bMin) * i / numBars);
        Color useColor = Color.FromArgb (rAvg, gAvg, bAvg);
        int width = (r.Width - left) / (numBars - i);
        using (SolidBrush br = new SolidBrush (useColor))
        {
            g.FillRectangle (br, new Rectangle (left, 0, width, r.Height));
        } left += width;
    }
}


#====================
#gpt output=============

Python:
def paint_gradient_bars(g, r, start_color, end_color, num_bars): 
    r_min = start_color.red 
    g_min = start_color.green 
    b_min = start_color.blue 
    r_max = end_color.red 
    g_max = end_color.green 
    b_max = end_color.blue 
    left = 0 
    for i in range (num_bars): 
        r_avg = r_min + ((r_max - r_min) * i / num_bars) 
        g_avg = g_min + ((g_max - g_min) * i / num_bars) 
        b_avg = b_min + ((b_max - b_min) * i / num_bars) 
        use_color = (r_avg, g_avg, b_avg)
        width = (r.width - left) / (num_bars - i) 
        br = Paint(use_color)
        g.fill_rectangle(br, (left, 0, width, r.height))
        left += width 

C:
void paint_gradient_bars(Graphics g, Rectangle r, Color start_color, Color end_color, int num_bars)
{
    int r_min = start_color.R;
    int g_min = start_color.G;
    int b_min = start_color.B;
    int r_max = end_color.R;
    int g_max = end_color.G;
    int b_max = end_color.B;
    int left = 0;
    for (int i = 0; i < num_bars; i++)
    {
        int r_avg = r_min + (int)((r_max - r_min) * i / num_bars);
        int g_avg = g_min + (int)((g_max - g_min) * i / num_bars);
        int b_avg = b_min + (int)((b_max - b_min) * i / num_bars);
        int r = r_avg;
        int g = g_avg;
        int b = b_avg;
        int width = (r.Width - left) / (num_bars - i);
        Color use_color = Color.FromArgb(r, g, b);
        g.FillRectangle(use_color, new Rectangle(left, 0, width, r.Height));
        left += width;
    }
}

Java: 
public void paintGradientBars(Graphics g, Rectangle r, Color startColor, Color endColor, int numBars) {
    int rMin = startColor.getRed();
    int gMin = startColor.getGreen();
    int bMin = startColor.getBlue();
    int rMax = endColor.getRed();
    int gMax = endColor.getGreen();
    int bMax = endColor.getBlue();
    int left = 0;
    for (int i = 0; i < numBars; i++) {
        int rAvg = rMin + (int) ((rMax - rMin) * i / numBars);
        int gAvg = gMin + (int) ((gMax - gMin) * i / numBars);
        int bAvg = bMin + (int) ((bMax - bMin) * i / numBars);
        Color useColor = new Color(rAvg, gAvg, bAvg);
        int width = (r.Width - left) / (numBars - i);
        g.setColor(useColor);
        g.fillRect(left, 0, width, r.Height);
        left += width;
    }
}

