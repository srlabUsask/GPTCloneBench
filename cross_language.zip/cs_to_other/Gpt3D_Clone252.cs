#input 
static void Main () {
    var persons = new PersonList ();
    for (int i = 0; i < 100000; i ++) {
        persons.Add (new Person ("P" + i.ToString (), RandomString (5, true)));
    }
    var unsortedPersons = new PersonList (persons);
    const int COUNT = 30;
    Stopwatch watch = new Stopwatch ();
    for (int i = 0; i < COUNT; i ++) {
        watch.Start ();
        Sort (persons);
        watch.Stop ();
        persons.Clear ();
        persons.AddRange (unsortedPersons);
    }
    Console.WriteLine ("Sort: {0}ms", watch.ElapsedMilliseconds);
    watch = new Stopwatch ();
    for (int i = 0; i < COUNT; i ++) {
        watch.Start ();
        OrderBy (persons);
        watch.Stop ();
        persons.Clear ();
        persons.AddRange (unsortedPersons);
    }
    Console.WriteLine ("OrderBy: {0}ms", watch.ElapsedMilliseconds);
    watch = new Stopwatch ();
    for (int i = 0; i < COUNT; i ++) {
        watch.Start ();
        OrderByWithToList (persons);
        watch.Stop ();
        persons.Clear ();
        persons.AddRange (unsortedPersons);
    }
    Console.WriteLine ("OrderByWithToList: {0}ms", watch.ElapsedMilliseconds);
}


#====================
#gpt output=============

Python Implementation:
def main():
    persons = PersonList()
    for i in range(100000):
        persons.add(Person("P" + str(i), RandomString(5, True)))
    unsortedPersons = PersonList(persons)
    COUNT = 30
    watch = Stopwatch()
    for i in range(COUNT):
        watch.start()
        sort(persons)
        watch.stop()
        persons.clear()
        persons.add_range(unsortedPersons)
    print("Sort:", watch.elapsedMilliseconds, "ms")
    watch = Stopwatch()
    for i in range (COUNT):
        watch.start()
        order_by(persons)
        watch.stop()
        persons.clear()
        persons.add_range(unsortedPersons)
    print("OrderBy:", watch.elapsedMilliseconds, "ms")
    watch = Stopwatch()
    for i in range (COUNT):
        watch.start()
        order_by_with_to_list(persons)
        watch.stop()
        persons.clear()
        persons.add_range(unsortedPersons)
    print("OrderByWithToList:" , watch.elapsedMilliseconds, "ms")

C Implementation:
void main () {
    PersonList persons = createPersonList();
    for(int i = 0; i < 100000; i++) {
        Person* person = createPerson("P" + charIntToString(i), randomString(5, true)); 
        addPerson(persons, person);
    }
    PersonList unsortedPersons = copyPersonList(persons);
    const int COUNT = 30;
    Stopwatch watch = createStopwatch();
    for(int i = 0; i < COUNT; i++) {
        startStopwatch(watch);
        sortPersonList(persons);
        stopStopwatch(watch);
        clearPersonList(persons);
        addPersonListRange(persons, unsortedPersons);
    }
    printf("Sort: %(watch.elapsedMilliseconds)ms\n", watch.elapsedMilliseconds);
    watch = createStopwatch();
    for(int i = 0; i < COUNT; i++) {
        startStopwatch(watch);
        orderByPersonList(persons);
        stopStopwatch(watch);
        clearPersonList(persons);
        addPersonListRange(persons, unsortedPersons);
    }
    printf("OrderBy: %(watch.elapsedMilliseconds)ms\n", watch.elapsedMilliseconds);
    watch = createStopwatch();
    for(int i = 0; i < COUNT; i++) {
        startStopwatch(watch);
        orderByWithToListPersonList(persons);
        stopStopwatch(watch);
        clearPersonList(persons);
        addPersonListRange(persons, unsortedPersons);
    }
    printf("OrderByWithToList: %(watch.elapsedMilliseconds)ms\n", watch.elapsedMilliseconds);
}

Java Implementation:
public static void main() {
    PersonList persons = new PersonList();
    for (int i = 0; i < 100000; i++) {
        persons.add(new Person("P" + Integer.toString(i), RandomString(5, true)));
    }
    PersonList unsortedPersons = new PersonList(persons);
    final int COUNT = 30;
    Stopwatch watch = new Stopwatch();
    for (int i = 0; i < COUNT; i++) {
        watch.start();
        Sort.sort(persons);
        watch.stop();
        persons.clear();
        persons.addAll(unsortedPersons);
    }
    System.out.println("Sort: " + watch.elapsedMilliseconds + "ms");
    
    watch = new Stopwatch();
    for (int i = 0; i < COUNT; i++) {
        watch.start();
        OrderBy.orderBy(persons);
        watch.stop();
        persons.clear();
        persons.addAll(unsortedPersons);
    }
    System.out.println("OrderBy: " + watch.elapsedMilliseconds + "ms");
    
    watch = new Stopwatch();
    for (int i = 0; i < COUNT; i++) {
        watch.start();
        OrderByWithToList.orderByWithToList(persons);
        watch.stop();
        persons.clear();
        persons.addAll(unsortedPersons);
    }
    System.out.println("OrderByWithToList: " + watch.elapsedMilliseconds + "ms");
}

