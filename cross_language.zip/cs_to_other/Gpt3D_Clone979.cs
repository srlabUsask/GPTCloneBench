#input 
private static object SearchPositionUsingIndex (List < TagType < object > > tagList, string fieldTag) {
    var index = BuildIndex (tagList);
    int i;
    if (! index.TryGetValue (fieldTag, out i))
        return null;
    if (i + 1 >= tagList.Count)
        return null;
    return tagList [i + 1].Position;
}


#====================
#gpt output=============

Python:
def search_position_using_index(tag_list, field_tag):
    index = build_index(tag_list)
    if field_tag not in index:
        return None
    i = index[field_tag]
    if i + 1 >= len(tag_list):
        return None
    return tag_list[i+1].position

C: 
static Object *SearchPositionUsingIndex(List *tagList, char *fieldTag) {
    Index *index = BuildIndex(tagList);
    int i;
    if (Index_Find(index, fieldTag, &i) == 0)
        return NULL;
    if (i + 1 >= ListSize(tagList))
        return NULL;
    TagType *tag = ListGet(tagList, i + 1);
    return tag->Position;
}

Java: 
private static Object searchPositionUsingIndex(List< TagType<Object> > tagList, String fieldTag) {
    Map<String, Integer> index = buildIndex(tagList);
    if (!index.containsKey(fieldTag))
        return null;
    int i = index.get(fieldTag);
    if (i + 1 >= tagList.size())
        return null;
    return tagList.get(i + 1).Position;
}

