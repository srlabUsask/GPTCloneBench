#input 
private long [] GetHistogram (Bitmap image) {
    var histogram = new long [256];
    bool imageWasCloned = false;
    if (image.PixelFormat != PixelFormat.Format24bppRgb) {
        image = image.Clone (new Rectangle (0, 0, image.Width, image.Height), PixelFormat.Format24bppRgb);
        imageWasCloned = true;
    }
    BitmapData bmd = null;
    try {
        bmd = image.LockBits (new Rectangle (0, 0, image.Width, image.Height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        const int pixelSize = 3;
        int height = bmd.Height;
        int width = bmd.Width;
        int rowPadding = bmd.Stride - (width * pixelSize);
        unsafe {
            byte * pixelPtr = (byte *) bmd.Scan0;
            for (int y = 0; y < height; ++ y) {
                for (int x = 0; x < width; ++ x) {
                    histogram [(pixelPtr [0] + pixelPtr [1] + pixelPtr [2]) / 3] ++;
                    pixelPtr += pixelSize;
                }
                pixelPtr += rowPadding;
            }
        }}
    finally {
        if (bmd != null)
            image.UnlockBits (bmd);
        if (imageWasCloned)
            image.Dispose ();
    }
    return histogram;
}


#====================
#gpt output=============

// Python Implementation
def GetHistogram(image): 
    histogram = [0] * 256
    imageWasCloned = False
    
    if image.pixel_format != PixelFormat.Format24bppRgb:
        image = image.clone(0, 0, image.width, image.height, PixelFormat.Format24bppRgb) 
        imageWasCloned = True 
    
    bmd = None 
    try: 
        bmd = image.lock_bits(img.rectangle(0, 0, image.width, image.height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb) 
        pixelSize = 3 
        height = bmd.height 
        width = bmd.width 
        rowPadding = bmd.stride - (width * pixelSize) 
        pixelPtr = bmd.scan0 
        for y in range(height): 
            for x in range(width): 
                histogram[(pixelPtr[0] + pixelPtr[1] + pixelPtr[2])/3] += 1 
                pixelPtr += pixelSize 
            pixelPtr += rowPadding 
    finally: 
        if (bmd != None): 
            image.unlock_bits(bmd) 
        if imageWasCloned: 
            image.dispose() 
    
    return histogram 


// C Implementation
long* GetHistogram (Bitmap* image) {
	long* histogram = (long*)malloc(256 * sizeof(long));
	bool imageWasCloned = false;

	if (image->PixelFormat != PixelFormat_Format24bppRgb) {
		Bitmap_clone(image, 0, 0, image->width, image->height, PixelFormat_Format24bppRgb);
		imageWasCloned = true;
	}

	BitmapData* bmd = NULL;
	try {
		bmd = Bitmap_lockBits(image, &imageRectangle, ImageLockMode_ReadOnly, PixelFormat_Format24bppRgb);
		const int pixelSize = 3;
		int height = bmd->height;
		int width = bmd->width;
		int rowPadding = bmd->stride - (width * pixelSize);
		unsigned char* pixelPtr = bmd->scan0;

		for (int y = 0; y < height; ++ y) {
			for (int x = 0; x < width; ++ x) {
				histogram[(pixelPtr[0] + pixelPtr[1] + pixelPtr[2]) / 3] ++;
				pixelPtr += pixelSize;
			}
			pixelPtr += rowPadding;
		}}
	finally {
		if (bmd != NULL)
			Bitmap_unlockBits(image, bmd);
		if (imageWasCloned)
			Bitmap_dispose(image);
	}
	return histogram;
}


// Java Implementation 
public static long[] getHistogram(Bitmap image){
    long[] histogram = new long[256];
    boolean imageWasCloned = false;
    if(image.getPixelFormat() != PixelFormat.Format24bppRgb){
        image = image.clone(new Rectangle(0, 0, image.getWidth(), image.getHeight()), PixelFormat.Format24bppRgb);
        imageWasCloned = true;
    }
    BitmapData bmd = null;
    try {
        bmd = image.lockBits(new Rectangle(0, 0, image.getWidth(), image.getHeight()), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
        int pixelSize = 3;
        int height = bmd.getHeight();
        int width = bmd.getWidth();
        int rowPadding = bmd.getStride() - (width * pixelSize);
        byte[] pixelPtr = bmd.getScan0();

        for(int y = 0; y < height; y++){
            for(int x = 0; x < width; x++){
                histogram[(pixelPtr[0] + pixelPtr[1] + pixelPtr[2])/3]++;
                pixelPtr += pixelSize;
            }
            pixelPtr += rowPadding;
        }
    } finally {
        if(bmd != null){
            image.unlockBits(bmd);
        }
        if(imageWasCloned){
            image.dispose();
        }
    }
    return histogram;
}

