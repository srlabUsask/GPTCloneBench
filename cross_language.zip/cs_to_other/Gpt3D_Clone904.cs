#input 
private bool IsTableSame (DataTable t1, DataTable t2) {
    if (t1 == null)
        return false;
    if (t2 == null)
        return false;
    if (t1.Rows.Count != t2.Rows.Count)
        return false;
    if (t1.Columns.Count != t2.Columns.Count)
        return false;
    if (t1.Columns.Cast < DataColumn > ().Any (dc = > ! t2.Columns.Contains (dc.ColumnName))) {
        return false;
    }
    for (int i = 0; i <= t1.Rows.Count - 1; i ++) {
        if (t1.Columns.Cast < DataColumn > ().Any (dc1 = > t1.Rows [i] [dc1.ColumnName].ToString () != t2.Rows [i] [dc1.ColumnName].ToString ())) {
            return false;
        }
    }
    return true;
}


#====================
#gpt output=============

Python:
def IsTableSame(t1, t2):
    if t1 is None:
        return False
    if t2 is None:
        return False
    if len(t1.Rows) != len(t2.Rows):
        return False
    if len(t1.Columns) != len(t2.Columns):
        return False
    if any(dc not in t2.Columns for dc in t1.Columns):
        return False
    for i in range(len(t1.Rows)):
        if any(t1.Rows[i][dc1.ColumnName].ToString() != t2.Rows[i][dc1.ColumnName].ToString() for dc1 in t1.Columns):
            return False
    return True

C: 
bool IsTableSame(DataTable *t1, DataTable *t2){
    if (t1 == NULL)
        return false;
    if (t2 == NULL)
        return false;
    if (t1->Rows.Count != t2->Rows.Count)
        return false;
    if (t1->Columns.Count != t2->Columns.Count)
        return false;
    if (any_DataColumn(t1->Columns, dce){
        return !contains_DataColumn(t2->Columns, dce);
    }){
        return false;
    }
    for (int i = 0; i <= t1->Rows.Count - 1; i ++){
        if (any_DataColumn(t1->Columns, dc1){
            return t1->Rows[i][dc1.ColumnName].ToString() != t2->Rows[i][dc1.ColumnName].ToString();
        }){
            return false;
        }
    }
    return true;
}

Java: 
private boolean IsTableSame(DataTable t1, DataTable t2) {
    if (t1 == null)
        return false;
    if (t2 == null)
        return false;
    if (t1.Rows.size() != t2.Rows.size())
        return false;
    if (t1.Columns.size() != t2.Columns.size())
        return false;
    if (t1.Columns.stream().anyMatch(dc -> !t2.Columns.contains(dc.ColumnName))) {
        return false;
    }
    for (int i = 0; i <= t1.Rows.size() - 1; i ++) {
        if (t1.Columns.stream().anyMatch(dc1 -> !t1.Rows.get(i)[dc1.ColumnName].toString().equals(t2.Rows.get(i)[dc1.ColumnName].toString()))) {
            return false;
        }
    }
    return true;
}

