#input 
static IEnumerable < string > GetVariations (string s) {
    int [] indexes = new int [s.Length];
    StringBuilder sb = new StringBuilder ();
    while (IncrementIndexes (indexes, s.Length)) {
        sb.Clear ();
        for (int i = 0; i < indexes.Length; i ++) {
            if (indexes [i] != 0) {
                sb.Append (s [indexes [i] - 1]);
            }
        }
        yield return sb.ToString ();
    }
}


#====================
#gpt output=============


Python Implementation:

def get_variations(s):
    indexes = [0] * len(s)
    string_builder = ""
    while(increment_indexes(indexes, len(s))):
        string_builder = ""
        for i in range(len(indexes)):
            if(indexes[i] != 0):
                string_builder += s[indexes[i]-1]
        yield string_builder

C Implementation:

char** get_variations(char* s)
{
    static size_t *indexes = [0] * strlen(s);
    static size_t string_builder_size = 0;
    static char **return_from_string_container = NULL;
    while (increment_indexes(indexes, strlen(s)))
    {
        string_builder_size = 0;
        char *string_builder = malloc(string_builder_size);

        for (int i = 0; i < indexes.length; i++)
        {
            if (indexes[i] != 0)
            {
                string_builder_size += 1;
                string_builder = realloc(string_builder, string_builder_size);
                string_builder[string_builder_size - 1] = s[indexes[i] - 1];
            }
        }
        return_from_string_container = realloc(return_from_string_container, string_builder_size * sizeof(char *));
        *return_from_string_container = string_builder;
        string_builder = NULL;
    }

    return return_from_string_container;
}

Java Implementation:

public static List<String> getVariations(String s) {
	int[] indexes = new int[s.length()];
	StringBuilder sb = new StringBuilder();
	List<String> result = new ArrayList<>();

	while(incrementIndexes(indexes, s.length())) {
	    sb.setLength(0);
	    for(int i=0; i<indexes.length; i++) {
		if(indexes[i] != 0) {
		    sb.append(s.charAt(indexes[i]));
		}
	    }
	    result.add(sb.toString());
	}
	return result;
    }

