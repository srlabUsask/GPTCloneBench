#input 
protected void TextBox1_TextChanged1 (object sender, EventArgs e) {
    dt = g1.return_dt ("select name from tbl_data_show");
    if (dt.Rows.Count > 0) {
        if (TextBox1.Text == dt.Rows [0] ["name"]) {
            Label1.Text = "4";
            Label1.Visible = true;
        } else if (TextBox1.Text != dt.Rows [0] ["name"]) {
            Label2.Text = "5";
            Label2.Visible = true;
        } else {
            Label1.Visible = false;
            Label2.Visible = false;
        }
    }
}


#====================
#gpt output=============

Python:
def TextBox1_TextChanged1 (self, sender, e):
    dt = g1.return_dt ("select name from tbl_data_show")
    if len (dt.rows) > 0:
        if TextBox1.text == dt.rows[0]["name"]:
            Label1.text = "4"
            Label1.visible = True
        elif TextBox1.text != dt.rows [0]["name"]:
            Label2.text = "5"
            Label2.visible = True
        else:
            Label1.visible = False
            Label2.visible = False

C: 
void TextBox1_TextChanged1 (Object* sender, EventArgs* e) {
    DataTable* dt = g1->return_dt("select name from tbl_data_show");
    if (dt->Rows->Count > 0) {
        if (TextBox1->Text->Equals(dt->Rows[0]->"name")) {
            Label1->Text = "4";
            Label1->Visible = true;
        } 
        else if (!TextBox1->Text->Equals(dt->Rows[0]->"name")) {
            Label2->Text = "5";
            Label2->Visible = true;
        } 
        else {
            Label1->Visible = false;
            Label2->Visible = false;
        }
    }
}

Java:
protected void TextBox1_TextChanged1(Object sender, EventArgs e) {
    DataTable dt = g1.return_dt("select name from tbl_data_show");
    if (dt.rows.size() > 0) {
        if (TextBox1.getText().equals(dt.rows.get(0).get("name"))) {
            Label1.setText("4");
            Label1.setVisible(true);
        } else if (!TextBox1.getText().equals(dt.rows.get(0).get("name"))) {
            Label2.setText("5");
            Label2.setVisible(true);
        } else {
            Label1.setVisible(false);
            Label2.setVisible(false);
        }
    }
}

