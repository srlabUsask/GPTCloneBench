#input 
static void Main (string [] args) {
    long i = 0;
    int runs = 10 * 1000 * 1000;
    Task [] t = new Task [Environment.ProcessorCount];
    Stopwatch stp = Stopwatch.StartNew ();
    for (int k = 0; k < t.Length; k ++) {
        t [k] = Task.Run (() = > {
            for (int j = 0; j < runs; j ++) {
                i ++;
            }
        });
    }
    Task.WaitAll (t);
    stp.Stop ();
    Console.WriteLine ("i = {0}   should be = {1}  ms={2}", i, runs * t.Length, stp.ElapsedMilliseconds);
    Console.ReadLine ();
}


#====================
#gpt output=============

Python:
import time
def main(args):
    i = 0
    runs = 10 * 1000 * 1000
    num_tasks = len(args)
    start_time = time.time()

    for k in range(num_tasks):
        for j in range(runs):
            i += 1

    end_time = time.time()
    total_time = end_time - start_time

    print(f"i = {i}, should be = {runs * num_tasks}, ms={total_time}")

if __name__ == "__main__":
    main(sys.argv[1:])


C:
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char **argv){
    long i=0;
    int runs = 10 * 1000 * 1000;
    int num_tasks = argc;
    clock_t start_time = clock();

    for (int k=0; k<num_tasks; k++){
        for (int j=0; j<runs; j++){
            i++;
        }
    }

    clock_t end_time = clock();
    float total_time = (float)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("i=%ld, should be=%d, ms=%.3f\n",i,runs*num_tasks,total_time*1000);
    return 0;
}

Java:
public class Main {
  public static void main(String[] args) {
    long i = 0;
    int runs = 10 * 1000 * 1000;
    Task[] tasks = new Task[args.length];
    long startTime = System.currentTimeMillis();

    for (int k = 0; k < tasks.length; k++) {
      tasks[k] = new Task(() -> {
        for (int j = 0; j < runs; j++) {
          i++;
        }
      });
    }
    for (int k = 0; k < tasks.length; k++) {
      tasks[k].start();
    }

    try {
      for (int k = 0; k < tasks.length; k++) {
        tasks[k].join();
      }
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    long endTime = System.currentTimeMillis();
    long totalTime = endTime - startTime;
    System.out.println("i = " + i + "should be =" + runs*tasks.length + "ms=" + totalTime);
  }

}
class Task extends Thread {
  Runnable mRunnable;
  Task(Runnable runnable) {
    mRunnable = runnable;
  }

  @Override
  public void run() {
    mRunnable.run();
  }
}

