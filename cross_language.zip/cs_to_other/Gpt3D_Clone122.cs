#input 
private static bool GetFileNameFromHandle (IntPtr handle, int processId, out string fileName) {
    IntPtr currentProcess = NativeMethods.GetCurrentProcess ();
    bool remote = (processId != NativeMethods.GetProcessId (currentProcess));
    SafeProcessHandle processHandle = null;
    SafeObjectHandle objectHandle = null;
    try {
        if (remote) {
            processHandle = NativeMethods.OpenProcess (ProcessAccessRights.PROCESS_DUP_HANDLE, true, processId);
            if (NativeMethods.DuplicateHandle (processHandle.DangerousGetHandle (), handle, currentProcess, out objectHandle, 0, false, DuplicateHandleOptions.DUPLICATE_SAME_ACCESS)) {
                handle = objectHandle.DangerousGetHandle ();
            }
        }
        return GetFileNameFromHandle (handle, out fileName, 200);
    }
    finally {
        if (remote) {
            if (processHandle != null) {
                processHandle.Close ();
            }
            if (objectHandle != null) {
                objectHandle.Close ();
            }
        }
    }
}


#====================
#gpt output=============

//Python:
def GetFileNameFromHandle (handle, processId):
    currentProcess = NativeMethods.GetCurrentProcess ()
    remote = (processId != NativeMethods.GetProcessId (currentProcess))
    processHandle = None
    objectHandle = None
    try:
        if remote:
            processHandle = NativeMethods.OpenProcess (ProcessAccessRights.PROCESS_DUP_HANDLE, True, processId)
            if NativeMethods.DuplicateHandle (processHandle.DangerousGetHandle (), handle, currentProcess, out objectHandle, 0, False, DuplicateHandleOptions.DUPLICATE_SAME_ACCESS):
                handle = objectHandle.DangerousGetHandle
        return GetFileNameFromHandle (handle, out fileName, 200)
    finally:
        if remote:
            if processHandle is not None:
                processHandle.Close ()
            if objectHandle is not None:
                objectHandle.Close ()
        

//C:
bool GetFileNameFromHandle (IntPtr handle, int processId, char *fileName) {
    IntPtr currentProcess = NativeMethods.GetCurrentProcess ();
    bool remote = (processId != NativeMethods.GetProcessId (currentProcess));
    SafeProcessHandle processHandle = NULL;
    SafeObjectHandle objectHandle = NULL;
    try {
        if (remote) {
            processHandle = NativeMethods.OpenProcess (ProcessAccessRights.PROCESS_DUP_HANDLE, true, processId);
            if (NativeMethods.DuplicateHandle (processHandle.DangerousGetHandle (), handle, currentProcess, &objectHandle, 0, false, DuplicateHandleOptions.DUPLICATE_SAME_ACCESS)) {
                handle = objectHandle.DangerousGetHandle ();
            }
        }
        return GetFileNameFromHandle (handle, fileName, 200);
    }
    finally {
        if (remote) {
            if (processHandle != NULL) {
                processHandle->Close ();
            }
            if (objectHandle != NULL) {
                objectHandle->Close ();
            }
        }
    }
}


//Java:
private static boolean GetFileNameFromHandle (IntPtr handle, int processId, StringBuilder fileName) {
    IntPtr currentProcess = NativeMethods.getCurrentProcess ();
    boolean remote = (processId != NativeMethods.getProcessId (currentProcess));
    SafeProcessHandle processHandle = null;
    SafeObjectHandle objectHandle = null;
    try {
        if (remote) {
            processHandle = NativeMethods.openProcess (ProcessAccessRights.PROCESS_DUP_HANDLE, true, processId);
            if (NativeMethods.duplicateHandle (processHandle.getDangerousGetHandle (), handle, currentProcess, objectHandle, 0, false, DuplicateHandleOptions.DUPLICATE_SAME_ACCESS)) {
                handle = objectHandle.getDangerousGetHandle ();
            }
        }
        return GetFileNameFromHandle (handle, fileName, 200);
    }
    finally {
        if (remote) {
            if (processHandle != null) {
                processHandle.close ();
            }
            if (objectHandle != null) {
                objectHandle.close ();
            }
        }
    }
}

