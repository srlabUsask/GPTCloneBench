#input 
public bool CheckForCrossing (List < Line2D > lines) {
    List < endpointEntry > pts = new List < endpointEntry > (2 * lines.Count);
    foreach (Line2D lin in lines) {
        endpointEntry hi, lo;
        if (lin.P1.X < lin.P2.X) {
            hi = new endpointEntry () {XValue = lin.P2.X, isHi = true, line = lin, hi = lin.P2.X, lo = lin.P1.X};
            lo = new endpointEntry () {XValue = lin.P1.X, isHi = false, line = lin, hi = lin.P1.X, lo = lin.P2.X};
        } else {
            hi = new endpointEntry () {XValue = lin.P1.X, isHi = true, line = lin, hi = lin.P1.X, lo = lin.P2.X};
            lo = new endpointEntry () {XValue = lin.P2.X, isHi = false, line = lin, hi = lin.P2.X, lo = lin.P1.X};
        }
        pts.Add (hi);
        pts.Add (lo);
    }
    pts.Sort (new endpointSorter ());
    endpointEntry prev = null;
    foreach (endpointEntry pt in pts) {
        if (prev != null) {
            pt.bLink = prev;
            prev.fLink = pt;
        }
        prev = pt;
    }
    foreach (endpointEntry pt in pts) {
        if (pt.isHi) {
            for (endpointEntry pLo = pt.fLink; (pLo != null) && (pLo.XValue >= pt.lo); pLo = pLo.fLink) {
                if (! pLo.isHi) {
                    if (pt.line.intersectsLine (pLo.line))
                        return true;
                }
            }
        }
    }
    return false;
}


#====================
#gpt output=============

Python:

def CheckForCrossing(lines):
    pts = []
    for lin in lines:
        hi = {}
        lo = {}
        if lin.P1.X < lin.P2.X:
            hi = {'XValue':lin.P2.X, 'isHi':True, 'line':lin, 'hi':lin.P2.X, 'lo':lin.P1.X}
            lo = {'XValue':lin.P1.X, 'isHi':False, 'line':lin, 'hi':lin.P1.X, 'lo':lin.P2.X}
        else:
            hi = {'XValue':lin.P1.X, 'isHi':True, 'line':lin, 'hi':lin.P1.X, 'lo':lin.P2.X}
            lo = {'XValue':lin.P2.X, 'isHi':False, 'line':lin, 'hi':lin.P2.X, 'lo':lin.P1.X}
        pts.append(hi)
        pts.append(lo)
    pts.sort(key = lambda x : x['XValue'])
    prev = None
    for pt in pts:
        if prev != None:
            pt['bLink'] = prev
            prev['fLink'] = pt
        prev = pt
    for pt in pts:
        if pt['isHi']:
            pLo = pt['fLink']
            while pLo != None and pLo['XValue'] >= pt['lo']:
                if not pLo['isHi']:
                    if pt['line'].intersectsLine(pLo['line']):
                        return True
                pLo = pLo['fLink']
    return False


C:

bool CheckForCrossing(List *lines) {
    List *pts = List_create(2 * List_size(lines));
    ListNode *cursor = List_cursorFirst(lines);
    while(cursor != NULL) {
        Line2D *lin = List_cursorGet(lines);
        endpointEntry hi;
        endpointEntry lo;
        if (lin->P1.X < lin->P2.X) {
            hi = (endpointEntry) { 
                .XValue = lin->P2.X, 
                .isHi = true, 
                .line = lin, 
                .hi = lin->P2.X, 
                .lo = lin->P1.X 
            };
            lo = (endpointEntry) { 
                .XValue = lin->P1.X, 
                .isHi = false, 
                .line = lin, 
                .hi = lin->P1.X, 
                .lo = lin->P2.X 
            };
        } else {
            hi = (endpointEntry) { 
                .XValue = lin->P1.X, 
                .isHi = true, 
                .line = lin, 
                .hi = lin->P1.X, 
                .lo = lin->P2.X 
            };
            lo = (endpointEntry) { 
                .XValue = lin->P2.X, 
                .isHi = false, 
                .line = lin, 
                .hi = lin->P2.X, 
                .lo = lin->P1.X  
            };
        }
        List_addLast(pts, &hi);
        List_addLast(pts, &lo);
        cursor = List_cursorNext(lines);
    }

    List_sort(pts, endpointSorter_compare);
    endpointEntry *prev;
    for(int i = 0; i < List_size(pts); i++) {
        endpointEntry *pt = List_get(pts, i);
        if(prev != NULL) {
            pt->bLink = prev;
            prev->fLink = pt;
        }
        prev = pt;
    }

    for(int i = 0; i < List_size(pts); i++) {
        endpointEntry *pt = List_get(pts, i);
        if(pt->isHi) {
            endpointEntry *pLo = pt->fLink;
            while(pLo != NULL && pLo->XValue >= pt->lo) {
                if(!pLo->isHi) {
                    if(intersectsLine(pt->line, pLo->line)) {
                        return true;
                    }
                }
                pLo = pLo->fLink;
            }
        }
    }

    return false;
}


Java:

public static boolean CheckForCrossing (List<Line2D> lines) {
    List<endpointEntry> pts = new ArrayList<>(2 * lines.size());
    for (Line2D lin : lines) {
        endpointEntry hi;
        endpointEntry lo;
        if (lin.P1.X < lin.P2.X) {
            hi = new endpointEntry {XValue = lin.P2.X, isHi = true, line = lin, hi = lin.P2.X, lo = lin.P1.X};
            lo = new endpointEntry {XValue = lin.P1.X, isHi = false, line = lin, hi = lin.P1.X, lo = lin.P2.X};
        } else {
            hi = new endpointEntry {XValue = lin.P1.X, isHi = true, line = lin, hi = lin.P1.X, lo = lin.P2.X};
            lo = new endpointEntry {XValue = lin.P2.X, isHi = false, line = lin, hi = lin.P2.X, lo = lin.P1.X};
        }
        pts.add(hi);
        pts.add(lo);
    }
    pts.sort(Comparator.comparingInt(e -> e.XValue));
    endpointEntry prev = null;
    for (endpointEntry pt : pts) {
        if (prev != null) {
            pt.bLink = prev;
            prev.fLink = pt;
        }
        prev = pt;
    }
    for (endpointEntry pt : pts) {
        if (pt.isHi) {
            for (endpointEntry pLo = pt.fLink; pLo != null && pLo.XValue >= pt.lo; pLo = pLo.fLink) {
                if (!pLo.isHi) {
                    if (pt.line.intersectsLine(pLo.line))
                        return true;
                }
            }
        }
    }
    return false;
}

