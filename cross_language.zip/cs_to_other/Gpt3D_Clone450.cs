#input 
public override void WriteJson (JsonWriter writer, object value, JsonSerializer serializer) {
    if (value == null) {
        writer.WriteNull ();
        return;
    }
    var model = value as MyModel;
    if (model == null)
        throw new JsonSerializationException ();
    writer.WriteStartObject ();
    writer.WritePropertyName ("name");
    writer.WriteValue (model.Name);
    writer.WritePropertyName ("details");
    writer.WriteStartObject ();
    writer.WritePropertyName ("size");
    serializer.Serialize (writer, model.Size);
    writer.WritePropertyName ("weight");
    writer.WriteValue (model.Weight);
    writer.WriteEndObject ();
    writer.WriteEndObject ();
}


#====================
#gpt output=============

Python
defWriteJson (self, writer, value, serializer): 
    if value == None: 
        writer.WriteNull() 
        return
    model = value as MyModel 
    if not model: 
        raise JsonSerializationException
    writer.WriteStartObject() 
    writer.WritePropertyName('name') 
    writer.WriteValue(model.Name)
    writer.WritePropertyName('details') 
    writer.WriteStartObject() 
    writer.WritePropertyName('size') 
    serializer.Serialize(writer, model.Size) 
    writer.WritePropertyName('weight') 
    writer.WriteValue(model.Weight) 
    writer.WriteEndObject() 
    writer.WriteEndObject() 

C
void WriteJson (JsonWriter * writer, void * value, JsonSerializer * serializer)
{
    if (value == null)
    {
        JsonWriter_WriteNull (writer);
        return;
    }
    MyModel * model = (MyModel *)value;
    if (model == null)
        throw new JsonSerializationException;
    JsonWriter_WriteStartObject (writer);
    JsonWriter_WritePropertyName (writer, "name");
    JsonWriter_WriteValue (writer, model->Name);
    JsonWriter_WritePropertyName (writer, "details");
    JsonWriter_WriteStartObject (writer);
    JsonWriter_WritePropertyName (writer, "size");
    JsonSerializer_Serialize (serializer, writer, model->Size);
    JsonWriter_WritePropertyName (writer, "weight");
    JsonWriter_WriteValue (writer, model->Weight);
    JsonWriter_WriteEndObject (writer);
    JsonWriter_WriteEndObject (writer);

Java
public void writeJson (JsonWriter writer, Object value, JsonSerializer serializer) {
    if (value == null) {
        writer.writeNull ();
        return;
    }
    MyModel model = (MyModel) value;
    if (model == null)
        throw new JsonSerializationException();
    writer.writeStartObject();
    writer.writePropertyName("name");
    writer.writeValue(model.getName());
    writer.writePropertyName("details");
    writer.writeStartObject();
    writer.writePropertyName("size");
    serializer.serialize(writer, model.getSize());
    writer.writePropertyName("weight");
    writer.writeValue(model.getWeight());
    writer.writeEndObject();
    writer.writeEndObject();
}

