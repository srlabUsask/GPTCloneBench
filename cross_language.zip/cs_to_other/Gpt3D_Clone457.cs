#input 
private static string ExtractCN (string dn) {
    string [] parts = dn.Split (new char [] {','});
    for (int i = 0; i < parts.Length; i ++) {
        var p = parts [i];
        var elems = p.Split (new char [] {'='});
        var t = elems [0].Trim ().ToUpper ();
        var v = elems [1].Trim ();
        if (t == "CN") {
            return v;
        }
    }
    return null;
}


#====================
#gpt output=============


Python Implementation: 
def ExtractCN(dn):
    parts = dn.split(',')
    for i in range(len(parts)):
        elems = parts[i].split('=')
        t = elems[0].strip().upper()
        v = elems[1].strip()
        if t == "CN":
            return v
    return None


C Implementation: 
char* ExtractCN (char* dn) {
    char *parts = strtok("(char*)dn, ","); 
    for (int i = 0; i < parts.Length; i++) {
        char* elems = strtok(parts[i], "=");
        char* t = strupr(elems[0].strip());
        char* v = elems[1].strip();

        if(strcmp(t, "CN") == 0){
            return v;
        }
    }

    return NULL;
}


Java Implementation:
public static String ExtractCN(String dn) {
    String[] parts = dn.split(",");
    for(int i = 0; i < parts.length; i++) {
        String[] elems = parts[i].split("=");
        String t = elems[0].trim().toUpperCase();
        String v = elems[1].trim();
        if(t.equals("CN")) {
            return v;
        }
    }
    return null;
}

