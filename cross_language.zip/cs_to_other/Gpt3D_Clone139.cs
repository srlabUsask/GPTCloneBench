#input 
static void Main (string [] args) {
    string Path = @"C:\Abhishek\Documents";
    string filePath = @"C:\Abhishek\Documents.txt";
    bool isDirExists = Directory.Exists (Path);
    bool isFileExists = File.Exists (filePath);
    if (isDirExists) {
        Console.WriteLine ("Directory Exists");
    } else {
        Console.WriteLine ("Directory does not exists");
    }
    if (isFileExists) {
        Console.WriteLine ("File Exists");
    } else {
        Console.WriteLine ("File does not exists");
    }
    Console.ReadKey ();
}


#====================
#gpt output=============

Python: 
import os 
  
Path = 'C:\\Abhishek\\Documents'
filePath = 'C:\\Abhishek\\Documents.txt'

isDirExists = os.path.isdir(Path)
isFileExists = os.path.isfile(filePath)
if isDirExists: 
    print("Directory Exists") 
else: 
    print("Directory does not exists")
if isFileExists: 
    print("File Exists")
else:
    print("File does not exists")


C:
#include<stdio.h>
#include<conio.h> 
#include<direct.h> 
#include <io.h> 
#define MAX_PATH 100 

int main() 
{ 
    char path[] = "C:\\Abhishek\\Documents"; 
    char filePath[] = "C:\\Abhisek\\Documents.txt"; 
    int dirExists = 0; 
    int fileExists = 0; 
            
    dirExists = _chdir(path); 
    _getcwd(path, MAX_PATH); 
    fileExists = _access(filePath, 0); 
    if(dirExists == 0) 
        printf("Directory Exists\n"); 
    else
        printf("Directory does not exists\n"); 
    if(fileExists == 0) 
        printf("File Exists\n"); 
    else
        printf("File does not exists\n"); 
    getch(); 
    return 0; 
} 


Java:
import java.io.File;

public class Main { 
    public static void main(String[] args) 
    { 
        String Path = "C:\\Abhishek\\Documents"; 
        String filePath = "C:\\Abhishek\\Documents.txt"; 
  
        boolean isDirExists = new File(Path).isDirectory(); 
        boolean isFileExists = new File(filePath).isFile(); 
        if (isDirExists) { 
            System.out.println("Directory Exists"); 
        } 
        else { 
            System.out.println("Directory does not exists"); 
        } 
        if (isFileExists) { 
            System.out.println("File Exists"); 
        } 
        else { 
            System.out.println("File does not exists"); 
        } 
    } 
}

