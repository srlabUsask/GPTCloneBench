#input 
static int Main (string [] args) {
    var num1 = 10;
    var num2 = 100;
    var maxValue = 0;
    var LoopCount = 1000000000;
    double controlTotalSeconds;
    {
        var stopwatch = new Stopwatch ();
        stopwatch.Start ();
        for (var i = 0; i < LoopCount; i ++) {
        }
        stopwatch.Stop ();
        controlTotalSeconds = stopwatch.Elapsed.TotalSeconds;
        Console.WriteLine ("Control - Empty Loop - " + controlTotalSeconds + " seconds");
    } Console.WriteLine ();
    {
        var stopwatch = new Stopwatch ();
        stopwatch.Start ();
        for (int i = 0; i < LoopCount; i ++) {
            maxValue = Math.Max (num1, num2);
        }
        stopwatch.Stop ();
        Console.WriteLine ("Math.Max() - " + stopwatch.Elapsed.TotalSeconds + " seconds");
        Console.WriteLine ("Relative: " + (stopwatch.Elapsed.TotalSeconds - controlTotalSeconds) + " seconds");
    } Console.WriteLine ();
    {
        var stopwatch = new Stopwatch ();
        stopwatch.Start ();
        for (int i = 0; i < LoopCount; i ++) {
            maxValue = num1 > num2 ? num1 : num2;
        }
        stopwatch.Stop ();
        Console.WriteLine ("Inline Max: " + stopwatch.Elapsed.TotalSeconds + " seconds");
        Console.WriteLine ("Relative: " + (stopwatch.Elapsed.TotalSeconds - controlTotalSeconds) + " seconds");
    } Console.ReadLine ();
    return maxValue;
}


#====================
#gpt output=============


Python:
def Main(args):
    num1 = 10
    num2 = 100
    maxValue = 0
    LoopCount = 1000000000
    controlTotalSeconds = 0

    start = time.time()
    for i in range(LoopCount):
        pass
    controlTotalSeconds = time.time() - start
    print("Control - Empty Loop - %s seconds" % controlTotalSeconds)
    
    start = time.time()
    for i in range(LoopCount):
        maxValue = max(num1, num2)
    print("Math.Max() - %s seconds" % (time.time() - start))
    print("Relative: %s seconds" % (time.time() - start) - controlTotalSeconds)

    start = time.time()
    for i in range(LoopCount):
        maxValue = num1 if num1 > num2 else num2
    print("Inline Max: %s seconds" % (time.time() - start))
    print("Relative: %s seconds" % (time.time() - start) - controlTotalSeconds)

    raw_input()
    return maxValue


C:
int Main(string args[]) {
    int num1 = 10;
    int num2 = 100;
    int maxValue = 0;
    const int LoopCount = 1000000000;
    double controlTotalSeconds;

    clock_t controlStartTime = clock();
    for(int i = 0; i < LoopCount; i++) {}
    controlTotalSeconds = (double)(clock() - controlStartTime) / CLOCKS_PER_SEC;
    printf("Control - Empty Loop - %f seconds\n", controlTotalSeconds);

    clock_t maxStartTime = clock();
    for(int i = 0; i < LoopCount; i++) {
        maxValue = (num1>num2) ? num1 : num2;
    }
    printf("Inline Max: %f seconds\n", (double)(clock() - maxStartTime) / CLOCKS_PER_SEC);
    printf("Relative: %f seconds\n", (double)(clock() - maxStartTime) / CLOCKS_PER_SEC - controlTotalSeconds);

    getch();
    return maxValue;
}



Java:
public static int Main(String[] args) {
    int num1 = 10;
    int num2 = 100;
    int maxValue = 0;
    final int LoopCount = 1000000000;
    double controlTotalSeconds;

    long controlStartTime = System.nanoTime();
    for(int i = 0; i < LoopCount; i++) {}
    controlTotalSeconds = (double)(System.nanoTime() - controlStartTime) / 1000000000;
    System.out.println("Control - Empty Loop - " + controlTotalSeconds + " seconds");

    long maxStartTime = System.nanoTime();
    for(int i = 0; i < LoopCount; i++) {
        maxValue = Math.max(num1, num2);
    }
    System.out.println("Math.Max() - " + (double)(System.nanoTime() - maxStartTime) / 1000000000 + " seconds");
    System.out.println("Relative: " + (double)(System.nanoTime() - maxStartTime) / 1000000000 - controlTotalSeconds  + " seconds");

    maxStartTime = System.nanoTime();
    for(int i = 0; i < LoopCount; i++) {
        maxValue = num1 > num2 ? num1 : num2;
    }
    System.out.println("Inline Max: " + (double)(System.nanoTime() - maxStartTime) / 1000000000  + " seconds");
    System.out.println("Relative: " + (double)(System.nanoTime() - maxStartTime) / 1000000000 - controlTotalSeconds  + " seconds");

    System.console().readLine();
    return maxValue;
}

