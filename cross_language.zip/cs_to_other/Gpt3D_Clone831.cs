#input 
public Control FindControl (Control root, string name) {
    if (root == null)
        throw new ArgumentNullException ("root");
    var stack = new Stack < Control > ();
    stack.Push (root);
    while (stack.Count > 0) {
        Control item = stack.Pop ();
        if (item.Name == name)
            return item;
        foreach (Control child in item.Controls) {
            stack.Push (child);
        }
    }
    return null;
}


#====================
#gpt output=============

Python:
def findControl(root, name):
    if root == None:
        raise Exception('root cannot be None')
    stack = []
    stack.append(root)
    while len(stack) > 0:
        item = stack.pop()
        if item.name == name:
            return item
        for child in item.controls:
            stack.append(child)    
    return None

C:
Control* findControl(Control* root, char *name)
{
    if (root == NULL)
    {
        fprintf(stderr, "root cannot be NULL \n");
        exit(1);
    }
    Control* stack[1024];
    int top = -1;
    stack[++top] = root;
    while (top >= 0)
    {
        Control* item = stack[top--];
        if (strcmp(item->name, name) == 0)
            return item;
        while (item->children != NULL) {
            stack[++top] = item->children;
            item = item->next;
        }
    }
    return NULL;
}

Java:
public static Control findControl(Control root, String name) {
  if (root == null) {
    throw new IllegalArgumentException("root cannot be null");
  }
  Stack<Control> stack = new Stack<>();
  stack.push(root);
  while (!stack.isEmpty()) {
    Control item = stack.pop();
    if (item.getName().equals(name)) {
      return item;
    }
    for (Control child : item.getControls()) {
      stack.push(child);
    }
  }
  return null;
}

