#input 
public void Enqueue (T item) {
    if (queue.Contains (item)) {
        queue.Remove (item);
    }
    queue.Add (item);
    while (queue.Count > maximumSize) {
        Dequeue ();
    }
}


#====================
#gpt output=============

#Python: 
def enqueue(item):
    if item in queue:
        queue.remove(item)
    queue.append(item)
    while len(queue) > maximum_size:
        queue.pop(0)

#C:
void enqueue(T item) {
    if(item_exists(queue, item)) {
        remove_item(queue, item);
    }
    add_item(queue, item);
    if (size_of_queue(queue) > maximumSize) {
        dequeue();
    }
}

#Java:
public void enqueue(T item) {
    if (queue.contains(item)) {
        queue.remove(item);
    }
    queue.add(item);
    while (queue.size() > maximumSize) {
        dequeue();
    }
}

