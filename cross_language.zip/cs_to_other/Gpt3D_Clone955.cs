#input 
private Point GetLocationRelativeToForm (Control c) {
    Point controlLocationRelativeToForm1 = new Point ();
    Control currentControl = c;
    while (currentControl.Parent != null) {
        controlLocationRelativeToForm1.Offset (currentControl.Left, currentControl.Top);
        currentControl = currentControl.Parent;
    }
    Point controlScreenPoint = c.PointToScreen (Point.Empty);
    Point formScreenPoint = PointToScreen (Point.Empty);
    Point controlLocationRelativeToForm2 = controlScreenPoint - new Size (formScreenPoint);
    Point locationOnForm = c.FindForm ().PointToClient (c.Parent.PointToScreen (c.Location));
    Debug.Assert (controlLocationRelativeToForm1 == controlLocationRelativeToForm2);
    Debug.Assert (locationOnForm == controlLocationRelativeToForm1);
    Debug.Assert (locationOnForm == controlLocationRelativeToForm2);
    return controlLocationRelativeToForm1;
}


#====================
#gpt output=============

Python:
def get_location_relative_to_form(control):
    control_location_relative_to_form1 = (0, 0)
    current_control = control
    while current_control.parent is not None:
        control_location_relative_to_form1[0] += current_control.left
        control_location_relative_to_form1[1] += current_control.top
        current_control = current_control.parent
    control_screen_point = control.point_to_screen((0,0))
    form_screen_point = point_to_screen((0,0))
    control_location_relative_to_form2 = (control_screen_point[0] - form_screen_point[0], control_screen_point[1] - form_screen_point[1])
    location_on_form = current_control.find_form().point_to_client(control.parent.point_to_screen(control.location))
    assert control_location_relative_to_form1 == control_location_relative_to_form2
    assert location_on_form == control_location_relative_to_form1
    assert location_on_form == control_location_relative_to_form2
    return control_location_relative_to_form1


C:
Point get_location_relative_to_form(Control* c) {
    Point control_location_relative_to_form1 = {0, 0};
    Control* current_control = c;
    while (current_control->parent != NULL) {
        control_location_relative_to_form1.x += current_control->left;
        control_location_relative_to_form1.y += current_control->top;
        current_control = current_control->parent;
    }
    Point control_screen_point = c->point_to_screen(Point.empty);
    Point form_screen_point = point_to_screen(Point.empty);
    Point control_location_relative_to_form2 = {
        control_screen_point.x - form_screen_point.x,
        control_screen_point.y - form_screen_point.y
    };
    Point location_on_form = current_control->find_form()->point_to_client(c->parent->point_to_screen(c->location));
    
    assert(control_location_relative_to_form1.x == control_location_relative_to_form2.x && control_location_relative_to_form1.y == control_location_relative_to_form2.y);
    assert(location_on_form.x == control_location_relative_to_form1.x && location_on_form.y == control_location_relative_to_form1.y);
    assert(location_on_form.x == control_location_relative_to_form2.x && location_on_form.y == control_location_relative_to_form2.y);
    
    return control_location_relative_to_form1;
}


Java:
public static Point getLocationRelativeToForm(Control c) {
    Point controlLocationRelativeToForm1 = new Point(0, 0);
    Control currentControl = c;
    while (currentControl.getParent() != null) {
        controlLocationRelativeToForm1.x += currentControl.getLeft();
        controlLocationRelativeToForm1.y += currentControl.getTop();
        currentControl = currentControl.getParent();
    }
    Point controlScreenPoint = c.getPointToScreen(Point.empty);
    Point formScreenPoint = getPointToScreen(Point.empty);
    Point controlLocationRelativeToForm2 = new Point(
            controlScreenPoint.x - formScreenPoint.x,
            controlScreenPoint.y - formScreenPoint.y
    );
    Point locationOnForm = currentControl.findForm().getPointToClient(c.getParent().getPointToScreen(c.getLocation()));

    assert controlLocationRelativeToForm1.x == controlLocationRelativeToForm2.x && controlLocationRelativeToForm1.y == controlLocationRelativeToForm2.y;
    assert locationOnForm.x == controlLocationRelativeToForm1.x && locationOnForm.y == controlLocationRelativeToForm1.y;
    assert locationOnForm.x == controlLocationRelativeToForm2.x && locationOnForm.y == controlLocationRelativeToForm2.y;

    return controlLocationRelativeToForm1;
}

