#input 
private TreeNode findValueStartingAtNode (TreeNode node, IComparable value) {
    Console.WriteLine ("looking for value {0}", value);
    if (node == null) {
        Console.WriteLine ("node is null -- returning null");
        return null;
    } else if (value.CompareTo (node.data) == 0) {
        Console.WriteLine ("value found at current node");
        Console.WriteLine ("current node data is {0}", node.data);
        Console.WriteLine ("done and returning node");
        return node;
    } else {
        Console.WriteLine ("checking left child");
        TreeNode left = findValueStartingAtNode (node.left_child, value);
        if (left != null)
            return left;
        Console.WriteLine ("checking right child");
        TreeNode right = findValueStartingAtNode (node.right_child, value);
        if (right != null)
            return right;
        Console.WriteLine ("value not found in either child");
        Console.WriteLine ("current node data is {0}", node.data);
        return null;
    }
}


#====================
#gpt output=============

// Python:
def findValueStartingAtNode(node, value):
    print("Looking for value " + str(value))
    if node == None:
        print("node is null-- returning null")
        return None
    elif value == node.data:
        print("value found at current node")
        print("Current node data is " + str(node.data))
        print("Done and returning node")
        return node
    else:
        print("Checking left child")
        left = findValueStartingAtNode(node.left_child, value)
        if left != None:
            return left
        print("Checking right child")
        right = findValueStartingAtNode(node.right_child, value)
        if right != None:
            return right
        print("Value not found in either a child")
        print("Current node data is " + str(node.data))
        return None
        

// Java:
public TreeNode findValueStartingAtNode(TreeNode node, Comparable value){
    System.out.println("Looking for value " + value);
    if(node == null){
        System.out.println("Node is null -- returning null");
        return null;
    } else if (value.compareTo(node.data) == 0){
        System.out.println("Value found at current node");
        System.out.println("Current node data is " + node.data);
        System.out.println("Done and returning node");
        return node;
    } else{
        System.out.println("Checking left child");
        TreeNode left = findValueStartingAtNode(node.left_child, value);
        if(left != null)
            return left;
        System.out.println("Checking right child");
        TreeNode right = findValueStartingAtNode(node.right_child, value);
        if(right != null)
            return right;
        System.out.println("Value not found in either child");
        System.out.println("Current node data is "+ node.data);
        return null;
    }
}


// C:
TreeNode findValueStartingAtNode(TreeNode* node, comparable value){
    printf ("Looking for value %d \n", value);
    if (node == NULL) {
        printf ("Node is null -- returning null \n");
        return NULL;
    } else if (value == node->data) {
        printf ("Value found at current node \n");
        printf ("Current node data is %d \n", node->data);
        printf ("Done and returning node \n");
        return node;
    } else {
        printf ("Checking left child \n");
        TreeNode* left = findValueStartingAtNode(node->left_child, value);
        if (left != NULL)
            return left;
        printf ("Checking right child \n");
        TreeNode* right = findValueStartingAtNode(node->right_child, value);
        if (right != NULL)
            return right;
        printf ("Value not found in either child \n");
        printf ("Current node data is %d \n", node->data);
        return NULL;
    }
}

