#input 
public static void Main () {
    int a = 1234;
    int b = 4321;
    Console.WriteLine ("Before: a {0} and b {1}", a, b);
    b = b - a;
    a = a + b;
    b = a - b;
    Console.WriteLine ("After: a {0} and b {1}", a, b);
}


#====================
#gpt output=============

Python
a = 1234
b = 4321
print("Before: a {0} and b {1}".format(a, b))
b = b - a
a = a + b
b = a - b
print("After: a {0} and b {1}".format(a, b))


C
#include <stdio.h>

int main() {
    int a = 1234;
    int b = 4321;
    printf("Before: a %d and b %d\n", a, b);
    b = b - a;
    a = a + b;
    b = a - b;
    printf("After: a %d and b %d\n", a, b);
    return 0;
}


Java
public static void main(String[] args) {
    int a = 1234;
    int b = 4321;
    System.out.println("Before: a " + a +" and b " + b);
    b = b - a;
    a = a + b;
    b = a - b;
    System.out.println("After: a " + a +" and b " + b);

}

