#input 
void OnShapeBrushChanged () {
    Brush rtn = default (Brush);
    for (int i = 0; i < ShapeChildren.Count; i ++) {
        Shape shape = ShapeChildren [i];
        if (i == 0) {
            rtn = shape.Fill;
        } else if (rtn != shape.Fill) {
            SetValue (FillDifferentProperty, default (Brush));
        } else
            SetValue (FillDifferentProperty, rtn);
    }
}


#====================
#gpt output=============

Python

def OnShapeBrushChanged():
    rtn = None
    for i in range(len(ShapeChildren)):
        shape = ShapeChildren[i]
        if i == 0:
            rtn = shape.Fill
        elif rtn != shape.Fill:
            SetValue(FillDifferentProperty, None)
        else:
            SetValue(FillDifferentProperty, rtn)
            

C

void OnShapeBrushChanged () {
    Brush rtn = default (Brush);
    for  (int i = 0; i < ShapeChildren.Count; i ++) {
        Shape shape = ShapeChildren [i];
        if (i == 0) {
            rtn = shape.Fill;
        } else if (rtn != shape.Fill) {
            SetValue (FillDifferentProperty, default (Brush));
        } else {
            SetValue (FillDifferentProperty, rtn);
        }
    }
}


Java

public static void OnShapeBrushChanged () {
    Brush rtn = default (Brush);
    for (int i = 0; i < ShapeChildren.count; i ++) {
        Shape shape = ShapeChildren.get(i);
        if (i == 0) {
            rtn = shape.getFill();
        } else if (!rtn.equals(shape.getFill())) {
            SetValue(FillDifferentProperty, default (Brush));
        } else {
            SetValue(FillDifferentProperty, rtn);
        }
    }
}

