#input 
public static IntPtr getHWnd (string title) {
    IntPtr hWnd = FindWindow (null, title);
    BringWindowToTop (hWnd);
    SetActiveWindow (hWnd);
    SetForegroundWindow (hWnd);
    Thread.Sleep (500);
    foreach (Process process in Process.GetProcessesByName ("IExplore")) {
        if (process.MainWindowTitle.ToLower ().Contains (title.ToLower ())) {
            hWnd = process.MainWindowHandle;
            break;
        }
    }
    EnumProc proc = new EnumProc (EnumWindows);
    EnumChildWindows (hWnd, proc, ref hWnd);
    return hWnd;
}


#====================
#gpt output=============

Python implementation:
def getHWnd(title):
    hWnd = pyWin32.FindWindow(None, title)
    pyWin32.BringWindowToTop(hWnd)
    pyWin32.SetActiveWindow(hWnd)
    pyWin32.SetForegroundWindow(hWnd)
    time.sleep(500)
    for process in psutil.process_iter():
        if process.name().lower() == 'iexplore':
            if process.as_dict(attrs=['name', 'MainWindowTitle']).get('MainWindowTitle', '').lower().__contains__(title.lower()):
                hWnd = int(process.as_dict(attrs=['pid', 'name', 'MainWindowHandle']).get('MainWindowHandle', -1))
                break
    cProc = pyWin32.EnumProc(pyWin32.EnumWindows)
    pyWin32.EnumChildWindows(hWnd, cProc, hWnd)
    return hWnd

C implementation:
IntPtr getHWnd(char* title) {
    IntPtr hWnd = FindWindow(NULL, title);
    BringWindowToTop(hWnd);
    SetActiveWindow(hWnd);
    SetForegroundWindow(hWnd);
    Sleep(500);
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 pe = {0};
    if (Process32First(snapshot, &pe)) {
        do {
            if (!stricmp(pe.szExeFile, "IExplore")) {
                if (strstr(pe.szExeFile, title)) {
                    hWnd = pe.th32ProcessID;
                    break;
                }
            }
        } while (Process32Next(snapshot, &pe));
    }
    CloseHandle(snapshot);
    EnumProc proc;
    proc.lpEnumFunc = EnumWindows;
    EnumChildWindows(hWnd, &proc, &hWnd);
    return hWnd;
}

Java implementation:
public static IntPtr getHWnd (String title) {
    IntPtr hWnd = FindWindow(null, title);
    BringWindowToTop(hWnd);
    SetActiveWindow(hWnd);
    SetForegroundWindow(hWnd);
    Thread.sleep(500);
    for (Process process : Process.getProcessesByName("IExplore")) {
        if (process.MainWindowTitle.toLowerCase().contains(title.toLowerCase())) {
            hWnd = process.MainWindowHandle;
            break;
        }
    }
    EnumProc proc = new EnumProc(EnumWindows);
    EnumChildWindows(hWnd, proc, hWnd);
    return hWnd;
}

