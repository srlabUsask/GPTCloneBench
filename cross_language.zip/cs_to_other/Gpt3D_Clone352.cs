#input 
public override void WellKnownBinary (Stream sout) {
    byte order = BitConverter.IsLittleEndian ? (byte) 1 : (byte) 0;
    sout.WriteByte (order);
    sout.Write (GeoBase.MultiPointWkbs, 0, 4);
    sout.Write (BitConverter.GetBytes (this.Points.Count), 0, 4);
    foreach (var point in this.Points) {
        sout.WriteByte (order);
        sout.Write (GeoBase.PointWkbs, 0, 4);
        point.WellKnownBinary (sout);
    }
}


#====================
#gpt output=============

Python:

def WellKnownBinary (sout): 
    order = 1 if BitConverter.IsLittleEndian else 0 
    sout.WriteByte (order)
    sout.Write (GeoBase.MultiPointWkbs, 0, 4)
    sout.Write (BitConverter.GetBytes (this.Points.Count), 0, 4)

    for point in this.Points: 
        sout.WriteByte (order)
        sout.Write (GeoBase.PointWkbs, 0, 4)
        point.WellKnownBinary (sout)

C:

void WellKnownBinary (Stream *sout) { 
    byte order = BitConverter.IsLittleEndian ? (byte) 1 : (byte) 0;
    sout->WriteByte (order);
    sout->Write (GeoBase.MultiPointWkbs, 0, 4);
    sout->Write (BitConverter.GetBytes (this.Points.Count), 0, 4);
    
    for (int i = 0; i < this.Point.Count; i++) {
        var point = this.Points[i];
        sout->WriteByte (order);
        sout->Write (GeoBase.PointWkbs, 0, 4);
        point.WellKnownBinary(sout);
    }
}

Java:

public void WellKnownBinary (Stream sout) { 
    byte order = BitConverter.IsLittleEndian ? (byte) 1 : (byte) 0;
    sout.WriteByte (order);
    sout.Write (GeoBase.MultiPointWkbs, 0, 4);
    sout.Write (BitConverter.GetBytes (this.Points.Count), 0, 4);
    
    for (Point point : this.Points) {
        sout.WriteByte (order);
        sout.Write (GeoBase.PointWkbs, 0, 4);
        point.WellKnownBinary(sout);
    }
}

