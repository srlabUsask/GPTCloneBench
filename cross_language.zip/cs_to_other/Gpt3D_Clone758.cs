#input 
static Dictionary < string, object > NvcToDictionary (NameValueCollection nvc, bool handleMultipleValuesPerKey) {
    var result = new Dictionary < string, object > ();
    foreach (string key in nvc.Keys) {
        if (handleMultipleValuesPerKey) {
            string [] values = nvc.GetValues (key);
            if (values.Length == 1) {
                result.Add (key, values [0]);
            } else {
                result.Add (key, values);
            }
        } else {
            result.Add (key, nvc [key]);
        }
    }
    return result;
}


#====================
#gpt output=============

Python:
def nvc_to_dictionary(nvc, handle_multiple_values_per_key):
    result = {}
    for key in nvc.keys():
        if handle_multiple_values_per_key:
            values = nvc.get_values(key)
            if len(values) == 1:
                result[key] = values[0]
            else:
                result[key] = values
        else:
            result[key] = nvc[key]
    return result

C:
Dictionary* NvcToDictionary(NameValueCollection* nvc, bool handleMultipleValuesPerKey) {
    Dictionary *result = CreateDictionary();
    foreach (NameValueEntry* entry in nvc) {
        if (handleMultipleValuesPerKey) {
            NameValueEntry** values = nvc->getValues(entry->key);
            int length = nvc-> getValuesCount(entry->key);
            if (length == 1)
                AddToDictionary(result, entry->key, *values[0]);
            else
                AddToDictionary(result, entry->key, (void*)values);
        } else {
            AddToDictionary(result, entry->key, entry->value);
        }
    }
    return result;
}

Java:
public static Map<String, Object> nvcToDictionary(NameValueCollection nvc, boolean handleMultipleValuesPerKey) {
    Map<String, Object> result = new HashMap<>();
    for (String key : nvc.keySet()) {
        if (handleMultipleValuesPerKey) {
            String[] values = nvc.getValues(key);
            if (values.length == 1)
                result.put(key, values[0]);
            else 
                result.put(key, values);
        } else {
            result.put(key, nvc.get(key));
        }
    }
    return result;
}

