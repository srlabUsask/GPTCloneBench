#input 
public static void Rename (this FileSystemInfo item, string newName) {
    if (item == null) {
        throw new ArgumentNullException ("item");
    }
    FileInfo fileInfo = item as FileInfo;
    if (fileInfo != null) {
        fileInfo.Rename (newName);
        return;
    }
    DirectoryInfo directoryInfo = item as DirectoryInfo;
    if (directoryInfo != null) {
        directoryInfo.Rename (newName);
        return;
    }
    throw new ArgumentException ("Item", "Unexpected subclass of FileSystemInfo " + item.GetType ());
}


#====================
#gpt output=============

Python:
def rename(self, item, new_name):
    if item is None:
        raise ArgumentNullException("item")
    if isinstance(item, FileInfo):
        item.rename(new_name)
    elif isinstance(item, DirectoryInfo):
        item.rename(new_name)
    else:
        raise ArgumentException("Item", 
            "Unexpected subclass of FileSystemInfo " + item.GetType())


C:
void Rename(FileSystemInfo *item, char *newName){
    if (item==NULL){
        throw ArgumentNullException("item");
    }
    FileInfo *fileInfo = (FileInfo*)item;
    if (fileInfo!=NULL){
        fileInfo->Rename(newName);
        return;
    }
    DirectoryInfo *directoryInfo = (DirectoryInfo*)item;
    if (directoryInfo!=NULL){
        directoryInfo->Rename(newName);
        return;
    }
    throw ArgumentException("Item", "Unexpected subclass of FileSystemInfo %s",item->GetType());
} 


Java:
public static void rename(FileSystemInfo item, String newName) 
{ 
    if (item == null) 
    { 
        throw new ArgumentNullException("item"); 
    } 
    if (item instanceof FileInfo) 
    { 
        ((FileInfo)item).rename(newName); 
        return; 
    } 
    if (item instanceof DirectoryInfo) 
    { 
        ((DirectoryInfo)item).rename(newName); 
        return; 
    } 
    throw new ArgumentException("Item", 
             "Unexpected subclass of FileSystemInfo " + item.getClass().toString()); 
}

