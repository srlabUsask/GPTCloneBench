#input 
public string ShrinkPath (string path, int maxLength) {
    List < string > parts = new List < string > (path.Split ('\\'));
    string start = parts [0] + @"\" + parts [1];
    parts.RemoveAt (1);
    parts.RemoveAt (0);
    string end = parts [parts.Count - 1];
    parts.RemoveAt (parts.Count - 1);
    parts.Insert (0, "...");
    while (parts.Count > 1 && start.Length + end.Length + parts.Sum (p = > p.Length) + parts.Count > maxLength)
        parts.RemoveAt (parts.Count - 1);
    string mid = "";
    parts.ForEach (p = > mid += p + @"\");
    return start + mid + end;
}


#====================
#gpt output=============

Python: 
def ShrinkPath(path, maxLength): 
  parts = path.split('\\') 
  start = parts[0] + '\\' + parts[1] 
  del parts[1] 
  del parts[0] 
  end = parts[len(parts)-1] 
  del parts[len(parts)-1] 
  parts.insert(0, '...') 
  while len(parts) > 1 and (len(start) + len(end) + len(parts) + 
  sum(len(p) for p in parts)) > maxLength: 
    del parts[len(parts)-1] 
  mid = '' 
  for p in parts: 
    mid += p + '\\' 
  return start + mid + end 

C: 
char* ShrinkPath(char* path, int maxLength){
  char** parts = malloc(sizeof(char*)*100); // Assuming max number of parts are 100
  int partsCount = 0;
  char* part = strtok (path,"\\");
  while (part != NULL)
  {
  	parts[partsCount++] = part;
  	part = strtok (NULL, "\\");
  }
  char* start = malloc(strlen(parts[0]) + strlen(parts[1]) + 2); // +2 for extra \ and \0
  sprintf(start, "%s\\%s", parts[0], parts[1]);
  char* end = parts[partsCount-1];
  // Shrinking the parts which are in the middle
  int i;
  for (i=1; i<partsCount-1; i++){
  	strcat(start, parts[i]);
  	strcat(start, "\\");
  	if(strlen(start) + strlen(end) >= maxLength)
  		break;
  }
  strcat(start, "...");
  char* mid = malloc(strlen(start) + strlen(end) + 1);
  i++;
  for(; i<partsCount-1; i++) {
  	strcat(mid, parts[i]);
  	strcat(mid, "\\");
  }
  strcat(mid, end);
  strcat(start, mid);
  return start;
}

Java:
public static String shrinkPath(String path, int maxLength){
  String[] parts = path.split("\\\\");
  String start = parts[0] + "\\" + parts[1];
  parts = Arrays.copyOfRange(parts, 2, parts.length-1);
  String end = parts[parts.length-1];
  parts[0] = "...";
  
  while(start.length() + end.length() + Arrays.stream(parts).mapToInt(String::length).sum() + parts.length > maxLength){
    parts = Arrays.copyOfRange(parts, 0, parts.length-1);
  }
  
  String mid = Arrays.stream(parts).collect(Collectors.joining("\\"));
  
  return start + mid + end;
}

