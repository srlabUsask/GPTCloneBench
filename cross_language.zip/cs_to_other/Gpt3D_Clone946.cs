#input 
static String findFirstKeyByValue (Dictionary < string, string > Data_Array, String value) {
    if (Data_Array.ContainsValue (value)) {
        foreach (String key in Data_Array.Keys) {
            if (Data_Array [key].Equals (value))
                return key;
        }
    }
    return null;
}


#====================
#gpt output=============

Python:
def findFirstKeyByValue(data_array, value):
    if value in data_array.values():
        for k in data_array.keys():
            if data_array[k] == value:
                return k
    return None


C:
char * findFirstKeyByValue(Dictionary* Data_Array, char *value) {
    Node *curr = Data_Array->head;
    while (curr != NULL) {
        if (!strcmp(curr->value, value)) {
            return curr->key;
        }
        curr = curr->next;
    }
    return NULL;
}

Java:
public static String findFirstKeyByValue(Map<String, String> Data_Array, String value) {
    if (Data_Array.containsValue(value)) {
        for (String key : Data_Array.keySet()) {
            if (Data_Array.get(key).equals(value)) {
                return key;
            }
        }
    }
    return null;
}

