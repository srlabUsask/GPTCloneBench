#input 
private static int IndexOfLongestRun (string str) {
    char [] array1 = str.ToCharArray ();
    Comparer comparer = new Comparer ();
    int counter = 1;
    int maxCount = 0;
    int idenxOf = 0;
    int i;
    for (i = 0; i < array1.Length - 1; i ++) {
        if (comparer.Compare (array1 [i], array1 [i + 1]) == 0) {
            counter ++;
        } else {
            if (maxCount < counter) {
                maxCount = counter;
                idenxOf = i - counter + 1;
            }
            counter = 1;
        }
    }
    if (maxCount < counter) {
        maxCount = counter;
        idenxOf = i - counter + 1;
    }
    return idenxOf;
}


#====================
#gpt output=============

Python:

def IndexOfLongestRun(str): 
    array1 = list(str) 
    maxCount = 0
    indexOf = 0
    counter = 1
    for i in range(len(array1)-1): 
        if array1[i] == array1[i+1]: 
            counter += 1
        else: 
            if maxCount < counter: 
                maxCount = counter
                indexOf = i - counter + 1
            counter = 1
    if maxCount < counter: 
        maxCount = counter
        indexOf = i - counter + 1
    return indexOf

C:

static int IndexOfLongestRun (char* str) {
    int counter = 1;
    int maxCount = 0;
    int idenxOf = 0;
    int i;
    for (i = 0; str[i + 1] != '\0'; i ++) {
        if (str[i] == str[i + 1]) {
            counter ++;
        } else {
            if (maxCount < counter) {
                maxCount = counter;
                idenxOf = i - counter + 1;
            }
            counter = 1;
        }
    }
    if (maxCount < counter) {
        maxCount = counter;
        idenxOf = i - counter + 1;
    }
    return idenxOf;
}

Java: 

public static int IndexOfLongestRun (String str) {
    char[] array1 = str.toCharArray ();
    int counter = 1;
    int maxCount = 0;
    int indexOf = 0;
    for (int i = 0; i < array1.length - 1; i ++) {
        if (array1[i] == array1[i + 1]) {
            counter ++;
        } else {
            if (maxCount < counter) {
                maxCount = counter;
                indexOf = i - counter + 1;
            }
            counter = 1;
        }
    }
    if (maxCount < counter) {
        maxCount = counter;
        indexOf = i - counter + 1;
    }
    return indexOf;
}

