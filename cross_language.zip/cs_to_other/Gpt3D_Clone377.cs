#input 
protected override void OnCollectionChanged (NotifyCollectionChangedEventArgs e) {
    if (suppressNotification)
        return;
    base.OnCollectionChanged (e);
    if (CollectionChanged != null) {
        CollectionChanged.Invoke (this, e);
    }
}


#====================
#gpt output=============

Python

def OnCollectionChanged(self, e):
    if self.suppressNotification:
        return
    super().OnCollectionChanged(e)
    if self.CollectionChanged is not None:
        self.CollectionChanged.invoke(self, e)


C

void OnCollectionChanged(struct NotifyCollectionChangedEventArgs* e) {
    if (suppressNotification)
        return;
    base_OnCollectionChanged(e);
    if (CollectionChanged != NULL) {
        (*CollectionChanged)(this, e);
    }
}


Java

@Override
protected void onCollectionChanged(NotifyCollectionChangedEventArgs e) {
    if (suppressNotification)
        return;
    super.onCollectionChanged(e);
    if (collectionChanged != null) {
        collectionChanged.invoke(this, e);
    }
}

