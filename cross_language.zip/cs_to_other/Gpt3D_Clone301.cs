#input 
protected void Button1_Click (object sender, EventArgs e) {
    try {
        using (MySqlCommand SelectCommand = new MySqlCommand ("select count(*) from films.user where user_name=@username AND password = @password", cs))
        {
            SelectCommand.Parameters.AddWithValue ("@username", username.Text);
            SelectCommand.Parameters.AddWithValue ("@password", password.Text);
            cs.Open ();
            int count = (int) SelectCommand.ExecuteScalar ();
            if (count == 1) {
                Response.Write (@"<script language='javascript'>alert('wow your in !!');</script>");
            } else if (count > 1) {
                Response.Write (@"<script language='javascript'>alert('duplicate');</script>");
            } else
                Response.Write (@"<script language='javascript'>alert('wrong password');</script>");
        }}
    catch (Exception ex) {
        Response.Write (@"<script language='javascript'>alert(ex.message);</script>");
    }
}


#====================
#gpt output=============

Python: 
def button1_click():
  try: 
    cs = sql.connect(user=username, password=password, db='films)
    stmt = sql.prepare("SELECT COUNT(*) FROM films.user WHERE user_name=? AND password = ?")
    stmt.execute(username.Text, password.Text)
    count = stmt.fetchone()
    if count == 1:
      response.write("<script language='javascript'>alert('wow your in !!')</script>")
    elif count > 1:
      response.write("<script language='javascript'>alert('duplicate')</script>")
    else:
      response.write("<script language='javascript'>alert('wrong password')</script>")
    cs.close()
  except Exception as ex:
    response.write("<script language='javascript'>alert(" + str(ex.message) + ")</script>")

C: 
void button1_click(){
  try 
  {
    MYSQL *cs = mysql_init(NULL);
    mysql_real_connect(cs, "localhost", username, password, dbname, 0, NULL, 0);  
    char statement[200] = "SELECT COUNT(*) FROM films.user WHERE user_name=@username AND password = @password";
    MYSQL_STMT *selectCommand = mysql_stmt_init(cs);

    mysql_stmt_prepare(selectCommand,statement,strlen(statement));
    MYSQL_BIND *selectBinds = (MYSQL_BIND*)malloc(2*sizeof(MYSQL_BIND));
    
    MYSQL_TYPE selectTypes[] = {MYSQL_TYPE_VAR_STRING,MYSQL_TYPE_VAR_STRING};
    int selectLengths[] = {usernameLen,passwordLen};
    void *selectParameters[] = {(void*)username.Text,(void*)password.Text};
 
    memset(selectBinds, 0, sizeof(selectBinds));

    for (int i = 0; i < 2; i++) 
    {
      selectBinds[i].buffer_type = selectTypes[i];
      selectBinds[i].buffer_length = selectLengths[i];
      selectBinds[i].buffer = selectParameters[i]; 
      selectBinds[i].length = &selectLengths[i];
    }
    
    mysql_stmt_bind_param(selectCommand,selectBinds);
    mysql_stmt_execute(selectCommand);
    int count = 0;
    mysql_stmt_fetch(selectCommand, &count;

    if(count == 1)
    {
      printf("<script language='javascript'>alert('wow your in !!');</script>")
    } 
    else if(count > 1)
    {
      printf("<script language='javascript'>alert('duplicate');</script>")
    }
    else 
    {
      printf("<script language='javascript'>alert('wrong password');</script>")
    }

    free(selectBinds);
    mysql_stmt_close(selectCommand);
    mysql_close(cs);
  } 
  catch (MYSQL_STMT *ex)
  {
    printf("<script language='javascript'>alert(%s);</script>",mysql_stmt_error(ex)));
  }
}

Java: 
protected void Button1_Click (Object sender, EventArgs e) {
    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/films", user, password);

        Statement statement = conn.createStatement();
        String query = "select count(*) from films.user where user_name=? AND password = ?";

        PreparedStatement selectStmt = conn.prepareStatement(query);

        selectStmt.setString(1, username.Text);
        selectStmt.setString(2, password.Text);

        int count = selectStmt.executeQuery();

        if (count == 1) {
            Response.Write("<script language='javascript'>alert('wow your in !!');</script>");
        } else if (count > 1) {
            Response.Write("<script language='javascript'>alert('duplicate');</script>");
        } else
            Response.Write("<script language='javascript'>alert('wrong password');</script>");
    } catch (SQLException ex) {
        Response.Write("<script language='javascript'>alert(" + ex.getMessage() + ");</script>");
    }
}

