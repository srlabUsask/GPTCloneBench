#input 
public void TestList () {
    cvList.Add (new ColumnAndValue () {ColumnName = "Column 1", ColumnValue = "Value 1"});
    cvList.Add (new ColumnAndValue () {ColumnName = "Column 2", ColumnValue = "Value 2"});
    cvList.Add (new ColumnAndValue () {ColumnName = "Column 3", ColumnValue = "Value 3"});
    cvList.Add (new ColumnAndValue () {ColumnName = "Column 4", ColumnValue = "Value 4"});
    List < string > c1 = cvList.Select (c = > c.ColumnName).ToList ();
    foreach (object obj in c1) {
        Console.WriteLine (obj.ToString ());
    }
}


#====================
#gpt output=============

Python:
def test_list():
    cv_list = []
    cv_list.append({"ColumnName": "Column 1", "ColumnValue": "Value 1"})
    cv_list.append({"ColumnName": "Column 2", "ColumnValue": "Value 2"})
    cv_list.append({"ColumnName": "Column 3", "ColumnValue": "Value 3"})
    cv_list.append({"ColumnName": "Column 4", "ColumnValue": "Value 4"})
    c1 = [c['ColumnName'] for c in cv_list]
    for obj in c1:
        print(obj)

C: 
void TestList(){
   cvList *list;
   cvList_new(&list);
   cvList_add(list, "Column 1", "Value 1");
   cvList_add(list, "Column 2", "Value 2");
   cvList_add(list, "Column 3", "Value 3");
   cvList_add(list, "Column 4", "Value 4");
   cvList_Map *map = cvList_newMap(list);
   for(int i = 0; i<map->length; i++){
        printf("%s\n", map->columns[i]);
   }
   cvList_free(list);
   cvList_freeMap(map);
}

Java:
public void testList() {
    List<ColumnAndValue> cvList = new ArrayList<>();
    cvList.add(new ColumnAndValue("Column 1", "Value 1"));
    cvList.add(new ColumnAndValue("Column 2", "Value 2"));
    cvList.add(new ColumnAndValue("Column 3", "Value 3"));
    cvList.add(new ColumnAndValue("Column 4", "Value 4"));
    List<String> c1 = cvList.stream().map(c -> c.getColumnName()).collect(Collectors.toList());
    for (Object obj : c1) {
        System.out.println(obj.toString());
    }
}

