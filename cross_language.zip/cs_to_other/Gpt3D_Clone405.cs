#input 
static void Main (string [] args) {
    Console.WriteLine ("Start notepad and hit any key...");
    Console.ReadKey (true);
    Process [] processes = Process.GetProcessesByName ("notepad");
    foreach (Process p in processes) {
        var handle = p.MainWindowHandle;
        SetWindowPos (handle, new IntPtr (SpecialWindowHandles.HWND_TOP), 10, 10, 450, 450, SetWindowPosFlags.SWP_SHOWWINDOW);
        break;
    }
}


#====================
#gpt output=============


Python:
import win32gui
import win32process
import win32con

def main(args):
 print("Start notepad and hit any key...")
 input() 
 
 processes = win32process.EnumProcesses()
 for pid in processes:
  try:
   hwnd = win32gui.FindWindow(None, 'notepad')
   win32gui.SetWindowPos(hwnd, win32con.HWND_TOP, 10, 10, 450, 450, win32con.SWP_SHOWWINDOW)
   break
  except:
   pass
 
if __name__ == '__main__':
 main(None)



Java:
import java.awt.Rectangle;
import java.awt.Robot;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Start notepad and hit any key...");
        new Scanner(System.in).nextLine();
        Robot robot = null;
        try {
            robot = new Robot();
            for (String process : ProcessHandle.allProcesses()) {
                if (process.contains("notepad")) {
                    Rectangle rect = new Rectangle(10, 10, 450, 450);
                    robot.setWindowBounds(rect);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



C:
#include <stdio.h>
#include <windows.h> 
#include <psapi.h>

int main(int argc, char *argv[])
{

    printf("Start notepad and hit any key...\n");
    getchar();

    DWORD pids[1024], cbNeeded, cProcesses;
    char szProcessName[MAX_PATH] = TEXT("");

    if (EnumProcesses(pids, sizeof(pids), &cbNeeded))
    {          
        cProcesses = cbNeeded / sizeof(DWORD);

        for (int i = 0; i < cProcesses; i++)
        {
            HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pids[i]);

            if (NULL != hProcess)
            {
                HMODULE hMod;
                DWORD cbNeeded;

                if (EnumProcessModules(hProcess, &hMod, sizeof(hMod), &cbNeeded))
                {
                    GetModuleBaseNameA(hProcess, hMod, szProcessName, sizeof(szProcessName) / sizeof(TCHAR));

                    if (strcmp(szProcessName, "notepad.exe") == 0)
                    {
                        SetWindowPos(hProcess, NULL, 10, 10, 450, 450, SWP_SHOWWINDOW);
                        break;
                    }
                }
            }
        }
    }
    return 0;
}

