#input 
protected override void OnCreate (Bundle bundle) {
    base.OnCreate (bundle);
    SetContentView (Resource.Layout.splashscreen);
    new Thread (new ThreadStart (() = > {
        Thread.Sleep (1500);
        Intent main = new Intent (this, typeof (MainActivity));
        this.StartActivity (main);
        this.Finish ();
    })).Start ();
}


#====================
#gpt output=============

Python:
def onCreate(self, bundle):
    super().onCreate(bundle) 
    self.setContentView(Resource.Layout.splashscreen)
    thread = threading.Thread(target=self.run_in_background)
    thread.start()

def run_in_background(self): 
    time.sleep(1500)
    main_activity = Intent(self, MainActivity)
    self.startActivity(main_activity)
    self.finish()

C:
void OnCreate(Bundle bundle)
{
    Base_OnCreate(bundle);
    SetContentView(Resource.Layout.splashscreen);
    pthread_t myThread;
    pthread_create( &myThread, NULL, StartActivity, (void*) this);
}

void* StartActivity(void* arg)
{
    wait(1500);
    Intent main = new Intent(arg, typeof(MainActivity));
    ((Activity*)arg)->startActivity(main);
    ((Activity*)arg)->finish();
}

Java:
@Override
protected void onCreate(Bundle bundle) {
    super.onCreate(bundle);
    setContentView(Resource.Layout.splashscreen);
    Thread t = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
              Thread.sleep(1500);
            } catch(InterruptedException e) {
                e.printStackTrace();
            }

            Intent main = new Intent(this, MainActivity.class);
            startActivity(main);
            finish();
        }
    });
    t.start();
}

