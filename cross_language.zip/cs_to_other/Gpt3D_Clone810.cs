#input 
[TestMethod ()] public void SortTest () {
    TupleList < int, string > list = new TupleList < int, string > ();
    list.Add (1, "cat");
    list.Add (1, "car");
    list.Add (2, "dog");
    list.Add (2, "door");
    list.Add (3, "elephant");
    list.Add (1, "coconut");
    list.Add (1, "cab");
    list.Sort ();
    foreach (Tuple < int, string > tuple in list) {
        Console.WriteLine (string.Format ("{0}:{1}", tuple.Item1, tuple.Item2));
    }
    int expected_first = 1;
    int expected_last = 3;
    int first = list.First ().Item1;
    int last = list.Last ().Item1;
    Assert.AreEqual (expected_first, first);
    Assert.AreEqual (expected_last, last);
}


#====================
#gpt output=============

Python: 
def sort_test():
    list = []
    list.append((1, "cat"))
    list.append((1, "car"))
    list.append((2, "dog"))
    list.append((2, "door"))
    list.append((3, "elephant"))
    list.append((1, "coconut"))
    list.append((1, "cab"))
    list.sort()
    for tuple in list:
        print(str(tuple[0]) + ":" + tuple[1])
    expected_first = 1
    expected_last = 3
    first = list[0][0]
    last = list[-1][0]
    assert expected_first == first
    assert expected_last == last

C: 
void SortTest() {
    TupleList *list = tupleList_create();
    tupleList_append(list, 1, "cat");
    tupleList_append(list, 1, "car");
    tupleList_append(list, 2, "dog");
    tupleList_append(list, 2, "door");
    tupleList_append(list, 3, "elephant");
    tupleList_append(list, 1, "coconut");
    tupleList_append(list, 1, "cab");
    tupleList_sort(list);
    for (int i = 0; i < list->size; i++) {
        Tuple *tuple = list->tuples[i];
        printf("%d:%s\n", tuple->item1, tuple->item2);
    }
    int expected_first = 1;
    int expected_last = 3;
    int first = list->tuples[0]->item1;
    int last = list->tuples[list->size - 1]->item1;
    assert(expected_first == first);
    assert(expected_last == last);
}

Java: 
@Test
public void sortTest() {
    TupleList<Integer, String> list = new TupleList<>();
    list.add(1, "cat");
    list.add(1, "car");
    list.add(2, "dog");
    list.add(2, "door");
    list.add(3, "elephant");
    list.add(1, "coconut");
    list.add(1, "cab");
    list.sort();
    for (Tuple<Integer, String> tuple: list) {
        System.out.println(tuple.item1 + ":" + tuple.item2);
    }
    int expected_first = 1;
    int expected_last = 3;
    int first = list.get(0).item1;
    int last = list.get(list.size() - 1).item1;
    assertEquals(expected_first, first);
    assertEquals(expected_last, last);
}

