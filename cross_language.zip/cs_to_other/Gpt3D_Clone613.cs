#input 
public bool UrlIsValid (string url) {
    try {
        HttpWebRequest request = HttpWebRequest.Create (url) as HttpWebRequest;
        request.Timeout = 5000;
        request.Method = "HEAD";
        using (HttpWebResponse response = request.GetResponse () as HttpWebResponse)
        {
            int statusCode = (int) response.StatusCode;
            if (statusCode >= 100 && statusCode < 400) {
                return true;
            } else if (statusCode >= 500 && statusCode <= 510) {
                Debug.WriteLine (String.Format ("The remote server has thrown an internal error. Url is not valid: {0}", url));
                return false;
            }
        }}
    catch (WebException ex) {
        if (ex.Status == WebExceptionStatus.ProtocolError) {
            return false;
        } else {
            log.Warn (String.Format ("Unhandled status [{0}] returned for url: {1}", ex.Status, url), ex);
        }
    }
    catch (Exception ex) {
        log.Error (String.Format ("Could not test url {0}.", url), ex);
    }
    return false;
}


#====================
#gpt output=============

Python: 
def UrlIsValid(url):
  try:
    request = urllib.request.Request(url)
    request.timeout = 5000
    request.method = "HEAD"
    response = urllib.request.urlopen(request)
    statusCode = response.getcode() 
    if statusCode >= 100 and statusCode <400:
       return True
    elif statusCode >= 500 and statusCode <=510:
       print("The remote server has thrown an internal error. Url is not valid" + url)
       return False
   except urllib.error.HTTPError as e:
     print("Unhandled status " + str(e.status) + " returned for url: "+ url)
     return False
   except Exception as e:
    print("Could not test url " + url, e)
    return False

C: 
bool UrlIsValid (char* url) {
  CURL* curl;
  CURLcode result;
  long response_code;
  
  curl = curl_easy_init();
  if(curl) {
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, 5000);
    curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
   
    result = curl_easy_perform(curl);
    if(result == CURLE_OK) {
      result = curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
      if ((response_code >= 100) && (response_code < 400)) {
        return true;
      } else if ((response_code >= 500) && (response_code <= 510)) {
        printf("The remote server has thrown an internal error. Url is not valid: %s\n", url);
        return false;
      }
    } else {
      printf("Could not test url %s.\n", url);
      return false;
    }
  }
  
  curl_easy_cleanup(curl);
 
  return false;
} 

Java: 
public static boolean urlIsValid(String url) {
   try {
      URL u = new URL(url);
      HttpURLConnection huc = (HttpURLConnection) u.openConnection();
      huc.setRequestMethod("HEAD");
      huc.setConnectTimeout(5000);
      int statusCode = huc.getResponseCode();

      if(statusCode >= 100 && statusCode < 400) {
         return true;
      } else if (statusCode >= 500 && statusCode <= 510) {
         System.out.println("The remote server has thrown an internal error. Url is not valid: " + url);
         return false;
      }
    } catch (MalformedURLException e) {
      System.out.println(String.format("Unhandled status [%s] returned for url: %s", e.getMessage(), url));
      return false;
    } catch (IOException e) {
      System.out.println(String.format("Could not test url %s.", url));
      e.printStackTrace();
      return false;
    }

    return false;
  }

